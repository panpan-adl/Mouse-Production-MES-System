-- MySQL dump 10.13  Distrib 8.3.0, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mouse_mes_completion_test_20261024_095632
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mm_ai_budget`
--

DROP TABLE IF EXISTS `mm_ai_budget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_ai_budget` (
  `user_id` bigint NOT NULL,
  `day` date NOT NULL,
  `calls` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`,`day`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_ai_budget`
--

LOCK TABLES `mm_ai_budget` WRITE;
/*!40000 ALTER TABLE `mm_ai_budget` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_ai_budget` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_ai_session`
--

DROP TABLE IF EXISTS `mm_ai_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_ai_session` (
  `id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` bigint NOT NULL,
  `filters` json NOT NULL,
  `revision` int NOT NULL DEFAULT '0',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_ai_session`
--

LOCK TABLES `mm_ai_session` WRITE;
/*!40000 ALTER TABLE `mm_ai_session` DISABLE KEYS */;
INSERT INTO `mm_ai_session` (`id`, `user_id`, `filters`, `revision`, `updated_at`) VALUES ('2a1e9996-b2b1-4c5b-b82a-e7fd1fda5fad',1,'{\"kind\": \"INVENTORY\", \"material\": \"5\"}',1,'2026-10-23 23:35:17');
INSERT INTO `mm_ai_session` (`id`, `user_id`, `filters`, `revision`, `updated_at`) VALUES ('7ba9a8a9-d4e8-4c7b-9b69-148b09245174',1,'{\"to\": \"2026-10-23\", \"from\": \"2026-10-01\", \"kind\": \"INVENTORY\", \"material\": \"5\"}',1,'2026-10-23 23:24:51');
/*!40000 ALTER TABLE `mm_ai_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_area`
--

DROP TABLE IF EXISTS `mm_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_area` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `warehouse_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_area`
--

LOCK TABLES `mm_area` WRITE;
/*!40000 ALTER TABLE `mm_area` DISABLE KEYS */;
INSERT INTO `mm_area` (`id`, `code`, `name`, `warehouse_id`, `created_at`) VALUES (1,'WH-A100-RM-A','默认库区',2,'2026-10-19 00:41:54');
INSERT INTO `mm_area` (`id`, `code`, `name`, `warehouse_id`, `created_at`) VALUES (2,'WH-A100-LINE-A','默认库区',3,'2026-10-19 00:41:54');
INSERT INTO `mm_area` (`id`, `code`, `name`, `warehouse_id`, `created_at`) VALUES (3,'WH-A100-FG-A','默认库区',4,'2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_audit`
--

DROP TABLE IF EXISTS `mm_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_audit` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `actor_id` bigint NOT NULL,
  `resource` varchar(60) NOT NULL,
  `action` varchar(30) NOT NULL,
  `record_id` bigint DEFAULT NULL,
  `details` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_audit`
--

LOCK TABLES `mm_audit` WRITE;
/*!40000 ALTER TABLE `mm_audit` DISABLE KEYS */;
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (1,1,'units','SAVE',8,NULL,'2026-10-24 01:56:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (2,1,'units','SAVE',9,NULL,'2026-10-24 01:56:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (3,1,'categories','SAVE',1,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (4,1,'categories','SAVE',2,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (5,1,'workshops','SAVE',2,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (6,1,'equipment','SAVE',2,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (7,1,'stations','SAVE',5,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (8,1,'operations','SAVE',1,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (9,1,'operations','SAVE',2,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (10,1,'operations','SAVE',3,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (11,1,'operations','SAVE',4,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (12,1,'qc-items','SAVE',5,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (13,1,'qc-templates','SAVE',4,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (14,1,'qc-lines','SAVE',13,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (15,1,'qc-templates','SAVE',5,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (16,1,'qc-lines','SAVE',14,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (17,1,'qc-templates','SAVE',6,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (18,1,'qc-lines','SAVE',15,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (19,1,'qc-templates','SAVE',7,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (20,1,'qc-lines','SAVE',16,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (21,1,'teams','SAVE',2,NULL,'2026-10-24 01:56:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (22,1,'members','SAVE',2,NULL,'2026-10-24 01:56:50');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (23,1,'schedules','SAVE',1,NULL,'2026-10-24 01:56:50');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (24,1,'work-orders','CREATE',1,NULL,'2026-10-24 01:56:50');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (25,7,'suppliers','SAVE',1,NULL,'2026-10-24 01:56:50');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (26,6,'stock-documents','PURCHASE_RECEIPT',1,NULL,'2026-10-24 01:56:51');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (27,6,'stock-documents','PURCHASE_RECEIPT',2,NULL,'2026-10-24 01:56:52');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (28,6,'fulfillment','ISSUE',1,NULL,'2026-10-24 01:56:53');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (29,6,'stock-documents','LINE_RETURN',3,NULL,'2026-10-24 01:56:54');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (30,6,'stock-documents','LINE_ISSUE',4,NULL,'2026-10-24 01:56:54');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (31,5,'inspections','EXECUTE',1,NULL,'2026-10-24 01:56:54');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (32,5,'inspections','EXECUTE',2,NULL,'2026-10-24 01:56:55');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (33,5,'inspections','EXECUTE',3,NULL,'2026-10-24 01:56:55');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (34,5,'inspections','EXECUTE',4,NULL,'2026-10-24 01:56:55');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (35,5,'inspections','EXECUTE',5,NULL,'2026-10-24 01:56:55');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (36,6,'stock-documents','PRODUCTION_RECEIPT',5,NULL,'2026-10-24 01:56:55');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (37,6,'stock-documents','PRODUCTION_RECEIPT',6,NULL,'2026-10-24 01:56:55');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (38,6,'stock-documents','SALES_SHIPMENT',7,NULL,'2026-10-24 01:56:56');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (39,6,'stock-documents','SALES_SHIPMENT',8,NULL,'2026-10-24 01:56:56');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (40,6,'stock-documents','SALES_RETURN',9,NULL,'2026-10-24 01:56:56');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (41,1,'units','SAVE',10,NULL,'2026-10-24 01:56:57');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (42,6,'stock-documents','PURCHASE_RECEIPT',11,NULL,'2026-10-24 01:56:57');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (43,6,'stock-documents','PURCHASE_RETURN',12,NULL,'2026-10-24 01:56:57');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (44,1,'checks','SAVE',2,NULL,'2026-10-24 01:56:57');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (45,9,'check-records','SAVE',1,NULL,'2026-10-24 01:56:57');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (46,9,'check-records','SAVE',2,NULL,'2026-10-24 01:56:57');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (47,1,'teams','SAVE',3,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (48,1,'members','SAVE',3,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (49,1,'shifts','SAVE',2,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (50,1,'shifts','SAVE',3,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (51,1,'holidays','SAVE',1,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (52,1,'rotations','SAVE',1,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (53,1,'rotation-teams','SAVE',1,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (54,1,'rotation-teams','SAVE',2,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (55,1,'rotation-shifts','SAVE',1,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (56,1,'rotation-shifts','SAVE',2,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (57,1,'schedules','SAVE',2,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (58,1,'schedules','SAVE',3,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (59,1,'sops','SAVE',1,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (60,1,'products','SAVE',7,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (61,1,'mappings','SAVE',2,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (62,1,'bom-versions','SAVE',2,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (63,1,'bom-lines','SAVE',15,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (64,1,'bom-lines','SAVE',16,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (65,1,'bom-lines','SAVE',17,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (66,1,'bom-lines','SAVE',18,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (67,1,'bom-lines','SAVE',19,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (68,1,'routes','SAVE',2,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (69,1,'operations','SAVE',5,NULL,'2026-10-24 01:56:58');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (70,1,'qc-templates','SAVE',8,NULL,'2026-10-24 01:56:59');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (71,1,'qc-lines','SAVE',17,NULL,'2026-10-24 01:56:59');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (72,1,'products','SAVE',8,NULL,'2026-10-24 01:56:59');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (73,1,'mappings','SAVE',3,NULL,'2026-10-24 01:56:59');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (74,1,'bom-versions','SAVE',3,NULL,'2026-10-24 01:56:59');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (75,1,'bom-lines','SAVE',20,NULL,'2026-10-24 01:56:59');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (76,1,'bom-lines','SAVE',21,NULL,'2026-10-24 01:56:59');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (77,1,'bom-lines','SAVE',22,NULL,'2026-10-24 01:56:59');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (78,1,'bom-lines','SAVE',23,NULL,'2026-10-24 01:56:59');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (79,1,'routes','SAVE',3,NULL,'2026-10-24 01:56:59');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (80,1,'operations','SAVE',6,NULL,'2026-10-24 01:56:59');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (81,1,'qc-templates','SAVE',9,NULL,'2026-10-24 01:56:59');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (82,1,'qc-lines','SAVE',18,NULL,'2026-10-24 01:56:59');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (83,1,'work-orders','CREATE',2,NULL,'2026-10-24 01:56:59');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (84,1,'work-orders','CREATE',3,NULL,'2026-10-24 01:56:59');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (85,1,'work-orders','CREATE',4,NULL,'2026-10-24 01:56:59');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (86,6,'stock-documents','PURCHASE_RECEIPT',15,NULL,'2026-10-24 01:56:59');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (87,6,'stock-documents','LINE_ISSUE',16,NULL,'2026-10-24 01:57:00');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (88,5,'inspections','EXECUTE',6,NULL,'2026-10-24 01:57:00');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (89,6,'fulfillment','RECEIPT',3,NULL,'2026-10-24 01:57:00');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (90,6,'stock-documents','PURCHASE_RECEIPT',17,NULL,'2026-10-24 01:57:00');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (91,6,'stock-documents','LINE_ISSUE',18,NULL,'2026-10-24 01:57:00');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (92,5,'inspections','EXECUTE',7,NULL,'2026-10-24 01:57:01');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (93,6,'fulfillment','RECEIPT',4,NULL,'2026-10-24 01:57:01');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (94,6,'stock-documents','PURCHASE_RECEIPT',19,NULL,'2026-10-24 01:57:01');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (95,6,'stock-documents','LINE_ISSUE',20,NULL,'2026-10-24 01:57:01');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (96,6,'stock-documents','LINE_ISSUE',21,NULL,'2026-10-24 01:57:01');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (97,5,'inspections','EXECUTE',8,NULL,'2026-10-24 01:57:01');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (98,5,'inspections','EXECUTE',9,NULL,'2026-10-24 01:57:02');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (99,5,'inspections','EXECUTE',10,NULL,'2026-10-24 01:57:02');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (100,5,'inspections','EXECUTE',11,NULL,'2026-10-24 01:57:02');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (101,5,'inspections','EXECUTE',12,NULL,'2026-10-24 01:57:02');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (102,6,'fulfillment','RECEIPT',2,NULL,'2026-10-24 01:57:02');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (103,1,'work-orders','CREATE',5,NULL,'2026-10-24 01:57:02');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (104,1,'work-orders','CREATE',6,NULL,'2026-10-24 01:57:02');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (105,6,'stock-documents','PURCHASE_RECEIPT',22,NULL,'2026-10-24 01:57:03');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (106,6,'stock-documents','LINE_ISSUE',23,NULL,'2026-10-24 01:57:03');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (107,5,'inspections','EXECUTE',13,NULL,'2026-10-24 01:57:03');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (108,5,'inspections','EXECUTE',14,NULL,'2026-10-24 01:57:03');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (109,5,'inspections','EXECUTE',15,NULL,'2026-10-24 01:57:03');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (110,5,'inspections','EXECUTE',16,NULL,'2026-10-24 01:57:04');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (111,6,'fulfillment','RECEIPT',5,NULL,'2026-10-24 01:57:04');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (112,6,'stock-documents','PURCHASE_RECEIPT',24,NULL,'2026-10-24 01:57:04');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (113,6,'stock-documents','LINE_ISSUE',25,NULL,'2026-10-24 01:57:05');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (114,5,'inspections','EXECUTE',17,NULL,'2026-10-24 01:57:05');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (115,5,'inspections','EXECUTE',18,NULL,'2026-10-24 01:57:05');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (116,5,'inspections','EXECUTE',19,NULL,'2026-10-24 01:57:05');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (117,5,'inspections','EXECUTE',20,NULL,'2026-10-24 01:57:05');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (118,6,'fulfillment','RECEIPT',6,NULL,'2026-10-24 01:57:05');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (119,6,'stock-documents','SALES_SHIPMENT',26,NULL,'2026-10-24 01:57:05');
/*!40000 ALTER TABLE `mm_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_auto_event`
--

DROP TABLE IF EXISTS `mm_auto_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_auto_event` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `rule_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `task_id` bigint NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'PENDING',
  `attempts` int NOT NULL DEFAULT '0',
  `error` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `finished_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rule_code` (`rule_code`,`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_auto_event`
--

LOCK TABLES `mm_auto_event` WRITE;
/*!40000 ALTER TABLE `mm_auto_event` DISABLE KEYS */;
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (1,'REPORT_QC',2,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 09:56:54.929078','2026-10-24 09:56:55.259871');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (2,'REPORT_QC',3,'SUCCEEDED',1,NULL,'2026-10-24 09:56:55.204667','2026-10-24 09:56:55.268950');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (3,'REPORT_QC',4,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 09:56:55.414485','2026-10-24 09:56:57.299231');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (4,'REPORT_QC',5,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 09:56:55.722678','2026-10-24 09:56:57.307518');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (5,'REPORT_QC',10,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 09:57:00.282334','2026-10-24 09:57:01.344288');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (6,'REPORT_QC',11,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 09:57:01.120052','2026-10-24 09:57:01.358657');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (7,'REPORT_QC',6,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 09:57:01.941230','2026-10-24 09:57:03.386568');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (8,'REPORT_QC',12,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 09:57:02.063424','2026-10-24 09:57:03.394417');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (9,'REPORT_QC',7,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 09:57:02.124253','2026-10-24 09:57:03.404307');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (10,'REPORT_QC',8,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 09:57:02.292551','2026-10-24 09:57:03.419617');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (11,'REPORT_QC',9,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 09:57:02.475813','2026-10-24 09:57:03.433931');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (12,'REPORT_QC',13,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 09:57:03.736318','2026-10-24 09:57:05.451948');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (13,'REPORT_QC',14,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 09:57:03.849750','2026-10-24 09:57:05.461104');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (14,'REPORT_QC',15,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 09:57:03.969707','2026-10-24 09:57:05.469906');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (15,'REPORT_QC',16,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 09:57:04.082852','2026-10-24 09:57:05.476995');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (16,'REPORT_QC',17,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 09:57:05.284106','2026-10-24 09:57:05.485994');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (17,'REPORT_QC',18,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 09:57:05.370627','2026-10-24 09:57:05.494576');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (18,'REPORT_QC',19,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 09:57:05.521749','2026-10-24 09:57:07.524612');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (19,'REPORT_QC',20,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 09:57:05.688866','2026-10-24 09:57:07.532302');
/*!40000 ALTER TABLE `mm_auto_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_auto_rule`
--

DROP TABLE IF EXISTS `mm_auto_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_auto_rule` (
  `code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `enabled` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_auto_rule`
--

LOCK TABLES `mm_auto_rule` WRITE;
/*!40000 ALTER TABLE `mm_auto_rule` DISABLE KEYS */;
INSERT INTO `mm_auto_rule` (`code`, `name`, `enabled`) VALUES ('REPORT_QC','完整报工后自动创建质检待办',1);
/*!40000 ALTER TABLE `mm_auto_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_bom`
--

DROP TABLE IF EXISTS `mm_bom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_bom` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `product_id` bigint NOT NULL,
  `root_material_id` bigint NOT NULL,
  `version` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_bom`
--

LOCK TABLES `mm_bom` WRITE;
/*!40000 ALTER TABLE `mm_bom` DISABLE KEYS */;
INSERT INTO `mm_bom` (`id`, `code`, `name`, `product_id`, `root_material_id`, `version`, `created_at`) VALUES (1,'BOM-A100-V1','A100多级BOM',6,16,'1.0','2026-10-19 00:41:54');
INSERT INTO `mm_bom` (`id`, `code`, `name`, `product_id`, `root_material_id`, `version`, `created_at`) VALUES (2,'MC-SB-15-095646861401','隔离半成品BOM',7,15,'1','2026-10-24 01:56:58');
INSERT INTO `mm_bom` (`id`, `code`, `name`, `product_id`, `root_material_id`, `version`, `created_at`) VALUES (3,'MC-SB-14-095646861401','隔离半成品BOM',8,14,'1','2026-10-24 01:56:59');
/*!40000 ALTER TABLE `mm_bom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_bom_line`
--

DROP TABLE IF EXISTS `mm_bom_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_bom_line` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `bom_id` bigint NOT NULL,
  `parent_material_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `quantity` decimal(14,4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bom_id` (`bom_id`,`parent_material_id`,`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_bom_line`
--

LOCK TABLES `mm_bom_line` WRITE;
/*!40000 ALTER TABLE `mm_bom_line` DISABLE KEYS */;
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (1,1,16,14,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (2,1,16,15,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (3,1,15,2,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (4,1,15,3,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (5,1,14,4,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (6,1,14,5,2.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (7,1,14,6,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (8,1,14,7,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (9,1,15,8,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (10,1,15,9,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (11,1,15,10,4.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (12,1,16,11,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (13,1,16,12,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (14,1,16,13,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (15,2,15,10,4.0000,'2026-10-24 01:56:58');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (16,2,15,9,1.0000,'2026-10-24 01:56:58');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (17,2,15,8,1.0000,'2026-10-24 01:56:58');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (18,2,15,3,1.0000,'2026-10-24 01:56:58');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (19,2,15,2,1.0000,'2026-10-24 01:56:58');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (20,3,14,7,1.0000,'2026-10-24 01:56:59');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (21,3,14,6,1.0000,'2026-10-24 01:56:59');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (22,3,14,5,2.0000,'2026-10-24 01:56:59');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (23,3,14,4,1.0000,'2026-10-24 01:56:59');
/*!40000 ALTER TABLE `mm_bom_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_category`
--

DROP TABLE IF EXISTS `mm_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `parent_id` bigint DEFAULT NULL,
  `kind` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_category`
--

LOCK TABLES `mm_category` WRITE;
/*!40000 ALTER TABLE `mm_category` DISABLE KEYS */;
INSERT INTO `mm_category` (`id`, `code`, `name`, `parent_id`, `kind`) VALUES (1,'MC-CAT-095646861401','鼠标产品',NULL,'PRODUCT');
INSERT INTO `mm_category` (`id`, `code`, `name`, `parent_id`, `kind`) VALUES (2,'MC-SUB-095646861401','办公鼠标',1,'PRODUCT');
/*!40000 ALTER TABLE `mm_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_check_due`
--

DROP TABLE IF EXISTS `mm_check_due`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_check_due` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `plan_id` bigint NOT NULL,
  `due_date` date NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'PENDING',
  `record_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_due` (`plan_id`,`due_date`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_check_due`
--

LOCK TABLES `mm_check_due` WRITE;
/*!40000 ALTER TABLE `mm_check_due` DISABLE KEYS */;
INSERT INTO `mm_check_due` (`id`, `plan_id`, `due_date`, `status`, `record_id`) VALUES (1,1,'2026-10-19','OVERDUE',NULL);
INSERT INTO `mm_check_due` (`id`, `plan_id`, `due_date`, `status`, `record_id`) VALUES (2,1,'2026-10-20','OVERDUE',NULL);
INSERT INTO `mm_check_due` (`id`, `plan_id`, `due_date`, `status`, `record_id`) VALUES (3,1,'2026-10-21','OVERDUE',NULL);
INSERT INTO `mm_check_due` (`id`, `plan_id`, `due_date`, `status`, `record_id`) VALUES (4,1,'2026-10-22','OVERDUE',NULL);
INSERT INTO `mm_check_due` (`id`, `plan_id`, `due_date`, `status`, `record_id`) VALUES (5,1,'2026-10-23','OVERDUE',NULL);
INSERT INTO `mm_check_due` (`id`, `plan_id`, `due_date`, `status`, `record_id`) VALUES (6,1,'2026-10-24','PENDING',NULL);
INSERT INTO `mm_check_due` (`id`, `plan_id`, `due_date`, `status`, `record_id`) VALUES (7,2,'2026-10-24','DONE',1);
/*!40000 ALTER TABLE `mm_check_due` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_check_plan`
--

DROP TABLE IF EXISTS `mm_check_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_check_plan` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `equipment_id` bigint NOT NULL,
  `interval_days` int NOT NULL,
  `standard` varchar(500) NOT NULL,
  `owner_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enabled` int NOT NULL DEFAULT '1',
  `plan_type` varchar(20) NOT NULL DEFAULT 'CHECK',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_check_plan`
--

LOCK TABLES `mm_check_plan` WRITE;
/*!40000 ALTER TABLE `mm_check_plan` DISABLE KEYS */;
INSERT INTO `mm_check_plan` (`id`, `code`, `name`, `equipment_id`, `interval_days`, `standard`, `owner_id`, `created_at`, `enabled`, `plan_type`) VALUES (1,'CHECK-A100','USB功能测试台日点检',1,1,'连接完整、供电正常、测试软件可识别',1,'2026-10-19 00:41:54',1,'CHECK');
INSERT INTO `mm_check_plan` (`id`, `code`, `name`, `equipment_id`, `interval_days`, `standard`, `owner_id`, `created_at`, `enabled`, `plan_type`) VALUES (2,'MC-CHECK-095646861401','隔离周期点检',2,1,'供电及功能正常',9,'2026-10-24 01:56:57',1,'CHECK');
/*!40000 ALTER TABLE `mm_check_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_check_plan_subject`
--

DROP TABLE IF EXISTS `mm_check_plan_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_check_plan_subject` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `plan_id` bigint NOT NULL,
  `subject_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_check_subject` (`plan_id`,`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_check_plan_subject`
--

LOCK TABLES `mm_check_plan_subject` WRITE;
/*!40000 ALTER TABLE `mm_check_plan_subject` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_check_plan_subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_check_record`
--

DROP TABLE IF EXISTS `mm_check_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_check_record` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `plan_id` bigint NOT NULL,
  `checked_at` datetime NOT NULL,
  `actual_value` varchar(500) NOT NULL,
  `result` varchar(20) NOT NULL,
  `remark` varchar(500) DEFAULT NULL,
  `actor_id` bigint NOT NULL,
  `maintenance_id` bigint DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_check_record`
--

LOCK TABLES `mm_check_record` WRITE;
/*!40000 ALTER TABLE `mm_check_record` DISABLE KEYS */;
INSERT INTO `mm_check_record` (`id`, `plan_id`, `checked_at`, `actual_value`, `result`, `remark`, `actor_id`, `maintenance_id`, `created_at`) VALUES (1,2,'2026-10-24 09:56:58','隔离验收异常，生成报修','FAIL',NULL,9,1,'2026-10-24 01:56:57');
INSERT INTO `mm_check_record` (`id`, `plan_id`, `checked_at`, `actual_value`, `result`, `remark`, `actor_id`, `maintenance_id`, `created_at`) VALUES (2,2,'2026-10-24 09:56:58','隔离验收异常，生成报修','FAIL',NULL,9,1,'2026-10-24 01:56:57');
/*!40000 ALTER TABLE `mm_check_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_check_subject`
--

DROP TABLE IF EXISTS `mm_check_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_check_subject` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `kind` varchar(20) NOT NULL,
  `standard` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_check_subject`
--

LOCK TABLES `mm_check_subject` WRITE;
/*!40000 ALTER TABLE `mm_check_subject` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_check_subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_code_rule`
--

DROP TABLE IF EXISTS `mm_code_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_code_rule` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `prefix` varchar(32) NOT NULL,
  `width` int NOT NULL DEFAULT '6',
  `next_value` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_code_rule`
--

LOCK TABLES `mm_code_rule` WRITE;
/*!40000 ALTER TABLE `mm_code_rule` DISABLE KEYS */;
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (1,'ITEM_CODE','ITEM_CODE','MAT-',6,16);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (2,'VENDOR_CODE','VENDOR_CODE','SUP-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (3,'CLIENT_CODE','CLIENT_CODE','CUS-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (4,'WORKSHOP_CODE','WORKSHOP_CODE','WS-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (5,'WORKSTATION_CODE','WORKSTATION_CODE','ST-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (6,'WAREHOUSE_CODE','WAREHOUSE_CODE','WH-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (7,'AREA_CODE','AREA_CODE','AR-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (8,'LOCATION_CODE','LOCATION_CODE','LOC-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (9,'ISSUE_CODE','ISSUE_CODE','ISS-',6,9);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (10,'WORKORDER_CODE','WORKORDER_CODE','MO-',6,12);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (11,'PACKAGE_CODE','PACKAGE_CODE','PKG-',6,3);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (12,'DOCUMENT_CODE','DOCUMENT_CODE','DOC-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (13,'UOM_CODE','UOM_CODE','UOM-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (14,'PRODUCT_CODE','PRODUCT_CODE','PRD-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (15,'PROCESS_CODE','PROCESS_CODE','OP-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (16,'ROUTE_CODE','ROUTE_CODE','ROUTE-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (17,'CHECKPLAN_CODE','CHECKPLAN_CODE','CHECK-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (18,'MACHINERY_CODE','MACHINERY_CODE','EQ-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (19,'QC_TEMPLATR_CODE','QC_TEMPLATR_CODE','QCT-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (20,'QC_ITEM_CODE','QC_ITEM_CODE','QCI-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (21,'DEFECT_CODE','DEFECT_CODE','DF-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (22,'BOM_CODE','BOM_CODE','BOM-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (23,'TEAM_CODE','TEAM_CODE','TEAM-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (24,'CAL_PLAN_CODE','CAL_PLAN_CODE','CAL-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (25,'SOP_CODE','SOP_CODE','SOP-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (26,'ITEMRECPT_CODE','ITEMRECPT_CODE','PR-',6,9);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (27,'WM_RTVENDOR_CODE','WM_RTVENDOR_CODE','P-RET-',6,2);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (28,'RTISSUE_CODE','RTISSUE_CODE','L-RET-',6,2);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (29,'PRODUCTRECPT_CODE','PRODUCTRECPT_CODE','FG-IN-',6,8);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (30,'PRODUCTSALSE_CODE','PRODUCTSALSE_CODE','SHIP-',6,4);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (31,'RTSALSE_CODE','RTSALSE_CODE','S-RET-',6,2);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (32,'QC_IQC_CODE','QC_IQC_CODE','IQC-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (33,'IPQC_CODE','IPQC_CODE','IPQC-',6,21);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (34,'OQC_CODE','OQC_CODE','OQC-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (35,'REPAIR_CODE','REPAIR_CODE','REPAIR-',6,2);
/*!40000 ALTER TABLE `mm_code_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_defect`
--

DROP TABLE IF EXISTS `mm_defect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_defect` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `severity` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_defect`
--

LOCK TABLES `mm_defect` WRITE;
/*!40000 ALTER TABLE `mm_defect` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_defect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_document`
--

DROP TABLE IF EXISTS `mm_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_document` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(80) NOT NULL,
  `kind` varchar(32) NOT NULL,
  `source_id` bigint DEFAULT NULL,
  `warehouse_id` bigint NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'DRAFT',
  `reason` varchar(500) DEFAULT NULL,
  `actor_id` bigint NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `posted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_document`
--

LOCK TABLES `mm_document` WRITE;
/*!40000 ALTER TABLE `mm_document` DISABLE KEYS */;
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (1,'PR-000001','PURCHASE_RECEIPT',1,2,'POSTED','隔离验收',6,'2026-10-24 09:56:50','2026-10-24 09:56:51');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (2,'PR-000002','PURCHASE_RECEIPT',1,2,'POSTED','隔离验收',6,'2026-10-24 09:56:51','2026-10-24 09:56:52');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (3,'L-RET-000001','LINE_RETURN',1,2,'POSTED','隔离验收',6,'2026-10-24 09:56:54','2026-10-24 09:56:54');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (4,'ISS-000002','LINE_ISSUE',1,2,'POSTED','隔离验收',6,'2026-10-24 09:56:54','2026-10-24 09:56:54');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (5,'FG-IN-000001','PRODUCTION_RECEIPT',1,4,'POSTED','隔离验收',6,'2026-10-24 09:56:55','2026-10-24 09:56:55');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (6,'FG-IN-000002','PRODUCTION_RECEIPT',1,4,'POSTED','隔离验收',6,'2026-10-24 09:56:55','2026-10-24 09:56:55');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (7,'SHIP-000001','SALES_SHIPMENT',5,4,'POSTED','隔离验收',6,'2026-10-24 09:56:56','2026-10-24 09:56:56');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (8,'SHIP-000002','SALES_SHIPMENT',5,4,'POSTED','隔离验收',6,'2026-10-24 09:56:56','2026-10-24 09:56:56');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (9,'S-RET-000001','SALES_RETURN',5,4,'POSTED','隔离验收',6,'2026-10-24 09:56:56','2026-10-24 09:56:56');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (11,'PR-000003','PURCHASE_RECEIPT',2,2,'POSTED','隔离验收',6,'2026-10-24 09:56:57','2026-10-24 09:56:57');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (12,'P-RET-000001','PURCHASE_RETURN',2,2,'POSTED','隔离验收',6,'2026-10-24 09:56:57','2026-10-24 09:56:57');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (15,'PR-000004','PURCHASE_RECEIPT',3,2,'POSTED','隔离验收',6,'2026-10-24 09:56:59','2026-10-24 09:56:59');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (16,'ISS-000003','LINE_ISSUE',3,2,'POSTED','隔离验收',6,'2026-10-24 09:56:59','2026-10-24 09:57:00');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (17,'PR-000005','PURCHASE_RECEIPT',4,2,'POSTED','隔离验收',6,'2026-10-24 09:57:00','2026-10-24 09:57:00');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (18,'ISS-000004','LINE_ISSUE',4,2,'POSTED','隔离验收',6,'2026-10-24 09:57:00','2026-10-24 09:57:00');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (19,'PR-000006','PURCHASE_RECEIPT',5,2,'POSTED','隔离验收',6,'2026-10-24 09:57:01','2026-10-24 09:57:01');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (20,'ISS-000005','LINE_ISSUE',2,2,'POSTED','隔离验收',6,'2026-10-24 09:57:01','2026-10-24 09:57:01');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (21,'ISS-000006','LINE_ISSUE',2,4,'POSTED','隔离验收',6,'2026-10-24 09:57:01','2026-10-24 09:57:01');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (22,'PR-000007','PURCHASE_RECEIPT',6,2,'POSTED','隔离验收',6,'2026-10-24 09:57:02','2026-10-24 09:57:03');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (23,'ISS-000007','LINE_ISSUE',5,2,'POSTED','隔离验收',6,'2026-10-24 09:57:03','2026-10-24 09:57:03');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (24,'PR-000008','PURCHASE_RECEIPT',7,2,'POSTED','隔离验收',6,'2026-10-24 09:57:04','2026-10-24 09:57:04');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (25,'ISS-000008','LINE_ISSUE',6,2,'POSTED','隔离验收',6,'2026-10-24 09:57:04','2026-10-24 09:57:05');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`) VALUES (26,'SHIP-000003','SALES_SHIPMENT',6,4,'POSTED','隔离验收',6,'2026-10-24 09:57:05','2026-10-24 09:57:05');
/*!40000 ALTER TABLE `mm_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_document_check`
--

DROP TABLE IF EXISTS `mm_document_check`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_document_check` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `line_id` bigint NOT NULL,
  `template_id` bigint NOT NULL,
  `quantity` decimal(18,2) NOT NULL,
  `qualified_quantity` decimal(18,2) NOT NULL,
  `results` json NOT NULL,
  `status` varchar(20) NOT NULL,
  `actor_id` bigint NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_document_check`
--

LOCK TABLES `mm_document_check` WRITE;
/*!40000 ALTER TABLE `mm_document_check` DISABLE KEYS */;
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (1,1,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:50');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (2,2,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:51');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (3,3,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:51');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (4,4,1,100.00,100.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:51');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (5,5,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:51');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (6,6,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:51');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (7,7,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:51');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (8,8,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:51');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (9,9,1,200.00,200.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:51');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (10,10,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:51');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (11,11,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:51');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (12,12,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:51');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (13,13,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:51');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (14,14,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:51');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (15,15,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:51');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (16,16,1,100.00,100.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:51');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (17,17,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:51');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (18,18,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:52');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (19,19,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:52');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (20,20,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:52');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (21,21,1,200.00,200.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:52');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (22,22,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:52');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (23,23,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:52');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (24,24,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:52');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (25,29,3,40.00,40.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:56');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (26,30,3,60.00,60.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:56');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (27,31,3,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:56');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (28,33,1,20.00,20.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:57');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (29,37,1,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:59');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (30,38,1,20.00,20.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:59');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (31,39,1,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:59');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (32,40,1,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:56:59');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (33,45,1,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:00');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (34,46,1,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:00');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (35,47,1,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:00');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (36,48,1,40.00,40.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:00');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (37,54,1,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:01');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (38,55,1,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:01');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (39,56,1,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:01');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (40,62,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:03');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (41,63,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:03');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (42,64,1,2.00,2.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:03');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (43,65,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:03');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (44,66,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:03');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (45,67,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:03');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (46,68,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:03');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (47,69,1,4.00,4.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:03');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (48,70,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:03');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (49,71,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:03');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (50,72,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:03');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (51,85,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:04');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (52,86,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:04');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (53,87,1,2.00,2.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:04');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (54,88,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:04');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (55,89,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:04');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (56,90,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:04');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (57,91,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:04');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (58,92,1,4.00,4.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:04');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (59,93,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:04');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (60,94,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:04');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (61,95,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:04');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (62,108,3,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:05');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (63,109,3,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 09:57:05');
/*!40000 ALTER TABLE `mm_document_check` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_document_line`
--

DROP TABLE IF EXISTS `mm_document_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_document_line` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `document_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `lot_id` bigint NOT NULL,
  `location_id` bigint DEFAULT NULL,
  `quantity` decimal(18,2) NOT NULL,
  `source_line_id` bigint DEFAULT NULL,
  `input_unit_id` bigint DEFAULT NULL,
  `entered_quantity` decimal(18,6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `mm_document_line_chk_1` CHECK ((`quantity` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_document_line`
--

LOCK TABLES `mm_document_line` WRITE;
/*!40000 ALTER TABLE `mm_document_line` DISABLE KEYS */;
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (1,1,2,1,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (2,1,3,2,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (3,1,4,3,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (4,1,5,4,2,100.00,NULL,NULL,100.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (5,1,6,5,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (6,1,7,6,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (7,1,8,7,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (8,1,9,8,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (9,1,10,9,2,200.00,NULL,NULL,200.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (10,1,11,10,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (11,1,12,11,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (12,1,13,12,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (13,2,2,13,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (14,2,3,14,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (15,2,4,15,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (16,2,5,16,2,100.00,NULL,NULL,100.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (17,2,6,17,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (18,2,7,18,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (19,2,8,19,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (20,2,9,20,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (21,2,10,21,2,200.00,NULL,NULL,200.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (22,2,11,22,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (23,2,12,23,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (24,2,13,24,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (25,3,2,13,2,40.00,NULL,NULL,40.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (26,4,2,13,2,40.00,NULL,NULL,40.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (27,5,16,25,4,40.00,NULL,NULL,40.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (28,6,16,25,4,60.00,NULL,NULL,60.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (29,7,16,25,4,40.00,NULL,NULL,40.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (30,8,16,25,4,60.00,NULL,NULL,60.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (31,9,16,25,4,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (33,11,2,26,2,20.00,NULL,10,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (34,12,2,26,2,5.00,NULL,NULL,5.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (37,15,4,27,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (38,15,5,28,2,20.00,NULL,NULL,20.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (39,15,6,29,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (40,15,7,30,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (41,16,4,27,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (42,16,5,28,2,20.00,NULL,NULL,20.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (43,16,6,29,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (44,16,7,30,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (45,17,3,32,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (46,17,8,33,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (47,17,9,34,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (48,17,10,35,2,40.00,NULL,NULL,40.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (49,18,2,26,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (50,18,3,32,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (51,18,8,33,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (52,18,9,34,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (53,18,10,35,2,40.00,NULL,NULL,40.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (54,19,11,37,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (55,19,12,38,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (56,19,13,39,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (57,20,11,37,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (58,20,12,38,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (59,20,13,39,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (60,21,14,31,4,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (61,21,15,36,4,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (62,22,3,41,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (63,22,4,42,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (64,22,5,43,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (65,22,6,44,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (66,22,7,45,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (67,22,8,46,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (68,22,9,47,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (69,22,10,48,2,4.00,NULL,NULL,4.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (70,22,11,49,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (71,22,12,50,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (72,22,13,51,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (73,23,2,26,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (74,23,3,41,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (75,23,4,42,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (76,23,5,43,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (77,23,6,44,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (78,23,7,45,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (79,23,8,46,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (80,23,9,47,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (81,23,10,48,2,4.00,NULL,NULL,4.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (82,23,11,49,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (83,23,12,50,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (84,23,13,51,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (85,24,3,53,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (86,24,4,54,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (87,24,5,55,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (88,24,6,56,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (89,24,7,57,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (90,24,8,58,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (91,24,9,59,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (92,24,10,60,2,4.00,NULL,NULL,4.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (93,24,11,61,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (94,24,12,62,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (95,24,13,63,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (96,25,2,26,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (97,25,3,53,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (98,25,4,54,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (99,25,5,55,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (100,25,6,56,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (101,25,7,57,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (102,25,8,58,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (103,25,9,59,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (104,25,10,60,2,4.00,NULL,NULL,4.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (105,25,11,61,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (106,25,12,62,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (107,25,13,63,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (108,26,16,52,4,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (109,26,16,64,4,1.00,NULL,NULL,1.000000);
/*!40000 ALTER TABLE `mm_document_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_guard`
--

DROP TABLE IF EXISTS `mm_guard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_guard` (
  `id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_guard`
--

LOCK TABLES `mm_guard` WRITE;
/*!40000 ALTER TABLE `mm_guard` DISABLE KEYS */;
INSERT INTO `mm_guard` (`id`) VALUES (1);
/*!40000 ALTER TABLE `mm_guard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_holiday`
--

DROP TABLE IF EXISTS `mm_holiday`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_holiday` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_date` date NOT NULL,
  `is_working` int NOT NULL,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `work_date` (`work_date`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_holiday`
--

LOCK TABLES `mm_holiday` WRITE;
/*!40000 ALTER TABLE `mm_holiday` DISABLE KEYS */;
INSERT INTO `mm_holiday` (`id`, `work_date`, `is_working`, `name`) VALUES (1,'2032-01-10',1,'隔离调休上班');
/*!40000 ALTER TABLE `mm_holiday` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_inspection`
--

DROP TABLE IF EXISTS `mm_inspection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_inspection` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(80) NOT NULL,
  `template_id` bigint NOT NULL,
  `kind` varchar(30) NOT NULL,
  `source_type` varchar(30) NOT NULL,
  `source_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  `qualified_quantity` int NOT NULL,
  `results` json NOT NULL,
  `status` varchar(30) NOT NULL,
  `actor_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_inspection`
--

LOCK TABLES `mm_inspection` WRITE;
/*!40000 ALTER TABLE `mm_inspection` DISABLE KEYS */;
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (1,'IPQC-000001',4,'PROCESS','TASK',2,100,0,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 20, \"result\": \"FAIL\"}]','BLOCKED',5,'2026-10-24 01:56:54');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (2,'IPQC-000002',4,'PROCESS','TASK',2,100,100,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:56:55');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (3,'IPQC-000003',5,'PROCESS','TASK',3,100,100,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:56:55');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (4,'IPQC-000004',6,'PROCESS','TASK',4,100,100,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:56:55');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (5,'IPQC-000005',7,'PROCESS','TASK',5,100,100,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:56:55');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (6,'IPQC-000006',9,'PROCESS','TASK',10,10,10,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:57:00');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (7,'IPQC-000007',8,'PROCESS','TASK',11,10,10,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:57:01');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (8,'IPQC-000008',4,'PROCESS','TASK',6,6,6,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:57:01');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (9,'IPQC-000009',4,'PROCESS','TASK',12,4,4,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:57:02');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (10,'IPQC-000010',5,'PROCESS','TASK',7,10,10,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:57:02');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (11,'IPQC-000011',6,'PROCESS','TASK',8,10,10,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:57:02');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (12,'IPQC-000012',7,'PROCESS','TASK',9,10,10,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:57:02');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (13,'IPQC-000013',4,'PROCESS','TASK',13,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:57:03');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (14,'IPQC-000014',5,'PROCESS','TASK',14,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:57:03');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (15,'IPQC-000015',6,'PROCESS','TASK',15,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:57:03');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (16,'IPQC-000016',7,'PROCESS','TASK',16,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:57:04');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (17,'IPQC-000017',4,'PROCESS','TASK',17,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:57:05');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (18,'IPQC-000018',5,'PROCESS','TASK',18,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:57:05');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (19,'IPQC-000019',6,'PROCESS','TASK',19,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:57:05');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (20,'IPQC-000020',7,'PROCESS','TASK',20,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-095646861401\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 09:56:49\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 01:57:05');
/*!40000 ALTER TABLE `mm_inspection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_inventory_anchor`
--

DROP TABLE IF EXISTS `mm_inventory_anchor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_inventory_anchor` (
  `id` int NOT NULL,
  `captured_at` datetime(6) NOT NULL,
  `ledger_id` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_inventory_anchor`
--

LOCK TABLES `mm_inventory_anchor` WRITE;
/*!40000 ALTER TABLE `mm_inventory_anchor` DISABLE KEYS */;
INSERT INTO `mm_inventory_anchor` (`id`, `captured_at`, `ledger_id`) VALUES (1,'2026-10-23 23:22:35.041312',0);
/*!40000 ALTER TABLE `mm_inventory_anchor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_inventory_baseline`
--

DROP TABLE IF EXISTS `mm_inventory_baseline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_inventory_baseline` (
  `material_id` bigint NOT NULL,
  `warehouse_id` bigint NOT NULL,
  `quantity` decimal(18,2) NOT NULL,
  PRIMARY KEY (`material_id`,`warehouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_inventory_baseline`
--

LOCK TABLES `mm_inventory_baseline` WRITE;
/*!40000 ALTER TABLE `mm_inventory_baseline` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_inventory_baseline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_job_config`
--

DROP TABLE IF EXISTS `mm_job_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_job_config` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `enabled` int NOT NULL DEFAULT '1',
  `interval_seconds` int NOT NULL,
  `last_run` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_job_config`
--

LOCK TABLES `mm_job_config` WRITE;
/*!40000 ALTER TABLE `mm_job_config` DISABLE KEYS */;
INSERT INTO `mm_job_config` (`id`, `code`, `name`, `enabled`, `interval_seconds`, `last_run`) VALUES (1,'EQUIPMENT_CHECK','设备到期任务',1,60,'2026-10-24 10:14:00');
INSERT INTO `mm_job_config` (`id`, `code`, `name`, `enabled`, `interval_seconds`, `last_run`) VALUES (2,'REPORT_QC','报工质检事件',1,2,'2026-10-24 10:14:27');
/*!40000 ALTER TABLE `mm_job_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_job_run`
--

DROP TABLE IF EXISTS `mm_job_run`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_job_run` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(80) NOT NULL,
  `started_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `finished_at` datetime DEFAULT NULL,
  `status` varchar(20) NOT NULL,
  `error` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_job_run`
--

LOCK TABLES `mm_job_run` WRITE;
/*!40000 ALTER TABLE `mm_job_run` DISABLE KEYS */;
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (1,'EQUIPMENT_CHECK','2026-10-24 09:56:57','2026-10-24 09:56:57','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (2,'EQUIPMENT_CHECK','2026-10-24 09:56:57','2026-10-24 09:56:57','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (3,'EQUIPMENT_CHECK','2026-10-24 09:58:00','2026-10-24 09:58:00','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (4,'EQUIPMENT_CHECK','2026-10-24 09:59:00','2026-10-24 09:59:00','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (5,'EQUIPMENT_CHECK','2026-10-24 10:00:00','2026-10-24 10:00:00','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (6,'EQUIPMENT_CHECK','2026-10-24 10:01:00','2026-10-24 10:01:00','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (7,'EQUIPMENT_CHECK','2026-10-24 10:02:00','2026-10-24 10:02:00','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (8,'EQUIPMENT_CHECK','2026-10-24 10:03:00','2026-10-24 10:03:00','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (9,'EQUIPMENT_CHECK','2026-10-24 10:04:00','2026-10-24 10:04:00','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (10,'EQUIPMENT_CHECK','2026-10-24 10:05:00','2026-10-24 10:05:00','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (11,'EQUIPMENT_CHECK','2026-10-24 10:06:00','2026-10-24 10:06:00','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (12,'EQUIPMENT_CHECK','2026-10-24 10:07:00','2026-10-24 10:07:00','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (13,'EQUIPMENT_CHECK','2026-10-24 10:08:00','2026-10-24 10:08:00','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (14,'EQUIPMENT_CHECK','2026-10-24 10:09:00','2026-10-24 10:09:00','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (15,'EQUIPMENT_CHECK','2026-10-24 10:10:00','2026-10-24 10:10:00','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (16,'EQUIPMENT_CHECK','2026-10-24 10:11:00','2026-10-24 10:11:00','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (17,'EQUIPMENT_CHECK','2026-10-24 10:12:00','2026-10-24 10:12:00','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (18,'EQUIPMENT_CHECK','2026-10-24 10:13:00','2026-10-24 10:13:00','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (19,'EQUIPMENT_CHECK','2026-10-24 10:14:00','2026-10-24 10:14:00','SUCCEEDED',NULL);
/*!40000 ALTER TABLE `mm_job_run` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_legacy_link`
--

DROP TABLE IF EXISTS `mm_legacy_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_legacy_link` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source_type` varchar(40) NOT NULL,
  `source_id` bigint NOT NULL,
  `plan_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `source_type` (`source_type`,`source_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_legacy_link`
--

LOCK TABLES `mm_legacy_link` WRITE;
/*!40000 ALTER TABLE `mm_legacy_link` DISABLE KEYS */;
INSERT INTO `mm_legacy_link` (`id`, `source_type`, `source_id`, `plan_id`, `created_at`) VALUES (1,'ORDER',2,1,'2026-10-19 00:41:54');
INSERT INTO `mm_legacy_link` (`id`, `source_type`, `source_id`, `plan_id`, `created_at`) VALUES (2,'ORDER',1,2,'2026-10-19 00:41:54');
INSERT INTO `mm_legacy_link` (`id`, `source_type`, `source_id`, `plan_id`, `created_at`) VALUES (3,'ORDER',3,3,'2026-10-19 00:41:54');
INSERT INTO `mm_legacy_link` (`id`, `source_type`, `source_id`, `plan_id`, `created_at`) VALUES (4,'ORDER',4,7,'2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_legacy_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_line_movement`
--

DROP TABLE IF EXISTS `mm_line_movement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_line_movement` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `lot_id` bigint NOT NULL,
  `quantity` decimal(18,6) NOT NULL,
  `kind` varchar(32) NOT NULL,
  `source_id` bigint NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_line_move` (`kind`,`source_id`,`material_id`,`lot_id`)
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_line_movement`
--

LOCK TABLES `mm_line_movement` WRITE;
/*!40000 ALTER TABLE `mm_line_movement` DISABLE KEYS */;
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (1,1,2,1,50.000000,'ISSUE',1,'2026-10-24 09:56:52');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (2,1,2,13,50.000000,'ISSUE',1,'2026-10-24 09:56:52');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (3,1,3,2,50.000000,'ISSUE',1,'2026-10-24 09:56:52');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (4,1,3,14,50.000000,'ISSUE',1,'2026-10-24 09:56:52');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (5,1,4,3,50.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (6,1,4,15,50.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (7,1,5,4,100.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (8,1,5,16,100.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (9,1,6,5,50.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (10,1,6,17,50.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (11,1,7,6,50.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (12,1,7,18,50.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (13,1,8,7,50.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (14,1,8,19,50.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (15,1,9,8,50.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (16,1,9,20,50.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (17,1,10,9,200.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (18,1,10,21,200.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (19,1,11,10,50.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (20,1,11,22,50.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (21,1,12,11,50.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (22,1,12,23,50.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (23,1,13,12,50.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (24,1,13,24,50.000000,'ISSUE',1,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (25,1,2,1,-50.000000,'CONSUME',3,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (26,1,2,13,-10.000000,'CONSUME',3,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (27,1,3,2,-50.000000,'CONSUME',3,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (28,1,3,14,-10.000000,'CONSUME',3,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (29,1,4,3,-50.000000,'CONSUME',3,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (30,1,4,15,-10.000000,'CONSUME',3,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (31,1,5,4,-100.000000,'CONSUME',3,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (32,1,5,16,-20.000000,'CONSUME',3,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (33,1,6,5,-50.000000,'CONSUME',3,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (34,1,6,17,-10.000000,'CONSUME',3,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (35,1,7,6,-50.000000,'CONSUME',3,'2026-10-24 09:56:53');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (36,1,7,18,-10.000000,'CONSUME',3,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (37,1,8,7,-50.000000,'CONSUME',3,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (38,1,8,19,-10.000000,'CONSUME',3,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (39,1,9,8,-50.000000,'CONSUME',3,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (40,1,9,20,-10.000000,'CONSUME',3,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (41,1,10,9,-200.000000,'CONSUME',3,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (42,1,10,21,-40.000000,'CONSUME',3,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (43,1,11,10,-50.000000,'CONSUME',3,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (44,1,11,22,-10.000000,'CONSUME',3,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (45,1,12,11,-50.000000,'CONSUME',3,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (46,1,12,23,-10.000000,'CONSUME',3,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (47,1,13,12,-50.000000,'CONSUME',3,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (48,1,13,24,-10.000000,'CONSUME',3,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (49,1,2,13,-40.000000,'LINE_RETURN',3,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (50,1,2,13,40.000000,'LINE_ISSUE',4,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (51,1,2,13,-40.000000,'CONSUME',4,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (52,1,3,14,-40.000000,'CONSUME',4,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (53,1,4,15,-40.000000,'CONSUME',4,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (54,1,5,16,-80.000000,'CONSUME',4,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (55,1,6,17,-40.000000,'CONSUME',4,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (56,1,7,18,-40.000000,'CONSUME',4,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (57,1,8,19,-40.000000,'CONSUME',4,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (58,1,9,20,-40.000000,'CONSUME',4,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (59,1,10,21,-160.000000,'CONSUME',4,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (60,1,11,22,-40.000000,'CONSUME',4,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (61,1,12,23,-40.000000,'CONSUME',4,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (62,1,13,24,-40.000000,'CONSUME',4,'2026-10-24 09:56:54');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (63,1,16,25,100.000000,'OUTPUT',7,'2026-10-24 09:56:55');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (64,1,16,25,-40.000000,'PRODUCTION_RECEIPT',5,'2026-10-24 09:56:55');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (65,1,16,25,-60.000000,'PRODUCTION_RECEIPT',6,'2026-10-24 09:56:55');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (66,3,4,27,10.000000,'LINE_ISSUE',16,'2026-10-24 09:57:00');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (67,3,5,28,20.000000,'LINE_ISSUE',16,'2026-10-24 09:57:00');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (68,3,6,29,10.000000,'LINE_ISSUE',16,'2026-10-24 09:57:00');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (69,3,7,30,10.000000,'LINE_ISSUE',16,'2026-10-24 09:57:00');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (70,3,4,27,-10.000000,'CONSUME',8,'2026-10-24 09:57:00');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (71,3,5,28,-20.000000,'CONSUME',8,'2026-10-24 09:57:00');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (72,3,6,29,-10.000000,'CONSUME',8,'2026-10-24 09:57:00');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (73,3,7,30,-10.000000,'CONSUME',8,'2026-10-24 09:57:00');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (74,3,14,31,10.000000,'OUTPUT',8,'2026-10-24 09:57:00');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (75,3,14,31,-10.000000,'RECEIPT',9,'2026-10-24 09:57:00');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (76,4,2,26,10.000000,'LINE_ISSUE',18,'2026-10-24 09:57:00');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (77,4,3,32,10.000000,'LINE_ISSUE',18,'2026-10-24 09:57:00');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (78,4,8,33,10.000000,'LINE_ISSUE',18,'2026-10-24 09:57:00');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (79,4,9,34,10.000000,'LINE_ISSUE',18,'2026-10-24 09:57:00');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (80,4,10,35,40.000000,'LINE_ISSUE',18,'2026-10-24 09:57:00');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (81,4,2,26,-10.000000,'CONSUME',9,'2026-10-24 09:57:01');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (82,4,3,32,-10.000000,'CONSUME',9,'2026-10-24 09:57:01');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (83,4,8,33,-10.000000,'CONSUME',9,'2026-10-24 09:57:01');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (84,4,9,34,-10.000000,'CONSUME',9,'2026-10-24 09:57:01');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (85,4,10,35,-40.000000,'CONSUME',9,'2026-10-24 09:57:01');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (86,4,15,36,10.000000,'OUTPUT',9,'2026-10-24 09:57:01');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (87,4,15,36,-10.000000,'RECEIPT',11,'2026-10-24 09:57:01');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (88,2,11,37,10.000000,'LINE_ISSUE',20,'2026-10-24 09:57:01');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (89,2,12,38,10.000000,'LINE_ISSUE',20,'2026-10-24 09:57:01');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (90,2,13,39,10.000000,'LINE_ISSUE',20,'2026-10-24 09:57:01');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (91,2,14,31,10.000000,'LINE_ISSUE',21,'2026-10-24 09:57:01');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (92,2,15,36,10.000000,'LINE_ISSUE',21,'2026-10-24 09:57:01');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (93,2,11,37,-6.000000,'CONSUME',10,'2026-10-24 09:57:01');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (94,2,12,38,-6.000000,'CONSUME',10,'2026-10-24 09:57:01');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (95,2,13,39,-6.000000,'CONSUME',10,'2026-10-24 09:57:01');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (96,2,14,31,-6.000000,'CONSUME',10,'2026-10-24 09:57:01');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (97,2,15,36,-6.000000,'CONSUME',10,'2026-10-24 09:57:01');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (98,2,11,37,-4.000000,'CONSUME',11,'2026-10-24 09:57:02');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (99,2,12,38,-4.000000,'CONSUME',11,'2026-10-24 09:57:02');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (100,2,13,39,-4.000000,'CONSUME',11,'2026-10-24 09:57:02');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (101,2,14,31,-4.000000,'CONSUME',11,'2026-10-24 09:57:02');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (102,2,15,36,-4.000000,'CONSUME',11,'2026-10-24 09:57:02');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (103,2,16,40,10.000000,'OUTPUT',14,'2026-10-24 09:57:02');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (104,2,16,40,-10.000000,'RECEIPT',13,'2026-10-24 09:57:02');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (105,5,2,26,1.000000,'LINE_ISSUE',23,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (106,5,3,41,1.000000,'LINE_ISSUE',23,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (107,5,4,42,1.000000,'LINE_ISSUE',23,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (108,5,5,43,2.000000,'LINE_ISSUE',23,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (109,5,6,44,1.000000,'LINE_ISSUE',23,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (110,5,7,45,1.000000,'LINE_ISSUE',23,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (111,5,8,46,1.000000,'LINE_ISSUE',23,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (112,5,9,47,1.000000,'LINE_ISSUE',23,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (113,5,10,48,4.000000,'LINE_ISSUE',23,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (114,5,11,49,1.000000,'LINE_ISSUE',23,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (115,5,12,50,1.000000,'LINE_ISSUE',23,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (116,5,13,51,1.000000,'LINE_ISSUE',23,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (117,5,2,26,-1.000000,'CONSUME',15,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (118,5,3,41,-1.000000,'CONSUME',15,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (119,5,4,42,-1.000000,'CONSUME',15,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (120,5,5,43,-2.000000,'CONSUME',15,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (121,5,6,44,-1.000000,'CONSUME',15,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (122,5,7,45,-1.000000,'CONSUME',15,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (123,5,8,46,-1.000000,'CONSUME',15,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (124,5,9,47,-1.000000,'CONSUME',15,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (125,5,10,48,-4.000000,'CONSUME',15,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (126,5,11,49,-1.000000,'CONSUME',15,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (127,5,12,50,-1.000000,'CONSUME',15,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (128,5,13,51,-1.000000,'CONSUME',15,'2026-10-24 09:57:03');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (129,5,16,52,1.000000,'OUTPUT',18,'2026-10-24 09:57:04');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (130,5,16,52,-1.000000,'RECEIPT',15,'2026-10-24 09:57:04');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (131,6,2,26,1.000000,'LINE_ISSUE',25,'2026-10-24 09:57:04');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (132,6,3,53,1.000000,'LINE_ISSUE',25,'2026-10-24 09:57:04');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (133,6,4,54,1.000000,'LINE_ISSUE',25,'2026-10-24 09:57:04');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (134,6,5,55,2.000000,'LINE_ISSUE',25,'2026-10-24 09:57:04');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (135,6,6,56,1.000000,'LINE_ISSUE',25,'2026-10-24 09:57:04');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (136,6,7,57,1.000000,'LINE_ISSUE',25,'2026-10-24 09:57:04');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (137,6,8,58,1.000000,'LINE_ISSUE',25,'2026-10-24 09:57:04');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (138,6,9,59,1.000000,'LINE_ISSUE',25,'2026-10-24 09:57:04');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (139,6,10,60,4.000000,'LINE_ISSUE',25,'2026-10-24 09:57:04');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (140,6,11,61,1.000000,'LINE_ISSUE',25,'2026-10-24 09:57:04');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (141,6,12,62,1.000000,'LINE_ISSUE',25,'2026-10-24 09:57:04');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (142,6,13,63,1.000000,'LINE_ISSUE',25,'2026-10-24 09:57:04');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (143,6,2,26,-1.000000,'CONSUME',19,'2026-10-24 09:57:05');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (144,6,3,53,-1.000000,'CONSUME',19,'2026-10-24 09:57:05');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (145,6,4,54,-1.000000,'CONSUME',19,'2026-10-24 09:57:05');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (146,6,5,55,-2.000000,'CONSUME',19,'2026-10-24 09:57:05');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (147,6,6,56,-1.000000,'CONSUME',19,'2026-10-24 09:57:05');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (148,6,7,57,-1.000000,'CONSUME',19,'2026-10-24 09:57:05');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (149,6,8,58,-1.000000,'CONSUME',19,'2026-10-24 09:57:05');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (150,6,9,59,-1.000000,'CONSUME',19,'2026-10-24 09:57:05');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (151,6,10,60,-4.000000,'CONSUME',19,'2026-10-24 09:57:05');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (152,6,11,61,-1.000000,'CONSUME',19,'2026-10-24 09:57:05');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (153,6,12,62,-1.000000,'CONSUME',19,'2026-10-24 09:57:05');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (154,6,13,63,-1.000000,'CONSUME',19,'2026-10-24 09:57:05');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (155,6,16,64,1.000000,'OUTPUT',22,'2026-10-24 09:57:05');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (156,6,16,64,-1.000000,'RECEIPT',17,'2026-10-24 09:57:05');
/*!40000 ALTER TABLE `mm_line_movement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_line_stock`
--

DROP TABLE IF EXISTS `mm_line_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_line_stock` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `lot_id` bigint NOT NULL,
  `quantity` decimal(18,6) NOT NULL DEFAULT '0.000000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_line` (`work_order_id`,`material_id`,`lot_id`),
  CONSTRAINT `mm_line_stock_chk_1` CHECK ((`quantity` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_line_stock`
--

LOCK TABLES `mm_line_stock` WRITE;
/*!40000 ALTER TABLE `mm_line_stock` DISABLE KEYS */;
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (1,1,2,1,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (2,1,2,13,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (3,1,3,2,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (4,1,3,14,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (5,1,4,3,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (6,1,4,15,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (7,1,5,4,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (8,1,5,16,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (9,1,6,5,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (10,1,6,17,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (11,1,7,6,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (12,1,7,18,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (13,1,8,7,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (14,1,8,19,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (15,1,9,8,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (16,1,9,20,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (17,1,10,9,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (18,1,10,21,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (19,1,11,10,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (20,1,11,22,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (21,1,12,11,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (22,1,12,23,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (23,1,13,12,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (24,1,13,24,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (26,1,16,25,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (27,3,4,27,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (28,3,5,28,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (29,3,6,29,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (30,3,7,30,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (31,3,14,31,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (32,4,2,26,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (33,4,3,32,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (34,4,8,33,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (35,4,9,34,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (36,4,10,35,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (37,4,15,36,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (38,2,11,37,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (39,2,12,38,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (40,2,13,39,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (41,2,14,31,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (42,2,15,36,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (43,2,16,40,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (44,5,2,26,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (45,5,3,41,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (46,5,4,42,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (47,5,5,43,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (48,5,6,44,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (49,5,7,45,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (50,5,8,46,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (51,5,9,47,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (52,5,10,48,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (53,5,11,49,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (54,5,12,50,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (55,5,13,51,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (56,5,16,52,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (57,6,2,26,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (58,6,3,53,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (59,6,4,54,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (60,6,5,55,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (61,6,6,56,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (62,6,7,57,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (63,6,8,58,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (64,6,9,59,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (65,6,10,60,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (66,6,11,61,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (67,6,12,62,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (68,6,13,63,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (69,6,16,64,0.000000);
/*!40000 ALTER TABLE `mm_line_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_location`
--

DROP TABLE IF EXISTS `mm_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_location` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `area_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `x_coordinate` int DEFAULT NULL,
  `y_coordinate` int DEFAULT NULL,
  `z_coordinate` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_location`
--

LOCK TABLES `mm_location` WRITE;
/*!40000 ALTER TABLE `mm_location` DISABLE KEYS */;
INSERT INTO `mm_location` (`id`, `code`, `name`, `area_id`, `created_at`, `x_coordinate`, `y_coordinate`, `z_coordinate`) VALUES (1,'WH-A100-RM-01','一号库位',1,'2026-10-19 00:41:54',NULL,NULL,NULL);
INSERT INTO `mm_location` (`id`, `code`, `name`, `area_id`, `created_at`, `x_coordinate`, `y_coordinate`, `z_coordinate`) VALUES (2,'WH-A100-LINE-01','一号库位',2,'2026-10-19 00:41:54',NULL,NULL,NULL);
INSERT INTO `mm_location` (`id`, `code`, `name`, `area_id`, `created_at`, `x_coordinate`, `y_coordinate`, `z_coordinate`) VALUES (3,'WH-A100-FG-01','一号库位',3,'2026-10-19 00:41:54',NULL,NULL,NULL);
/*!40000 ALTER TABLE `mm_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_member`
--

DROP TABLE IF EXISTS `mm_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_member` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `team_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `team_id` (`team_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_member`
--

LOCK TABLES `mm_member` WRITE;
/*!40000 ALTER TABLE `mm_member` DISABLE KEYS */;
INSERT INTO `mm_member` (`id`, `team_id`, `user_id`, `created_at`) VALUES (1,1,1,'2026-10-19 00:41:54');
INSERT INTO `mm_member` (`id`, `team_id`, `user_id`, `created_at`) VALUES (2,2,4,'2026-10-24 01:56:50');
INSERT INTO `mm_member` (`id`, `team_id`, `user_id`, `created_at`) VALUES (3,3,12,'2026-10-24 01:56:58');
/*!40000 ALTER TABLE `mm_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_menu`
--

DROP TABLE IF EXISTS `mm_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_menu` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `path` varchar(200) NOT NULL,
  `parent_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_menu`
--

LOCK TABLES `mm_menu` WRITE;
/*!40000 ALTER TABLE `mm_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_nc`
--

DROP TABLE IF EXISTS `mm_nc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_nc` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `inspection_id` bigint NOT NULL,
  `task_id` bigint DEFAULT NULL,
  `defect_id` bigint DEFAULT NULL,
  `quantity` decimal(18,2) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'OPEN',
  `decision` varchar(20) DEFAULT NULL,
  `reason` varchar(500) DEFAULT NULL,
  `approved_by` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inspection_id` (`inspection_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_nc`
--

LOCK TABLES `mm_nc` WRITE;
/*!40000 ALTER TABLE `mm_nc` DISABLE KEYS */;
INSERT INTO `mm_nc` (`id`, `inspection_id`, `task_id`, `defect_id`, `quantity`, `status`, `decision`, `reason`, `approved_by`, `created_at`) VALUES (1,1,2,NULL,100.00,'CLOSED','REWORK','重新校准后返工',5,'2026-10-24 09:56:54');
/*!40000 ALTER TABLE `mm_nc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_notice`
--

DROP TABLE IF EXISTS `mm_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_notice` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `kind` varchar(20) NOT NULL,
  `target_role` bigint DEFAULT NULL,
  `published_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` datetime DEFAULT NULL,
  `actor_id` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_notice`
--

LOCK TABLES `mm_notice` WRITE;
/*!40000 ALTER TABLE `mm_notice` DISABLE KEYS */;
INSERT INTO `mm_notice` (`id`, `title`, `content`, `kind`, `target_role`, `published_at`, `expires_at`, `actor_id`) VALUES (1,'隔离公告095646861401','真实持久化公告','info',3,'2026-10-24 09:56:56',NULL,1);
/*!40000 ALTER TABLE `mm_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_notice_read`
--

DROP TABLE IF EXISTS `mm_notice_read`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_notice_read` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `notice_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `read_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_read` (`notice_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_notice_read`
--

LOCK TABLES `mm_notice_read` WRITE;
/*!40000 ALTER TABLE `mm_notice_read` DISABLE KEYS */;
INSERT INTO `mm_notice_read` (`id`, `notice_id`, `user_id`, `read_at`) VALUES (1,1,4,'2026-10-24 09:56:56');
/*!40000 ALTER TABLE `mm_notice_read` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_operation`
--

DROP TABLE IF EXISTS `mm_operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_operation` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `route_id` bigint NOT NULL,
  `sequence_no` int NOT NULL,
  `station_id` bigint NOT NULL,
  `predecessor_id` bigint DEFAULT NULL,
  `standard_minutes` decimal(10,2) NOT NULL,
  `requires_qc` int NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_key` int NOT NULL DEFAULT '0',
  `output_material_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `route_id` (`route_id`,`sequence_no`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_operation`
--

LOCK TABLES `mm_operation` WRITE;
/*!40000 ALTER TABLE `mm_operation` DISABLE KEYS */;
INSERT INTO `mm_operation` (`id`, `code`, `name`, `route_id`, `sequence_no`, `station_id`, `predecessor_id`, `standard_minutes`, `requires_qc`, `created_at`, `is_key`, `output_material_id`) VALUES (1,'OP-A100-1','电子装配站',1,10,5,NULL,2.00,1,'2026-10-19 00:41:54',0,NULL);
INSERT INTO `mm_operation` (`id`, `code`, `name`, `route_id`, `sequence_no`, `station_id`, `predecessor_id`, `standard_minutes`, `requires_qc`, `created_at`, `is_key`, `output_material_id`) VALUES (2,'OP-A100-2','结构装配站',1,20,5,NULL,2.00,1,'2026-10-19 00:41:54',0,NULL);
INSERT INTO `mm_operation` (`id`, `code`, `name`, `route_id`, `sequence_no`, `station_id`, `predecessor_id`, `standard_minutes`, `requires_qc`, `created_at`, `is_key`, `output_material_id`) VALUES (3,'OP-A100-3','总装测试站',1,30,5,2,2.00,1,'2026-10-19 00:41:54',0,NULL);
INSERT INTO `mm_operation` (`id`, `code`, `name`, `route_id`, `sequence_no`, `station_id`, `predecessor_id`, `standard_minutes`, `requires_qc`, `created_at`, `is_key`, `output_material_id`) VALUES (4,'OP-A100-4','贴标包装站',1,40,5,3,2.00,1,'2026-10-19 00:41:54',1,NULL);
INSERT INTO `mm_operation` (`id`, `code`, `name`, `route_id`, `sequence_no`, `station_id`, `predecessor_id`, `standard_minutes`, `requires_qc`, `created_at`, `is_key`, `output_material_id`) VALUES (5,'MC-SO-15-095646861401','半成品制造',2,10,5,NULL,1.00,1,'2026-10-24 01:56:58',1,NULL);
INSERT INTO `mm_operation` (`id`, `code`, `name`, `route_id`, `sequence_no`, `station_id`, `predecessor_id`, `standard_minutes`, `requires_qc`, `created_at`, `is_key`, `output_material_id`) VALUES (6,'MC-SO-14-095646861401','半成品制造',3,10,5,NULL,1.00,1,'2026-10-24 01:56:59',1,NULL);
/*!40000 ALTER TABLE `mm_operation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_package`
--

DROP TABLE IF EXISTS `mm_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_package` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(80) NOT NULL,
  `customer_id` bigint DEFAULT NULL,
  `order_id` bigint DEFAULT NULL,
  `length_mm` decimal(18,2) NOT NULL,
  `width_mm` decimal(18,2) NOT NULL,
  `height_mm` decimal(18,2) NOT NULL,
  `net_weight` decimal(18,2) NOT NULL,
  `gross_weight` decimal(18,2) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'DRAFT',
  `parent_id` bigint DEFAULT NULL,
  `created_by` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_package`
--

LOCK TABLES `mm_package` WRITE;
/*!40000 ALTER TABLE `mm_package` DISABLE KEYS */;
INSERT INTO `mm_package` (`id`, `code`, `customer_id`, `order_id`, `length_mm`, `width_mm`, `height_mm`, `net_weight`, `gross_weight`, `status`, `parent_id`, `created_by`) VALUES (1,'PKG-000001',NULL,NULL,100.00,100.00,100.00,1.00,2.00,'CONFIRMED',2,6);
INSERT INTO `mm_package` (`id`, `code`, `customer_id`, `order_id`, `length_mm`, `width_mm`, `height_mm`, `net_weight`, `gross_weight`, `status`, `parent_id`, `created_by`) VALUES (2,'PKG-000002',NULL,NULL,100.00,100.00,100.00,1.00,2.00,'CONFIRMED',NULL,6);
/*!40000 ALTER TABLE `mm_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_package_item`
--

DROP TABLE IF EXISTS `mm_package_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_package_item` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `package_id` bigint NOT NULL,
  `inventory_id` bigint NOT NULL,
  `quantity` decimal(18,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_package_item` (`package_id`,`inventory_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_package_item`
--

LOCK TABLES `mm_package_item` WRITE;
/*!40000 ALTER TABLE `mm_package_item` DISABLE KEYS */;
INSERT INTO `mm_package_item` (`id`, `package_id`, `inventory_id`, `quantity`) VALUES (1,1,50,4.00);
/*!40000 ALTER TABLE `mm_package_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_parameter`
--

DROP TABLE IF EXISTS `mm_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_parameter` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_parameter`
--

LOCK TABLES `mm_parameter` WRITE;
/*!40000 ALTER TABLE `mm_parameter` DISABLE KEYS */;
INSERT INTO `mm_parameter` (`id`, `code`, `name`, `value`) VALUES (1,'APP_NAME','系统显示名称','Mouse MES');
INSERT INTO `mm_parameter` (`id`, `code`, `name`, `value`) VALUES (2,'NOTICE_LIMIT','公告最多显示条数','200');
INSERT INTO `mm_parameter` (`id`, `code`, `name`, `value`) VALUES (3,'DEFAULT_DURATION_MINUTES','默认任务时长（分钟）','60');
/*!40000 ALTER TABLE `mm_parameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_position`
--

DROP TABLE IF EXISTS `mm_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_position` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `department_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_position`
--

LOCK TABLES `mm_position` WRITE;
/*!40000 ALTER TABLE `mm_position` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_product_material`
--

DROP TABLE IF EXISTS `mm_product_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_product_material` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`),
  UNIQUE KEY `material_id` (`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_product_material`
--

LOCK TABLES `mm_product_material` WRITE;
/*!40000 ALTER TABLE `mm_product_material` DISABLE KEYS */;
INSERT INTO `mm_product_material` (`id`, `product_id`, `material_id`, `created_at`) VALUES (1,6,16,'2026-10-19 00:41:54');
INSERT INTO `mm_product_material` (`id`, `product_id`, `material_id`, `created_at`) VALUES (2,7,15,'2026-10-24 01:56:58');
INSERT INTO `mm_product_material` (`id`, `product_id`, `material_id`, `created_at`) VALUES (3,8,14,'2026-10-24 01:56:59');
/*!40000 ALTER TABLE `mm_product_material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_qc_item`
--

DROP TABLE IF EXISTS `mm_qc_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_qc_item` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `standard` varchar(500) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_type` varchar(20) NOT NULL DEFAULT 'TEXT',
  `lower_limit` decimal(18,6) DEFAULT NULL,
  `upper_limit` decimal(18,6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_qc_item`
--

LOCK TABLES `mm_qc_item` WRITE;
/*!40000 ALTER TABLE `mm_qc_item` DISABLE KEYS */;
INSERT INTO `mm_qc_item` (`id`, `code`, `name`, `standard`, `created_at`, `data_type`, `lower_limit`, `upper_limit`) VALUES (1,'QC-VISUAL','外观装配','零件完整、无明显裂纹','2026-10-19 00:41:54','TEXT',NULL,NULL);
INSERT INTO `mm_qc_item` (`id`, `code`, `name`, `standard`, `created_at`, `data_type`, `lower_limit`, `upper_limit`) VALUES (2,'QC-USB','USB识别','连接后可识别输入设备','2026-10-19 00:41:54','TEXT',NULL,NULL);
INSERT INTO `mm_qc_item` (`id`, `code`, `name`, `standard`, `created_at`, `data_type`, `lower_limit`, `upper_limit`) VALUES (3,'QC-KEY','按键滚轮','左右键与滚轮均有响应','2026-10-19 00:41:54','TEXT',NULL,NULL);
INSERT INTO `mm_qc_item` (`id`, `code`, `name`, `standard`, `created_at`, `data_type`, `lower_limit`, `upper_limit`) VALUES (4,'QC-MOVE','指针移动','测试面移动可产生指针响应','2026-10-19 00:41:54','TEXT',NULL,NULL);
INSERT INTO `mm_qc_item` (`id`, `code`, `name`, `standard`, `created_at`, `data_type`, `lower_limit`, `upper_limit`) VALUES (5,'MC-QC-095646861401','数值检验','0至10','2026-10-24 01:56:49','NUMBER',0.000000,10.000000);
/*!40000 ALTER TABLE `mm_qc_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_qc_line`
--

DROP TABLE IF EXISTS `mm_qc_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_qc_line` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `template_id` bigint NOT NULL,
  `item_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_id` (`template_id`,`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_qc_line`
--

LOCK TABLES `mm_qc_line` WRITE;
/*!40000 ALTER TABLE `mm_qc_line` DISABLE KEYS */;
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (1,3,3,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (2,2,3,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (3,1,3,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (4,3,4,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (5,2,4,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (6,1,4,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (7,3,2,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (8,2,2,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (9,1,2,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (10,3,1,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (11,2,1,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (12,1,1,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (13,4,5,'2026-10-24 01:56:49');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (14,5,5,'2026-10-24 01:56:49');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (15,6,5,'2026-10-24 01:56:49');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (16,7,5,'2026-10-24 01:56:49');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (17,8,5,'2026-10-24 01:56:59');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (18,9,5,'2026-10-24 01:56:59');
/*!40000 ALTER TABLE `mm_qc_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_qc_template`
--

DROP TABLE IF EXISTS `mm_qc_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_qc_template` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `product_id` bigint NOT NULL,
  `kind` varchar(30) NOT NULL,
  `version` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operation_id` bigint DEFAULT NULL,
  `phase` varchar(20) NOT NULL DEFAULT 'FINAL',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_qc_template`
--

LOCK TABLES `mm_qc_template` WRITE;
/*!40000 ALTER TABLE `mm_qc_template` DISABLE KEYS */;
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (1,'QC-A100-INCOMING','A100来料检测模板',6,'INCOMING','1.0','2026-10-19 00:41:54',NULL,'FINAL');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (2,'QC-A100-PROCESS','A100过程检测模板',6,'PROCESS','1.0','2026-10-19 00:41:54',NULL,'FINAL');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (3,'QC-A100-SHIPPING','A100出货检测模板',6,'SHIPPING','1.0','2026-10-19 00:41:54',NULL,'FINAL');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (4,'MC-T-095646861401-1','电子装配站专用检验',6,'PROCESS','1','2026-10-24 01:56:49',1,'FINAL');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (5,'MC-T-095646861401-2','结构装配站专用检验',6,'PROCESS','1','2026-10-24 01:56:49',2,'FINAL');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (6,'MC-T-095646861401-3','总装测试站专用检验',6,'PROCESS','1','2026-10-24 01:56:49',3,'FINAL');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (7,'MC-T-095646861401-4','贴标包装站专用检验',6,'PROCESS','1','2026-10-24 01:56:49',4,'FINAL');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (8,'MC-SQ-15-095646861401','半成品最终检验',7,'PROCESS','1','2026-10-24 01:56:59',5,'FINAL');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (9,'MC-SQ-14-095646861401','半成品最终检验',8,'PROCESS','1','2026-10-24 01:56:59',6,'FINAL');
/*!40000 ALTER TABLE `mm_qc_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_qc_todo`
--

DROP TABLE IF EXISTS `mm_qc_todo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_qc_todo` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `event_id` bigint DEFAULT NULL,
  `task_id` bigint NOT NULL,
  `work_order_id` bigint NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'WAITING',
  `inspection_id` bigint DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `completed_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_id` (`task_id`),
  UNIQUE KEY `event_id` (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_qc_todo`
--

LOCK TABLES `mm_qc_todo` WRITE;
/*!40000 ALTER TABLE `mm_qc_todo` DISABLE KEYS */;
INSERT INTO `mm_qc_todo` (`id`, `event_id`, `task_id`, `work_order_id`, `status`, `inspection_id`, `created_at`, `completed_at`) VALUES (1,2,3,1,'DONE',3,'2026-10-24 09:56:55.268642','2026-10-24 09:56:55.277330');
/*!40000 ALTER TABLE `mm_qc_todo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_query_audit`
--

DROP TABLE IF EXISTS `mm_query_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_query_audit` (
  `id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` bigint NOT NULL,
  `session_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `question` varchar(1200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `mode` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `filters` json DEFAULT NULL,
  `input_tokens` int NOT NULL DEFAULT '0',
  `output_tokens` int NOT NULL DEFAULT '0',
  `elapsed_ms` bigint NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_query_audit`
--

LOCK TABLES `mm_query_audit` WRITE;
/*!40000 ALTER TABLE `mm_query_audit` DISABLE KEYS */;
INSERT INTO `mm_query_audit` (`id`, `user_id`, `session_id`, `question`, `mode`, `status`, `filters`, `input_tokens`, `output_tokens`, `elapsed_ms`, `created_at`) VALUES ('2e9dfb16-ae6b-4ffb-8f88-263a35e8c358',1,'2a1e9996-b2b1-4c5b-b82a-e7fd1fda5fad','当前微动开关库存','local','SUCCEEDED','{\"kind\": \"INVENTORY\", \"material\": \"5\"}',0,0,11,'2026-10-23 23:35:17');
INSERT INTO `mm_query_audit` (`id`, `user_id`, `session_id`, `question`, `mode`, `status`, `filters`, `input_tokens`, `output_tokens`, `elapsed_ms`, `created_at`) VALUES ('4264f7dc-23ee-4338-a236-f71c725fd046',1,'7ba9a8a9-d4e8-4c7b-9b69-148b09245174','本月微动开关库存','local','SUCCEEDED','{\"to\": \"2026-10-23\", \"from\": \"2026-10-01\", \"kind\": \"INVENTORY\", \"material\": \"5\"}',0,0,16,'2026-10-23 23:24:51');
/*!40000 ALTER TABLE `mm_query_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_replenishment`
--

DROP TABLE IF EXISTS `mm_replenishment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_replenishment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `material_id` bigint NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'SUGGESTED',
  `confirmed_by` bigint DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `material_id` (`material_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_replenishment`
--

LOCK TABLES `mm_replenishment` WRITE;
/*!40000 ALTER TABLE `mm_replenishment` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_replenishment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_rework`
--

DROP TABLE IF EXISTS `mm_rework`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_rework` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nc_id` bigint NOT NULL,
  `task_id` bigint NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'PENDING',
  `result` varchar(500) DEFAULT NULL,
  `completed_by` bigint DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nc_id` (`nc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_rework`
--

LOCK TABLES `mm_rework` WRITE;
/*!40000 ALTER TABLE `mm_rework` DISABLE KEYS */;
INSERT INTO `mm_rework` (`id`, `nc_id`, `task_id`, `status`, `result`, `completed_by`, `completed_at`) VALUES (1,1,2,'DONE','隔离验收：完成返工',4,'2026-10-24 09:56:55');
/*!40000 ALTER TABLE `mm_rework` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_role_menu`
--

DROP TABLE IF EXISTS `mm_role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_role_menu` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `role_id` bigint NOT NULL,
  `menu_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_menu` (`role_id`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_role_menu`
--

LOCK TABLES `mm_role_menu` WRITE;
/*!40000 ALTER TABLE `mm_role_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_role_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_rotation`
--

DROP TABLE IF EXISTS `mm_rotation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_rotation` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `station_id` bigint NOT NULL,
  `cycle_days` int NOT NULL DEFAULT '1',
  `cycle_unit` varchar(20) NOT NULL DEFAULT 'DAY',
  `mode` varchar(20) NOT NULL,
  `is_generated` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_rotation`
--

LOCK TABLES `mm_rotation` WRITE;
/*!40000 ALTER TABLE `mm_rotation` DISABLE KEYS */;
INSERT INTO `mm_rotation` (`id`, `code`, `name`, `start_date`, `end_date`, `station_id`, `cycle_days`, `cycle_unit`, `mode`, `is_generated`) VALUES (1,'MC-ROT-095646861401','隔离两班倒','2032-01-10','2032-01-10',5,1,'DAY','TWO',1);
/*!40000 ALTER TABLE `mm_rotation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_rotation_shift`
--

DROP TABLE IF EXISTS `mm_rotation_shift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_rotation_shift` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `rotation_id` bigint NOT NULL,
  `shift_id` bigint NOT NULL,
  `sequence_no` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rotation_shift` (`rotation_id`,`shift_id`),
  UNIQUE KEY `uq_rotation_shift_sequence` (`rotation_id`,`sequence_no`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_rotation_shift`
--

LOCK TABLES `mm_rotation_shift` WRITE;
/*!40000 ALTER TABLE `mm_rotation_shift` DISABLE KEYS */;
INSERT INTO `mm_rotation_shift` (`id`, `rotation_id`, `shift_id`, `sequence_no`) VALUES (1,1,2,1);
INSERT INTO `mm_rotation_shift` (`id`, `rotation_id`, `shift_id`, `sequence_no`) VALUES (2,1,3,2);
/*!40000 ALTER TABLE `mm_rotation_shift` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_rotation_team`
--

DROP TABLE IF EXISTS `mm_rotation_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_rotation_team` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `rotation_id` bigint NOT NULL,
  `team_id` bigint NOT NULL,
  `sequence_no` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rotation_team` (`rotation_id`,`team_id`),
  UNIQUE KEY `uq_rotation_seq` (`rotation_id`,`sequence_no`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_rotation_team`
--

LOCK TABLES `mm_rotation_team` WRITE;
/*!40000 ALTER TABLE `mm_rotation_team` DISABLE KEYS */;
INSERT INTO `mm_rotation_team` (`id`, `rotation_id`, `team_id`, `sequence_no`) VALUES (1,1,2,1);
INSERT INTO `mm_rotation_team` (`id`, `rotation_id`, `team_id`, `sequence_no`) VALUES (2,1,3,2);
/*!40000 ALTER TABLE `mm_rotation_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_route`
--

DROP TABLE IF EXISTS `mm_route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_route` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `product_id` bigint NOT NULL,
  `version` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_route`
--

LOCK TABLES `mm_route` WRITE;
/*!40000 ALTER TABLE `mm_route` DISABLE KEYS */;
INSERT INTO `mm_route` (`id`, `code`, `name`, `product_id`, `version`, `created_at`) VALUES (1,'ROUTE-A100-V1','A100装配工艺',6,'1.0','2026-10-19 00:41:54');
INSERT INTO `mm_route` (`id`, `code`, `name`, `product_id`, `version`, `created_at`) VALUES (2,'MC-SR-15-095646861401','隔离半成品路线',7,'1','2026-10-24 01:56:58');
INSERT INTO `mm_route` (`id`, `code`, `name`, `product_id`, `version`, `created_at`) VALUES (3,'MC-SR-14-095646861401','隔离半成品路线',8,'1','2026-10-24 01:56:59');
/*!40000 ALTER TABLE `mm_route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_schedule`
--

DROP TABLE IF EXISTS `mm_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_schedule` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `team_id` bigint NOT NULL,
  `shift_id` bigint NOT NULL,
  `station_id` bigint NOT NULL,
  `equipment_id` bigint DEFAULT NULL,
  `start_at` datetime NOT NULL,
  `end_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `start_at` (`start_at`,`end_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_schedule`
--

LOCK TABLES `mm_schedule` WRITE;
/*!40000 ALTER TABLE `mm_schedule` DISABLE KEYS */;
INSERT INTO `mm_schedule` (`id`, `team_id`, `shift_id`, `station_id`, `equipment_id`, `start_at`, `end_at`, `created_at`) VALUES (1,2,1,5,2,'2026-10-24 08:56:50','2026-10-24 15:56:50','2026-10-24 01:56:50');
INSERT INTO `mm_schedule` (`id`, `team_id`, `shift_id`, `station_id`, `equipment_id`, `start_at`, `end_at`, `created_at`) VALUES (2,2,2,5,2,'2032-01-10 08:00:00','2032-01-10 20:00:00','2026-10-24 01:56:58');
INSERT INTO `mm_schedule` (`id`, `team_id`, `shift_id`, `station_id`, `equipment_id`, `start_at`, `end_at`, `created_at`) VALUES (3,3,3,5,2,'2032-01-10 20:00:00','2032-01-11 08:00:00','2026-10-24 01:56:58');
/*!40000 ALTER TABLE `mm_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_shift`
--

DROP TABLE IF EXISTS `mm_shift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_shift` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_shift`
--

LOCK TABLES `mm_shift` WRITE;
/*!40000 ALTER TABLE `mm_shift` DISABLE KEYS */;
INSERT INTO `mm_shift` (`id`, `code`, `name`, `start_time`, `end_time`, `created_at`) VALUES (1,'DAY','白班','08:00:00','17:00:00','2026-10-19 00:41:54');
INSERT INTO `mm_shift` (`id`, `code`, `name`, `start_time`, `end_time`, `created_at`) VALUES (2,'MC-DAY-095646861401','验收日班','08:00:00','20:00:00','2026-10-24 01:56:58');
INSERT INTO `mm_shift` (`id`, `code`, `name`, `start_time`, `end_time`, `created_at`) VALUES (3,'MC-NIGHT-095646861401','验收夜班','20:00:00','08:00:00','2026-10-24 01:56:58');
/*!40000 ALTER TABLE `mm_shift` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_sop`
--

DROP TABLE IF EXISTS `mm_sop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_sop` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `product_id` bigint NOT NULL,
  `operation_id` bigint NOT NULL,
  `version` varchar(32) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `enabled` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_sop`
--

LOCK TABLES `mm_sop` WRITE;
/*!40000 ALTER TABLE `mm_sop` DISABLE KEYS */;
INSERT INTO `mm_sop` (`id`, `code`, `name`, `product_id`, `operation_id`, `version`, `image_path`, `enabled`) VALUES (1,'MC-SOP-095646861401','隔离上传验收图',6,1,'1','/api/mes/sop-images/80a43902-32d1-4572-b387-67e32cc02292.png',1);
/*!40000 ALTER TABLE `mm_sop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_station`
--

DROP TABLE IF EXISTS `mm_station`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_station` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `workshop_id` bigint NOT NULL,
  `equipment_id` bigint DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_station`
--

LOCK TABLES `mm_station` WRITE;
/*!40000 ALTER TABLE `mm_station` DISABLE KEYS */;
INSERT INTO `mm_station` (`id`, `code`, `name`, `workshop_id`, `equipment_id`, `created_at`) VALUES (1,'ST-A100-1','电子装配站',1,NULL,'2026-10-19 00:41:54');
INSERT INTO `mm_station` (`id`, `code`, `name`, `workshop_id`, `equipment_id`, `created_at`) VALUES (2,'ST-A100-2','结构装配站',1,NULL,'2026-10-19 00:41:54');
INSERT INTO `mm_station` (`id`, `code`, `name`, `workshop_id`, `equipment_id`, `created_at`) VALUES (3,'ST-A100-3','总装测试站',1,1,'2026-10-19 00:41:54');
INSERT INTO `mm_station` (`id`, `code`, `name`, `workshop_id`, `equipment_id`, `created_at`) VALUES (4,'ST-A100-4','贴标包装站',1,NULL,'2026-10-19 00:41:54');
INSERT INTO `mm_station` (`id`, `code`, `name`, `workshop_id`, `equipment_id`, `created_at`) VALUES (5,'MC-ST-095646861401','隔离生产工作站',2,2,'2026-10-24 01:56:49');
/*!40000 ALTER TABLE `mm_station` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_station_resource`
--

DROP TABLE IF EXISTS `mm_station_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_station_resource` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `station_id` bigint NOT NULL,
  `resource_type` varchar(20) NOT NULL,
  `equipment_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_station_resource`
--

LOCK TABLES `mm_station_resource` WRITE;
/*!40000 ALTER TABLE `mm_station_resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_station_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_stock_posting`
--

DROP TABLE IF EXISTS `mm_stock_posting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_stock_posting` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `kind` varchar(30) NOT NULL,
  `source_id` bigint NOT NULL,
  `document_id` bigint NOT NULL,
  `document_no` varchar(80) NOT NULL,
  `warehouse_id` bigint NOT NULL,
  `location_id` bigint DEFAULT NULL,
  `quantity` decimal(14,2) NOT NULL,
  `actor_id` bigint NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kind` (`kind`,`source_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_stock_posting`
--

LOCK TABLES `mm_stock_posting` WRITE;
/*!40000 ALTER TABLE `mm_stock_posting` DISABLE KEYS */;
INSERT INTO `mm_stock_posting` (`id`, `kind`, `source_id`, `document_id`, `document_no`, `warehouse_id`, `location_id`, `quantity`, `actor_id`, `created_at`) VALUES (1,'ISSUE',1,1,'ISS-000001',2,NULL,100.00,6,'2026-10-24 09:56:53');
INSERT INTO `mm_stock_posting` (`id`, `kind`, `source_id`, `document_id`, `document_no`, `warehouse_id`, `location_id`, `quantity`, `actor_id`, `created_at`) VALUES (2,'RECEIPT',3,9,'FG-IN-000003',4,4,10.00,6,'2026-10-24 09:57:00');
INSERT INTO `mm_stock_posting` (`id`, `kind`, `source_id`, `document_id`, `document_no`, `warehouse_id`, `location_id`, `quantity`, `actor_id`, `created_at`) VALUES (3,'RECEIPT',4,11,'FG-IN-000004',4,4,10.00,6,'2026-10-24 09:57:01');
INSERT INTO `mm_stock_posting` (`id`, `kind`, `source_id`, `document_id`, `document_no`, `warehouse_id`, `location_id`, `quantity`, `actor_id`, `created_at`) VALUES (4,'RECEIPT',2,13,'FG-IN-000005',4,4,10.00,6,'2026-10-24 09:57:02');
INSERT INTO `mm_stock_posting` (`id`, `kind`, `source_id`, `document_id`, `document_no`, `warehouse_id`, `location_id`, `quantity`, `actor_id`, `created_at`) VALUES (5,'RECEIPT',5,15,'FG-IN-000006',4,4,1.00,6,'2026-10-24 09:57:04');
INSERT INTO `mm_stock_posting` (`id`, `kind`, `source_id`, `document_id`, `document_no`, `warehouse_id`, `location_id`, `quantity`, `actor_id`, `created_at`) VALUES (6,'RECEIPT',6,17,'FG-IN-000007',4,4,1.00,6,'2026-10-24 09:57:05');
/*!40000 ALTER TABLE `mm_stock_posting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_task_consumption`
--

DROP TABLE IF EXISTS `mm_task_consumption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_task_consumption` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `operation_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `quantity_per_unit` decimal(18,6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_consume` (`operation_id`,`material_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_task_consumption`
--

LOCK TABLES `mm_task_consumption` WRITE;
/*!40000 ALTER TABLE `mm_task_consumption` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_task_consumption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_task_context`
--

DROP TABLE IF EXISTS `mm_task_context`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_task_context` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `task_id` bigint NOT NULL,
  `work_order_id` bigint NOT NULL,
  `operation_id` bigint NOT NULL,
  `sequence_no` int NOT NULL,
  `predecessor_id` bigint DEFAULT NULL,
  `requires_qc` int NOT NULL,
  `is_terminal` int NOT NULL,
  `station_id` bigint NOT NULL,
  `schedule_id` bigint DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_id` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_task_context`
--

LOCK TABLES `mm_task_context` WRITE;
/*!40000 ALTER TABLE `mm_task_context` DISABLE KEYS */;
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (1,2,1,1,10,NULL,1,0,5,1,'2026-10-24 01:56:50');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (2,3,1,2,20,NULL,1,0,5,1,'2026-10-24 01:56:50');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (3,4,1,3,30,2,1,0,5,1,'2026-10-24 01:56:50');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (4,5,1,4,40,3,1,1,5,1,'2026-10-24 01:56:50');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (5,6,2,1,10,NULL,1,0,5,1,'2026-10-24 01:56:59');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (6,7,2,2,20,NULL,1,0,5,1,'2026-10-24 01:56:59');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (7,8,2,3,30,2,1,0,5,1,'2026-10-24 01:56:59');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (8,9,2,4,40,3,1,1,5,1,'2026-10-24 01:56:59');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (9,10,3,6,10,NULL,1,1,5,1,'2026-10-24 01:56:59');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (10,11,4,5,10,NULL,1,1,5,1,'2026-10-24 01:56:59');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (11,12,2,1,10,NULL,1,0,5,1,'2026-10-24 01:56:59');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (12,13,5,1,10,NULL,1,0,5,1,'2026-10-24 01:57:02');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (13,14,5,2,20,NULL,1,0,5,1,'2026-10-24 01:57:02');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (14,15,5,3,30,2,1,0,5,1,'2026-10-24 01:57:02');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (15,16,5,4,40,3,1,1,5,1,'2026-10-24 01:57:02');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (16,17,6,1,10,NULL,1,0,5,1,'2026-10-24 01:57:02');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (17,18,6,2,20,NULL,1,0,5,1,'2026-10-24 01:57:02');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (18,19,6,3,30,2,1,0,5,1,'2026-10-24 01:57:02');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (19,20,6,4,40,3,1,1,5,1,'2026-10-24 01:57:02');
/*!40000 ALTER TABLE `mm_task_context` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_task_slot`
--

DROP TABLE IF EXISTS `mm_task_slot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_task_slot` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `task_id` bigint NOT NULL,
  `station_id` bigint NOT NULL,
  `owner_id` bigint NOT NULL,
  `start_at` datetime NOT NULL,
  `end_at` datetime NOT NULL,
  `quantity` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_id` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_task_slot`
--

LOCK TABLES `mm_task_slot` WRITE;
/*!40000 ALTER TABLE `mm_task_slot` DISABLE KEYS */;
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (1,2,5,4,'2026-10-24 09:55:54','2026-10-24 10:56:54',100);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (2,3,5,4,'2026-10-24 09:55:55','2026-10-24 10:56:55',100);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (3,4,5,4,'2026-10-24 09:55:55','2026-10-24 10:56:55',100);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (4,5,5,4,'2026-10-24 09:55:55','2026-10-24 10:56:55',100);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (5,10,5,4,'2026-10-24 09:56:00','2026-10-24 10:57:00',10);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (6,11,5,4,'2026-10-24 09:56:01','2026-10-24 10:57:01',10);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (7,6,5,4,'2026-10-24 09:56:02','2026-10-24 10:57:02',6);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (8,12,5,4,'2026-10-24 09:56:02','2026-10-24 10:57:02',4);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (9,7,5,4,'2026-10-24 09:56:02','2026-10-24 10:57:02',10);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (10,8,5,4,'2026-10-24 09:56:02','2026-10-24 10:57:02',10);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (11,9,5,4,'2026-10-24 09:56:02','2026-10-24 10:57:02',10);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (12,13,5,4,'2026-10-24 09:56:04','2026-10-24 10:57:04',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (13,14,5,4,'2026-10-24 09:56:04','2026-10-24 10:57:04',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (14,15,5,4,'2026-10-24 09:56:04','2026-10-24 10:57:04',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (15,16,5,4,'2026-10-24 09:56:04','2026-10-24 10:57:04',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (16,17,5,4,'2026-10-24 09:56:05','2026-10-24 10:57:05',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (17,18,5,4,'2026-10-24 09:56:05','2026-10-24 10:57:05',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (18,19,5,4,'2026-10-24 09:56:05','2026-10-24 10:57:05',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (19,20,5,4,'2026-10-24 09:56:06','2026-10-24 10:57:06',1);
/*!40000 ALTER TABLE `mm_task_slot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_team`
--

DROP TABLE IF EXISTS `mm_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_team` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `leader_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_team`
--

LOCK TABLES `mm_team` WRITE;
/*!40000 ALTER TABLE `mm_team` DISABLE KEYS */;
INSERT INTO `mm_team` (`id`, `code`, `name`, `leader_id`, `created_at`) VALUES (1,'TEAM-A100','A100装配一班',1,'2026-10-19 00:41:54');
INSERT INTO `mm_team` (`id`, `code`, `name`, `leader_id`, `created_at`) VALUES (2,'MC-TEAM-095646861401','验收班组',4,'2026-10-24 01:56:49');
INSERT INTO `mm_team` (`id`, `code`, `name`, `leader_id`, `created_at`) VALUES (3,'MC-TEAM2-095646861401','第二验收班组',12,'2026-10-24 01:56:58');
/*!40000 ALTER TABLE `mm_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_user_position`
--

DROP TABLE IF EXISTS `mm_user_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_user_position` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `position_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_position` (`user_id`,`position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_user_position`
--

LOCK TABLES `mm_user_position` WRITE;
/*!40000 ALTER TABLE `mm_user_position` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_user_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_work_consumption`
--

DROP TABLE IF EXISTS `mm_work_consumption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_work_consumption` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `operation_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `quantity_per_unit` decimal(18,6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_work_consume` (`work_order_id`,`operation_id`,`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_work_consumption`
--

LOCK TABLES `mm_work_consumption` WRITE;
/*!40000 ALTER TABLE `mm_work_consumption` DISABLE KEYS */;
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (1,1,1,4,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (2,1,1,5,2.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (3,1,1,6,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (4,1,1,7,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (5,1,1,2,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (6,1,1,3,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (7,1,1,8,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (8,1,1,9,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (9,1,1,10,4.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (10,1,1,11,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (11,1,1,12,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (12,1,1,13,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (25,2,1,11,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (26,2,1,12,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (27,2,1,13,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (28,2,1,14,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (29,2,1,15,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (30,3,6,4,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (31,3,6,5,2.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (32,3,6,6,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (33,3,6,7,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (34,4,5,2,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (35,4,5,3,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (36,4,5,8,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (37,4,5,9,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (38,4,5,10,4.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (39,5,1,2,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (40,5,1,3,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (41,5,1,4,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (42,5,1,5,2.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (43,5,1,6,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (44,5,1,7,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (45,5,1,8,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (46,5,1,9,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (47,5,1,10,4.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (48,5,1,11,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (49,5,1,12,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (50,5,1,13,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (51,6,1,2,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (52,6,1,3,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (53,6,1,4,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (54,6,1,5,2.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (55,6,1,6,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (56,6,1,7,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (57,6,1,8,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (58,6,1,9,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (59,6,1,10,4.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (60,6,1,11,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (61,6,1,12,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (62,6,1,13,1.000000);
/*!40000 ALTER TABLE `mm_work_consumption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_work_material`
--

DROP TABLE IF EXISTS `mm_work_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_work_material` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `material_code` varchar(60) NOT NULL,
  `material_name` varchar(100) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `required_quantity` decimal(14,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `work_order_id` (`work_order_id`,`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_work_material`
--

LOCK TABLES `mm_work_material` WRITE;
/*!40000 ALTER TABLE `mm_work_material` DISABLE KEYS */;
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (1,1,4,'MAT-PCB-A100','PCB主板','块',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (2,1,5,'MAT-SWITCH-01','微动开关','个',200.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (3,1,6,'MAT-ENCODER-01','滚轮编码器','个',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (4,1,7,'MAT-USB-CABLE-A100','USB连接线','根',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (5,1,2,'MAT-SHELL-TOP-A100','鼠标上盖','个',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (6,1,3,'MAT-SHELL-BOTTOM-A100','鼠标下盖','个',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (7,1,8,'MAT-WHEEL-A100','滚轮组件','个',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (8,1,9,'MAT-LENS-A100','光学透镜','个',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (9,1,10,'MAT-SCREW-A100','固定螺钉','颗',400.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (10,1,11,'MAT-FEET-A100','防滑脚贴','套',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (11,1,12,'MAT-LABEL-A100','产品铭牌','张',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (12,1,13,'MAT-BOX-A100','包装盒','个',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (25,2,11,'MAT-FEET-A100','防滑脚贴','套',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (26,2,12,'MAT-LABEL-A100','产品铭牌','张',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (27,2,13,'MAT-BOX-A100','包装盒','个',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (28,2,14,'MAT-SEMI-E-A100','A100电子组件','个',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (29,2,15,'MAT-SEMI-S-A100','A100结构组件','个',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (30,3,4,'MAT-PCB-A100','PCB主板','块',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (31,3,5,'MAT-SWITCH-01','微动开关','个',20.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (32,3,6,'MAT-ENCODER-01','滚轮编码器','个',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (33,3,7,'MAT-USB-CABLE-A100','USB连接线','根',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (34,4,2,'MAT-SHELL-TOP-A100','鼠标上盖','个',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (35,4,3,'MAT-SHELL-BOTTOM-A100','鼠标下盖','个',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (36,4,8,'MAT-WHEEL-A100','滚轮组件','个',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (37,4,9,'MAT-LENS-A100','光学透镜','个',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (38,4,10,'MAT-SCREW-A100','固定螺钉','颗',40.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (39,5,11,'MAT-FEET-A100','防滑脚贴','套',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (40,5,12,'MAT-LABEL-A100','产品铭牌','张',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (41,5,13,'MAT-BOX-A100','包装盒','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (42,5,4,'MAT-PCB-A100','PCB主板','块',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (43,5,5,'MAT-SWITCH-01','微动开关','个',2.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (44,5,6,'MAT-ENCODER-01','滚轮编码器','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (45,5,7,'MAT-USB-CABLE-A100','USB连接线','根',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (46,5,2,'MAT-SHELL-TOP-A100','鼠标上盖','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (47,5,3,'MAT-SHELL-BOTTOM-A100','鼠标下盖','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (48,5,8,'MAT-WHEEL-A100','滚轮组件','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (49,5,9,'MAT-LENS-A100','光学透镜','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (50,5,10,'MAT-SCREW-A100','固定螺钉','颗',4.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (51,6,11,'MAT-FEET-A100','防滑脚贴','套',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (52,6,12,'MAT-LABEL-A100','产品铭牌','张',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (53,6,13,'MAT-BOX-A100','包装盒','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (54,6,4,'MAT-PCB-A100','PCB主板','块',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (55,6,5,'MAT-SWITCH-01','微动开关','个',2.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (56,6,6,'MAT-ENCODER-01','滚轮编码器','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (57,6,7,'MAT-USB-CABLE-A100','USB连接线','根',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (58,6,2,'MAT-SHELL-TOP-A100','鼠标上盖','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (59,6,3,'MAT-SHELL-BOTTOM-A100','鼠标下盖','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (60,6,8,'MAT-WHEEL-A100','滚轮组件','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (61,6,9,'MAT-LENS-A100','光学透镜','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (62,6,10,'MAT-SCREW-A100','固定螺钉','颗',4.00);
/*!40000 ALTER TABLE `mm_work_material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_work_order`
--

DROP TABLE IF EXISTS `mm_work_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_work_order` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(80) NOT NULL,
  `plan_id` bigint NOT NULL,
  `bom_id` bigint NOT NULL,
  `route_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  `bom_snapshot` json NOT NULL,
  `route_snapshot` json NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'CREATED',
  `created_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `plan_id` (`plan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_work_order`
--

LOCK TABLES `mm_work_order` WRITE;
/*!40000 ALTER TABLE `mm_work_order` DISABLE KEYS */;
INSERT INTO `mm_work_order` (`id`, `code`, `plan_id`, `bom_id`, `route_id`, `quantity`, `bom_snapshot`, `route_snapshot`, `status`, `created_by`, `created_at`) VALUES (1,'MO-000001',8,1,1,100,'[{\"id\": 1, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 14, \"parent_material_id\": 16}, {\"id\": 2, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 15, \"parent_material_id\": 16}, {\"id\": 3, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 2, \"parent_material_id\": 15}, {\"id\": 4, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 3, \"parent_material_id\": 15}, {\"id\": 5, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 4, \"parent_material_id\": 14}, {\"id\": 6, \"bom_id\": 1, \"quantity\": 2.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 5, \"parent_material_id\": 14}, {\"id\": 7, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 6, \"parent_material_id\": 14}, {\"id\": 8, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 7, \"parent_material_id\": 14}, {\"id\": 9, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 8, \"parent_material_id\": 15}, {\"id\": 10, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 9, \"parent_material_id\": 15}, {\"id\": 11, \"bom_id\": 1, \"quantity\": 4.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 10, \"parent_material_id\": 15}, {\"id\": 12, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 11, \"parent_material_id\": 16}, {\"id\": 13, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 12, \"parent_material_id\": 16}, {\"id\": 14, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 13, \"parent_material_id\": 16}]','[{\"id\": 1, \"code\": \"OP-A100-1\", \"name\": \"电子装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 10, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 2, \"code\": \"OP-A100-2\", \"name\": \"结构装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 20, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 3, \"code\": \"OP-A100-3\", \"name\": \"总装测试站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 30, \"predecessor_id\": 2, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 4, \"code\": \"OP-A100-4\", \"name\": \"贴标包装站\", \"is_key\": 1, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 40, \"predecessor_id\": 3, \"standard_minutes\": 2.0, \"output_material_id\": null}]','PRODUCTION_COMPLETED',1,'2026-10-24 01:56:50');
INSERT INTO `mm_work_order` (`id`, `code`, `plan_id`, `bom_id`, `route_id`, `quantity`, `bom_snapshot`, `route_snapshot`, `status`, `created_by`, `created_at`) VALUES (2,'MO-000003',9,1,1,10,'[{\"id\": 5, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 4, \"parent_material_id\": 14}, {\"id\": 6, \"bom_id\": 1, \"quantity\": 2.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 5, \"parent_material_id\": 14}, {\"id\": 7, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 6, \"parent_material_id\": 14}, {\"id\": 8, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 7, \"parent_material_id\": 14}, {\"id\": 3, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 2, \"parent_material_id\": 15}, {\"id\": 4, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 3, \"parent_material_id\": 15}, {\"id\": 9, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 8, \"parent_material_id\": 15}, {\"id\": 10, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 9, \"parent_material_id\": 15}, {\"id\": 11, \"bom_id\": 1, \"quantity\": 4.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 10, \"parent_material_id\": 15}, {\"id\": 12, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 11, \"parent_material_id\": 16}, {\"id\": 13, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 12, \"parent_material_id\": 16}, {\"id\": 14, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 13, \"parent_material_id\": 16}, {\"id\": 1, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 14, \"parent_material_id\": 16}, {\"id\": 2, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 15, \"parent_material_id\": 16}]','[{\"id\": 1, \"code\": \"OP-A100-1\", \"name\": \"电子装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 10, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 2, \"code\": \"OP-A100-2\", \"name\": \"结构装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 20, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 3, \"code\": \"OP-A100-3\", \"name\": \"总装测试站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 30, \"predecessor_id\": 2, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 4, \"code\": \"OP-A100-4\", \"name\": \"贴标包装站\", \"is_key\": 1, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 40, \"predecessor_id\": 3, \"standard_minutes\": 2.0, \"output_material_id\": null}]','PRODUCTION_COMPLETED',1,'2026-10-24 01:56:59');
INSERT INTO `mm_work_order` (`id`, `code`, `plan_id`, `bom_id`, `route_id`, `quantity`, `bom_snapshot`, `route_snapshot`, `status`, `created_by`, `created_at`) VALUES (3,'MO-000005',10,3,3,10,'[{\"id\": 23, \"bom_id\": 3, \"quantity\": 1.0, \"created_at\": \"2026-10-24 09:56:59\", \"material_id\": 4, \"parent_material_id\": 14}, {\"id\": 22, \"bom_id\": 3, \"quantity\": 2.0, \"created_at\": \"2026-10-24 09:56:59\", \"material_id\": 5, \"parent_material_id\": 14}, {\"id\": 21, \"bom_id\": 3, \"quantity\": 1.0, \"created_at\": \"2026-10-24 09:56:59\", \"material_id\": 6, \"parent_material_id\": 14}, {\"id\": 20, \"bom_id\": 3, \"quantity\": 1.0, \"created_at\": \"2026-10-24 09:56:59\", \"material_id\": 7, \"parent_material_id\": 14}]','[{\"id\": 6, \"code\": \"MC-SO-14-095646861401\", \"name\": \"半成品制造\", \"is_key\": 1, \"route_id\": 3, \"created_at\": \"2026-10-24 09:56:59\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 10, \"predecessor_id\": null, \"standard_minutes\": 1.0, \"output_material_id\": null}]','PRODUCTION_COMPLETED',1,'2026-10-24 01:56:59');
INSERT INTO `mm_work_order` (`id`, `code`, `plan_id`, `bom_id`, `route_id`, `quantity`, `bom_snapshot`, `route_snapshot`, `status`, `created_by`, `created_at`) VALUES (4,'MO-000007',11,2,2,10,'[{\"id\": 19, \"bom_id\": 2, \"quantity\": 1.0, \"created_at\": \"2026-10-24 09:56:58\", \"material_id\": 2, \"parent_material_id\": 15}, {\"id\": 18, \"bom_id\": 2, \"quantity\": 1.0, \"created_at\": \"2026-10-24 09:56:58\", \"material_id\": 3, \"parent_material_id\": 15}, {\"id\": 17, \"bom_id\": 2, \"quantity\": 1.0, \"created_at\": \"2026-10-24 09:56:58\", \"material_id\": 8, \"parent_material_id\": 15}, {\"id\": 16, \"bom_id\": 2, \"quantity\": 1.0, \"created_at\": \"2026-10-24 09:56:58\", \"material_id\": 9, \"parent_material_id\": 15}, {\"id\": 15, \"bom_id\": 2, \"quantity\": 4.0, \"created_at\": \"2026-10-24 09:56:58\", \"material_id\": 10, \"parent_material_id\": 15}]','[{\"id\": 5, \"code\": \"MC-SO-15-095646861401\", \"name\": \"半成品制造\", \"is_key\": 1, \"route_id\": 2, \"created_at\": \"2026-10-24 09:56:58\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 10, \"predecessor_id\": null, \"standard_minutes\": 1.0, \"output_material_id\": null}]','PRODUCTION_COMPLETED',1,'2026-10-24 01:56:59');
INSERT INTO `mm_work_order` (`id`, `code`, `plan_id`, `bom_id`, `route_id`, `quantity`, `bom_snapshot`, `route_snapshot`, `status`, `created_by`, `created_at`) VALUES (5,'MO-000009',12,1,1,1,'[{\"id\": 5, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 4, \"parent_material_id\": 14}, {\"id\": 6, \"bom_id\": 1, \"quantity\": 2.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 5, \"parent_material_id\": 14}, {\"id\": 7, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 6, \"parent_material_id\": 14}, {\"id\": 8, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 7, \"parent_material_id\": 14}, {\"id\": 3, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 2, \"parent_material_id\": 15}, {\"id\": 4, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 3, \"parent_material_id\": 15}, {\"id\": 9, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 8, \"parent_material_id\": 15}, {\"id\": 10, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 9, \"parent_material_id\": 15}, {\"id\": 11, \"bom_id\": 1, \"quantity\": 4.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 10, \"parent_material_id\": 15}, {\"id\": 12, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 11, \"parent_material_id\": 16}, {\"id\": 13, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 12, \"parent_material_id\": 16}, {\"id\": 14, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 13, \"parent_material_id\": 16}, {\"id\": 1, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 14, \"parent_material_id\": 16}, {\"id\": 2, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 15, \"parent_material_id\": 16}]','[{\"id\": 1, \"code\": \"OP-A100-1\", \"name\": \"电子装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 10, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 2, \"code\": \"OP-A100-2\", \"name\": \"结构装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 20, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 3, \"code\": \"OP-A100-3\", \"name\": \"总装测试站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 30, \"predecessor_id\": 2, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 4, \"code\": \"OP-A100-4\", \"name\": \"贴标包装站\", \"is_key\": 1, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 40, \"predecessor_id\": 3, \"standard_minutes\": 2.0, \"output_material_id\": null}]','PRODUCTION_COMPLETED',1,'2026-10-24 01:57:02');
INSERT INTO `mm_work_order` (`id`, `code`, `plan_id`, `bom_id`, `route_id`, `quantity`, `bom_snapshot`, `route_snapshot`, `status`, `created_by`, `created_at`) VALUES (6,'MO-000011',13,1,1,1,'[{\"id\": 5, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 4, \"parent_material_id\": 14}, {\"id\": 6, \"bom_id\": 1, \"quantity\": 2.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 5, \"parent_material_id\": 14}, {\"id\": 7, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 6, \"parent_material_id\": 14}, {\"id\": 8, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 7, \"parent_material_id\": 14}, {\"id\": 3, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 2, \"parent_material_id\": 15}, {\"id\": 4, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 3, \"parent_material_id\": 15}, {\"id\": 9, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 8, \"parent_material_id\": 15}, {\"id\": 10, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 9, \"parent_material_id\": 15}, {\"id\": 11, \"bom_id\": 1, \"quantity\": 4.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 10, \"parent_material_id\": 15}, {\"id\": 12, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 11, \"parent_material_id\": 16}, {\"id\": 13, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 12, \"parent_material_id\": 16}, {\"id\": 14, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 13, \"parent_material_id\": 16}, {\"id\": 1, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 14, \"parent_material_id\": 16}, {\"id\": 2, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 15, \"parent_material_id\": 16}]','[{\"id\": 1, \"code\": \"OP-A100-1\", \"name\": \"电子装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 10, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 2, \"code\": \"OP-A100-2\", \"name\": \"结构装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 20, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 3, \"code\": \"OP-A100-3\", \"name\": \"总装测试站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 30, \"predecessor_id\": 2, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 4, \"code\": \"OP-A100-4\", \"name\": \"贴标包装站\", \"is_key\": 1, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 40, \"predecessor_id\": 3, \"standard_minutes\": 2.0, \"output_material_id\": null}]','PRODUCTION_COMPLETED',1,'2026-10-24 01:57:02');
/*!40000 ALTER TABLE `mm_work_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_work_output`
--

DROP TABLE IF EXISTS `mm_work_output`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_work_output` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `operation_id` bigint NOT NULL,
  `material_id` bigint DEFAULT NULL,
  `is_key` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_work_output` (`work_order_id`,`operation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_work_output`
--

LOCK TABLES `mm_work_output` WRITE;
/*!40000 ALTER TABLE `mm_work_output` DISABLE KEYS */;
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (1,1,1,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (2,1,2,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (3,1,3,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (4,1,4,16,1);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (9,2,1,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (10,2,2,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (11,2,3,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (12,2,4,16,1);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (13,3,6,14,1);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (14,4,5,15,1);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (15,5,1,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (16,5,2,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (17,5,3,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (18,5,4,16,1);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (19,6,1,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (20,6,2,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (21,6,3,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (22,6,4,16,1);
/*!40000 ALTER TABLE `mm_work_output` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_work_product`
--

DROP TABLE IF EXISTS `mm_work_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_work_product` (
  `work_order_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  PRIMARY KEY (`work_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_work_product`
--

LOCK TABLES `mm_work_product` WRITE;
/*!40000 ALTER TABLE `mm_work_product` DISABLE KEYS */;
INSERT INTO `mm_work_product` (`work_order_id`, `material_id`, `quantity`) VALUES (1,16,100);
INSERT INTO `mm_work_product` (`work_order_id`, `material_id`, `quantity`) VALUES (2,16,10);
INSERT INTO `mm_work_product` (`work_order_id`, `material_id`, `quantity`) VALUES (3,14,10);
INSERT INTO `mm_work_product` (`work_order_id`, `material_id`, `quantity`) VALUES (4,15,10);
INSERT INTO `mm_work_product` (`work_order_id`, `material_id`, `quantity`) VALUES (5,16,1);
INSERT INTO `mm_work_product` (`work_order_id`, `material_id`, `quantity`) VALUES (6,16,1);
/*!40000 ALTER TABLE `mm_work_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_work_relation`
--

DROP TABLE IF EXISTS `mm_work_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_work_relation` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `parent_work_order_id` bigint NOT NULL,
  `child_work_order_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `child_work_order_id` (`child_work_order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_work_relation`
--

LOCK TABLES `mm_work_relation` WRITE;
/*!40000 ALTER TABLE `mm_work_relation` DISABLE KEYS */;
INSERT INTO `mm_work_relation` (`id`, `parent_work_order_id`, `child_work_order_id`, `material_id`) VALUES (1,2,3,14);
INSERT INTO `mm_work_relation` (`id`, `parent_work_order_id`, `child_work_order_id`, `material_id`) VALUES (2,2,4,15);
/*!40000 ALTER TABLE `mm_work_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_workshop`
--

DROP TABLE IF EXISTS `mm_workshop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_workshop` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_workshop`
--

LOCK TABLES `mm_workshop` WRITE;
/*!40000 ALTER TABLE `mm_workshop` DISABLE KEYS */;
INSERT INTO `mm_workshop` (`id`, `code`, `name`, `created_at`) VALUES (1,'WS-A100','鼠标装配车间','2026-10-19 00:41:54');
INSERT INTO `mm_workshop` (`id`, `code`, `name`, `created_at`) VALUES (2,'MC-WS-095646861401','隔离验收车间','2026-10-24 01:56:49');
/*!40000 ALTER TABLE `mm_workshop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_attendance`
--

DROP TABLE IF EXISTS `t_attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_attendance` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '考勤ID',
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `user_name` varchar(50) NOT NULL COMMENT '用户姓名',
  `attendance_date` date NOT NULL COMMENT '考勤日期',
  `check_in_time` datetime DEFAULT NULL COMMENT '签到时间',
  `check_out_time` datetime DEFAULT NULL COMMENT '签退时间',
  `work_hours` decimal(5,2) DEFAULT NULL COMMENT '工时',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='考勤记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_attendance`
--

LOCK TABLES `t_attendance` WRITE;
/*!40000 ALTER TABLE `t_attendance` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_bom`
--

DROP TABLE IF EXISTS `t_bom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_bom` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'BOM ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `material_name` varchar(100) NOT NULL COMMENT '物料名称',
  `quantity` decimal(10,2) NOT NULL COMMENT '用量',
  `unit` varchar(20) NOT NULL COMMENT '单位',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='BOM表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_bom`
--

LOCK TABLES `t_bom` WRITE;
/*!40000 ALTER TABLE `t_bom` DISABLE KEYS */;
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (25,8,4,'PCB主板',1.00,'块','BOM版本 1');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (26,8,5,'微动开关',2.00,'个','BOM版本 1');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (27,8,6,'滚轮编码器',1.00,'个','BOM版本 1');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (28,8,7,'USB连接线',1.00,'根','BOM版本 1');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (29,7,2,'鼠标上盖',1.00,'个','BOM版本 1');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (30,7,3,'鼠标下盖',1.00,'个','BOM版本 1');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (31,7,8,'滚轮组件',1.00,'个','BOM版本 1');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (32,7,9,'光学透镜',1.00,'个','BOM版本 1');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (33,7,10,'固定螺钉',4.00,'颗','BOM版本 1');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (46,6,11,'防滑脚贴',1.00,'套','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (47,6,12,'产品铭牌',1.00,'张','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (48,6,13,'包装盒',1.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (49,6,4,'PCB主板',1.00,'块','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (50,6,5,'微动开关',2.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (51,6,6,'滚轮编码器',1.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (52,6,7,'USB连接线',1.00,'根','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (53,6,2,'鼠标上盖',1.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (54,6,3,'鼠标下盖',1.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (55,6,8,'滚轮组件',1.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (56,6,9,'光学透镜',1.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (57,6,10,'固定螺钉',4.00,'颗','BOM版本 1.0');
/*!40000 ALTER TABLE `t_bom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_bom_item`
--

DROP TABLE IF EXISTS `t_bom_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_bom_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'BOM明细ID',
  `bom_id` bigint NOT NULL COMMENT 'BOM ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `quantity` decimal(10,2) NOT NULL COMMENT '用量',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='BOM明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_bom_item`
--

LOCK TABLES `t_bom_item` WRITE;
/*!40000 ALTER TABLE `t_bom_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_bom_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_customer`
--

DROP TABLE IF EXISTS `t_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_customer` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '客户ID',
  `customer_code` varchar(50) NOT NULL COMMENT '客户编码',
  `customer_name` varchar(100) NOT NULL COMMENT '客户名称',
  `contact_person` varchar(50) DEFAULT NULL COMMENT '联系人',
  `phone` varchar(20) DEFAULT NULL COMMENT '电话',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `address` varchar(255) DEFAULT NULL COMMENT '地址',
  `status` varchar(30) NOT NULL DEFAULT '1' COMMENT '状态',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_code` (`customer_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='客户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_customer`
--

LOCK TABLES `t_customer` WRITE;
/*!40000 ALTER TABLE `t_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_department`
--

DROP TABLE IF EXISTS `t_department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_department` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '部门ID',
  `parent_id` bigint NOT NULL DEFAULT '0' COMMENT '父部门ID',
  `dept_name` varchar(50) NOT NULL COMMENT '部门名称',
  `dept_code` varchar(50) NOT NULL COMMENT '部门编码',
  `leader_id` bigint DEFAULT NULL COMMENT '负责人ID',
  `leader_name` varchar(50) DEFAULT NULL COMMENT '负责人姓名',
  `sort` int NOT NULL DEFAULT '0' COMMENT '显示顺序',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：-1删除 0禁用 1活跃',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='部门表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_department`
--

LOCK TABLES `t_department` WRITE;
/*!40000 ALTER TABLE `t_department` DISABLE KEYS */;
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (1,0,'总经办','CEO',NULL,NULL,1,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (2,0,'生产部','PROD',NULL,NULL,2,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (3,0,'质检部','QC',NULL,NULL,3,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (4,0,'仓储部','WAREHOUSE',NULL,NULL,4,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (5,0,'采购部','PURCHASE',NULL,NULL,5,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (6,0,'销售部','SALES',NULL,NULL,6,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (7,0,'设备部','EQUIPMENT',NULL,NULL,7,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (8,0,'财务部','FINANCE',NULL,NULL,8,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (9,0,'人力资源部','HR',NULL,NULL,9,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
/*!40000 ALTER TABLE `t_department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_dict`
--

DROP TABLE IF EXISTS `t_dict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_dict` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '字典ID',
  `dict_name` varchar(100) NOT NULL COMMENT '字典名称',
  `dict_type` varchar(100) NOT NULL COMMENT '字典类型',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0禁用 1启用',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `dict_type` (`dict_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='字典类型表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_dict`
--

LOCK TABLES `t_dict` WRITE;
/*!40000 ALTER TABLE `t_dict` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_dict` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_dict_item`
--

DROP TABLE IF EXISTS `t_dict_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_dict_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '字典数据ID',
  `dict_type` varchar(100) NOT NULL COMMENT '字典类型',
  `item_label` varchar(100) NOT NULL COMMENT '字典标签',
  `item_value` varchar(100) NOT NULL COMMENT '字典值',
  `sort` int NOT NULL DEFAULT '0' COMMENT '显示顺序',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0禁用 1启用',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='字典数据表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_dict_item`
--

LOCK TABLES `t_dict_item` WRITE;
/*!40000 ALTER TABLE `t_dict_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_dict_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_equipment`
--

DROP TABLE IF EXISTS `t_equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_equipment` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '设备ID',
  `equipment_code` varchar(50) NOT NULL COMMENT '设备编码',
  `equipment_name` varchar(100) NOT NULL COMMENT '设备名称',
  `equipment_type` varchar(50) DEFAULT NULL COMMENT '设备类型',
  `model` varchar(50) DEFAULT NULL COMMENT '型号',
  `manufacturer` varchar(100) DEFAULT NULL COMMENT '厂商',
  `purchase_date` date DEFAULT NULL COMMENT '购置日期',
  `purchase_price` decimal(12,2) DEFAULT '0.00' COMMENT '购置价格',
  `warranty_period` int DEFAULT NULL COMMENT '保修期',
  `location` varchar(100) DEFAULT NULL COMMENT '设备位置',
  `status` varchar(30) NOT NULL DEFAULT 'NORMAL' COMMENT '状态：NORMAL正常 REPAIR_REQUESTED报修中 REPAIRING维修中 REPAIRED已维修 SCRAPPED报废',
  `responsible_id` bigint DEFAULT NULL COMMENT '负责人ID',
  `responsible_name` varchar(50) DEFAULT NULL COMMENT '负责人姓名',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `equipment_code` (`equipment_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='设备表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_equipment`
--

LOCK TABLES `t_equipment` WRITE;
/*!40000 ALTER TABLE `t_equipment` DISABLE KEYS */;
INSERT INTO `t_equipment` (`id`, `equipment_code`, `equipment_name`, `equipment_type`, `model`, `manufacturer`, `purchase_date`, `purchase_price`, `warranty_period`, `location`, `status`, `responsible_id`, `responsible_name`, `remark`, `create_time`, `update_time`, `is_deleted`) VALUES (1,'EQ-A100-01','A100功能测试台',NULL,'USB测试台',NULL,NULL,0.00,NULL,'总装测试站','NORMAL',NULL,NULL,NULL,'2026-10-19 08:41:54','2026-10-24 09:56:39',0);
INSERT INTO `t_equipment` (`id`, `equipment_code`, `equipment_name`, `equipment_type`, `model`, `manufacturer`, `purchase_date`, `purchase_price`, `warranty_period`, `location`, `status`, `responsible_id`, `responsible_name`, `remark`, `create_time`, `update_time`, `is_deleted`) VALUES (2,'MC-EQ-095646861401','隔离设备',NULL,'TEST',NULL,NULL,0.00,NULL,'隔离车间','NORMAL',NULL,NULL,NULL,'2026-10-24 09:56:49','2026-10-24 09:56:58',0);
/*!40000 ALTER TABLE `t_equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_inventory`
--

DROP TABLE IF EXISTS `t_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_inventory` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '库存ID',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `location_id` bigint DEFAULT NULL COMMENT '库位ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_id` bigint DEFAULT NULL COMMENT '批次ID',
  `quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '库存数量',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '最后更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='库存表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_inventory`
--

LOCK TABLES `t_inventory` WRITE;
/*!40000 ALTER TABLE `t_inventory` DISABLE KEYS */;
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (1,2,2,2,1,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (2,2,2,3,2,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (3,2,2,4,3,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (4,2,2,5,4,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (5,2,2,6,5,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (6,2,2,7,6,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (7,2,2,8,7,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (8,2,2,9,8,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (9,2,2,10,9,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (10,2,2,11,10,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (11,2,2,12,11,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (12,2,2,13,12,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (13,2,2,2,13,0.00,'2026-10-24 09:56:55',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (14,2,2,3,14,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (15,2,2,4,15,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (16,2,2,5,16,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (17,2,2,6,17,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (18,2,2,7,18,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (19,2,2,8,19,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (20,2,2,9,20,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (21,2,2,10,21,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (22,2,2,11,22,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (23,2,2,12,23,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (24,2,2,13,24,0.00,'2026-10-24 09:56:53',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (25,3,3,2,1,0.00,'2026-10-24 09:56:54',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (26,3,3,2,13,0.00,'2026-10-24 09:56:55',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (27,3,3,3,2,0.00,'2026-10-24 09:56:54',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (28,3,3,3,14,0.00,'2026-10-24 09:56:55',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (29,3,3,4,3,0.00,'2026-10-24 09:56:54',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (30,3,3,4,15,0.00,'2026-10-24 09:56:55',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (31,3,3,5,4,0.00,'2026-10-24 09:56:54',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (32,3,3,5,16,0.00,'2026-10-24 09:56:55',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (33,3,3,6,5,0.00,'2026-10-24 09:56:54',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (34,3,3,6,17,0.00,'2026-10-24 09:56:55',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (35,3,3,7,6,0.00,'2026-10-24 09:56:54',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (36,3,3,7,18,0.00,'2026-10-24 09:56:55',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (37,3,3,8,7,0.00,'2026-10-24 09:56:54',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (38,3,3,8,19,0.00,'2026-10-24 09:56:55',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (39,3,3,9,8,0.00,'2026-10-24 09:56:54',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (40,3,3,9,20,0.00,'2026-10-24 09:56:55',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (41,3,3,10,9,0.00,'2026-10-24 09:56:54',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (42,3,3,10,21,0.00,'2026-10-24 09:56:55',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (43,3,3,11,10,0.00,'2026-10-24 09:56:54',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (44,3,3,11,22,0.00,'2026-10-24 09:56:55',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (45,3,3,12,11,0.00,'2026-10-24 09:56:54',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (46,3,3,12,23,0.00,'2026-10-24 09:56:55',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (47,3,3,13,12,0.00,'2026-10-24 09:56:54',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (48,3,3,13,24,0.00,'2026-10-24 09:56:55',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (49,3,3,16,25,0.00,'2026-10-24 09:56:56',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (50,4,4,16,25,10.00,'2026-10-24 09:56:57',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (51,2,2,2,26,3.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (52,2,2,4,27,0.00,'2026-10-24 09:57:00',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (53,2,2,5,28,0.00,'2026-10-24 09:57:00',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (54,2,2,6,29,0.00,'2026-10-24 09:57:00',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (55,2,2,7,30,0.00,'2026-10-24 09:57:00',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (56,3,3,4,27,0.00,'2026-10-24 09:57:00',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (57,3,3,5,28,0.00,'2026-10-24 09:57:00',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (58,3,3,6,29,0.00,'2026-10-24 09:57:00',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (59,3,3,7,30,0.00,'2026-10-24 09:57:00',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (60,3,3,14,31,0.00,'2026-10-24 09:57:02',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (61,4,4,14,31,0.00,'2026-10-24 09:57:02',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (62,2,2,3,32,0.00,'2026-10-24 09:57:01',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (63,2,2,8,33,0.00,'2026-10-24 09:57:01',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (64,2,2,9,34,0.00,'2026-10-24 09:57:01',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (65,2,2,10,35,0.00,'2026-10-24 09:57:01',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (66,3,3,2,26,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (67,3,3,3,32,0.00,'2026-10-24 09:57:01',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (68,3,3,8,33,0.00,'2026-10-24 09:57:01',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (69,3,3,9,34,0.00,'2026-10-24 09:57:01',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (70,3,3,10,35,0.00,'2026-10-24 09:57:01',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (71,3,3,15,36,0.00,'2026-10-24 09:57:02',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (72,4,4,15,36,0.00,'2026-10-24 09:57:02',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (73,2,2,11,37,0.00,'2026-10-24 09:57:02',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (74,2,2,12,38,0.00,'2026-10-24 09:57:02',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (75,2,2,13,39,0.00,'2026-10-24 09:57:02',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (76,3,3,11,37,0.00,'2026-10-24 09:57:02',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (77,3,3,12,38,0.00,'2026-10-24 09:57:02',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (78,3,3,13,39,0.00,'2026-10-24 09:57:02',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (79,3,3,16,40,0.00,'2026-10-24 09:57:03',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (80,4,4,16,40,10.00,'2026-10-24 09:57:03',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (81,2,2,3,41,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (82,2,2,4,42,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (83,2,2,5,43,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (84,2,2,6,44,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (85,2,2,7,45,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (86,2,2,8,46,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (87,2,2,9,47,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (88,2,2,10,48,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (89,2,2,11,49,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (90,2,2,12,50,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (91,2,2,13,51,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (92,3,3,3,41,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (93,3,3,4,42,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (94,3,3,5,43,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (95,3,3,6,44,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (96,3,3,7,45,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (97,3,3,8,46,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (98,3,3,9,47,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (99,3,3,10,48,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (100,3,3,11,49,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (101,3,3,12,50,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (102,3,3,13,51,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (103,3,3,16,52,0.00,'2026-10-24 09:57:04',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (104,4,4,16,52,0.00,'2026-10-24 09:57:06',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (105,2,2,3,53,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (106,2,2,4,54,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (107,2,2,5,55,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (108,2,2,6,56,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (109,2,2,7,57,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (110,2,2,8,58,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (111,2,2,9,59,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (112,2,2,10,60,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (113,2,2,11,61,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (114,2,2,12,62,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (115,2,2,13,63,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (116,3,3,3,53,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (117,3,3,4,54,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (118,3,3,5,55,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (119,3,3,6,56,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (120,3,3,7,57,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (121,3,3,8,58,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (122,3,3,9,59,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (123,3,3,10,60,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (124,3,3,11,61,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (125,3,3,12,62,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (126,3,3,13,63,0.00,'2026-10-24 09:57:05',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (127,3,3,16,64,0.00,'2026-10-24 09:57:06',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (128,4,4,16,64,0.00,'2026-10-24 09:57:06',0);
/*!40000 ALTER TABLE `t_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_inventory_in`
--

DROP TABLE IF EXISTS `t_inventory_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_inventory_in` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '入库单ID',
  `in_no` varchar(50) NOT NULL COMMENT '入库单号',
  `in_type` tinyint NOT NULL COMMENT '入库类型',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `material_name` varchar(100) NOT NULL COMMENT '物料名称',
  `quantity` int NOT NULL COMMENT '入库数量',
  `unit_price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '总金额',
  `supplier_id` bigint DEFAULT NULL COMMENT '供应商ID',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `in_date` date NOT NULL COMMENT '入库日期',
  `create_by` bigint NOT NULL COMMENT '操作人ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `in_no` (`in_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='入库单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_inventory_in`
--

LOCK TABLES `t_inventory_in` WRITE;
/*!40000 ALTER TABLE `t_inventory_in` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_inventory_in` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_inventory_out`
--

DROP TABLE IF EXISTS `t_inventory_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_inventory_out` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '出库单ID',
  `out_no` varchar(50) NOT NULL COMMENT '出库单号',
  `out_type` tinyint NOT NULL COMMENT '出库类型',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `material_name` varchar(100) NOT NULL COMMENT '物料名称',
  `quantity` int NOT NULL COMMENT '出库数量',
  `unit_price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '总金额',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `out_date` date NOT NULL COMMENT '出库日期',
  `create_by` bigint NOT NULL COMMENT '操作人ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `out_no` (`out_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='出库单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_inventory_out`
--

LOCK TABLES `t_inventory_out` WRITE;
/*!40000 ALTER TABLE `t_inventory_out` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_inventory_out` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_inventory_transaction`
--

DROP TABLE IF EXISTS `t_inventory_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_inventory_transaction` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '库存流水ID',
  `transaction_no` varchar(80) NOT NULL COMMENT '库存流水编号',
  `transaction_type` varchar(10) NOT NULL COMMENT '流水方向：IN入库 OUT出库',
  `business_type` varchar(30) DEFAULT NULL COMMENT '业务类型',
  `source_order_id` bigint DEFAULT NULL COMMENT '来源单据ID',
  `source_order_no` varchar(80) DEFAULT NULL COMMENT '来源单据编号',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `location_id` bigint DEFAULT NULL COMMENT '库位ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_id` bigint DEFAULT NULL COMMENT '批次ID',
  `quantity` decimal(10,2) NOT NULL COMMENT '变动数量',
  `before_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变动前数量',
  `after_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变动后数量',
  `created_by` bigint DEFAULT NULL COMMENT '操作人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_no` (`transaction_no`)
) ENGINE=InnoDB AUTO_INCREMENT=292 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='库存流水表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_inventory_transaction`
--

LOCK TABLES `t_inventory_transaction` WRITE;
/*!40000 ALTER TABLE `t_inventory_transaction` DISABLE KEYS */;
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (1,'INV-IN-20261024095651456-7120203424100','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,2,1,50.00,0.00,50.00,6,'2026-10-24 09:56:51',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (2,'INV-IN-20261024095651506-7120253034700','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,3,2,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (3,'INV-IN-20261024095651515-7120262078800','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,4,3,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (4,'INV-IN-20261024095651535-7120282805800','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,5,4,100.00,0.00,100.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (5,'INV-IN-20261024095651541-7120288607900','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,6,5,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (6,'INV-IN-20261024095651545-7120292828300','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,7,6,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (7,'INV-IN-20261024095651555-7120302211700','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,8,7,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (8,'INV-IN-20261024095651559-7120306480200','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,9,8,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (9,'INV-IN-20261024095651565-7120312164500','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,10,9,200.00,0.00,200.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (10,'INV-IN-20261024095651570-7120316875900','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,11,10,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (11,'INV-IN-20261024095651574-7120320825500','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,12,11,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (12,'INV-IN-20261024095651582-7120329120700','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,13,12,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (13,'INV-IN-20261024095652211-7120957967500','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,2,13,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (14,'INV-IN-20261024095652224-7120972117000','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,3,14,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (15,'INV-IN-20261024095652239-7120986404200','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,4,15,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (16,'INV-IN-20261024095652256-7121004122500','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,5,16,100.00,0.00,100.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (17,'INV-IN-20261024095652265-7121012930000','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,6,17,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (18,'INV-IN-20261024095652270-7121017268900','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,7,18,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (19,'INV-IN-20261024095652273-7121020957400','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,8,19,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (20,'INV-IN-20261024095652281-7121028376200','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,9,20,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (21,'INV-IN-20261024095652284-7121031259700','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,10,21,200.00,0.00,200.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (22,'INV-IN-20261024095652314-7121061734200','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,11,22,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (23,'INV-IN-20261024095652328-7121075243300','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,12,23,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (24,'INV-IN-20261024095652340-7121087249300','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,13,24,50.00,0.00,50.00,6,'2026-10-24 09:56:52',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (25,'INV-OUT-20261024095652694-7121441539300','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,2,1,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (26,'INV-OUT-20261024095652706-7121454062000','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,2,13,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (27,'INV-OUT-20261024095652715-7121462383000','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,3,2,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (28,'INV-OUT-20261024095652719-7121466151300','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,3,14,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (29,'INV-OUT-20261024095652722-7121469732800','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,4,3,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (30,'INV-OUT-20261024095652729-7121476433400','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,4,15,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (31,'INV-OUT-20261024095652732-7121479704200','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,5,4,100.00,100.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (32,'INV-OUT-20261024095652737-7121484915300','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,5,16,100.00,100.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (33,'INV-OUT-20261024095652752-7121499850000','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,6,5,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (34,'INV-OUT-20261024095652759-7121506622700','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,6,17,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (35,'INV-OUT-20261024095652779-7121526145400','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,7,6,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (36,'INV-OUT-20261024095652784-7121531382900','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,7,18,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (37,'INV-OUT-20261024095652793-7121539843700','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,8,7,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (38,'INV-OUT-20261024095652796-7121543255400','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,8,19,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (39,'INV-OUT-20261024095652800-7121547277300','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,9,8,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (40,'INV-OUT-20261024095652813-7121560644400','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,9,20,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (41,'INV-OUT-20261024095652821-7121567864100','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,10,9,200.00,200.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (42,'INV-OUT-20261024095652824-7121571262200','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,10,21,200.00,200.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (43,'INV-OUT-20261024095652827-7121574655500','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,11,10,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (44,'INV-OUT-20261024095652837-7121584098300','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,11,22,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (45,'INV-OUT-20261024095652840-7121587506900','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,12,11,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (46,'INV-OUT-20261024095652844-7121591182300','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,12,23,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (47,'INV-OUT-20261024095652847-7121594305400','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,13,12,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (48,'INV-OUT-20261024095652861-7121607733000','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,13,24,50.00,50.00,0.00,6,'2026-10-24 09:56:53',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (49,'INV-IN-20261024095652889-7121636491300','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,2,1,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (50,'INV-IN-20261024095652911-7121658414800','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,2,13,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (51,'INV-IN-20261024095652926-7121674746100','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,3,2,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (52,'INV-IN-20261024095652957-7121704662100','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,3,14,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (53,'INV-IN-20261024095653024-7121771102700','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,4,3,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (54,'INV-IN-20261024095653075-7121822843100','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,4,15,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (55,'INV-IN-20261024095653110-7121858112800','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,5,4,100.00,0.00,100.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (56,'INV-IN-20261024095653133-7121879823300','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,5,16,100.00,0.00,100.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (57,'INV-IN-20261024095653149-7121896384600','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,6,5,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (58,'INV-IN-20261024095653166-7121913203600','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,6,17,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (59,'INV-IN-20261024095653178-7121926064600','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,7,6,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (60,'INV-IN-20261024095653203-7121950713000','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,7,18,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (61,'INV-IN-20261024095653211-7121958468000','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,8,7,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (62,'INV-IN-20261024095653251-7121999171600','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,8,19,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (63,'INV-IN-20261024095653272-7122019694300','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,9,8,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (64,'INV-IN-20261024095653290-7122037092100','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,9,20,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (65,'INV-IN-20261024095653309-7122056197000','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,10,9,200.00,0.00,200.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (66,'INV-IN-20261024095653345-7122092566100','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,10,21,200.00,0.00,200.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (67,'INV-IN-20261024095653360-7122107869900','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,11,10,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (68,'INV-IN-20261024095653369-7122116870700','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,11,22,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (69,'INV-IN-20261024095653372-7122120257300','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,12,11,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (70,'INV-IN-20261024095653383-7122130266700','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,12,23,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (71,'INV-IN-20261024095653387-7122134613000','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,13,12,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (72,'INV-IN-20261024095653392-7122138877400','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,13,24,50.00,0.00,50.00,6,'2026-10-24 09:56:53','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (73,'INV-OUT-20261024095653778-7122525265300','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,2,1,50.00,50.00,0.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (74,'INV-OUT-20261024095653791-7122538447100','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,2,13,10.00,50.00,40.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (75,'INV-OUT-20261024095653798-7122545266500','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,3,2,50.00,50.00,0.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (76,'INV-OUT-20261024095653802-7122550145900','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,3,14,10.00,50.00,40.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (77,'INV-OUT-20261024095653812-7122559651200','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,4,3,50.00,50.00,0.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (78,'INV-OUT-20261024095653873-7122620693000','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,4,15,10.00,50.00,40.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (79,'INV-OUT-20261024095653882-7122629878300','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,5,4,100.00,100.00,0.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (80,'INV-OUT-20261024095653900-7122647546700','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,5,16,20.00,100.00,80.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (81,'INV-OUT-20261024095653954-7122702086000','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,6,5,50.00,50.00,0.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (82,'INV-OUT-20261024095653992-7122739575000','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,6,17,10.00,50.00,40.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (83,'INV-OUT-20261024095654011-7122758788600','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,7,6,50.00,50.00,0.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (84,'INV-OUT-20261024095654036-7122783689800','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,7,18,10.00,50.00,40.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (85,'INV-OUT-20261024095654045-7122792590900','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,8,7,50.00,50.00,0.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (86,'INV-OUT-20261024095654081-7122828100100','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,8,19,10.00,50.00,40.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (87,'INV-OUT-20261024095654134-7122881100500','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,9,8,50.00,50.00,0.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (88,'INV-OUT-20261024095654163-7122910626000','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,9,20,10.00,50.00,40.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (89,'INV-OUT-20261024095654179-7122926684000','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,10,9,200.00,200.00,0.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (90,'INV-OUT-20261024095654190-7122937292100','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,10,21,40.00,200.00,160.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (91,'INV-OUT-20261024095654201-7122948640100','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,11,10,50.00,50.00,0.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (92,'INV-OUT-20261024095654211-7122958107600','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,11,22,10.00,50.00,40.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (93,'INV-OUT-20261024095654224-7122971196100','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,12,11,50.00,50.00,0.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (94,'INV-OUT-20261024095654240-7122987832200','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,12,23,10.00,50.00,40.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (95,'INV-OUT-20261024095654261-7123008058400','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,13,12,50.00,50.00,0.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (96,'INV-OUT-20261024095654273-7123020043000','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,13,24,10.00,50.00,40.00,4,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (97,'INV-OUT-20261024095654489-7123236635200','OUT','WIP_LINE_RETURN',3,'LINE-LINE_RETURN-1-3',3,3,2,13,40.00,40.00,0.00,6,'2026-10-24 09:56:54','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (98,'INV-IN-20261024095654506-7123254761200','IN','LINE_RETURN',3,'L-RET-000001',2,2,2,13,40.00,0.00,40.00,6,'2026-10-24 09:56:55',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (99,'INV-IN-20261024095654639-7123386131500','IN','WIP_LINE_ISSUE',4,'LINE-LINE_ISSUE-1-4',3,3,2,13,40.00,0.00,40.00,6,'2026-10-24 09:56:55','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (100,'INV-OUT-20261024095654681-7123428868500','OUT','LINE_ISSUE',2,'ISS-000002',2,2,2,13,40.00,40.00,0.00,6,'2026-10-24 09:56:55',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (101,'INV-OUT-20261024095654728-7123476380300','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,2,13,40.00,40.00,0.00,4,'2026-10-24 09:56:55','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (102,'INV-OUT-20261024095654742-7123489620400','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,3,14,40.00,40.00,0.00,4,'2026-10-24 09:56:55','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (103,'INV-OUT-20261024095654775-7123522636000','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,4,15,40.00,40.00,0.00,4,'2026-10-24 09:56:55','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (104,'INV-OUT-20261024095654785-7123532840300','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,5,16,80.00,80.00,0.00,4,'2026-10-24 09:56:55','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (105,'INV-OUT-20261024095654818-7123565961200','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,6,17,40.00,40.00,0.00,4,'2026-10-24 09:56:55','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (106,'INV-OUT-20261024095654827-7123574287000','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,7,18,40.00,40.00,0.00,4,'2026-10-24 09:56:55','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (107,'INV-OUT-20261024095654855-7123603011100','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,8,19,40.00,40.00,0.00,4,'2026-10-24 09:56:55','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (108,'INV-OUT-20261024095654873-7123620387200','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,9,20,40.00,40.00,0.00,4,'2026-10-24 09:56:55','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (109,'INV-OUT-20261024095654881-7123629331500','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,10,21,160.00,160.00,0.00,4,'2026-10-24 09:56:55','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (110,'INV-OUT-20261024095654889-7123636884100','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,11,22,40.00,40.00,0.00,4,'2026-10-24 09:56:55','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (111,'INV-OUT-20261024095654892-7123639990300','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,12,23,40.00,40.00,0.00,4,'2026-10-24 09:56:55','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (112,'INV-OUT-20261024095654910-7123657078600','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,13,24,40.00,40.00,0.00,4,'2026-10-24 09:56:55','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (113,'INV-IN-20261024095655716-7124463544000','IN','WIP_OUTPUT',7,'LINE-OUTPUT-1-7',3,3,16,25,100.00,0.00,100.00,4,'2026-10-24 09:56:56','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (114,'INV-OUT-20261024095655889-7124635838500','OUT','WIP_PRODUCTION_RECEIPT',5,'LINE-PRODUCTION_RECEIPT-1-5',3,3,16,25,40.00,100.00,60.00,6,'2026-10-24 09:56:56','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (115,'INV-IN-20261024095655894-7124640952700','IN','PRODUCTION_RECEIPT',4,'FG-IN-000001',4,4,16,25,40.00,0.00,40.00,6,'2026-10-24 09:56:56',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (116,'INV-OUT-20261024095655948-7124694775500','OUT','WIP_PRODUCTION_RECEIPT',6,'LINE-PRODUCTION_RECEIPT-1-6',3,3,16,25,60.00,60.00,0.00,6,'2026-10-24 09:56:56','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (117,'INV-IN-20261024095655957-7124704184700','IN','PRODUCTION_RECEIPT',5,'FG-IN-000002',4,4,16,25,60.00,40.00,100.00,6,'2026-10-24 09:56:56',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (118,'INV-OUT-20261024095656172-7124918917500','OUT','SALES_SHIPMENT',3,'SHIP-000001',4,4,16,25,40.00,100.00,60.00,6,'2026-10-24 09:56:56',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (119,'INV-OUT-20261024095656314-7125061890600','OUT','SALES_SHIPMENT',4,'SHIP-000002',4,4,16,25,60.00,60.00,0.00,6,'2026-10-24 09:56:56',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (120,'INV-IN-20261024095656506-7125254026000','IN','SALES_RETURN',6,'S-RET-000001',4,4,16,25,10.00,0.00,10.00,6,'2026-10-24 09:56:57',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (121,'INV-IN-20261024095657425-7126171879900','IN','PURCHASE_RECEIPT',7,'PR-000003',2,2,2,26,20.00,0.00,20.00,6,'2026-10-24 09:56:57',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (122,'INV-OUT-20261024095657533-7126279922300','OUT','PURCHASE_RETURN',5,'P-RET-000001',2,2,2,26,5.00,20.00,15.00,6,'2026-10-24 09:56:58',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (123,'INV-IN-20261024095659939-7128686789800','IN','PURCHASE_RECEIPT',8,'PR-000004',2,2,4,27,10.00,0.00,10.00,6,'2026-10-24 09:57:00',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (124,'INV-IN-20261024095659942-7128689218300','IN','PURCHASE_RECEIPT',8,'PR-000004',2,2,5,28,20.00,0.00,20.00,6,'2026-10-24 09:57:00',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (125,'INV-IN-20261024095659947-7128693999100','IN','PURCHASE_RECEIPT',8,'PR-000004',2,2,6,29,10.00,0.00,10.00,6,'2026-10-24 09:57:00',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (126,'INV-IN-20261024095659950-7128697530800','IN','PURCHASE_RECEIPT',8,'PR-000004',2,2,7,30,10.00,0.00,10.00,6,'2026-10-24 09:57:00',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (127,'INV-IN-20261024095700063-7128810712800','IN','WIP_LINE_ISSUE',16,'LINE-LINE_ISSUE-3-16',3,3,4,27,10.00,0.00,10.00,6,'2026-10-24 09:57:00','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (128,'INV-IN-20261024095700071-7128818445100','IN','WIP_LINE_ISSUE',16,'LINE-LINE_ISSUE-3-16',3,3,5,28,20.00,0.00,20.00,6,'2026-10-24 09:57:00','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (129,'INV-IN-20261024095700078-7128824903000','IN','WIP_LINE_ISSUE',16,'LINE-LINE_ISSUE-3-16',3,3,6,29,10.00,0.00,10.00,6,'2026-10-24 09:57:00','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (130,'INV-IN-20261024095700085-7128831754400','IN','WIP_LINE_ISSUE',16,'LINE-LINE_ISSUE-3-16',3,3,7,30,10.00,0.00,10.00,6,'2026-10-24 09:57:00','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (131,'INV-OUT-20261024095700092-7128839153500','OUT','LINE_ISSUE',6,'ISS-000003',2,2,4,27,10.00,10.00,0.00,6,'2026-10-24 09:57:00',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (132,'INV-OUT-20261024095700095-7128842088000','OUT','LINE_ISSUE',6,'ISS-000003',2,2,5,28,20.00,20.00,0.00,6,'2026-10-24 09:57:00',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (133,'INV-OUT-20261024095700098-7128845560400','OUT','LINE_ISSUE',6,'ISS-000003',2,2,6,29,10.00,10.00,0.00,6,'2026-10-24 09:57:00',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (134,'INV-OUT-20261024095700104-7128851674100','OUT','LINE_ISSUE',6,'ISS-000003',2,2,7,30,10.00,10.00,0.00,6,'2026-10-24 09:57:00',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (135,'INV-OUT-20261024095700227-7128974785400','OUT','WIP_CONSUME',8,'LINE-CONSUME-3-8',3,3,4,27,10.00,10.00,0.00,4,'2026-10-24 09:57:00','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (136,'INV-OUT-20261024095700241-7128988150200','OUT','WIP_CONSUME',8,'LINE-CONSUME-3-8',3,3,5,28,20.00,20.00,0.00,4,'2026-10-24 09:57:00','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (137,'INV-OUT-20261024095700251-7128998826600','OUT','WIP_CONSUME',8,'LINE-CONSUME-3-8',3,3,6,29,10.00,10.00,0.00,4,'2026-10-24 09:57:00','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (138,'INV-OUT-20261024095700258-7129005129800','OUT','WIP_CONSUME',8,'LINE-CONSUME-3-8',3,3,7,30,10.00,10.00,0.00,4,'2026-10-24 09:57:00','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (139,'INV-IN-20261024095700274-7129021458700','IN','WIP_OUTPUT',8,'LINE-OUTPUT-3-8',3,3,14,31,10.00,0.00,10.00,4,'2026-10-24 09:57:00','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (140,'INV-IN-20261024095700382-7129129841400','IN','PRODUCTION_RECEIPT',9,'FG-IN-000003',4,4,14,31,10.00,0.00,10.00,6,'2026-10-24 09:57:00',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (141,'INV-OUT-20261024095700406-7129152978500','OUT','WIP_RECEIPT',9,'LINE-RECEIPT-3-9',3,3,14,31,10.00,10.00,0.00,6,'2026-10-24 09:57:00','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (142,'INV-IN-20261024095700725-7129472568400','IN','PURCHASE_RECEIPT',10,'PR-000005',2,2,3,32,10.00,0.00,10.00,6,'2026-10-24 09:57:01',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (143,'INV-IN-20261024095700729-7129476916900','IN','PURCHASE_RECEIPT',10,'PR-000005',2,2,8,33,10.00,0.00,10.00,6,'2026-10-24 09:57:01',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (144,'INV-IN-20261024095700737-7129484607900','IN','PURCHASE_RECEIPT',10,'PR-000005',2,2,9,34,10.00,0.00,10.00,6,'2026-10-24 09:57:01',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (145,'INV-IN-20261024095700740-7129487461900','IN','PURCHASE_RECEIPT',10,'PR-000005',2,2,10,35,40.00,0.00,40.00,6,'2026-10-24 09:57:01',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (146,'INV-IN-20261024095700863-7129610635300','IN','WIP_LINE_ISSUE',18,'LINE-LINE_ISSUE-4-18',3,3,2,26,10.00,0.00,10.00,6,'2026-10-24 09:57:01','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (147,'INV-IN-20261024095700868-7129615772800','IN','WIP_LINE_ISSUE',18,'LINE-LINE_ISSUE-4-18',3,3,3,32,10.00,0.00,10.00,6,'2026-10-24 09:57:01','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (148,'INV-IN-20261024095700874-7129621622300','IN','WIP_LINE_ISSUE',18,'LINE-LINE_ISSUE-4-18',3,3,8,33,10.00,0.00,10.00,6,'2026-10-24 09:57:01','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (149,'INV-IN-20261024095700887-7129634146700','IN','WIP_LINE_ISSUE',18,'LINE-LINE_ISSUE-4-18',3,3,9,34,10.00,0.00,10.00,6,'2026-10-24 09:57:01','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (150,'INV-IN-20261024095700893-7129640000800','IN','WIP_LINE_ISSUE',18,'LINE-LINE_ISSUE-4-18',3,3,10,35,40.00,0.00,40.00,6,'2026-10-24 09:57:01','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (151,'INV-OUT-20261024095700911-7129658380800','OUT','LINE_ISSUE',7,'ISS-000004',2,2,2,26,10.00,15.00,5.00,6,'2026-10-24 09:57:01',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (152,'INV-OUT-20261024095700918-7129665511300','OUT','LINE_ISSUE',7,'ISS-000004',2,2,3,32,10.00,10.00,0.00,6,'2026-10-24 09:57:01',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (153,'INV-OUT-20261024095700928-7129675501000','OUT','LINE_ISSUE',7,'ISS-000004',2,2,8,33,10.00,10.00,0.00,6,'2026-10-24 09:57:01',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (154,'INV-OUT-20261024095700935-7129682329000','OUT','LINE_ISSUE',7,'ISS-000004',2,2,9,34,10.00,10.00,0.00,6,'2026-10-24 09:57:01',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (155,'INV-OUT-20261024095700943-7129689997100','OUT','LINE_ISSUE',7,'ISS-000004',2,2,10,35,40.00,40.00,0.00,6,'2026-10-24 09:57:01',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (156,'INV-OUT-20261024095701067-7129814759600','OUT','WIP_CONSUME',9,'LINE-CONSUME-4-9',3,3,2,26,10.00,10.00,0.00,4,'2026-10-24 09:57:01','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (157,'INV-OUT-20261024095701094-7129842207400','OUT','WIP_CONSUME',9,'LINE-CONSUME-4-9',3,3,3,32,10.00,10.00,0.00,4,'2026-10-24 09:57:01','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (158,'INV-OUT-20261024095701101-7129848404400','OUT','WIP_CONSUME',9,'LINE-CONSUME-4-9',3,3,8,33,10.00,10.00,0.00,4,'2026-10-24 09:57:01','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (159,'INV-OUT-20261024095701104-7129851488000','OUT','WIP_CONSUME',9,'LINE-CONSUME-4-9',3,3,9,34,10.00,10.00,0.00,4,'2026-10-24 09:57:01','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (160,'INV-OUT-20261024095701113-7129859898400','OUT','WIP_CONSUME',9,'LINE-CONSUME-4-9',3,3,10,35,40.00,40.00,0.00,4,'2026-10-24 09:57:01','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (161,'INV-IN-20261024095701116-7129864326900','IN','WIP_OUTPUT',9,'LINE-OUTPUT-4-9',3,3,15,36,10.00,0.00,10.00,4,'2026-10-24 09:57:01','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (162,'INV-IN-20261024095701156-7129903603200','IN','PRODUCTION_RECEIPT',11,'FG-IN-000004',4,4,15,36,10.00,0.00,10.00,6,'2026-10-24 09:57:01',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (163,'INV-OUT-20261024095701160-7129907725600','OUT','WIP_RECEIPT',11,'LINE-RECEIPT-4-11',3,3,15,36,10.00,10.00,0.00,6,'2026-10-24 09:57:01','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (164,'INV-IN-20261024095701460-7130207935900','IN','PURCHASE_RECEIPT',12,'PR-000006',2,2,11,37,10.00,0.00,10.00,6,'2026-10-24 09:57:01',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (165,'INV-IN-20261024095701465-7130212577300','IN','PURCHASE_RECEIPT',12,'PR-000006',2,2,12,38,10.00,0.00,10.00,6,'2026-10-24 09:57:01',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (166,'INV-IN-20261024095701468-7130215648000','IN','PURCHASE_RECEIPT',12,'PR-000006',2,2,13,39,10.00,0.00,10.00,6,'2026-10-24 09:57:01',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (167,'INV-IN-20261024095701595-7130342796800','IN','WIP_LINE_ISSUE',20,'LINE-LINE_ISSUE-2-20',3,3,11,37,10.00,0.00,10.00,6,'2026-10-24 09:57:02','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (168,'INV-IN-20261024095701601-7130348507100','IN','WIP_LINE_ISSUE',20,'LINE-LINE_ISSUE-2-20',3,3,12,38,10.00,0.00,10.00,6,'2026-10-24 09:57:02','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (169,'INV-IN-20261024095701625-7130372079800','IN','WIP_LINE_ISSUE',20,'LINE-LINE_ISSUE-2-20',3,3,13,39,10.00,0.00,10.00,6,'2026-10-24 09:57:02','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (170,'INV-OUT-20261024095701648-7130395705500','OUT','LINE_ISSUE',8,'ISS-000005',2,2,11,37,10.00,10.00,0.00,6,'2026-10-24 09:57:02',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (171,'INV-OUT-20261024095701655-7130402130700','OUT','LINE_ISSUE',8,'ISS-000005',2,2,12,38,10.00,10.00,0.00,6,'2026-10-24 09:57:02',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (172,'INV-OUT-20261024095701658-7130405640600','OUT','LINE_ISSUE',8,'ISS-000005',2,2,13,39,10.00,10.00,0.00,6,'2026-10-24 09:57:02',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (173,'INV-IN-20261024095701736-7130484098900','IN','WIP_LINE_ISSUE',21,'LINE-LINE_ISSUE-2-21',3,3,14,31,10.00,0.00,10.00,6,'2026-10-24 09:57:02','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (174,'INV-IN-20261024095701740-7130487466800','IN','WIP_LINE_ISSUE',21,'LINE-LINE_ISSUE-2-21',3,3,15,36,10.00,0.00,10.00,6,'2026-10-24 09:57:02','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (175,'INV-OUT-20261024095701750-7130497080100','OUT','LINE_ISSUE',9,'ISS-000006',4,4,14,31,10.00,10.00,0.00,6,'2026-10-24 09:57:02',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (176,'INV-OUT-20261024095701752-7130499711300','OUT','LINE_ISSUE',9,'ISS-000006',4,4,15,36,10.00,10.00,0.00,6,'2026-10-24 09:57:02',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (177,'INV-OUT-20261024095701898-7130645603600','OUT','WIP_CONSUME',10,'LINE-CONSUME-2-10',3,3,11,37,6.00,10.00,4.00,4,'2026-10-24 09:57:02','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (178,'INV-OUT-20261024095701918-7130665828700','OUT','WIP_CONSUME',10,'LINE-CONSUME-2-10',3,3,12,38,6.00,10.00,4.00,4,'2026-10-24 09:57:02','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (179,'INV-OUT-20261024095701925-7130672744400','OUT','WIP_CONSUME',10,'LINE-CONSUME-2-10',3,3,13,39,6.00,10.00,4.00,4,'2026-10-24 09:57:02','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (180,'INV-OUT-20261024095701934-7130681772200','OUT','WIP_CONSUME',10,'LINE-CONSUME-2-10',3,3,14,31,6.00,10.00,4.00,4,'2026-10-24 09:57:02','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (181,'INV-OUT-20261024095701938-7130685710800','OUT','WIP_CONSUME',10,'LINE-CONSUME-2-10',3,3,15,36,6.00,10.00,4.00,4,'2026-10-24 09:57:02','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (182,'INV-OUT-20261024095702034-7130781845400','OUT','WIP_CONSUME',11,'LINE-CONSUME-2-11',3,3,11,37,4.00,4.00,0.00,4,'2026-10-24 09:57:02','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (183,'INV-OUT-20261024095702038-7130784780600','OUT','WIP_CONSUME',11,'LINE-CONSUME-2-11',3,3,12,38,4.00,4.00,0.00,4,'2026-10-24 09:57:02','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (184,'INV-OUT-20261024095702043-7130790561000','OUT','WIP_CONSUME',11,'LINE-CONSUME-2-11',3,3,13,39,4.00,4.00,0.00,4,'2026-10-24 09:57:02','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (185,'INV-OUT-20261024095702050-7130797410600','OUT','WIP_CONSUME',11,'LINE-CONSUME-2-11',3,3,14,31,4.00,4.00,0.00,4,'2026-10-24 09:57:02','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (186,'INV-OUT-20261024095702060-7130807567600','OUT','WIP_CONSUME',11,'LINE-CONSUME-2-11',3,3,15,36,4.00,4.00,0.00,4,'2026-10-24 09:57:02','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (187,'INV-IN-20261024095702469-7131216715200','IN','WIP_OUTPUT',14,'LINE-OUTPUT-2-14',3,3,16,40,10.00,0.00,10.00,4,'2026-10-24 09:57:02','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (188,'INV-IN-20261024095702541-7131288247200','IN','PRODUCTION_RECEIPT',13,'FG-IN-000005',4,4,16,40,10.00,0.00,10.00,6,'2026-10-24 09:57:03',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (189,'INV-OUT-20261024095702544-7131291511600','OUT','WIP_RECEIPT',13,'LINE-RECEIPT-2-13',3,3,16,40,10.00,10.00,0.00,6,'2026-10-24 09:57:03','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (190,'INV-IN-20261024095703273-7132020271200','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,3,41,1.00,0.00,1.00,6,'2026-10-24 09:57:03',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (191,'INV-IN-20261024095703278-7132025203200','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,4,42,1.00,0.00,1.00,6,'2026-10-24 09:57:03',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (192,'INV-IN-20261024095703286-7132034219700','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,5,43,2.00,0.00,2.00,6,'2026-10-24 09:57:03',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (193,'INV-IN-20261024095703299-7132047222900','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,6,44,1.00,0.00,1.00,6,'2026-10-24 09:57:03',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (194,'INV-IN-20261024095703313-7132061030800','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,7,45,1.00,0.00,1.00,6,'2026-10-24 09:57:03',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (195,'INV-IN-20261024095703318-7132065184700','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,8,46,1.00,0.00,1.00,6,'2026-10-24 09:57:03',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (196,'INV-IN-20261024095703323-7132070249700','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,9,47,1.00,0.00,1.00,6,'2026-10-24 09:57:03',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (197,'INV-IN-20261024095703331-7132079249200','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,10,48,4.00,0.00,4.00,6,'2026-10-24 09:57:03',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (198,'INV-IN-20261024095703334-7132082236600','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,11,49,1.00,0.00,1.00,6,'2026-10-24 09:57:03',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (199,'INV-IN-20261024095703344-7132092020400','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,12,50,1.00,0.00,1.00,6,'2026-10-24 09:57:03',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (200,'INV-IN-20261024095703349-7132096293300','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,13,51,1.00,0.00,1.00,6,'2026-10-24 09:57:03',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (201,'INV-IN-20261024095703460-7132207579100','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,2,26,1.00,0.00,1.00,6,'2026-10-24 09:57:03','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (202,'INV-IN-20261024095703466-7132213853900','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,3,41,1.00,0.00,1.00,6,'2026-10-24 09:57:03','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (203,'INV-IN-20261024095703469-7132216804800','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,4,42,1.00,0.00,1.00,6,'2026-10-24 09:57:03','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (204,'INV-IN-20261024095703472-7132219221500','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,5,43,2.00,0.00,2.00,6,'2026-10-24 09:57:03','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (205,'INV-IN-20261024095703474-7132221614000','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,6,44,1.00,0.00,1.00,6,'2026-10-24 09:57:03','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (206,'INV-IN-20261024095703482-7132229284400','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,7,45,1.00,0.00,1.00,6,'2026-10-24 09:57:03','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (207,'INV-IN-20261024095703488-7132235586200','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,8,46,1.00,0.00,1.00,6,'2026-10-24 09:57:03','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (208,'INV-IN-20261024095703501-7132249029600','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,9,47,1.00,0.00,1.00,6,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (209,'INV-IN-20261024095703505-7132252299800','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,10,48,4.00,0.00,4.00,6,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (210,'INV-IN-20261024095703508-7132254779000','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,11,49,1.00,0.00,1.00,6,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (211,'INV-IN-20261024095703519-7132265879300','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,12,50,1.00,0.00,1.00,6,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (212,'INV-IN-20261024095703521-7132268598600','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,13,51,1.00,0.00,1.00,6,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (213,'INV-OUT-20261024095703536-7132283077600','OUT','LINE_ISSUE',10,'ISS-000007',2,2,2,26,1.00,5.00,4.00,6,'2026-10-24 09:57:04',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (214,'INV-OUT-20261024095703538-7132285777700','OUT','LINE_ISSUE',10,'ISS-000007',2,2,3,41,1.00,1.00,0.00,6,'2026-10-24 09:57:04',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (215,'INV-OUT-20261024095703544-7132291995400','OUT','LINE_ISSUE',10,'ISS-000007',2,2,4,42,1.00,1.00,0.00,6,'2026-10-24 09:57:04',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (216,'INV-OUT-20261024095703548-7132296215800','OUT','LINE_ISSUE',10,'ISS-000007',2,2,5,43,2.00,2.00,0.00,6,'2026-10-24 09:57:04',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (217,'INV-OUT-20261024095703551-7132298857200','OUT','LINE_ISSUE',10,'ISS-000007',2,2,6,44,1.00,1.00,0.00,6,'2026-10-24 09:57:04',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (218,'INV-OUT-20261024095703554-7132301619300','OUT','LINE_ISSUE',10,'ISS-000007',2,2,7,45,1.00,1.00,0.00,6,'2026-10-24 09:57:04',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (219,'INV-OUT-20261024095703560-7132307717400','OUT','LINE_ISSUE',10,'ISS-000007',2,2,8,46,1.00,1.00,0.00,6,'2026-10-24 09:57:04',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (220,'INV-OUT-20261024095703564-7132311323100','OUT','LINE_ISSUE',10,'ISS-000007',2,2,9,47,1.00,1.00,0.00,6,'2026-10-24 09:57:04',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (221,'INV-OUT-20261024095703568-7132315227500','OUT','LINE_ISSUE',10,'ISS-000007',2,2,10,48,4.00,4.00,0.00,6,'2026-10-24 09:57:04',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (222,'INV-OUT-20261024095703570-7132317697100','OUT','LINE_ISSUE',10,'ISS-000007',2,2,11,49,1.00,1.00,0.00,6,'2026-10-24 09:57:04',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (223,'INV-OUT-20261024095703576-7132323331600','OUT','LINE_ISSUE',10,'ISS-000007',2,2,12,50,1.00,1.00,0.00,6,'2026-10-24 09:57:04',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (224,'INV-OUT-20261024095703578-7132325807600','OUT','LINE_ISSUE',10,'ISS-000007',2,2,13,51,1.00,1.00,0.00,6,'2026-10-24 09:57:04',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (225,'INV-OUT-20261024095703690-7132437744500','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,2,26,1.00,1.00,0.00,4,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (226,'INV-OUT-20261024095703693-7132440905900','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,3,41,1.00,1.00,0.00,4,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (227,'INV-OUT-20261024095703698-7132445525500','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,4,42,1.00,1.00,0.00,4,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (228,'INV-OUT-20261024095703701-7132449070400','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,5,43,2.00,2.00,0.00,4,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (229,'INV-OUT-20261024095703704-7132451895300','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,6,44,1.00,1.00,0.00,4,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (230,'INV-OUT-20261024095703707-7132454537100','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,7,45,1.00,1.00,0.00,4,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (231,'INV-OUT-20261024095703709-7132457103900','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,8,46,1.00,1.00,0.00,4,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (232,'INV-OUT-20261024095703716-7132463751300','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,9,47,1.00,1.00,0.00,4,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (233,'INV-OUT-20261024095703720-7132466886600','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,10,48,4.00,4.00,0.00,4,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (234,'INV-OUT-20261024095703723-7132470151300','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,11,49,1.00,1.00,0.00,4,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (235,'INV-OUT-20261024095703726-7132472900600','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,12,50,1.00,1.00,0.00,4,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (236,'INV-OUT-20261024095703734-7132481010000','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,13,51,1.00,1.00,0.00,4,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (237,'INV-IN-20261024095704079-7132826876400','IN','WIP_OUTPUT',18,'LINE-OUTPUT-5-18',3,3,16,52,1.00,0.00,1.00,4,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (238,'INV-IN-20261024095704140-7132887346100','IN','PRODUCTION_RECEIPT',15,'FG-IN-000006',4,4,16,52,1.00,0.00,1.00,6,'2026-10-24 09:57:04',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (239,'INV-OUT-20261024095704143-7132890671100','OUT','WIP_RECEIPT',15,'LINE-RECEIPT-5-15',3,3,16,52,1.00,1.00,0.00,6,'2026-10-24 09:57:04','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (240,'INV-IN-20261024095704674-7133420841800','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,3,53,1.00,0.00,1.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (241,'INV-IN-20261024095704676-7133423523100','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,4,54,1.00,0.00,1.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (242,'INV-IN-20261024095704679-7133426051500','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,5,55,2.00,0.00,2.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (243,'INV-IN-20261024095704682-7133429217200','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,6,56,1.00,0.00,1.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (244,'INV-IN-20261024095704685-7133431943300','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,7,57,1.00,0.00,1.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (245,'INV-IN-20261024095704692-7133439733200','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,8,58,1.00,0.00,1.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (246,'INV-IN-20261024095704695-7133442196400','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,9,59,1.00,0.00,1.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (247,'INV-IN-20261024095704699-7133446363000','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,10,60,4.00,0.00,4.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (248,'INV-IN-20261024095704701-7133448809100','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,11,61,1.00,0.00,1.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (249,'INV-IN-20261024095704708-7133455151800','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,12,62,1.00,0.00,1.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (250,'INV-IN-20261024095704710-7133457663900','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,13,63,1.00,0.00,1.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (251,'INV-IN-20261024095704869-7133616517700','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,2,26,1.00,0.00,1.00,6,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (252,'INV-IN-20261024095704923-7133670734400','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,3,53,1.00,0.00,1.00,6,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (253,'INV-IN-20261024095704957-7133704591000','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,4,54,1.00,0.00,1.00,6,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (254,'INV-IN-20261024095704962-7133708836900','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,5,55,2.00,0.00,2.00,6,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (255,'INV-IN-20261024095704966-7133713139000','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,6,56,1.00,0.00,1.00,6,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (256,'INV-IN-20261024095704973-7133720667000','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,7,57,1.00,0.00,1.00,6,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (257,'INV-IN-20261024095704977-7133724577700','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,8,58,1.00,0.00,1.00,6,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (258,'INV-IN-20261024095704981-7133728056300','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,9,59,1.00,0.00,1.00,6,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (259,'INV-IN-20261024095704988-7133734946600','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,10,60,4.00,0.00,4.00,6,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (260,'INV-IN-20261024095704991-7133738300000','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,11,61,1.00,0.00,1.00,6,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (261,'INV-IN-20261024095704994-7133741152300','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,12,62,1.00,0.00,1.00,6,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (262,'INV-IN-20261024095704998-7133745352800','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,13,63,1.00,0.00,1.00,6,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (263,'INV-OUT-20261024095705013-7133760978400','OUT','LINE_ISSUE',11,'ISS-000008',2,2,2,26,1.00,4.00,3.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (264,'INV-OUT-20261024095705018-7133765268800','OUT','LINE_ISSUE',11,'ISS-000008',2,2,3,53,1.00,1.00,0.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (265,'INV-OUT-20261024095705020-7133767570500','OUT','LINE_ISSUE',11,'ISS-000008',2,2,4,54,1.00,1.00,0.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (266,'INV-OUT-20261024095705022-7133769764100','OUT','LINE_ISSUE',11,'ISS-000008',2,2,5,55,2.00,2.00,0.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (267,'INV-OUT-20261024095705024-7133772130500','OUT','LINE_ISSUE',11,'ISS-000008',2,2,6,56,1.00,1.00,0.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (268,'INV-OUT-20261024095705027-7133774812500','OUT','LINE_ISSUE',11,'ISS-000008',2,2,7,57,1.00,1.00,0.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (269,'INV-OUT-20261024095705037-7133784215700','OUT','LINE_ISSUE',11,'ISS-000008',2,2,8,58,1.00,1.00,0.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (270,'INV-OUT-20261024095705040-7133787303000','OUT','LINE_ISSUE',11,'ISS-000008',2,2,9,59,1.00,1.00,0.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (271,'INV-OUT-20261024095705043-7133789894300','OUT','LINE_ISSUE',11,'ISS-000008',2,2,10,60,4.00,4.00,0.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (272,'INV-OUT-20261024095705046-7133793627400','OUT','LINE_ISSUE',11,'ISS-000008',2,2,11,61,1.00,1.00,0.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (273,'INV-OUT-20261024095705051-7133798637900','OUT','LINE_ISSUE',11,'ISS-000008',2,2,12,62,1.00,1.00,0.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (274,'INV-OUT-20261024095705053-7133800771700','OUT','LINE_ISSUE',11,'ISS-000008',2,2,13,63,1.00,1.00,0.00,6,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (275,'INV-OUT-20261024095705178-7133925378900','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,2,26,1.00,1.00,0.00,4,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (276,'INV-OUT-20261024095705191-7133937860400','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,3,53,1.00,1.00,0.00,4,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (277,'INV-OUT-20261024095705198-7133945104900','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,4,54,1.00,1.00,0.00,4,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (278,'INV-OUT-20261024095705206-7133954686600','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,5,55,2.00,2.00,0.00,4,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (279,'INV-OUT-20261024095705219-7133966126700','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,6,56,1.00,1.00,0.00,4,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (280,'INV-OUT-20261024095705228-7133975107500','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,7,57,1.00,1.00,0.00,4,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (281,'INV-OUT-20261024095705237-7133984300000','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,8,58,1.00,1.00,0.00,4,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (282,'INV-OUT-20261024095705243-7133990554400','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,9,59,1.00,1.00,0.00,4,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (283,'INV-OUT-20261024095705253-7134000519600','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,10,60,4.00,4.00,0.00,4,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (284,'INV-OUT-20261024095705260-7134007395500','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,11,61,1.00,1.00,0.00,4,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (285,'INV-OUT-20261024095705269-7134016123400','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,12,62,1.00,1.00,0.00,4,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (286,'INV-OUT-20261024095705275-7134022430100','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,13,63,1.00,1.00,0.00,4,'2026-10-24 09:57:05','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (287,'INV-IN-20261024095705681-7134428302500','IN','WIP_OUTPUT',22,'LINE-OUTPUT-6-22',3,3,16,64,1.00,0.00,1.00,4,'2026-10-24 09:57:06','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (288,'INV-IN-20261024095705760-7134507161600','IN','PRODUCTION_RECEIPT',17,'FG-IN-000007',4,4,16,64,1.00,0.00,1.00,6,'2026-10-24 09:57:06',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (289,'INV-OUT-20261024095705766-7134514293800','OUT','WIP_RECEIPT',17,'LINE-RECEIPT-6-17',3,3,16,64,1.00,1.00,0.00,6,'2026-10-24 09:57:06','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (290,'INV-OUT-20261024095705988-7134735098900','OUT','SALES_SHIPMENT',12,'SHIP-000003',4,4,16,52,1.00,1.00,0.00,6,'2026-10-24 09:57:06',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (291,'INV-OUT-20261024095705990-7134737609700','OUT','SALES_SHIPMENT',12,'SHIP-000003',4,4,16,64,1.00,1.00,0.00,6,'2026-10-24 09:57:06',NULL);
/*!40000 ALTER TABLE `t_inventory_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_location`
--

DROP TABLE IF EXISTS `t_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_location` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '库位ID',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `location_code` varchar(50) NOT NULL COMMENT '库位编码',
  `location_name` varchar(100) NOT NULL COMMENT '库位名称',
  `location_type` varchar(30) DEFAULT NULL COMMENT '库位类型',
  `status` varchar(30) NOT NULL DEFAULT '1' COMMENT '状态',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  `x_coordinate` int DEFAULT NULL,
  `y_coordinate` int DEFAULT NULL,
  `z_coordinate` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='库位表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_location`
--

LOCK TABLES `t_location` WRITE;
/*!40000 ALTER TABLE `t_location` DISABLE KEYS */;
INSERT INTO `t_location` (`id`, `warehouse_id`, `location_code`, `location_name`, `location_type`, `status`, `created_at`, `updated_at`, `is_deleted`, `x_coordinate`, `y_coordinate`, `z_coordinate`) VALUES (1,1,'LOC-001','默认库位','NORMAL','1','2026-07-15 10:21:37','2026-07-15 10:21:37',0,NULL,NULL,NULL);
INSERT INTO `t_location` (`id`, `warehouse_id`, `location_code`, `location_name`, `location_type`, `status`, `created_at`, `updated_at`, `is_deleted`, `x_coordinate`, `y_coordinate`, `z_coordinate`) VALUES (2,2,'WH-A100-RM-01','一号库位',NULL,'1','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,NULL,NULL);
INSERT INTO `t_location` (`id`, `warehouse_id`, `location_code`, `location_name`, `location_type`, `status`, `created_at`, `updated_at`, `is_deleted`, `x_coordinate`, `y_coordinate`, `z_coordinate`) VALUES (3,3,'WH-A100-LINE-01','一号库位',NULL,'1','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,NULL,NULL);
INSERT INTO `t_location` (`id`, `warehouse_id`, `location_code`, `location_name`, `location_type`, `status`, `created_at`, `updated_at`, `is_deleted`, `x_coordinate`, `y_coordinate`, `z_coordinate`) VALUES (4,4,'WH-A100-FG-01','一号库位',NULL,'1','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `t_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_login_log`
--

DROP TABLE IF EXISTS `t_login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_login_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '登录日志ID',
  `user_id` bigint DEFAULT NULL COMMENT '用户ID',
  `user_code` varchar(6) NOT NULL COMMENT '用户编码',
  `username` varchar(50) NOT NULL COMMENT '登录账号',
  `login_type` tinyint NOT NULL COMMENT '操作类型：1登录 2登出',
  `login_ip` varchar(50) DEFAULT NULL COMMENT '登录IP',
  `login_location` varchar(100) DEFAULT NULL COMMENT '登录地点',
  `browser` varchar(255) DEFAULT NULL COMMENT '浏览器',
  `os` varchar(255) DEFAULT NULL COMMENT '操作系统',
  `status` tinyint NOT NULL COMMENT '状态：0失败 1成功',
  `msg` varchar(255) DEFAULT NULL COMMENT '提示消息',
  `login_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '登录时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='登录日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_login_log`
--

LOCK TABLES `t_login_log` WRITE;
/*!40000 ALTER TABLE `t_login_log` DISABLE KEYS */;
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (1,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 10:30:23');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (2,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 10:42:43');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (3,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 10:51:17');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (4,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 12:51:59');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (5,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 14:33:47');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (6,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 14:39:34');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (7,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 14:49:01');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (8,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:18:43');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (9,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:23:59');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (10,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:24:57');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (11,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:43:18');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (12,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:46:25');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (13,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:54:24');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (14,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:56:25');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (15,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 16:02:53');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (16,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 16:14:27');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (17,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 17:16:23');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (18,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 17:20:30');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (19,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 18:15:56');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (20,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 18:20:48');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (21,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 18:40:30');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (22,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-15 19:13:32');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (23,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-15 19:15:46');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (24,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 19:16:19');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (25,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-15 19:18:28');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (26,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 19:21:38');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (27,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-15 19:31:50');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (28,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 19:40:27');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (29,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 19:51:06');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (30,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 20:09:03');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (31,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 20:37:43');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (32,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-16 08:52:29');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (33,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 08:54:42');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (34,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 09:23:04');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (35,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 10:25:16');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (36,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 10:29:50');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (37,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 10:40:43');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (38,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 10:46:00');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (39,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 10:50:16');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (40,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 11:03:09');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (41,1,'109001','admin',1,'172.24.79.157',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-16 11:21:10');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (42,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 11:24:54');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (43,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 11:30:09');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (44,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 12:22:24');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (45,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 12:28:50');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (46,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 13:06:01');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (47,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 14:25:11');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (48,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 14:38:45');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (49,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 15:56:23');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (50,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 22:42:16');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (51,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 22:42:49');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (52,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 22:53:03');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (53,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 08:31:56');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (54,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-07-17 08:55:53');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (55,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 08:57:11');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (56,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-07-17 09:07:04');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (57,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-07-17 09:09:58');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (58,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 09:11:59');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (59,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-07-17 09:14:48');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (60,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-07-17 09:24:56');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (61,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-07-17 09:32:46');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (62,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 13:19:59');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (63,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 13:25:37');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (64,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 13:51:53');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (65,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 13:54:59');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (66,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 13:56:52');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (67,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 14:04:10');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (68,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 14:04:23');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (69,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:16:08');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (70,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 14:18:43');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (71,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:19:48');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (72,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:22:18');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (73,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:24:42');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (74,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:28:12');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (75,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:31:05');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (76,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:33:25');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (77,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:34:49');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (78,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:41:47');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (79,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:42:28');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (80,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 14:43:04');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (81,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:43:51');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (82,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 14:44:16');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (83,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:45:39');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (84,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-18 08:37:01');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (85,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-18 08:37:09');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (86,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-18 08:37:59');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (87,2,'101001','prod_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-18 15:23:07');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (88,2,'101001','prod_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-18 15:23:26');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (89,1,'109001','admin',1,'127.0.0.1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-10-18 15:29:08');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (90,1,'109001','admin',1,'127.0.0.1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-10-19 08:43:28');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (91,1,'109001','admin',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-19 08:45:07');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (92,1,'109001','admin',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-19 09:13:50');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (93,1,'109001','admin',1,'127.0.0.1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-10-19 21:27:36');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (94,1,'109001','admin',1,'127.0.0.1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-10-23 23:24:07');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (95,1,'109001','admin',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-23 23:35:18');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (96,1,'109001','admin',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-24 09:56:47');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (97,4,'103001','worker1',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-24 09:56:48');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (98,5,'104001','qc_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-24 09:56:48');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (99,6,'105001','warehouse_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-24 09:56:48');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (100,7,'106001','purchase_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-24 09:56:48');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (101,8,'107001','sales_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-24 09:56:48');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (102,9,'108001','equipment_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-24 09:56:48');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (103,11,'111001','mcadmin',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-24 09:56:48');
/*!40000 ALTER TABLE `t_login_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_lot`
--

DROP TABLE IF EXISTS `t_lot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_lot` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '批次ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_no` varchar(50) NOT NULL COMMENT '批次号',
  `production_date` datetime DEFAULT NULL COMMENT '生产日期',
  `expire_date` datetime DEFAULT NULL COMMENT '过期日期',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `lot_no` (`lot_no`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='批次表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_lot`
--

LOCK TABLES `t_lot` WRITE;
/*!40000 ALTER TABLE `t_lot` DISABLE KEYS */;
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (1,2,'MC-095646861401-0-2','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:50','2026-10-24 09:56:50',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (2,3,'MC-095646861401-0-3','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:50','2026-10-24 09:56:50',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (3,4,'MC-095646861401-0-4','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:50','2026-10-24 09:56:50',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (4,5,'MC-095646861401-0-5','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:50','2026-10-24 09:56:50',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (5,6,'MC-095646861401-0-6','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:50','2026-10-24 09:56:50',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (6,7,'MC-095646861401-0-7','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:50','2026-10-24 09:56:50',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (7,8,'MC-095646861401-0-8','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:50','2026-10-24 09:56:50',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (8,9,'MC-095646861401-0-9','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:50','2026-10-24 09:56:50',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (9,10,'MC-095646861401-0-10','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:50','2026-10-24 09:56:50',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (10,11,'MC-095646861401-0-11','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:50','2026-10-24 09:56:50',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (11,12,'MC-095646861401-0-12','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:50','2026-10-24 09:56:50',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (12,13,'MC-095646861401-0-13','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:50','2026-10-24 09:56:50',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (13,2,'MC-095646861401-1-2','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:51','2026-10-24 09:56:51',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (14,3,'MC-095646861401-1-3','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:51','2026-10-24 09:56:51',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (15,4,'MC-095646861401-1-4','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:51','2026-10-24 09:56:51',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (16,5,'MC-095646861401-1-5','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:51','2026-10-24 09:56:51',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (17,6,'MC-095646861401-1-6','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:51','2026-10-24 09:56:51',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (18,7,'MC-095646861401-1-7','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:51','2026-10-24 09:56:51',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (19,8,'MC-095646861401-1-8','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:51','2026-10-24 09:56:51',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (20,9,'MC-095646861401-1-9','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:51','2026-10-24 09:56:51',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (21,10,'MC-095646861401-1-10','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:51','2026-10-24 09:56:51',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (22,11,'MC-095646861401-1-11','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:51','2026-10-24 09:56:51',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (23,12,'MC-095646861401-1-12','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:51','2026-10-24 09:56:51',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (24,13,'MC-095646861401-1-13','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:51','2026-10-24 09:56:51',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (25,16,'FG-MO-1','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:55','2026-10-24 09:56:55',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (26,2,'MC-BOXLOT-095646861401','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:57','2026-10-24 09:56:57',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (27,4,'MC-WO-095646861401-3-4','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:59','2026-10-24 09:56:59',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (28,5,'MC-WO-095646861401-3-5','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:59','2026-10-24 09:56:59',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (29,6,'MC-WO-095646861401-3-6','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:59','2026-10-24 09:56:59',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (30,7,'MC-WO-095646861401-3-7','2026-10-24 00:00:00',NULL,'2026-10-24 09:56:59','2026-10-24 09:56:59',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (31,14,'FG-MO-3','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:00','2026-10-24 09:57:00',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (32,3,'MC-WO-095646861401-4-3','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:00','2026-10-24 09:57:00',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (33,8,'MC-WO-095646861401-4-8','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:00','2026-10-24 09:57:00',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (34,9,'MC-WO-095646861401-4-9','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:00','2026-10-24 09:57:00',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (35,10,'MC-WO-095646861401-4-10','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:00','2026-10-24 09:57:00',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (36,15,'FG-MO-4','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:01','2026-10-24 09:57:01',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (37,11,'MC-WO-095646861401-2-11','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:01','2026-10-24 09:57:01',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (38,12,'MC-WO-095646861401-2-12','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:01','2026-10-24 09:57:01',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (39,13,'MC-WO-095646861401-2-13','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:01','2026-10-24 09:57:01',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (40,16,'FG-MO-2','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:02',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (41,3,'MC-WO-095646861401-5-3','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:02',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (42,4,'MC-WO-095646861401-5-4','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:02',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (43,5,'MC-WO-095646861401-5-5','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:02',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (44,6,'MC-WO-095646861401-5-6','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:02',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (45,7,'MC-WO-095646861401-5-7','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:02',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (46,8,'MC-WO-095646861401-5-8','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:02',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (47,9,'MC-WO-095646861401-5-9','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:02',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (48,10,'MC-WO-095646861401-5-10','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:02',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (49,11,'MC-WO-095646861401-5-11','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:02',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (50,12,'MC-WO-095646861401-5-12','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:02',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (51,13,'MC-WO-095646861401-5-13','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:02',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (52,16,'FG-MO-5','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:04','2026-10-24 09:57:04',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (53,3,'MC-WO-095646861401-6-3','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:04','2026-10-24 09:57:04',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (54,4,'MC-WO-095646861401-6-4','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:04','2026-10-24 09:57:04',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (55,5,'MC-WO-095646861401-6-5','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:04','2026-10-24 09:57:04',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (56,6,'MC-WO-095646861401-6-6','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:04','2026-10-24 09:57:04',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (57,7,'MC-WO-095646861401-6-7','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:04','2026-10-24 09:57:04',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (58,8,'MC-WO-095646861401-6-8','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:04','2026-10-24 09:57:04',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (59,9,'MC-WO-095646861401-6-9','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:04','2026-10-24 09:57:04',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (60,10,'MC-WO-095646861401-6-10','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:04','2026-10-24 09:57:04',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (61,11,'MC-WO-095646861401-6-11','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:04','2026-10-24 09:57:04',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (62,12,'MC-WO-095646861401-6-12','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:04','2026-10-24 09:57:04',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (63,13,'MC-WO-095646861401-6-13','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:04','2026-10-24 09:57:04',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (64,16,'FG-MO-6','2026-10-24 00:00:00',NULL,'2026-10-24 09:57:05','2026-10-24 09:57:05',0);
/*!40000 ALTER TABLE `t_lot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_maintenance`
--

DROP TABLE IF EXISTS `t_maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_maintenance` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '维护记录ID',
  `maintenance_no` varchar(50) NOT NULL COMMENT '维护单号',
  `equipment_id` bigint NOT NULL COMMENT '设备ID',
  `equipment_name` varchar(100) NOT NULL COMMENT '设备名称',
  `maintenance_type` tinyint NOT NULL COMMENT '维护类型',
  `fault_desc` text COMMENT '故障描述',
  `maintenance_content` text,
  `maintenance_user_id` bigint DEFAULT NULL,
  `maintenance_user_name` varchar(50) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `cost` decimal(10,2) DEFAULT NULL COMMENT '维护费用',
  `result` varchar(50) DEFAULT NULL,
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `status` varchar(30) NOT NULL DEFAULT 'PENDING' COMMENT '维修状态',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `maintenance_no` (`maintenance_no`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='设备维护记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_maintenance`
--

LOCK TABLES `t_maintenance` WRITE;
/*!40000 ALTER TABLE `t_maintenance` DISABLE KEYS */;
INSERT INTO `t_maintenance` (`id`, `maintenance_no`, `equipment_id`, `equipment_name`, `maintenance_type`, `fault_desc`, `maintenance_content`, `maintenance_user_id`, `maintenance_user_name`, `start_time`, `end_time`, `cost`, `result`, `remark`, `create_time`, `status`, `update_time`) VALUES (1,'REPAIR-000001',2,'隔离设备',2,'隔离验收异常，生成报修','隔离验收维修完成',9,'黄十二','2026-10-24 09:56:58','2026-10-24 09:56:58',0.00,'REPAIRED','来源点检记录 1','2026-10-24 09:56:58','FINISHED','2026-10-24 09:56:58');
/*!40000 ALTER TABLE `t_maintenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_material`
--

DROP TABLE IF EXISTS `t_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_material` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '物料ID',
  `material_code` varchar(50) NOT NULL COMMENT '物料编码',
  `material_name` varchar(100) NOT NULL COMMENT '物料名称',
  `material_type` tinyint NOT NULL COMMENT '物料类型：1原材料 2半成品 3成品',
  `specification` varchar(100) DEFAULT NULL COMMENT '规格型号',
  `unit` varchar(20) NOT NULL COMMENT '计量单位',
  `safety_stock` int DEFAULT NULL COMMENT '安全库存',
  `current_stock` int NOT NULL DEFAULT '0' COMMENT '当前库存',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0禁用 1启用',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `category_id` bigint DEFAULT NULL,
  `max_stock` decimal(18,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `material_code` (`material_code`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='物料表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_material`
--

LOCK TABLES `t_material` WRITE;
/*!40000 ALTER TABLE `t_material` DISABLE KEYS */;
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`) VALUES (1,'MAT-001','测试物料',1,'默认规格','个',10,100,1,'系统初始化物料','2026-07-15 10:21:37','2026-07-15 10:21:37',NULL,NULL);
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`) VALUES (2,'MAT-SHELL-TOP-A100','鼠标上盖',1,NULL,'个',0,3,1,NULL,'2026-10-19 08:41:54','2026-10-24 09:57:05',NULL,NULL);
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`) VALUES (3,'MAT-SHELL-BOTTOM-A100','鼠标下盖',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 09:57:05',NULL,NULL);
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`) VALUES (4,'MAT-PCB-A100','PCB主板',1,NULL,'块',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 09:57:05',NULL,NULL);
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`) VALUES (5,'MAT-SWITCH-01','微动开关',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 09:57:05',NULL,NULL);
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`) VALUES (6,'MAT-ENCODER-01','滚轮编码器',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 09:57:05',NULL,NULL);
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`) VALUES (7,'MAT-USB-CABLE-A100','USB连接线',1,NULL,'根',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 09:57:05',NULL,NULL);
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`) VALUES (8,'MAT-WHEEL-A100','滚轮组件',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 09:57:05',NULL,NULL);
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`) VALUES (9,'MAT-LENS-A100','光学透镜',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 09:57:05',NULL,NULL);
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`) VALUES (10,'MAT-SCREW-A100','固定螺钉',1,NULL,'颗',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 09:57:05',NULL,NULL);
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`) VALUES (11,'MAT-FEET-A100','防滑脚贴',1,NULL,'套',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 09:57:05',NULL,NULL);
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`) VALUES (12,'MAT-LABEL-A100','产品铭牌',1,NULL,'张',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 09:57:05',NULL,NULL);
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`) VALUES (13,'MAT-BOX-A100','包装盒',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 09:57:05',NULL,NULL);
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`) VALUES (14,'MAT-SEMI-E-A100','A100电子组件',2,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 09:57:02',NULL,NULL);
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`) VALUES (15,'MAT-SEMI-S-A100','A100结构组件',2,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 09:57:02',NULL,NULL);
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`) VALUES (16,'MAT-FG-A100','A100鼠标成品',3,NULL,'只',0,20,1,NULL,'2026-10-19 08:41:54','2026-10-24 09:57:05',NULL,NULL);
/*!40000 ALTER TABLE `t_material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_material_issue`
--

DROP TABLE IF EXISTS `t_material_issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_material_issue` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '领料单ID',
  `issue_no` varchar(50) NOT NULL COMMENT '领料单号',
  `work_order_id` bigint NOT NULL COMMENT '工单ID',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `total_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总数量',
  `status` varchar(30) NOT NULL DEFAULT 'PENDING' COMMENT '状态',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `issue_no` (`issue_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产领料单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_material_issue`
--

LOCK TABLES `t_material_issue` WRITE;
/*!40000 ALTER TABLE `t_material_issue` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_material_issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_material_issue_item`
--

DROP TABLE IF EXISTS `t_material_issue_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_material_issue_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '领料明细ID',
  `issue_id` bigint NOT NULL COMMENT '领料单ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_id` bigint DEFAULT NULL COMMENT '批次ID',
  `planned_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '计划数量',
  `actual_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '实际数量',
  `location_id` bigint DEFAULT NULL COMMENT '库位ID',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产领料明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_material_issue_item`
--

LOCK TABLES `t_material_issue_item` WRITE;
/*!40000 ALTER TABLE `t_material_issue_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_material_issue_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_operation_log`
--

DROP TABLE IF EXISTS `t_operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_operation_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '操作日志ID',
  `user_id` bigint DEFAULT NULL COMMENT '操作人ID',
  `user_code` varchar(6) NOT NULL COMMENT '操作人编码',
  `username` varchar(50) NOT NULL COMMENT '操作人账号',
  `module` varchar(50) NOT NULL COMMENT '操作模块',
  `operation` varchar(100) NOT NULL COMMENT '操作描述',
  `method` varchar(200) DEFAULT NULL COMMENT '请求方法',
  `request_url` varchar(255) DEFAULT NULL COMMENT '请求URL',
  `request_param` text COMMENT '请求参数',
  `response_result` text COMMENT '返回结果',
  `operate_ip` varchar(50) DEFAULT NULL COMMENT '操作IP',
  `operate_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  `status` tinyint NOT NULL COMMENT '状态：0失败 1成功',
  `error_msg` text COMMENT '错误消息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='操作日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_operation_log`
--

LOCK TABLES `t_operation_log` WRITE;
/*!40000 ALTER TABLE `t_operation_log` DISABLE KEYS */;
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (1,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 10:30:23',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (2,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 10:42:43',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (3,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 10:51:17',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (4,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 12:51:59',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (5,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 14:33:47',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (6,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 14:39:34',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (7,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 14:49:01',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (8,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:18:43',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (9,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:23:59',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (10,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:24:57',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (11,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:43:18',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (12,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:46:25',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (13,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:54:24',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (14,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:56:25',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (15,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 16:02:53',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (16,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 16:14:27',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (17,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 17:16:23',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (18,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 17:20:30',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (19,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 18:15:56',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (20,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 18:20:48',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (21,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 18:40:30',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (22,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:13:32',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (23,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:15:46',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (24,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:16:19',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (25,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:18:28',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (26,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:21:38',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (27,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:31:50',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (28,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:40:27',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (29,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:51:06',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (30,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 20:09:03',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (31,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 20:37:43',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (32,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 08:52:29',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (33,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 08:54:42',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (34,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 09:23:04',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (35,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 10:25:16',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (36,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 10:29:50',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (37,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 10:40:43',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (38,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 10:46:00',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (39,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 10:50:16',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (40,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 11:03:09',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (41,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 11:21:10',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (42,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 11:24:54',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (43,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 11:30:09',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (44,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 12:22:24',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (45,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 12:28:50',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (46,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 13:06:01',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (47,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 14:25:11',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (48,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 14:38:45',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (49,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 15:56:23',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (50,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 22:42:16',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (51,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 22:42:49',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (52,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 22:53:03',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (53,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 08:31:56',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (54,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 08:55:53',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (55,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 08:57:11',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (56,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 09:07:04',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (57,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 09:09:58',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (58,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 09:11:59',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (59,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 09:14:48',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (60,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 09:24:56',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (61,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 09:32:46',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (62,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 13:19:59',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (63,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 13:25:37',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (64,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 13:51:53',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (65,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 13:54:59',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (66,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 13:56:52',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (67,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:04:10',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (68,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:04:23',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (69,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:16:08',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (70,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:18:43',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (71,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:19:48',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (72,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:22:18',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (73,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:24:42',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (74,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:28:12',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (75,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:31:05',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (76,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:33:25',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (77,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:34:49',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (78,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:41:47',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (79,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:42:28',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (80,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:43:04',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (81,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:43:51',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (82,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:44:16',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (83,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:45:39',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (84,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-18 08:37:01',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (85,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-18 08:37:09',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (86,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-18 08:37:59',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (87,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-18 15:23:07',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (88,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-18 15:23:26',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (89,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-18 15:29:08',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (90,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-19 08:43:28',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (91,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-19 08:45:07',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (92,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-19 09:13:51',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (93,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-19 21:27:36',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (94,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-23 23:24:07',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (95,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-23 23:35:18',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (96,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-24 09:56:47',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (97,4,'103001','worker1','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-24 09:56:48',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (98,5,'104001','qc_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-24 09:56:48',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (99,6,'105001','warehouse_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-24 09:56:48',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (100,7,'106001','purchase_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-24 09:56:48',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (101,8,'107001','sales_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-24 09:56:48',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (102,9,'108001','equipment_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-24 09:56:48',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (103,11,'111001','mcadmin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-24 09:56:48',1,NULL);
/*!40000 ALTER TABLE `t_operation_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order`
--

DROP TABLE IF EXISTS `t_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `order_no` varchar(50) NOT NULL COMMENT '订单编号',
  `customer_name` varchar(100) NOT NULL COMMENT '客户名称',
  `customer_phone` varchar(20) DEFAULT NULL COMMENT '客户电话',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `quantity` int NOT NULL COMMENT '订单数量',
  `unit_price` decimal(10,2) NOT NULL COMMENT '单价',
  `total_amount` decimal(10,2) NOT NULL COMMENT '总金额',
  `order_date` date NOT NULL COMMENT '下单日期',
  `delivery_date` date DEFAULT NULL COMMENT '交付日期',
  `order_status` tinyint NOT NULL DEFAULT '0' COMMENT '订单状态',
  `priority` tinyint NOT NULL DEFAULT '2' COMMENT '优先级',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_by` bigint NOT NULL COMMENT '创建人ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order`
--

LOCK TABLES `t_order` WRITE;
/*!40000 ALTER TABLE `t_order` DISABLE KEYS */;
INSERT INTO `t_order` (`id`, `order_no`, `customer_name`, `customer_phone`, `product_name`, `quantity`, `unit_price`, `total_amount`, `order_date`, `delivery_date`, `order_status`, `priority`, `remark`, `create_by`, `create_time`, `update_time`, `deleted`) VALUES (1,'ORD-20260715001','测试客户A','13900139001','测试鼠标',100,59.00,5900.00,'2026-07-15','2026-07-25',3,2,'测试订单',2,'2026-07-15 10:23:38','2026-07-16 11:29:17',0);
INSERT INTO `t_order` (`id`, `order_no`, `customer_name`, `customer_phone`, `product_name`, `quantity`, `unit_price`, `total_amount`, `order_date`, `delivery_date`, `order_status`, `priority`, `remark`, `create_by`, `create_time`, `update_time`, `deleted`) VALUES (2,'ORD-20260715002','测试客户B','13900139002','测试鼠标',200,59.00,11800.00,'2026-07-14','2026-07-22',1,1,'紧急订单',2,'2026-07-15 10:23:38','2026-07-17 13:57:49',1);
INSERT INTO `t_order` (`id`, `order_no`, `customer_name`, `customer_phone`, `product_name`, `quantity`, `unit_price`, `total_amount`, `order_date`, `delivery_date`, `order_status`, `priority`, `remark`, `create_by`, `create_time`, `update_time`, `deleted`) VALUES (3,'ORD-20260715003','测试客户C','13900139003','测试鼠标',150,59.00,8850.00,'2026-07-13','2026-07-20',2,2,'普通订单',2,'2026-07-15 10:23:38','2026-07-15 10:23:38',0);
INSERT INTO `t_order` (`id`, `order_no`, `customer_name`, `customer_phone`, `product_name`, `quantity`, `unit_price`, `total_amount`, `order_date`, `delivery_date`, `order_status`, `priority`, `remark`, `create_by`, `create_time`, `update_time`, `deleted`) VALUES (4,'ORD-20260715962','plt','15555555555','滚轮',10,10.00,100.00,'2026-07-15','2026-07-25',1,3,'无',2,'2026-07-15 20:41:20','2026-07-16 12:35:09',0);
INSERT INTO `t_order` (`id`, `order_no`, `customer_name`, `customer_phone`, `product_name`, `quantity`, `unit_price`, `total_amount`, `order_date`, `delivery_date`, `order_status`, `priority`, `remark`, `create_by`, `create_time`, `update_time`, `deleted`) VALUES (5,'MC-095646861401','隔离客户',NULL,'A100有线办公鼠标',100,89.00,8900.00,'2026-10-24',NULL,3,2,NULL,8,'2026-10-24 09:56:50','2026-10-24 09:56:56',0);
INSERT INTO `t_order` (`id`, `order_no`, `customer_name`, `customer_phone`, `product_name`, `quantity`, `unit_price`, `total_amount`, `order_date`, `delivery_date`, `order_status`, `priority`, `remark`, `create_by`, `create_time`, `update_time`, `deleted`) VALUES (6,'MC-MULTI-095646861401','隔离多工单客户',NULL,'A100有线办公鼠标',2,89.00,178.00,'2026-10-24',NULL,3,2,NULL,8,'2026-10-24 09:57:03','2026-10-24 09:57:05',0);
/*!40000 ALTER TABLE `t_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_product`
--

DROP TABLE IF EXISTS `t_order_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_product` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '订单产品明细ID',
  `order_id` bigint NOT NULL COMMENT '订单ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `quantity` int NOT NULL COMMENT '数量',
  `unit_price` decimal(10,2) NOT NULL COMMENT '单价',
  `subtotal` decimal(10,2) NOT NULL COMMENT '小计',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='订单产品明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_product`
--

LOCK TABLES `t_order_product` WRITE;
/*!40000 ALTER TABLE `t_order_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_order_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_product`
--

DROP TABLE IF EXISTS `t_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_product` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '产品ID',
  `product_code` varchar(50) NOT NULL COMMENT '产品编码',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `product_type` varchar(50) DEFAULT NULL COMMENT '产品类型',
  `model` varchar(50) DEFAULT NULL COMMENT '产品型号',
  `specification` varchar(100) DEFAULT NULL COMMENT '规格',
  `unit` varchar(20) NOT NULL COMMENT '单位',
  `cost_price` decimal(10,2) DEFAULT NULL COMMENT '成本价',
  `selling_price` decimal(10,2) DEFAULT NULL COMMENT '销售价',
  `description` text COMMENT '描述',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0停售 1在售',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `category_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code` (`product_code`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='产品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_product`
--

LOCK TABLES `t_product` WRITE;
/*!40000 ALTER TABLE `t_product` DISABLE KEYS */;
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`, `category_id`) VALUES (1,'PROD-001','测试鼠标','鼠标','M-001','默认规格','个',20.00,59.00,NULL,1,'2026-07-15 10:21:37','2026-07-15 10:21:37',NULL);
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`, `category_id`) VALUES (2,'PROD-002','无线鼠标','鼠标','M-002','无线蓝牙版','个',35.00,89.00,NULL,1,'2026-07-17 14:01:48','2026-07-17 14:01:48',NULL);
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`, `category_id`) VALUES (3,'PROD-003','游戏鼠标','鼠标','M-003','RGB背光','个',50.00,129.00,NULL,1,'2026-07-17 14:01:48','2026-07-17 14:01:48',NULL);
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`, `category_id`) VALUES (4,'PROD-004','办公鼠标','鼠标','M-004','静音版','个',25.00,69.00,NULL,1,'2026-07-17 14:01:48','2026-07-17 14:01:48',NULL);
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`, `category_id`) VALUES (5,'PROD-005','有线鼠标','鼠标','M-005','USB接口','个',15.00,49.00,NULL,1,'2026-07-17 14:01:48','2026-07-17 14:01:48',NULL);
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`, `category_id`) VALUES (6,'PRD-MOUSE-A100','A100有线办公鼠标','有线鼠标','A100','USB有线、1200DPI、3键','只',42.00,89.00,NULL,1,'2026-10-19 08:41:54','2026-10-19 08:41:54',NULL);
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`, `category_id`) VALUES (7,'MC-SEMI-15-095646861401','隔离A100结构组件',NULL,NULL,NULL,'个',1.00,1.00,NULL,1,'2026-10-24 09:56:58','2026-10-24 09:56:58',NULL);
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`, `category_id`) VALUES (8,'MC-SEMI-14-095646861401','隔离A100电子组件',NULL,NULL,NULL,'个',1.00,1.00,NULL,1,'2026-10-24 09:56:59','2026-10-24 09:56:59',NULL);
/*!40000 ALTER TABLE `t_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_production_order`
--

DROP TABLE IF EXISTS `t_production_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_production_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '生产订单ID',
  `po_no` varchar(50) NOT NULL COMMENT '生产订单编号',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `planned_quantity` decimal(10,2) NOT NULL COMMENT '计划数量',
  `actual_quantity` decimal(10,2) DEFAULT '0.00' COMMENT '实际数量',
  `planned_start_date` datetime DEFAULT NULL COMMENT '计划开始时间',
  `planned_end_date` datetime DEFAULT NULL COMMENT '计划结束时间',
  `actual_start_date` datetime DEFAULT NULL COMMENT '实际开始时间',
  `actual_end_date` datetime DEFAULT NULL COMMENT '实际结束时间',
  `status` varchar(30) NOT NULL DEFAULT 'DRAFT' COMMENT '状态',
  `department_id` bigint DEFAULT NULL COMMENT '部门ID',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `po_no` (`po_no`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_production_order`
--

LOCK TABLES `t_production_order` WRITE;
/*!40000 ALTER TABLE `t_production_order` DISABLE KEYS */;
INSERT INTO `t_production_order` (`id`, `po_no`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (1,'PO-20260715001',1,200.00,50.00,'2026-07-15 08:00:00','2026-07-22 18:00:00',NULL,NULL,'IN_PROGRESS',2,2,'2026-07-15 10:24:08','2026-07-15 10:24:08',0);
INSERT INTO `t_production_order` (`id`, `po_no`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (2,'PO-20260715002',1,100.00,0.00,'2026-07-16 08:00:00','2026-07-25 18:00:00',NULL,NULL,'DRAFT',2,2,'2026-07-15 10:24:08','2026-07-15 10:24:08',0);
/*!40000 ALTER TABLE `t_production_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_production_plan`
--

DROP TABLE IF EXISTS `t_production_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_production_plan` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '计划ID',
  `plan_no` varchar(50) NOT NULL COMMENT '计划编号',
  `order_id` bigint DEFAULT NULL COMMENT '订单ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `plan_quantity` int NOT NULL COMMENT '计划数量',
  `completed_quantity` int NOT NULL DEFAULT '0' COMMENT '完成数量',
  `start_date` date DEFAULT NULL COMMENT '开始日期',
  `end_date` date DEFAULT NULL COMMENT '结束日期',
  `plan_status` tinyint NOT NULL DEFAULT '0' COMMENT '计划状态',
  `priority` tinyint NOT NULL DEFAULT '2' COMMENT '优先级',
  `create_by` bigint NOT NULL COMMENT '创建人ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `plan_no` (`plan_no`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产计划表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_production_plan`
--

LOCK TABLES `t_production_plan` WRITE;
/*!40000 ALTER TABLE `t_production_plan` DISABLE KEYS */;
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (1,'PLAN-20260715001',2,1,'测试鼠标',200,50,'2026-07-15','2026-07-22',1,1,2,'2026-07-15 10:23:53','2026-07-15 10:23:53');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (2,'PLAN-20260715002',1,1,'测试鼠标',100,0,'2026-07-16','2026-07-25',0,2,2,'2026-07-15 10:23:53','2026-07-15 10:23:53');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (3,'PLAN-20260715003',3,1,'测试鼠标',150,150,'2026-07-13','2026-07-20',2,2,2,'2026-07-15 10:23:53','2026-07-15 10:23:53');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (7,'PLAN1784270777801',4,1,'滚轮',10,0,'2026-07-17','2026-07-25',0,3,2,'2026-07-17 14:46:18','2026-07-17 14:46:18');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (8,'PP1792807010144',5,6,'A100有线办公鼠标',100,100,'2026-10-24',NULL,2,2,8,'2026-10-24 09:56:50','2026-10-24 09:56:55');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (9,'PLAN-MO-000002',NULL,6,'A100有线办公鼠标',10,10,'2026-10-24','2026-10-31',2,2,1,'2026-10-24 09:56:59','2026-10-24 09:57:02');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (10,'PLAN-MO-000004',NULL,8,'隔离A100电子组件',10,10,'2026-10-24','2026-10-31',2,2,1,'2026-10-24 09:56:59','2026-10-24 09:57:00');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (11,'PLAN-MO-000006',NULL,7,'隔离A100结构组件',10,10,'2026-10-24','2026-10-31',2,2,1,'2026-10-24 09:56:59','2026-10-24 09:57:01');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (12,'PLAN-MO-000008',6,6,'A100有线办公鼠标',1,1,'2026-10-24','2026-10-31',2,2,1,'2026-10-24 09:57:02','2026-10-24 09:57:04');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (13,'PLAN-MO-000010',6,6,'A100有线办公鼠标',1,1,'2026-10-24','2026-10-31',2,2,1,'2026-10-24 09:57:02','2026-10-24 09:57:05');
/*!40000 ALTER TABLE `t_production_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_production_report`
--

DROP TABLE IF EXISTS `t_production_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_production_report` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '报工ID',
  `task_id` bigint NOT NULL COMMENT '任务ID',
  `report_user_id` bigint NOT NULL COMMENT '报工人ID',
  `report_user_name` varchar(50) NOT NULL COMMENT '报工人姓名',
  `report_quantity` int NOT NULL COMMENT '本次完成数量',
  `qualified_quantity` int NOT NULL COMMENT '合格数量',
  `defect_quantity` int NOT NULL COMMENT '不合格数量',
  `report_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '报工时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产报工表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_production_report`
--

LOCK TABLES `t_production_report` WRITE;
/*!40000 ALTER TABLE `t_production_report` DISABLE KEYS */;
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (1,1,3,'赵六',50,48,2,'2026-07-15 12:00:00','上午报工');
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (2,1,3,'赵六',30,29,1,'2026-07-15 18:00:00','下午报工');
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (3,2,4,'赵六',60,0,0,'2026-10-24 09:56:54',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (4,2,4,'赵六',40,0,0,'2026-10-24 09:56:55',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (5,3,4,'赵六',100,0,0,'2026-10-24 09:56:55',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (6,4,4,'赵六',100,0,0,'2026-10-24 09:56:55',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (7,5,4,'赵六',100,0,0,'2026-10-24 09:56:56',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (8,10,4,'赵六',10,0,0,'2026-10-24 09:57:00',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (9,11,4,'赵六',10,0,0,'2026-10-24 09:57:01',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (10,6,4,'赵六',6,0,0,'2026-10-24 09:57:02',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (11,12,4,'赵六',4,0,0,'2026-10-24 09:57:02',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (12,7,4,'赵六',10,0,0,'2026-10-24 09:57:02',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (13,8,4,'赵六',10,0,0,'2026-10-24 09:57:02',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (14,9,4,'赵六',10,0,0,'2026-10-24 09:57:02',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (15,13,4,'赵六',1,0,0,'2026-10-24 09:57:04',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (16,14,4,'赵六',1,0,0,'2026-10-24 09:57:04',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (17,15,4,'赵六',1,0,0,'2026-10-24 09:57:04',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (18,16,4,'赵六',1,0,0,'2026-10-24 09:57:04',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (19,17,4,'赵六',1,0,0,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (20,18,4,'赵六',1,0,0,'2026-10-24 09:57:05',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (21,19,4,'赵六',1,0,0,'2026-10-24 09:57:06',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (22,20,4,'赵六',1,0,0,'2026-10-24 09:57:06',NULL);
/*!40000 ALTER TABLE `t_production_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_production_report_item`
--

DROP TABLE IF EXISTS `t_production_report_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_production_report_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '报工明细ID',
  `report_id` bigint NOT NULL COMMENT '报工ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `good_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '良品数量',
  `defective_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '不良数量',
  `defect_type` varchar(100) DEFAULT NULL COMMENT '缺陷类型',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产报工明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_production_report_item`
--

LOCK TABLES `t_production_report_item` WRITE;
/*!40000 ALTER TABLE `t_production_report_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_production_report_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_production_task`
--

DROP TABLE IF EXISTS `t_production_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_production_task` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '任务ID',
  `task_no` varchar(50) NOT NULL COMMENT '任务编号',
  `plan_id` bigint NOT NULL COMMENT '计划ID',
  `task_type` tinyint NOT NULL COMMENT '任务类型',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `quantity` int NOT NULL COMMENT '任务数量',
  `assigned_user_id` bigint DEFAULT NULL COMMENT '分配用户ID',
  `assigned_user_name` varchar(50) DEFAULT NULL COMMENT '分配用户姓名',
  `task_status` tinyint NOT NULL DEFAULT '0' COMMENT '任务状态',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_no` (`task_no`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产任务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_production_task`
--

LOCK TABLES `t_production_task` WRITE;
/*!40000 ALTER TABLE `t_production_task` DISABLE KEYS */;
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (2,'MO-1-10',8,1,6,'A100有线办公鼠标',100,4,'赵六',4,'2026-10-24 09:56:54','2026-10-24 09:56:55',NULL,'2026-10-24 09:56:50','2026-10-24 09:56:55');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (3,'MO-1-20',8,1,6,'A100有线办公鼠标',100,4,'赵六',4,'2026-10-24 09:56:55','2026-10-24 09:56:55',NULL,'2026-10-24 09:56:50','2026-10-24 09:56:55');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (4,'MO-1-30',8,1,6,'A100有线办公鼠标',100,4,'赵六',4,'2026-10-24 09:56:55','2026-10-24 09:56:55',NULL,'2026-10-24 09:56:50','2026-10-24 09:56:55');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (5,'MO-1-40',8,1,6,'A100有线办公鼠标',100,4,'赵六',4,'2026-10-24 09:56:56','2026-10-24 09:56:56',NULL,'2026-10-24 09:56:50','2026-10-24 09:56:55');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (6,'MO-2-10',9,1,6,'A100有线办公鼠标',6,4,'赵六',4,'2026-10-24 09:57:02','2026-10-24 09:57:02',NULL,'2026-10-24 09:56:59','2026-10-24 09:57:01');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (7,'MO-2-20',9,1,6,'A100有线办公鼠标',10,4,'赵六',4,'2026-10-24 09:57:02','2026-10-24 09:57:02',NULL,'2026-10-24 09:56:59','2026-10-24 09:57:02');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (8,'MO-2-30',9,1,6,'A100有线办公鼠标',10,4,'赵六',4,'2026-10-24 09:57:02','2026-10-24 09:57:02',NULL,'2026-10-24 09:56:59','2026-10-24 09:57:02');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (9,'MO-2-40',9,1,6,'A100有线办公鼠标',10,4,'赵六',4,'2026-10-24 09:57:02','2026-10-24 09:57:02',NULL,'2026-10-24 09:56:59','2026-10-24 09:57:02');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (10,'MO-3-10',10,1,8,'隔离A100电子组件',10,4,'赵六',4,'2026-10-24 09:57:00','2026-10-24 09:57:00',NULL,'2026-10-24 09:56:59','2026-10-24 09:57:00');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (11,'MO-4-10',11,1,7,'隔离A100结构组件',10,4,'赵六',4,'2026-10-24 09:57:01','2026-10-24 09:57:01',NULL,'2026-10-24 09:56:59','2026-10-24 09:57:01');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (12,'MO-2-10-Sef4fea1e',9,1,6,'A100有线办公鼠标',4,4,'赵六',4,'2026-10-24 09:57:02','2026-10-24 09:57:02',NULL,'2026-10-24 09:56:59','2026-10-24 09:57:02');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (13,'MO-5-10',12,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 09:57:04','2026-10-24 09:57:04',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:03');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (14,'MO-5-20',12,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 09:57:04','2026-10-24 09:57:04',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:03');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (15,'MO-5-30',12,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 09:57:04','2026-10-24 09:57:04',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:03');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (16,'MO-5-40',12,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 09:57:04','2026-10-24 09:57:04',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:04');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (17,'MO-6-10',13,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 09:57:05','2026-10-24 09:57:05',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:05');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (18,'MO-6-20',13,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 09:57:05','2026-10-24 09:57:05',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:05');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (19,'MO-6-30',13,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 09:57:05','2026-10-24 09:57:06',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:05');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (20,'MO-6-40',13,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 09:57:06','2026-10-24 09:57:06',NULL,'2026-10-24 09:57:02','2026-10-24 09:57:05');
/*!40000 ALTER TABLE `t_production_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_purchase_order`
--

DROP TABLE IF EXISTS `t_purchase_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_purchase_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '采购订单ID',
  `po_no` varchar(50) NOT NULL COMMENT '采购订单编号',
  `supplier_id` bigint NOT NULL COMMENT '供应商ID',
  `order_date` datetime DEFAULT NULL COMMENT '采购日期',
  `expected_date` datetime DEFAULT NULL COMMENT '预计到货日期',
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总金额',
  `status` varchar(30) NOT NULL DEFAULT 'DRAFT' COMMENT '状态：DRAFT/SUBMITTED/APPROVED/PARTIAL_RECEIVED/COMPLETED/CANCELLED',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  `sales_order_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `po_no` (`po_no`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='采购订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_purchase_order`
--

LOCK TABLES `t_purchase_order` WRITE;
/*!40000 ALTER TABLE `t_purchase_order` DISABLE KEYS */;
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (1,'MC-095646861401-MAIN',1,NULL,NULL,1600.00,'COMPLETED',NULL,NULL,'2026-10-24 09:56:51','2026-10-24 09:56:52',0,NULL);
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (2,'MC-095646861401-CONVERT',1,NULL,NULL,20.00,'COMPLETED',NULL,NULL,'2026-10-24 09:56:57','2026-10-24 09:56:57',0,NULL);
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (3,'MC-095646861401-WO-3',1,NULL,NULL,50.00,'COMPLETED',NULL,NULL,'2026-10-24 09:57:00','2026-10-24 09:56:59',0,NULL);
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (4,'MC-095646861401-WO-4',1,NULL,NULL,70.00,'COMPLETED',NULL,NULL,'2026-10-24 09:57:00','2026-10-24 09:57:00',0,NULL);
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (5,'MC-095646861401-WO-2',1,NULL,NULL,30.00,'COMPLETED',NULL,NULL,'2026-10-24 09:57:01','2026-10-24 09:57:01',0,NULL);
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (6,'MC-095646861401-WO-5',1,NULL,NULL,15.00,'COMPLETED',NULL,NULL,'2026-10-24 09:57:03','2026-10-24 09:57:03',0,NULL);
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (7,'MC-095646861401-WO-6',1,NULL,NULL,15.00,'COMPLETED',NULL,NULL,'2026-10-24 09:57:04','2026-10-24 09:57:04',0,NULL);
/*!40000 ALTER TABLE `t_purchase_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_purchase_order_item`
--

DROP TABLE IF EXISTS `t_purchase_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_purchase_order_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '采购订单明细ID',
  `po_id` bigint NOT NULL COMMENT '采购订单ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `quantity` decimal(10,2) NOT NULL COMMENT '采购数量',
  `unit_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '单价',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `received_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '已到货数量',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='采购订单明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_purchase_order_item`
--

LOCK TABLES `t_purchase_order_item` WRITE;
/*!40000 ALTER TABLE `t_purchase_order_item` DISABLE KEYS */;
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (1,1,2,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (2,1,3,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (3,1,4,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (4,1,5,200.00,1.00,200.00,200.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (5,1,6,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (6,1,7,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (7,1,8,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (8,1,9,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (9,1,10,400.00,1.00,400.00,400.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (10,1,11,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (11,1,12,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (12,1,13,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (13,2,2,20.00,1.00,20.00,20.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (14,3,4,10.00,1.00,10.00,10.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (15,3,5,20.00,1.00,20.00,20.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (16,3,6,10.00,1.00,10.00,10.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (17,3,7,10.00,1.00,10.00,10.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (18,4,3,10.00,1.00,10.00,10.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (19,4,8,10.00,1.00,10.00,10.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (20,4,9,10.00,1.00,10.00,10.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (21,4,10,40.00,1.00,40.00,40.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (22,5,11,10.00,1.00,10.00,10.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (23,5,12,10.00,1.00,10.00,10.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (24,5,13,10.00,1.00,10.00,10.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (25,6,3,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (26,6,4,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (27,6,5,2.00,1.00,2.00,2.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (28,6,6,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (29,6,7,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (30,6,8,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (31,6,9,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (32,6,10,4.00,1.00,4.00,4.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (33,6,11,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (34,6,12,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (35,6,13,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (36,7,3,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (37,7,4,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (38,7,5,2.00,1.00,2.00,2.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (39,7,6,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (40,7,7,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (41,7,8,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (42,7,9,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (43,7,10,4.00,1.00,4.00,4.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (44,7,11,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (45,7,12,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (46,7,13,1.00,1.00,1.00,1.00,NULL);
/*!40000 ALTER TABLE `t_purchase_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_qc_inspection`
--

DROP TABLE IF EXISTS `t_qc_inspection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_qc_inspection` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '质检单ID',
  `inspection_no` varchar(50) NOT NULL COMMENT '质检单号',
  `inspection_type` varchar(30) NOT NULL COMMENT '质检类型',
  `source_order_id` bigint DEFAULT NULL COMMENT '来源单ID',
  `source_order_no` varchar(80) DEFAULT NULL COMMENT '来源单号',
  `sample_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '抽检数量',
  `qualified_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '合格数量',
  `defective_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '不合格数量',
  `result` varchar(30) DEFAULT NULL COMMENT '质检结果',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  `qualified_rate` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '合格率',
  `defect_reason` varchar(500) DEFAULT NULL COMMENT '不合格原因',
  `handle_method` varchar(500) DEFAULT NULL COMMENT '处理方式',
  `business_status` varchar(50) DEFAULT NULL COMMENT '后续业务状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `inspection_no` (`inspection_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='质检检验单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_qc_inspection`
--

LOCK TABLES `t_qc_inspection` WRITE;
/*!40000 ALTER TABLE `t_qc_inspection` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_qc_inspection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_qc_inspection_item`
--

DROP TABLE IF EXISTS `t_qc_inspection_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_qc_inspection_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '质检明细ID',
  `inspection_id` bigint NOT NULL COMMENT '质检单ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_id` bigint DEFAULT NULL COMMENT '批次ID',
  `sample_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '抽检数量',
  `qualified_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '合格数量',
  `defective_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '不合格数量',
  `defect_type` varchar(100) DEFAULT NULL COMMENT '缺陷类型',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `inspection_item` varchar(100) NOT NULL COMMENT '检测项',
  `inspection_standard` varchar(500) DEFAULT NULL COMMENT '检测标准',
  `actual_value` varchar(500) DEFAULT NULL COMMENT '实测值',
  `item_result` varchar(30) DEFAULT NULL COMMENT '明细结果',
  `defect_reason` varchar(500) DEFAULT NULL COMMENT '不合格原因',
  `handle_method` varchar(500) DEFAULT NULL COMMENT '处理方式',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='质检检验明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_qc_inspection_item`
--

LOCK TABLES `t_qc_inspection_item` WRITE;
/*!40000 ALTER TABLE `t_qc_inspection_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_qc_inspection_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_quality_check`
--

DROP TABLE IF EXISTS `t_quality_check`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_quality_check` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '质检记录ID',
  `check_no` varchar(50) NOT NULL COMMENT '质检单号',
  `task_id` bigint DEFAULT NULL COMMENT '任务ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `check_quantity` int NOT NULL COMMENT '质检数量',
  `qualified_quantity` int NOT NULL COMMENT '合格数量',
  `defect_quantity` int NOT NULL COMMENT '不合格数量',
  `qualified_rate` decimal(5,2) NOT NULL COMMENT '合格率',
  `check_result` tinyint NOT NULL COMMENT '质检结果',
  `checker_id` bigint NOT NULL COMMENT '质检员ID',
  `checker_name` varchar(50) NOT NULL COMMENT '质检员姓名',
  `check_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '质检时间',
  `defect_desc` text COMMENT '缺陷描述',
  `handle_result` varchar(500) DEFAULT NULL COMMENT '处理结果',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `check_no` (`check_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='质检记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_quality_check`
--

LOCK TABLES `t_quality_check` WRITE;
/*!40000 ALTER TABLE `t_quality_check` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_quality_check` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_quality_standard`
--

DROP TABLE IF EXISTS `t_quality_standard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_quality_standard` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '质检标准ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `standard_name` varchar(100) NOT NULL COMMENT '标准名称',
  `standard_content` text NOT NULL COMMENT '标准内容',
  `qualified_threshold` decimal(5,2) DEFAULT NULL COMMENT '合格阈值',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0禁用 1启用',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='质检标准表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_quality_standard`
--

LOCK TABLES `t_quality_standard` WRITE;
/*!40000 ALTER TABLE `t_quality_standard` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_quality_standard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_role`
--

DROP TABLE IF EXISTS `t_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_role` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `role_code` varchar(10) NOT NULL COMMENT '角色编码',
  `role_name` varchar(50) NOT NULL COMMENT '角色名称',
  `role_desc` varchar(255) DEFAULT NULL COMMENT '角色描述',
  `sort` int NOT NULL DEFAULT '0' COMMENT '显示顺序',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0禁用 1启用',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_code` (`role_code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='角色表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_role`
--

LOCK TABLES `t_role` WRITE;
/*!40000 ALTER TABLE `t_role` DISABLE KEYS */;
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (1,'101','生产经理','负责生产计划制定、任务分配和进度跟踪',1,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (2,'102','车间主任','负责车间日常管理和生产调度',2,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (3,'103','操作工','负责生产线操作和产品加工',3,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (4,'104','质检员','负责产品质量检测和质量标准执行',4,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (5,'105','仓管员','负责物料出入库管理和库存盘点',5,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (6,'106','采购专员','负责原材料采购和供应商管理',6,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (7,'107','销售专员','负责客户订单对接和销售业务',7,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (8,'108','设备管理员','负责设备管理和维修',8,1,'2026-07-15 10:21:37','2026-07-17 13:19:03');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (9,'109','CEO','公司最高管理者，拥有系统全部权限',9,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (10,'110','CFO','财务总监，负责公司利润、收入和支出管理',10,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
/*!40000 ALTER TABLE `t_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_sales_order`
--

DROP TABLE IF EXISTS `t_sales_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_sales_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '销售订单ID',
  `so_no` varchar(50) NOT NULL COMMENT '销售订单编号',
  `customer_id` bigint NOT NULL COMMENT '客户ID',
  `order_date` datetime DEFAULT NULL COMMENT '下单日期',
  `delivery_date` datetime DEFAULT NULL COMMENT '交付日期',
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总金额',
  `status` varchar(30) NOT NULL DEFAULT 'DRAFT' COMMENT '状态',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `so_no` (`so_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='销售订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_sales_order`
--

LOCK TABLES `t_sales_order` WRITE;
/*!40000 ALTER TABLE `t_sales_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_sales_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_sales_order_item`
--

DROP TABLE IF EXISTS `t_sales_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_sales_order_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '销售订单明细ID',
  `so_id` bigint NOT NULL COMMENT '销售订单ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `quantity` decimal(10,2) NOT NULL COMMENT '数量',
  `unit_price` decimal(10,2) NOT NULL COMMENT '单价',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='销售订单明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_sales_order_item`
--

LOCK TABLES `t_sales_order_item` WRITE;
/*!40000 ALTER TABLE `t_sales_order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_sales_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_stock_in`
--

DROP TABLE IF EXISTS `t_stock_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_stock_in` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '通用入库单ID',
  `stock_in_no` varchar(80) NOT NULL COMMENT '入库单号',
  `stock_in_type` varchar(30) NOT NULL COMMENT '入库类型',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `source_order_id` bigint DEFAULT NULL COMMENT '来源订单ID',
  `source_order_no` varchar(80) DEFAULT NULL COMMENT '来源订单编号',
  `total_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总数量',
  `status` varchar(30) NOT NULL DEFAULT 'PENDING' COMMENT '状态',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_in_no` (`stock_in_no`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通用入库单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_stock_in`
--

LOCK TABLES `t_stock_in` WRITE;
/*!40000 ALTER TABLE `t_stock_in` DISABLE KEYS */;
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (1,'PR-000001','PURCHASE_RECEIPT',2,1,'PR-000001',800.00,'COMPLETED',NULL,6,'2026-10-24 09:56:51','2026-10-24 09:56:51',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (2,'PR-000002','PURCHASE_RECEIPT',2,1,'PR-000002',800.00,'COMPLETED',NULL,6,'2026-10-24 09:56:52','2026-10-24 09:56:52',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (3,'L-RET-000001','LINE_RETURN',2,1,'L-RET-000001',40.00,'COMPLETED',NULL,6,'2026-10-24 09:56:55','2026-10-24 09:56:55',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (4,'FG-IN-000001','PRODUCTION_RECEIPT',4,1,'FG-IN-000001',40.00,'COMPLETED',NULL,6,'2026-10-24 09:56:56','2026-10-24 09:56:56',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (5,'FG-IN-000002','PRODUCTION_RECEIPT',4,1,'FG-IN-000002',60.00,'COMPLETED',NULL,6,'2026-10-24 09:56:56','2026-10-24 09:56:56',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (6,'S-RET-000001','SALES_RETURN',4,5,'S-RET-000001',10.00,'COMPLETED',NULL,6,'2026-10-24 09:56:57','2026-10-24 09:56:57',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (7,'PR-000003','PURCHASE_RECEIPT',2,2,'PR-000003',20.00,'COMPLETED',NULL,6,'2026-10-24 09:56:57','2026-10-24 09:56:57',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (8,'PR-000004','PURCHASE_RECEIPT',2,3,'PR-000004',50.00,'COMPLETED',NULL,6,'2026-10-24 09:57:00','2026-10-24 09:57:00',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (9,'FG-IN-000003','PRODUCTION_RECEIPT',4,3,'MO-000005',10.00,'COMPLETED',NULL,6,'2026-10-24 09:57:00','2026-10-24 09:57:00',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (10,'PR-000005','PURCHASE_RECEIPT',2,4,'PR-000005',70.00,'COMPLETED',NULL,6,'2026-10-24 09:57:01','2026-10-24 09:57:01',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (11,'FG-IN-000004','PRODUCTION_RECEIPT',4,4,'MO-000007',10.00,'COMPLETED',NULL,6,'2026-10-24 09:57:01','2026-10-24 09:57:01',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (12,'PR-000006','PURCHASE_RECEIPT',2,5,'PR-000006',30.00,'COMPLETED',NULL,6,'2026-10-24 09:57:01','2026-10-24 09:57:01',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (13,'FG-IN-000005','PRODUCTION_RECEIPT',4,2,'MO-000003',10.00,'COMPLETED',NULL,6,'2026-10-24 09:57:03','2026-10-24 09:57:03',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (14,'PR-000007','PURCHASE_RECEIPT',2,6,'PR-000007',15.00,'COMPLETED',NULL,6,'2026-10-24 09:57:03','2026-10-24 09:57:03',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (15,'FG-IN-000006','PRODUCTION_RECEIPT',4,5,'MO-000009',1.00,'COMPLETED',NULL,6,'2026-10-24 09:57:04','2026-10-24 09:57:04',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (16,'PR-000008','PURCHASE_RECEIPT',2,7,'PR-000008',15.00,'COMPLETED',NULL,6,'2026-10-24 09:57:05','2026-10-24 09:57:05',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (17,'FG-IN-000007','PRODUCTION_RECEIPT',4,6,'MO-000011',1.00,'COMPLETED',NULL,6,'2026-10-24 09:57:06','2026-10-24 09:57:06',0);
/*!40000 ALTER TABLE `t_stock_in` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_stock_in_item`
--

DROP TABLE IF EXISTS `t_stock_in_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_stock_in_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '通用入库明细ID',
  `stock_in_id` bigint NOT NULL COMMENT '入库单ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_id` bigint DEFAULT NULL COMMENT '批次ID',
  `quantity` decimal(10,2) NOT NULL COMMENT '数量',
  `location_id` bigint DEFAULT NULL COMMENT '库位ID',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通用入库明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_stock_in_item`
--

LOCK TABLES `t_stock_in_item` WRITE;
/*!40000 ALTER TABLE `t_stock_in_item` DISABLE KEYS */;
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (1,1,2,1,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (2,1,3,2,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (3,1,4,3,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (4,1,5,4,100.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (5,1,6,5,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (6,1,7,6,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (7,1,8,7,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (8,1,9,8,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (9,1,10,9,200.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (10,1,11,10,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (11,1,12,11,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (12,1,13,12,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (13,2,2,13,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (14,2,3,14,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (15,2,4,15,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (16,2,5,16,100.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (17,2,6,17,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (18,2,7,18,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (19,2,8,19,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (20,2,9,20,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (21,2,10,21,200.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (22,2,11,22,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (23,2,12,23,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (24,2,13,24,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (25,3,2,13,40.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (26,4,16,25,40.00,4,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (27,5,16,25,60.00,4,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (28,6,16,25,10.00,4,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (29,7,2,26,20.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (30,8,4,27,10.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (31,8,5,28,20.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (32,8,6,29,10.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (33,8,7,30,10.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (34,9,14,31,10.00,4,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (35,10,3,32,10.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (36,10,8,33,10.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (37,10,9,34,10.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (38,10,10,35,40.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (39,11,15,36,10.00,4,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (40,12,11,37,10.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (41,12,12,38,10.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (42,12,13,39,10.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (43,13,16,40,10.00,4,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (44,14,3,41,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (45,14,4,42,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (46,14,5,43,2.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (47,14,6,44,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (48,14,7,45,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (49,14,8,46,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (50,14,9,47,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (51,14,10,48,4.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (52,14,11,49,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (53,14,12,50,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (54,14,13,51,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (55,15,16,52,1.00,4,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (56,16,3,53,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (57,16,4,54,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (58,16,5,55,2.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (59,16,6,56,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (60,16,7,57,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (61,16,8,58,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (62,16,9,59,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (63,16,10,60,4.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (64,16,11,61,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (65,16,12,62,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (66,16,13,63,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (67,17,16,64,1.00,4,NULL);
/*!40000 ALTER TABLE `t_stock_in_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_stock_out`
--

DROP TABLE IF EXISTS `t_stock_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_stock_out` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '通用出库单ID',
  `stock_out_no` varchar(80) NOT NULL COMMENT '出库单号',
  `stock_out_type` varchar(30) NOT NULL COMMENT '出库类型',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `source_order_id` bigint DEFAULT NULL COMMENT '来源订单ID',
  `source_order_no` varchar(80) DEFAULT NULL COMMENT '来源订单编号',
  `total_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总数量',
  `status` varchar(30) NOT NULL DEFAULT 'PENDING' COMMENT '状态',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_out_no` (`stock_out_no`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通用出库单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_stock_out`
--

LOCK TABLES `t_stock_out` WRITE;
/*!40000 ALTER TABLE `t_stock_out` DISABLE KEYS */;
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (1,'ISS-000001','PRODUCTION_ISSUE',2,1,'MO-000001',1600.00,'COMPLETED',NULL,6,'2026-10-24 09:56:53','2026-10-24 09:56:53',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (2,'ISS-000002','LINE_ISSUE',2,1,'ISS-000002',40.00,'COMPLETED',NULL,6,'2026-10-24 09:56:55','2026-10-24 09:56:55',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (3,'SHIP-000001','SALES_SHIPMENT',4,5,'SHIP-000001',40.00,'COMPLETED',NULL,6,'2026-10-24 09:56:56','2026-10-24 09:56:56',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (4,'SHIP-000002','SALES_SHIPMENT',4,5,'SHIP-000002',60.00,'COMPLETED',NULL,6,'2026-10-24 09:56:56','2026-10-24 09:56:56',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (5,'P-RET-000001','PURCHASE_RETURN',2,2,'P-RET-000001',5.00,'COMPLETED',NULL,6,'2026-10-24 09:56:58','2026-10-24 09:56:58',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (6,'ISS-000003','LINE_ISSUE',2,3,'ISS-000003',50.00,'COMPLETED',NULL,6,'2026-10-24 09:57:00','2026-10-24 09:57:00',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (7,'ISS-000004','LINE_ISSUE',2,4,'ISS-000004',80.00,'COMPLETED',NULL,6,'2026-10-24 09:57:01','2026-10-24 09:57:01',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (8,'ISS-000005','LINE_ISSUE',2,2,'ISS-000005',30.00,'COMPLETED',NULL,6,'2026-10-24 09:57:02','2026-10-24 09:57:02',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (9,'ISS-000006','LINE_ISSUE',4,2,'ISS-000006',20.00,'COMPLETED',NULL,6,'2026-10-24 09:57:02','2026-10-24 09:57:02',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (10,'ISS-000007','LINE_ISSUE',2,5,'ISS-000007',16.00,'COMPLETED',NULL,6,'2026-10-24 09:57:04','2026-10-24 09:57:04',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (11,'ISS-000008','LINE_ISSUE',2,6,'ISS-000008',16.00,'COMPLETED',NULL,6,'2026-10-24 09:57:05','2026-10-24 09:57:05',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (12,'SHIP-000003','SALES_SHIPMENT',4,6,'SHIP-000003',2.00,'COMPLETED',NULL,6,'2026-10-24 09:57:06','2026-10-24 09:57:06',0);
/*!40000 ALTER TABLE `t_stock_out` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_stock_out_item`
--

DROP TABLE IF EXISTS `t_stock_out_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_stock_out_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '通用出库明细ID',
  `stock_out_id` bigint NOT NULL COMMENT '出库单ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_id` bigint DEFAULT NULL COMMENT '批次ID',
  `quantity` decimal(10,2) NOT NULL COMMENT '数量',
  `location_id` bigint DEFAULT NULL COMMENT '库位ID',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通用出库明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_stock_out_item`
--

LOCK TABLES `t_stock_out_item` WRITE;
/*!40000 ALTER TABLE `t_stock_out_item` DISABLE KEYS */;
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (1,1,2,1,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (2,1,2,13,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (3,1,3,2,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (4,1,3,14,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (5,1,4,3,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (6,1,4,15,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (7,1,5,4,100.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (8,1,5,16,100.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (9,1,6,5,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (10,1,6,17,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (11,1,7,6,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (12,1,7,18,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (13,1,8,7,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (14,1,8,19,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (15,1,9,8,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (16,1,9,20,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (17,1,10,9,200.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (18,1,10,21,200.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (19,1,11,10,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (20,1,11,22,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (21,1,12,11,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (22,1,12,23,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (23,1,13,12,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (24,1,13,24,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (25,2,2,13,40.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (26,3,16,25,40.00,4,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (27,4,16,25,60.00,4,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (28,5,2,26,5.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (29,6,4,27,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (30,6,5,28,20.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (31,6,6,29,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (32,6,7,30,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (33,7,2,26,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (34,7,3,32,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (35,7,8,33,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (36,7,9,34,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (37,7,10,35,40.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (38,8,11,37,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (39,8,12,38,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (40,8,13,39,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (41,9,14,31,10.00,4,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (42,9,15,36,10.00,4,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (43,10,2,26,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (44,10,3,41,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (45,10,4,42,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (46,10,5,43,2.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (47,10,6,44,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (48,10,7,45,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (49,10,8,46,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (50,10,9,47,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (51,10,10,48,4.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (52,10,11,49,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (53,10,12,50,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (54,10,13,51,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (55,11,2,26,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (56,11,3,53,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (57,11,4,54,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (58,11,5,55,2.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (59,11,6,56,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (60,11,7,57,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (61,11,8,58,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (62,11,9,59,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (63,11,10,60,4.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (64,11,11,61,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (65,11,12,62,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (66,11,13,63,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (67,12,16,52,1.00,4,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (68,12,16,64,1.00,4,NULL);
/*!40000 ALTER TABLE `t_stock_out_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_supplier`
--

DROP TABLE IF EXISTS `t_supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_supplier` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '供应商ID',
  `supplier_code` varchar(50) NOT NULL COMMENT '供应商编码',
  `supplier_name` varchar(100) NOT NULL COMMENT '供应商名称',
  `contact_person` varchar(50) DEFAULT NULL COMMENT '联系人',
  `contact_phone` varchar(20) DEFAULT NULL COMMENT '联系电话',
  `address` varchar(255) DEFAULT NULL COMMENT '地址',
  `bank_name` varchar(100) DEFAULT NULL COMMENT '开户银行',
  `bank_account` varchar(50) DEFAULT NULL COMMENT '银行账号',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：-1删除 0禁用 1活跃',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_code` (`supplier_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='供应商表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_supplier`
--

LOCK TABLES `t_supplier` WRITE;
/*!40000 ALTER TABLE `t_supplier` DISABLE KEYS */;
INSERT INTO `t_supplier` (`id`, `supplier_code`, `supplier_name`, `contact_person`, `contact_phone`, `address`, `bank_name`, `bank_account`, `status`, `remark`, `create_time`, `update_time`) VALUES (1,'MC-SUP-095646861401','隔离供应商',NULL,NULL,NULL,NULL,NULL,1,NULL,'2026-10-24 09:56:50','2026-10-24 09:56:50');
/*!40000 ALTER TABLE `t_supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_uom`
--

DROP TABLE IF EXISTS `t_uom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_uom` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '计量单位ID',
  `uom_code` varchar(50) NOT NULL COMMENT '单位编码',
  `uom_name` varchar(100) NOT NULL COMMENT '单位名称',
  `status` varchar(30) NOT NULL DEFAULT '1' COMMENT '状态',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  `main_unit_id` bigint DEFAULT NULL,
  `conversion_rate` decimal(18,6) NOT NULL DEFAULT '1.000000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uom_code` (`uom_code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='计量单位表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_uom`
--

LOCK TABLES `t_uom` WRITE;
/*!40000 ALTER TABLE `t_uom` DISABLE KEYS */;
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (1,'S1-U1','只','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,1.000000);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (2,'S1-U2','个','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,1.000000);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (3,'S1-U3','块','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,1.000000);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (4,'S1-U4','根','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,1.000000);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (5,'S1-U5','颗','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,1.000000);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (6,'S1-U6','套','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,1.000000);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (7,'S1-U7','张','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,1.000000);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (8,'MC-U-095646861401','测试主单位095646861401','ACTIVE','2026-10-24 09:56:48','2026-10-24 09:56:48',0,NULL,1.000000);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (9,'MC-A-095646861401','测试辅单位095646861401','ACTIVE','2026-10-24 09:56:48','2026-10-24 09:56:48',0,8,20.000000);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (10,'MC-BOX-095646861401','验收箱095646861401','ACTIVE','2026-10-24 09:56:57','2026-10-24 09:56:57',0,2,10.000000);
/*!40000 ALTER TABLE `t_uom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_user` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `user_code` varchar(6) NOT NULL COMMENT '6位用户编码',
  `username` varchar(50) NOT NULL COMMENT '登录账号',
  `password` varchar(255) NOT NULL COMMENT '登录密码',
  `real_name` varchar(50) DEFAULT NULL COMMENT '真实姓名',
  `phone` varchar(20) DEFAULT NULL COMMENT '手机号',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `gender` tinyint DEFAULT NULL COMMENT '性别：0女 1男',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像',
  `role_id` int NOT NULL COMMENT '角色ID',
  `dept_id` bigint DEFAULT NULL COMMENT '部门ID',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0离职 1在职 2试用期',
  `entry_date` date DEFAULT NULL COMMENT '入职日期',
  `leave_date` date DEFAULT NULL COMMENT '离职日期',
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(50) DEFAULT NULL COMMENT '最后登录IP',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除：0未删除 1已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_code` (`user_code`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user`
--

LOCK TABLES `t_user` WRITE;
/*!40000 ALTER TABLE `t_user` DISABLE KEYS */;
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (1,'109001','admin','','张三','13800138001','zhangsan@mouse.com',1,NULL,9,1,1,NULL,NULL,'2026-10-24 09:56:47','127.0.0.1','2026-07-15 10:21:37','2026-10-24 09:56:47',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (2,'101001','prod_manager','','李四','13800138002','lisi@mouse.com',1,NULL,1,2,1,NULL,NULL,'2026-10-18 15:23:26','127.0.0.1','2026-07-15 10:21:37','2026-10-18 15:23:26',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (3,'102001','workshop_manager','','王五','13800138003','wangwu@mouse.com',1,NULL,2,2,1,NULL,NULL,NULL,NULL,'2026-07-15 10:21:37','2026-07-15 10:21:37',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (4,'103001','worker1','','赵六','13800138004','zhaoliu@mouse.com',1,NULL,3,2,1,NULL,NULL,'2026-10-24 09:56:48','127.0.0.1','2026-07-15 10:21:37','2026-10-24 09:56:47',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (5,'104001','qc_manager','','周八','13800138006','zhouba@mouse.com',1,NULL,4,3,1,NULL,NULL,'2026-10-24 09:56:48','127.0.0.1','2026-07-15 10:21:37','2026-10-24 09:56:47',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (6,'105001','warehouse_manager','','吴九','13800138007','wujiu@mouse.com',1,NULL,5,4,1,NULL,NULL,'2026-10-24 09:56:48','127.0.0.1','2026-07-15 10:21:37','2026-10-24 09:56:47',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (7,'106001','purchase_manager','','郑十','13800138008','zhengshi@mouse.com',1,NULL,6,5,1,NULL,NULL,'2026-10-24 09:56:48','127.0.0.1','2026-07-15 10:21:37','2026-10-24 09:56:47',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (8,'107001','sales_manager','','陈十一','13800138009','chenshiyi@mouse.com',1,NULL,7,6,1,NULL,NULL,'2026-10-24 09:56:48','127.0.0.1','2026-07-15 10:21:37','2026-10-24 09:56:47',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (9,'108001','equipment_manager','','黄十二','13800138010','huangshier@mouse.com',1,NULL,8,7,1,NULL,NULL,'2026-10-24 09:56:48','127.0.0.1','2026-07-15 10:21:37','2026-10-24 09:56:47',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (10,'110001','cfo','','钱十三','13800138011','qianshisan@mouse.com',1,NULL,10,8,1,NULL,NULL,NULL,NULL,'2026-07-15 10:21:37','2026-07-15 10:21:37',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (11,'111001','mcadmin','','隔离系统管理员',NULL,NULL,NULL,NULL,11,1,1,NULL,NULL,'2026-10-24 09:56:48','127.0.0.1','2026-10-24 09:56:46','2026-10-24 09:56:48',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (12,'103999','mcworker2','','隔离第二操作工',NULL,NULL,NULL,NULL,3,1,1,NULL,NULL,NULL,NULL,'2026-10-24 09:56:58','2026-10-24 09:56:58',0);
/*!40000 ALTER TABLE `t_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user_role`
--

DROP TABLE IF EXISTS `t_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_user_role` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户角色关系ID',
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `role_id` bigint NOT NULL COMMENT '角色ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户角色关系表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user_role`
--

LOCK TABLES `t_user_role` WRITE;
/*!40000 ALTER TABLE `t_user_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_warehouse`
--

DROP TABLE IF EXISTS `t_warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_warehouse` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '仓库ID',
  `warehouse_code` varchar(50) NOT NULL COMMENT '仓库编码',
  `warehouse_name` varchar(100) NOT NULL COMMENT '仓库名称',
  `location` varchar(255) DEFAULT NULL COMMENT '仓库位置',
  `manager_id` bigint DEFAULT NULL COMMENT '仓管员ID',
  `manager_name` varchar(50) DEFAULT NULL COMMENT '仓管员姓名',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0禁用 1启用',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `warehouse_code` (`warehouse_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='仓库表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_warehouse`
--

LOCK TABLES `t_warehouse` WRITE;
/*!40000 ALTER TABLE `t_warehouse` DISABLE KEYS */;
INSERT INTO `t_warehouse` (`id`, `warehouse_code`, `warehouse_name`, `location`, `manager_id`, `manager_name`, `status`, `remark`, `create_time`, `update_time`) VALUES (1,'WH-001','默认仓库','默认库区',NULL,NULL,1,'系统初始化仓库','2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_warehouse` (`id`, `warehouse_code`, `warehouse_name`, `location`, `manager_id`, `manager_name`, `status`, `remark`, `create_time`, `update_time`) VALUES (2,'WH-A100-RM','A100原料仓',NULL,NULL,NULL,1,NULL,'2026-10-19 08:41:54','2026-10-19 08:41:54');
INSERT INTO `t_warehouse` (`id`, `warehouse_code`, `warehouse_name`, `location`, `manager_id`, `manager_name`, `status`, `remark`, `create_time`, `update_time`) VALUES (3,'WH-A100-LINE','A100线边库',NULL,NULL,NULL,1,NULL,'2026-10-19 08:41:54','2026-10-19 08:41:54');
INSERT INTO `t_warehouse` (`id`, `warehouse_code`, `warehouse_name`, `location`, `manager_id`, `manager_name`, `status`, `remark`, `create_time`, `update_time`) VALUES (4,'WH-A100-FG','A100成品仓',NULL,NULL,NULL,1,NULL,'2026-10-19 08:41:54','2026-10-19 08:41:54');
/*!40000 ALTER TABLE `t_warehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_work_order`
--

DROP TABLE IF EXISTS `t_work_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_work_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '工单ID',
  `wo_no` varchar(50) NOT NULL COMMENT '工单编号',
  `production_order_id` bigint NOT NULL COMMENT '生产订单ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `planned_quantity` decimal(10,2) NOT NULL COMMENT '计划数量',
  `actual_quantity` decimal(10,2) DEFAULT '0.00' COMMENT '实际数量',
  `planned_start_date` datetime DEFAULT NULL COMMENT '计划开始时间',
  `planned_end_date` datetime DEFAULT NULL COMMENT '计划结束时间',
  `actual_start_date` datetime DEFAULT NULL COMMENT '实际开始时间',
  `actual_end_date` datetime DEFAULT NULL COMMENT '实际结束时间',
  `status` varchar(30) NOT NULL DEFAULT 'PLANNED' COMMENT '状态',
  `department_id` bigint DEFAULT NULL COMMENT '部门ID',
  `assigned_user_id` bigint DEFAULT NULL COMMENT '分配员工ID',
  `assigned_user_name` varchar(50) DEFAULT NULL COMMENT '分配员工姓名',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `wo_no` (`wo_no`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_work_order`
--

LOCK TABLES `t_work_order` WRITE;
/*!40000 ALTER TABLE `t_work_order` DISABLE KEYS */;
INSERT INTO `t_work_order` (`id`, `wo_no`, `production_order_id`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `assigned_user_id`, `assigned_user_name`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (1,'WO-20260715001',1,1,100.00,0.00,'2026-07-15 08:00:00','2026-07-18 18:00:00','2026-07-17 14:47:24','2026-07-17 14:42:07','IN_PROGRESS',2,NULL,NULL,2,'2026-07-15 10:24:22','2026-07-17 14:47:24',0);
INSERT INTO `t_work_order` (`id`, `wo_no`, `production_order_id`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `assigned_user_id`, `assigned_user_name`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (2,'WO-20260715002',1,2,100.00,0.00,'2026-07-19 08:00:00','2026-07-22 18:00:00',NULL,NULL,'ASSIGNED',2,NULL,NULL,2,'2026-07-15 10:24:22','2026-07-17 14:03:01',0);
INSERT INTO `t_work_order` (`id`, `wo_no`, `production_order_id`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `assigned_user_id`, `assigned_user_name`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (3,'WO-20260715003',2,3,50.00,0.00,'2026-07-16 08:00:00','2026-07-20 18:00:00',NULL,NULL,'PLANNED',2,NULL,NULL,2,'2026-07-15 10:24:22','2026-07-17 14:03:01',0);
INSERT INTO `t_work_order` (`id`, `wo_no`, `production_order_id`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `assigned_user_id`, `assigned_user_name`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (4,'WO-20260717001',1,4,200.00,0.00,NULL,NULL,NULL,NULL,'PLANNED',2,NULL,NULL,2,'2026-07-17 14:03:01','2026-07-17 14:03:01',0);
INSERT INTO `t_work_order` (`id`, `wo_no`, `production_order_id`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `assigned_user_id`, `assigned_user_name`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (5,'WO-20260717002',2,2,150.00,0.00,NULL,NULL,NULL,NULL,'ASSIGNED',2,NULL,NULL,2,'2026-07-17 14:03:01','2026-07-17 14:41:13',0);
INSERT INTO `t_work_order` (`id`, `wo_no`, `production_order_id`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `assigned_user_id`, `assigned_user_name`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (6,'WO-20260717003',3,5,80.00,0.00,NULL,NULL,NULL,NULL,'ASSIGNED',2,NULL,NULL,2,'2026-07-17 14:03:01','2026-07-17 14:03:01',0);
/*!40000 ALTER TABLE `t_work_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'mouse_mes_completion_test_20261024_095632'
--

--
-- Dumping routines for database 'mouse_mes_completion_test_20261024_095632'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-01  8:18:10
