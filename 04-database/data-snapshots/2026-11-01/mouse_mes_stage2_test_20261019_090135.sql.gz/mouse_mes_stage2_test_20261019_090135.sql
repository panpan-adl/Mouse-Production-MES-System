-- MySQL dump 10.13  Distrib 8.3.0, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mouse_mes_stage2_test_20261019_090135
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mm_area`
--

DROP TABLE IF EXISTS `mm_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_area` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `warehouse_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_area`
--

LOCK TABLES `mm_area` WRITE;
/*!40000 ALTER TABLE `mm_area` DISABLE KEYS */;
INSERT INTO `mm_area` (`id`, `code`, `name`, `warehouse_id`, `created_at`) VALUES (1,'WH-A100-RM-A','默认库区',2,'2026-10-19 00:41:54');
INSERT INTO `mm_area` (`id`, `code`, `name`, `warehouse_id`, `created_at`) VALUES (2,'WH-A100-LINE-A','默认库区',3,'2026-10-19 00:41:54');
INSERT INTO `mm_area` (`id`, `code`, `name`, `warehouse_id`, `created_at`) VALUES (3,'WH-A100-FG-A','默认库区',4,'2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_audit`
--

DROP TABLE IF EXISTS `mm_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_audit` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `actor_id` bigint NOT NULL,
  `resource` varchar(60) NOT NULL,
  `action` varchar(30) NOT NULL,
  `record_id` bigint DEFAULT NULL,
  `details` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_audit`
--

LOCK TABLES `mm_audit` WRITE;
/*!40000 ALTER TABLE `mm_audit` DISABLE KEYS */;
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (1,1,'work-orders','CREATE',1,NULL,'2026-10-19 01:01:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (2,7,'suppliers','SAVE',1,NULL,'2026-10-19 01:01:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (3,5,'inspections','EXECUTE',1,NULL,'2026-10-19 01:01:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (4,5,'inspections','EXECUTE',2,NULL,'2026-10-19 01:01:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (5,6,'fulfillment','PURCHASE',1,NULL,'2026-10-19 01:01:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (6,5,'inspections','EXECUTE',3,NULL,'2026-10-19 01:01:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (7,6,'fulfillment','PURCHASE',2,NULL,'2026-10-19 01:01:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (8,6,'fulfillment','ISSUE',1,NULL,'2026-10-19 01:01:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (9,5,'inspections','EXECUTE',4,NULL,'2026-10-19 01:01:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (10,5,'inspections','EXECUTE',5,NULL,'2026-10-19 01:01:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (11,5,'inspections','EXECUTE',6,NULL,'2026-10-19 01:01:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (12,5,'inspections','EXECUTE',7,NULL,'2026-10-19 01:01:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (13,5,'inspections','EXECUTE',8,NULL,'2026-10-19 01:01:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (14,6,'fulfillment','RECEIPT',1,NULL,'2026-10-19 01:01:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (15,5,'inspections','EXECUTE',9,NULL,'2026-10-19 01:01:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (16,5,'inspections','EXECUTE',10,NULL,'2026-10-19 01:01:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (17,6,'fulfillment','SHIP',5,NULL,'2026-10-19 01:01:49');
/*!40000 ALTER TABLE `mm_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_bom`
--

DROP TABLE IF EXISTS `mm_bom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_bom` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `product_id` bigint NOT NULL,
  `root_material_id` bigint NOT NULL,
  `version` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_bom`
--

LOCK TABLES `mm_bom` WRITE;
/*!40000 ALTER TABLE `mm_bom` DISABLE KEYS */;
INSERT INTO `mm_bom` (`id`, `code`, `name`, `product_id`, `root_material_id`, `version`, `created_at`) VALUES (1,'BOM-A100-V1','A100多级BOM',6,16,'1.0','2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_bom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_bom_line`
--

DROP TABLE IF EXISTS `mm_bom_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_bom_line` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `bom_id` bigint NOT NULL,
  `parent_material_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `quantity` decimal(14,4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bom_id` (`bom_id`,`parent_material_id`,`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_bom_line`
--

LOCK TABLES `mm_bom_line` WRITE;
/*!40000 ALTER TABLE `mm_bom_line` DISABLE KEYS */;
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (1,1,16,14,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (2,1,16,15,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (3,1,15,2,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (4,1,15,3,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (5,1,14,4,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (6,1,14,5,2.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (7,1,14,6,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (8,1,14,7,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (9,1,15,8,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (10,1,15,9,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (11,1,15,10,4.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (12,1,16,11,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (13,1,16,12,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (14,1,16,13,1.0000,'2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_bom_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_check_plan`
--

DROP TABLE IF EXISTS `mm_check_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_check_plan` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `equipment_id` bigint NOT NULL,
  `interval_days` int NOT NULL,
  `standard` varchar(500) NOT NULL,
  `owner_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_check_plan`
--

LOCK TABLES `mm_check_plan` WRITE;
/*!40000 ALTER TABLE `mm_check_plan` DISABLE KEYS */;
INSERT INTO `mm_check_plan` (`id`, `code`, `name`, `equipment_id`, `interval_days`, `standard`, `owner_id`, `created_at`) VALUES (1,'CHECK-A100','USB功能测试台日点检',1,1,'连接完整、供电正常、测试软件可识别',1,'2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_check_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_check_record`
--

DROP TABLE IF EXISTS `mm_check_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_check_record` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `plan_id` bigint NOT NULL,
  `checked_at` datetime NOT NULL,
  `actual_value` varchar(500) NOT NULL,
  `result` varchar(20) NOT NULL,
  `remark` varchar(500) DEFAULT NULL,
  `actor_id` bigint NOT NULL,
  `maintenance_id` bigint DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_check_record`
--

LOCK TABLES `mm_check_record` WRITE;
/*!40000 ALTER TABLE `mm_check_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_check_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_guard`
--

DROP TABLE IF EXISTS `mm_guard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_guard` (
  `id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_guard`
--

LOCK TABLES `mm_guard` WRITE;
/*!40000 ALTER TABLE `mm_guard` DISABLE KEYS */;
INSERT INTO `mm_guard` (`id`) VALUES (1);
/*!40000 ALTER TABLE `mm_guard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_inspection`
--

DROP TABLE IF EXISTS `mm_inspection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_inspection` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(80) NOT NULL,
  `template_id` bigint NOT NULL,
  `kind` varchar(30) NOT NULL,
  `source_type` varchar(30) NOT NULL,
  `source_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  `qualified_quantity` int NOT NULL,
  `results` json NOT NULL,
  `status` varchar(30) NOT NULL,
  `actor_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_inspection`
--

LOCK TABLES `mm_inspection` WRITE;
/*!40000 ALTER TABLE `mm_inspection` DISABLE KEYS */;
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (1,'IQ-18a5958c-5de3-4e2c-90be-6bfe5bc5007c',1,'INCOMING','PURCHASE',1,1599,1598,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离验收故障\", \"result\": \"FAIL\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离验收故障\", \"result\": \"FAIL\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离验收故障\", \"result\": \"FAIL\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离验收故障\", \"result\": \"FAIL\"}]','BLOCKED',5,'2026-10-19 01:01:47');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (2,'IQ-0383c933-dbb3-4c19-ae19-c16fd17847db',1,'INCOMING','PURCHASE',1,1599,1599,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-19 01:01:47');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (3,'IQ-ad0ad2f1-1f0d-4e00-85f4-d557aec5a613',1,'INCOMING','PURCHASE',2,1,1,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-19 01:01:48');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (4,'IQ-94759a37-9b76-483c-b9b3-aee7371846b2',2,'PROCESS','TASK',2,100,99,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离验收故障\", \"result\": \"FAIL\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离验收故障\", \"result\": \"FAIL\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离验收故障\", \"result\": \"FAIL\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离验收故障\", \"result\": \"FAIL\"}]','BLOCKED',5,'2026-10-19 01:01:49');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (5,'IQ-64161c38-7d7c-40f3-8812-c454130ebc79',2,'PROCESS','TASK',2,100,100,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-19 01:01:49');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (6,'IQ-80748f6f-4311-47c4-8c0a-9b5da51ae55d',2,'PROCESS','TASK',3,100,100,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-19 01:01:49');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (7,'IQ-612c6ee5-a9ae-41ac-821a-e005e123f16e',2,'PROCESS','TASK',4,100,100,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-19 01:01:49');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (8,'IQ-b90c25dc-2817-462e-8d6b-355f5de78c75',2,'PROCESS','TASK',5,100,100,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-19 01:01:49');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (9,'IQ-98d6bf2c-5f80-4bb0-a918-4155b1e1f8ee',3,'SHIPPING','ORDER',5,100,99,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离验收故障\", \"result\": \"FAIL\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离验收故障\", \"result\": \"FAIL\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离验收故障\", \"result\": \"FAIL\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离验收故障\", \"result\": \"FAIL\"}]','BLOCKED',5,'2026-10-19 01:01:49');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (10,'IQ-e678e0a4-e2c3-46be-8bbd-3dd8481e82d8',3,'SHIPPING','ORDER',5,100,100,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"created_at\": \"2026-10-19 08:41:54\"}, \"actual\": \"隔离人工测量合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-19 01:01:49');
/*!40000 ALTER TABLE `mm_inspection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_legacy_link`
--

DROP TABLE IF EXISTS `mm_legacy_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_legacy_link` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source_type` varchar(40) NOT NULL,
  `source_id` bigint NOT NULL,
  `plan_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `source_type` (`source_type`,`source_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_legacy_link`
--

LOCK TABLES `mm_legacy_link` WRITE;
/*!40000 ALTER TABLE `mm_legacy_link` DISABLE KEYS */;
INSERT INTO `mm_legacy_link` (`id`, `source_type`, `source_id`, `plan_id`, `created_at`) VALUES (1,'ORDER',2,1,'2026-10-19 00:41:54');
INSERT INTO `mm_legacy_link` (`id`, `source_type`, `source_id`, `plan_id`, `created_at`) VALUES (2,'ORDER',1,2,'2026-10-19 00:41:54');
INSERT INTO `mm_legacy_link` (`id`, `source_type`, `source_id`, `plan_id`, `created_at`) VALUES (3,'ORDER',3,3,'2026-10-19 00:41:54');
INSERT INTO `mm_legacy_link` (`id`, `source_type`, `source_id`, `plan_id`, `created_at`) VALUES (4,'ORDER',4,7,'2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_legacy_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_location`
--

DROP TABLE IF EXISTS `mm_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_location` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `area_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_location`
--

LOCK TABLES `mm_location` WRITE;
/*!40000 ALTER TABLE `mm_location` DISABLE KEYS */;
INSERT INTO `mm_location` (`id`, `code`, `name`, `area_id`, `created_at`) VALUES (1,'WH-A100-RM-01','一号库位',1,'2026-10-19 00:41:54');
INSERT INTO `mm_location` (`id`, `code`, `name`, `area_id`, `created_at`) VALUES (2,'WH-A100-LINE-01','一号库位',2,'2026-10-19 00:41:54');
INSERT INTO `mm_location` (`id`, `code`, `name`, `area_id`, `created_at`) VALUES (3,'WH-A100-FG-01','一号库位',3,'2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_member`
--

DROP TABLE IF EXISTS `mm_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_member` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `team_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `team_id` (`team_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_member`
--

LOCK TABLES `mm_member` WRITE;
/*!40000 ALTER TABLE `mm_member` DISABLE KEYS */;
INSERT INTO `mm_member` (`id`, `team_id`, `user_id`, `created_at`) VALUES (1,1,1,'2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_operation`
--

DROP TABLE IF EXISTS `mm_operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_operation` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `route_id` bigint NOT NULL,
  `sequence_no` int NOT NULL,
  `station_id` bigint NOT NULL,
  `predecessor_id` bigint DEFAULT NULL,
  `standard_minutes` decimal(10,2) NOT NULL,
  `requires_qc` int NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `route_id` (`route_id`,`sequence_no`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_operation`
--

LOCK TABLES `mm_operation` WRITE;
/*!40000 ALTER TABLE `mm_operation` DISABLE KEYS */;
INSERT INTO `mm_operation` (`id`, `code`, `name`, `route_id`, `sequence_no`, `station_id`, `predecessor_id`, `standard_minutes`, `requires_qc`, `created_at`) VALUES (1,'OP-A100-1','电子装配站',1,10,1,NULL,2.00,1,'2026-10-19 00:41:54');
INSERT INTO `mm_operation` (`id`, `code`, `name`, `route_id`, `sequence_no`, `station_id`, `predecessor_id`, `standard_minutes`, `requires_qc`, `created_at`) VALUES (2,'OP-A100-2','结构装配站',1,20,2,NULL,2.00,1,'2026-10-19 00:41:54');
INSERT INTO `mm_operation` (`id`, `code`, `name`, `route_id`, `sequence_no`, `station_id`, `predecessor_id`, `standard_minutes`, `requires_qc`, `created_at`) VALUES (3,'OP-A100-3','总装测试站',1,30,3,2,2.00,1,'2026-10-19 00:41:54');
INSERT INTO `mm_operation` (`id`, `code`, `name`, `route_id`, `sequence_no`, `station_id`, `predecessor_id`, `standard_minutes`, `requires_qc`, `created_at`) VALUES (4,'OP-A100-4','贴标包装站',1,40,4,3,2.00,1,'2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_operation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_product_material`
--

DROP TABLE IF EXISTS `mm_product_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_product_material` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`),
  UNIQUE KEY `material_id` (`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_product_material`
--

LOCK TABLES `mm_product_material` WRITE;
/*!40000 ALTER TABLE `mm_product_material` DISABLE KEYS */;
INSERT INTO `mm_product_material` (`id`, `product_id`, `material_id`, `created_at`) VALUES (1,6,16,'2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_product_material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_qc_item`
--

DROP TABLE IF EXISTS `mm_qc_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_qc_item` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `standard` varchar(500) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_qc_item`
--

LOCK TABLES `mm_qc_item` WRITE;
/*!40000 ALTER TABLE `mm_qc_item` DISABLE KEYS */;
INSERT INTO `mm_qc_item` (`id`, `code`, `name`, `standard`, `created_at`) VALUES (1,'QC-VISUAL','外观装配','零件完整、无明显裂纹','2026-10-19 00:41:54');
INSERT INTO `mm_qc_item` (`id`, `code`, `name`, `standard`, `created_at`) VALUES (2,'QC-USB','USB识别','连接后可识别输入设备','2026-10-19 00:41:54');
INSERT INTO `mm_qc_item` (`id`, `code`, `name`, `standard`, `created_at`) VALUES (3,'QC-KEY','按键滚轮','左右键与滚轮均有响应','2026-10-19 00:41:54');
INSERT INTO `mm_qc_item` (`id`, `code`, `name`, `standard`, `created_at`) VALUES (4,'QC-MOVE','指针移动','测试面移动可产生指针响应','2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_qc_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_qc_line`
--

DROP TABLE IF EXISTS `mm_qc_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_qc_line` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `template_id` bigint NOT NULL,
  `item_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_id` (`template_id`,`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_qc_line`
--

LOCK TABLES `mm_qc_line` WRITE;
/*!40000 ALTER TABLE `mm_qc_line` DISABLE KEYS */;
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (1,3,3,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (2,2,3,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (3,1,3,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (4,3,4,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (5,2,4,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (6,1,4,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (7,3,2,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (8,2,2,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (9,1,2,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (10,3,1,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (11,2,1,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (12,1,1,'2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_qc_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_qc_template`
--

DROP TABLE IF EXISTS `mm_qc_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_qc_template` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `product_id` bigint NOT NULL,
  `kind` varchar(30) NOT NULL,
  `version` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_qc_template`
--

LOCK TABLES `mm_qc_template` WRITE;
/*!40000 ALTER TABLE `mm_qc_template` DISABLE KEYS */;
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`) VALUES (1,'QC-A100-INCOMING','A100来料检测模板',6,'INCOMING','1.0','2026-10-19 00:41:54');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`) VALUES (2,'QC-A100-PROCESS','A100过程检测模板',6,'PROCESS','1.0','2026-10-19 00:41:54');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`) VALUES (3,'QC-A100-SHIPPING','A100出货检测模板',6,'SHIPPING','1.0','2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_qc_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_route`
--

DROP TABLE IF EXISTS `mm_route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_route` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `product_id` bigint NOT NULL,
  `version` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_route`
--

LOCK TABLES `mm_route` WRITE;
/*!40000 ALTER TABLE `mm_route` DISABLE KEYS */;
INSERT INTO `mm_route` (`id`, `code`, `name`, `product_id`, `version`, `created_at`) VALUES (1,'ROUTE-A100-V1','A100装配工艺',6,'1.0','2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_schedule`
--

DROP TABLE IF EXISTS `mm_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_schedule` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `team_id` bigint NOT NULL,
  `shift_id` bigint NOT NULL,
  `station_id` bigint NOT NULL,
  `equipment_id` bigint DEFAULT NULL,
  `start_at` datetime NOT NULL,
  `end_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `start_at` (`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_schedule`
--

LOCK TABLES `mm_schedule` WRITE;
/*!40000 ALTER TABLE `mm_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_shift`
--

DROP TABLE IF EXISTS `mm_shift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_shift` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_shift`
--

LOCK TABLES `mm_shift` WRITE;
/*!40000 ALTER TABLE `mm_shift` DISABLE KEYS */;
INSERT INTO `mm_shift` (`id`, `code`, `name`, `start_time`, `end_time`, `created_at`) VALUES (1,'DAY','白班','08:00:00','17:00:00','2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_shift` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_station`
--

DROP TABLE IF EXISTS `mm_station`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_station` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `workshop_id` bigint NOT NULL,
  `equipment_id` bigint DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_station`
--

LOCK TABLES `mm_station` WRITE;
/*!40000 ALTER TABLE `mm_station` DISABLE KEYS */;
INSERT INTO `mm_station` (`id`, `code`, `name`, `workshop_id`, `equipment_id`, `created_at`) VALUES (1,'ST-A100-1','电子装配站',1,NULL,'2026-10-19 00:41:54');
INSERT INTO `mm_station` (`id`, `code`, `name`, `workshop_id`, `equipment_id`, `created_at`) VALUES (2,'ST-A100-2','结构装配站',1,NULL,'2026-10-19 00:41:54');
INSERT INTO `mm_station` (`id`, `code`, `name`, `workshop_id`, `equipment_id`, `created_at`) VALUES (3,'ST-A100-3','总装测试站',1,1,'2026-10-19 00:41:54');
INSERT INTO `mm_station` (`id`, `code`, `name`, `workshop_id`, `equipment_id`, `created_at`) VALUES (4,'ST-A100-4','贴标包装站',1,NULL,'2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_station` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_stock_posting`
--

DROP TABLE IF EXISTS `mm_stock_posting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_stock_posting` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `kind` varchar(30) NOT NULL,
  `source_id` bigint NOT NULL,
  `document_id` bigint NOT NULL,
  `document_no` varchar(80) NOT NULL,
  `warehouse_id` bigint NOT NULL,
  `location_id` bigint DEFAULT NULL,
  `quantity` decimal(14,2) NOT NULL,
  `actor_id` bigint NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kind` (`kind`,`source_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_stock_posting`
--

LOCK TABLES `mm_stock_posting` WRITE;
/*!40000 ALTER TABLE `mm_stock_posting` DISABLE KEYS */;
INSERT INTO `mm_stock_posting` (`id`, `kind`, `source_id`, `document_id`, `document_no`, `warehouse_id`, `location_id`, `quantity`, `actor_id`, `created_at`) VALUES (1,'PURCHASE',1,1,'PURCHASE_RECEIPT-1',2,2,1599.00,6,'2026-10-19 09:01:47');
INSERT INTO `mm_stock_posting` (`id`, `kind`, `source_id`, `document_id`, `document_no`, `warehouse_id`, `location_id`, `quantity`, `actor_id`, `created_at`) VALUES (2,'PURCHASE',2,2,'PURCHASE_RECEIPT-2',2,2,1.00,6,'2026-10-19 09:01:48');
INSERT INTO `mm_stock_posting` (`id`, `kind`, `source_id`, `document_id`, `document_no`, `warehouse_id`, `location_id`, `quantity`, `actor_id`, `created_at`) VALUES (3,'ISSUE',1,2,'PRODUCTION_ISSUE-1',2,NULL,100.00,6,'2026-10-19 09:01:48');
INSERT INTO `mm_stock_posting` (`id`, `kind`, `source_id`, `document_id`, `document_no`, `warehouse_id`, `location_id`, `quantity`, `actor_id`, `created_at`) VALUES (4,'RECEIPT',1,3,'PRODUCTION_RECEIPT-1',4,4,100.00,6,'2026-10-19 09:01:49');
INSERT INTO `mm_stock_posting` (`id`, `kind`, `source_id`, `document_id`, `document_no`, `warehouse_id`, `location_id`, `quantity`, `actor_id`, `created_at`) VALUES (5,'SHIP',5,3,'SALES_SHIPMENT-5',4,NULL,100.00,6,'2026-10-19 09:01:49');
/*!40000 ALTER TABLE `mm_stock_posting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_task_context`
--

DROP TABLE IF EXISTS `mm_task_context`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_task_context` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `task_id` bigint NOT NULL,
  `work_order_id` bigint NOT NULL,
  `operation_id` bigint NOT NULL,
  `sequence_no` int NOT NULL,
  `predecessor_id` bigint DEFAULT NULL,
  `requires_qc` int NOT NULL,
  `is_terminal` int NOT NULL,
  `station_id` bigint NOT NULL,
  `schedule_id` bigint DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_id` (`task_id`),
  UNIQUE KEY `work_order_id` (`work_order_id`,`operation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_task_context`
--

LOCK TABLES `mm_task_context` WRITE;
/*!40000 ALTER TABLE `mm_task_context` DISABLE KEYS */;
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (1,2,1,1,10,NULL,1,0,1,NULL,'2026-10-19 01:01:47');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (2,3,1,2,20,NULL,1,0,2,NULL,'2026-10-19 01:01:47');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (3,4,1,3,30,2,1,0,3,NULL,'2026-10-19 01:01:47');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (4,5,1,4,40,3,1,1,4,NULL,'2026-10-19 01:01:47');
/*!40000 ALTER TABLE `mm_task_context` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_team`
--

DROP TABLE IF EXISTS `mm_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_team` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `leader_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_team`
--

LOCK TABLES `mm_team` WRITE;
/*!40000 ALTER TABLE `mm_team` DISABLE KEYS */;
INSERT INTO `mm_team` (`id`, `code`, `name`, `leader_id`, `created_at`) VALUES (1,'TEAM-A100','A100装配一班',1,'2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_work_material`
--

DROP TABLE IF EXISTS `mm_work_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_work_material` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `material_code` varchar(60) NOT NULL,
  `material_name` varchar(100) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `required_quantity` decimal(14,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `work_order_id` (`work_order_id`,`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_work_material`
--

LOCK TABLES `mm_work_material` WRITE;
/*!40000 ALTER TABLE `mm_work_material` DISABLE KEYS */;
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (1,1,4,'MAT-PCB-A100','PCB主板','块',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (2,1,5,'MAT-SWITCH-01','微动开关','个',200.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (3,1,6,'MAT-ENCODER-01','滚轮编码器','个',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (4,1,7,'MAT-USB-CABLE-A100','USB连接线','根',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (5,1,2,'MAT-SHELL-TOP-A100','鼠标上盖','个',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (6,1,3,'MAT-SHELL-BOTTOM-A100','鼠标下盖','个',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (7,1,8,'MAT-WHEEL-A100','滚轮组件','个',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (8,1,9,'MAT-LENS-A100','光学透镜','个',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (9,1,10,'MAT-SCREW-A100','固定螺钉','颗',400.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (10,1,11,'MAT-FEET-A100','防滑脚贴','套',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (11,1,12,'MAT-LABEL-A100','产品铭牌','张',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (12,1,13,'MAT-BOX-A100','包装盒','个',100.00);
/*!40000 ALTER TABLE `mm_work_material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_work_order`
--

DROP TABLE IF EXISTS `mm_work_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_work_order` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(80) NOT NULL,
  `plan_id` bigint NOT NULL,
  `bom_id` bigint NOT NULL,
  `route_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  `bom_snapshot` json NOT NULL,
  `route_snapshot` json NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'CREATED',
  `created_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `plan_id` (`plan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_work_order`
--

LOCK TABLES `mm_work_order` WRITE;
/*!40000 ALTER TABLE `mm_work_order` DISABLE KEYS */;
INSERT INTO `mm_work_order` (`id`, `code`, `plan_id`, `bom_id`, `route_id`, `quantity`, `bom_snapshot`, `route_snapshot`, `status`, `created_by`, `created_at`) VALUES (1,'MO-PP1792371707287',8,1,1,100,'[{\"id\": 1, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 14, \"parent_material_id\": 16}, {\"id\": 2, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 15, \"parent_material_id\": 16}, {\"id\": 3, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 2, \"parent_material_id\": 15}, {\"id\": 4, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 3, \"parent_material_id\": 15}, {\"id\": 5, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 4, \"parent_material_id\": 14}, {\"id\": 6, \"bom_id\": 1, \"quantity\": 2.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 5, \"parent_material_id\": 14}, {\"id\": 7, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 6, \"parent_material_id\": 14}, {\"id\": 8, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 7, \"parent_material_id\": 14}, {\"id\": 9, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 8, \"parent_material_id\": 15}, {\"id\": 10, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 9, \"parent_material_id\": 15}, {\"id\": 11, \"bom_id\": 1, \"quantity\": 4.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 10, \"parent_material_id\": 15}, {\"id\": 12, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 11, \"parent_material_id\": 16}, {\"id\": 13, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 12, \"parent_material_id\": 16}, {\"id\": 14, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 13, \"parent_material_id\": 16}]','[{\"id\": 1, \"code\": \"OP-A100-1\", \"name\": \"电子装配站\", \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 1, \"requires_qc\": 1, \"sequence_no\": 10, \"predecessor_id\": null, \"standard_minutes\": 2.0}, {\"id\": 2, \"code\": \"OP-A100-2\", \"name\": \"结构装配站\", \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 2, \"requires_qc\": 1, \"sequence_no\": 20, \"predecessor_id\": null, \"standard_minutes\": 2.0}, {\"id\": 3, \"code\": \"OP-A100-3\", \"name\": \"总装测试站\", \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 3, \"requires_qc\": 1, \"sequence_no\": 30, \"predecessor_id\": 2, \"standard_minutes\": 2.0}, {\"id\": 4, \"code\": \"OP-A100-4\", \"name\": \"贴标包装站\", \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 4, \"requires_qc\": 1, \"sequence_no\": 40, \"predecessor_id\": 3, \"standard_minutes\": 2.0}]','PRODUCTION_COMPLETED',1,'2026-10-19 01:01:47');
/*!40000 ALTER TABLE `mm_work_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_work_product`
--

DROP TABLE IF EXISTS `mm_work_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_work_product` (
  `work_order_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  PRIMARY KEY (`work_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_work_product`
--

LOCK TABLES `mm_work_product` WRITE;
/*!40000 ALTER TABLE `mm_work_product` DISABLE KEYS */;
INSERT INTO `mm_work_product` (`work_order_id`, `material_id`, `quantity`) VALUES (1,16,100);
/*!40000 ALTER TABLE `mm_work_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_workshop`
--

DROP TABLE IF EXISTS `mm_workshop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_workshop` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_workshop`
--

LOCK TABLES `mm_workshop` WRITE;
/*!40000 ALTER TABLE `mm_workshop` DISABLE KEYS */;
INSERT INTO `mm_workshop` (`id`, `code`, `name`, `created_at`) VALUES (1,'WS-A100','鼠标装配车间','2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_workshop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_attendance`
--

DROP TABLE IF EXISTS `t_attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_attendance` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '考勤ID',
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `user_name` varchar(50) NOT NULL COMMENT '用户姓名',
  `attendance_date` date NOT NULL COMMENT '考勤日期',
  `check_in_time` datetime DEFAULT NULL COMMENT '签到时间',
  `check_out_time` datetime DEFAULT NULL COMMENT '签退时间',
  `work_hours` decimal(5,2) DEFAULT NULL COMMENT '工时',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='考勤记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_attendance`
--

LOCK TABLES `t_attendance` WRITE;
/*!40000 ALTER TABLE `t_attendance` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_bom`
--

DROP TABLE IF EXISTS `t_bom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_bom` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'BOM ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `material_name` varchar(100) NOT NULL COMMENT '物料名称',
  `quantity` decimal(10,2) NOT NULL COMMENT '用量',
  `unit` varchar(20) NOT NULL COMMENT '单位',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='BOM表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_bom`
--

LOCK TABLES `t_bom` WRITE;
/*!40000 ALTER TABLE `t_bom` DISABLE KEYS */;
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (1,6,4,'PCB主板',1.00,'块','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (2,6,5,'微动开关',2.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (3,6,6,'滚轮编码器',1.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (4,6,7,'USB连接线',1.00,'根','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (5,6,2,'鼠标上盖',1.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (6,6,3,'鼠标下盖',1.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (7,6,8,'滚轮组件',1.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (8,6,9,'光学透镜',1.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (9,6,10,'固定螺钉',4.00,'颗','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (10,6,11,'防滑脚贴',1.00,'套','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (11,6,12,'产品铭牌',1.00,'张','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (12,6,13,'包装盒',1.00,'个','BOM版本 1.0');
/*!40000 ALTER TABLE `t_bom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_bom_item`
--

DROP TABLE IF EXISTS `t_bom_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_bom_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'BOM明细ID',
  `bom_id` bigint NOT NULL COMMENT 'BOM ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `quantity` decimal(10,2) NOT NULL COMMENT '用量',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='BOM明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_bom_item`
--

LOCK TABLES `t_bom_item` WRITE;
/*!40000 ALTER TABLE `t_bom_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_bom_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_customer`
--

DROP TABLE IF EXISTS `t_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_customer` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '客户ID',
  `customer_code` varchar(50) NOT NULL COMMENT '客户编码',
  `customer_name` varchar(100) NOT NULL COMMENT '客户名称',
  `contact_person` varchar(50) DEFAULT NULL COMMENT '联系人',
  `phone` varchar(20) DEFAULT NULL COMMENT '电话',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `address` varchar(255) DEFAULT NULL COMMENT '地址',
  `status` varchar(30) NOT NULL DEFAULT '1' COMMENT '状态',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_code` (`customer_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='客户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_customer`
--

LOCK TABLES `t_customer` WRITE;
/*!40000 ALTER TABLE `t_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_department`
--

DROP TABLE IF EXISTS `t_department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_department` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '部门ID',
  `parent_id` bigint NOT NULL DEFAULT '0' COMMENT '父部门ID',
  `dept_name` varchar(50) NOT NULL COMMENT '部门名称',
  `dept_code` varchar(50) NOT NULL COMMENT '部门编码',
  `leader_id` bigint DEFAULT NULL COMMENT '负责人ID',
  `leader_name` varchar(50) DEFAULT NULL COMMENT '负责人姓名',
  `sort` int NOT NULL DEFAULT '0' COMMENT '显示顺序',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：-1删除 0禁用 1活跃',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='部门表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_department`
--

LOCK TABLES `t_department` WRITE;
/*!40000 ALTER TABLE `t_department` DISABLE KEYS */;
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (1,0,'总经办','CEO',NULL,NULL,1,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (2,0,'生产部','PROD',NULL,NULL,2,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (3,0,'质检部','QC',NULL,NULL,3,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (4,0,'仓储部','WAREHOUSE',NULL,NULL,4,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (5,0,'采购部','PURCHASE',NULL,NULL,5,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (6,0,'销售部','SALES',NULL,NULL,6,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (7,0,'设备部','EQUIPMENT',NULL,NULL,7,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (8,0,'财务部','FINANCE',NULL,NULL,8,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (9,0,'人力资源部','HR',NULL,NULL,9,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
/*!40000 ALTER TABLE `t_department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_dict`
--

DROP TABLE IF EXISTS `t_dict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_dict` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '字典ID',
  `dict_name` varchar(100) NOT NULL COMMENT '字典名称',
  `dict_type` varchar(100) NOT NULL COMMENT '字典类型',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0禁用 1启用',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `dict_type` (`dict_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='字典类型表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_dict`
--

LOCK TABLES `t_dict` WRITE;
/*!40000 ALTER TABLE `t_dict` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_dict` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_dict_item`
--

DROP TABLE IF EXISTS `t_dict_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_dict_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '字典数据ID',
  `dict_type` varchar(100) NOT NULL COMMENT '字典类型',
  `item_label` varchar(100) NOT NULL COMMENT '字典标签',
  `item_value` varchar(100) NOT NULL COMMENT '字典值',
  `sort` int NOT NULL DEFAULT '0' COMMENT '显示顺序',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0禁用 1启用',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='字典数据表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_dict_item`
--

LOCK TABLES `t_dict_item` WRITE;
/*!40000 ALTER TABLE `t_dict_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_dict_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_equipment`
--

DROP TABLE IF EXISTS `t_equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_equipment` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '设备ID',
  `equipment_code` varchar(50) NOT NULL COMMENT '设备编码',
  `equipment_name` varchar(100) NOT NULL COMMENT '设备名称',
  `equipment_type` varchar(50) DEFAULT NULL COMMENT '设备类型',
  `model` varchar(50) DEFAULT NULL COMMENT '型号',
  `manufacturer` varchar(100) DEFAULT NULL COMMENT '厂商',
  `purchase_date` date DEFAULT NULL COMMENT '购置日期',
  `purchase_price` decimal(12,2) DEFAULT '0.00' COMMENT '购置价格',
  `warranty_period` int DEFAULT NULL COMMENT '保修期',
  `location` varchar(100) DEFAULT NULL COMMENT '设备位置',
  `status` varchar(30) NOT NULL DEFAULT 'NORMAL' COMMENT '状态：NORMAL正常 REPAIR_REQUESTED报修中 REPAIRING维修中 REPAIRED已维修 SCRAPPED报废',
  `responsible_id` bigint DEFAULT NULL COMMENT '负责人ID',
  `responsible_name` varchar(50) DEFAULT NULL COMMENT '负责人姓名',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `equipment_code` (`equipment_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='设备表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_equipment`
--

LOCK TABLES `t_equipment` WRITE;
/*!40000 ALTER TABLE `t_equipment` DISABLE KEYS */;
INSERT INTO `t_equipment` (`id`, `equipment_code`, `equipment_name`, `equipment_type`, `model`, `manufacturer`, `purchase_date`, `purchase_price`, `warranty_period`, `location`, `status`, `responsible_id`, `responsible_name`, `remark`, `create_time`, `update_time`, `is_deleted`) VALUES (1,'EQ-A100-01','A100功能测试台',NULL,'USB测试台',NULL,NULL,0.00,NULL,'总装测试站','1',NULL,NULL,NULL,'2026-10-19 08:41:54','2026-10-19 08:41:54',0);
/*!40000 ALTER TABLE `t_equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_inventory`
--

DROP TABLE IF EXISTS `t_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_inventory` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '库存ID',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `location_id` bigint DEFAULT NULL COMMENT '库位ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_id` bigint DEFAULT NULL COMMENT '批次ID',
  `quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '库存数量',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '最后更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='库存表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_inventory`
--

LOCK TABLES `t_inventory` WRITE;
/*!40000 ALTER TABLE `t_inventory` DISABLE KEYS */;
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (1,2,2,2,1,0.00,'2026-10-19 09:01:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (2,2,2,3,2,0.00,'2026-10-19 09:01:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (3,2,2,4,3,0.00,'2026-10-19 09:01:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (4,2,2,5,4,0.00,'2026-10-19 09:01:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (5,2,2,6,5,0.00,'2026-10-19 09:01:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (6,2,2,7,6,0.00,'2026-10-19 09:01:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (7,2,2,8,7,0.00,'2026-10-19 09:01:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (8,2,2,9,8,0.00,'2026-10-19 09:01:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (9,2,2,10,9,0.00,'2026-10-19 09:01:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (10,2,2,11,10,0.00,'2026-10-19 09:01:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (11,2,2,12,11,0.00,'2026-10-19 09:01:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (12,2,2,13,12,0.00,'2026-10-19 09:01:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (13,2,2,10,13,0.00,'2026-10-19 09:01:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (14,4,4,16,14,0.00,'2026-10-19 09:01:50',0);
/*!40000 ALTER TABLE `t_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_inventory_in`
--

DROP TABLE IF EXISTS `t_inventory_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_inventory_in` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '入库单ID',
  `in_no` varchar(50) NOT NULL COMMENT '入库单号',
  `in_type` tinyint NOT NULL COMMENT '入库类型',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `material_name` varchar(100) NOT NULL COMMENT '物料名称',
  `quantity` int NOT NULL COMMENT '入库数量',
  `unit_price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '总金额',
  `supplier_id` bigint DEFAULT NULL COMMENT '供应商ID',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `in_date` date NOT NULL COMMENT '入库日期',
  `create_by` bigint NOT NULL COMMENT '操作人ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `in_no` (`in_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='入库单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_inventory_in`
--

LOCK TABLES `t_inventory_in` WRITE;
/*!40000 ALTER TABLE `t_inventory_in` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_inventory_in` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_inventory_out`
--

DROP TABLE IF EXISTS `t_inventory_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_inventory_out` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '出库单ID',
  `out_no` varchar(50) NOT NULL COMMENT '出库单号',
  `out_type` tinyint NOT NULL COMMENT '出库类型',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `material_name` varchar(100) NOT NULL COMMENT '物料名称',
  `quantity` int NOT NULL COMMENT '出库数量',
  `unit_price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '总金额',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `out_date` date NOT NULL COMMENT '出库日期',
  `create_by` bigint NOT NULL COMMENT '操作人ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `out_no` (`out_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='出库单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_inventory_out`
--

LOCK TABLES `t_inventory_out` WRITE;
/*!40000 ALTER TABLE `t_inventory_out` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_inventory_out` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_inventory_transaction`
--

DROP TABLE IF EXISTS `t_inventory_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_inventory_transaction` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '库存流水ID',
  `transaction_no` varchar(80) NOT NULL COMMENT '库存流水编号',
  `transaction_type` varchar(10) NOT NULL COMMENT '流水方向：IN入库 OUT出库',
  `business_type` varchar(30) DEFAULT NULL COMMENT '业务类型',
  `source_order_id` bigint DEFAULT NULL COMMENT '来源单据ID',
  `source_order_no` varchar(80) DEFAULT NULL COMMENT '来源单据编号',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `location_id` bigint DEFAULT NULL COMMENT '库位ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_id` bigint DEFAULT NULL COMMENT '批次ID',
  `quantity` decimal(10,2) NOT NULL COMMENT '变动数量',
  `before_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变动前数量',
  `after_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变动后数量',
  `created_by` bigint DEFAULT NULL COMMENT '操作人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_no` (`transaction_no`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='库存流水表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_inventory_transaction`
--

LOCK TABLES `t_inventory_transaction` WRITE;
/*!40000 ALTER TABLE `t_inventory_transaction` DISABLE KEYS */;
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (1,'INV-IN-20261019090147839-3456586519100','IN','PURCHASE_RECEIPT',1,'PURCHASE_RECEIPT-1',2,2,2,1,100.00,0.00,100.00,6,'2026-10-19 09:01:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (2,'INV-IN-20261019090147854-3456601988100','IN','PURCHASE_RECEIPT',1,'PURCHASE_RECEIPT-1',2,2,3,2,100.00,0.00,100.00,6,'2026-10-19 09:01:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (3,'INV-IN-20261019090147868-3456615897500','IN','PURCHASE_RECEIPT',1,'PURCHASE_RECEIPT-1',2,2,4,3,100.00,0.00,100.00,6,'2026-10-19 09:01:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (4,'INV-IN-20261019090147876-3456623463800','IN','PURCHASE_RECEIPT',1,'PURCHASE_RECEIPT-1',2,2,5,4,200.00,0.00,200.00,6,'2026-10-19 09:01:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (5,'INV-IN-20261019090147881-3456629749400','IN','PURCHASE_RECEIPT',1,'PURCHASE_RECEIPT-1',2,2,6,5,100.00,0.00,100.00,6,'2026-10-19 09:01:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (6,'INV-IN-20261019090147893-3456640343800','IN','PURCHASE_RECEIPT',1,'PURCHASE_RECEIPT-1',2,2,7,6,100.00,0.00,100.00,6,'2026-10-19 09:01:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (7,'INV-IN-20261019090147898-3456645213700','IN','PURCHASE_RECEIPT',1,'PURCHASE_RECEIPT-1',2,2,8,7,100.00,0.00,100.00,6,'2026-10-19 09:01:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (8,'INV-IN-20261019090147907-3456654768800','IN','PURCHASE_RECEIPT',1,'PURCHASE_RECEIPT-1',2,2,9,8,100.00,0.00,100.00,6,'2026-10-19 09:01:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (9,'INV-IN-20261019090147913-3456660609400','IN','PURCHASE_RECEIPT',1,'PURCHASE_RECEIPT-1',2,2,10,9,399.00,0.00,399.00,6,'2026-10-19 09:01:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (10,'INV-IN-20261019090147921-3456668973200','IN','PURCHASE_RECEIPT',1,'PURCHASE_RECEIPT-1',2,2,11,10,100.00,0.00,100.00,6,'2026-10-19 09:01:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (11,'INV-IN-20261019090147925-3456672817700','IN','PURCHASE_RECEIPT',1,'PURCHASE_RECEIPT-1',2,2,12,11,100.00,0.00,100.00,6,'2026-10-19 09:01:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (12,'INV-IN-20261019090147931-3456679083800','IN','PURCHASE_RECEIPT',1,'PURCHASE_RECEIPT-1',2,2,13,12,100.00,0.00,100.00,6,'2026-10-19 09:01:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (14,'INV-IN-20261019090148716-3457463360500','IN','PURCHASE_RECEIPT',2,'PURCHASE_RECEIPT-2',2,2,10,13,1.00,0.00,1.00,6,'2026-10-19 09:01:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (15,'INV-OUT-20261019090148778-3457526693400','OUT','PRODUCTION_ISSUE',2,'PRODUCTION_ISSUE-1',2,2,2,1,100.00,100.00,0.00,6,'2026-10-19 09:01:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (16,'INV-OUT-20261019090148789-3457536559500','OUT','PRODUCTION_ISSUE',2,'PRODUCTION_ISSUE-1',2,2,3,2,100.00,100.00,0.00,6,'2026-10-19 09:01:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (17,'INV-OUT-20261019090148801-3457547954100','OUT','PRODUCTION_ISSUE',2,'PRODUCTION_ISSUE-1',2,2,4,3,100.00,100.00,0.00,6,'2026-10-19 09:01:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (18,'INV-OUT-20261019090148806-3457553578000','OUT','PRODUCTION_ISSUE',2,'PRODUCTION_ISSUE-1',2,2,5,4,200.00,200.00,0.00,6,'2026-10-19 09:01:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (19,'INV-OUT-20261019090148818-3457565208300','OUT','PRODUCTION_ISSUE',2,'PRODUCTION_ISSUE-1',2,2,6,5,100.00,100.00,0.00,6,'2026-10-19 09:01:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (20,'INV-OUT-20261019090148823-3457570386300','OUT','PRODUCTION_ISSUE',2,'PRODUCTION_ISSUE-1',2,2,7,6,100.00,100.00,0.00,6,'2026-10-19 09:01:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (21,'INV-OUT-20261019090148833-3457580439100','OUT','PRODUCTION_ISSUE',2,'PRODUCTION_ISSUE-1',2,2,8,7,100.00,100.00,0.00,6,'2026-10-19 09:01:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (22,'INV-OUT-20261019090148837-3457584945200','OUT','PRODUCTION_ISSUE',2,'PRODUCTION_ISSUE-1',2,2,9,8,100.00,100.00,0.00,6,'2026-10-19 09:01:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (23,'INV-OUT-20261019090148846-3457593874900','OUT','PRODUCTION_ISSUE',2,'PRODUCTION_ISSUE-1',2,2,10,9,399.00,399.00,0.00,6,'2026-10-19 09:01:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (24,'INV-OUT-20261019090148851-3457598411300','OUT','PRODUCTION_ISSUE',2,'PRODUCTION_ISSUE-1',2,2,10,13,1.00,1.00,0.00,6,'2026-10-19 09:01:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (25,'INV-OUT-20261019090148854-3457602556600','OUT','PRODUCTION_ISSUE',2,'PRODUCTION_ISSUE-1',2,2,11,10,100.00,100.00,0.00,6,'2026-10-19 09:01:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (26,'INV-OUT-20261019090148862-3457610667200','OUT','PRODUCTION_ISSUE',2,'PRODUCTION_ISSUE-1',2,2,12,11,100.00,100.00,0.00,6,'2026-10-19 09:01:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (27,'INV-OUT-20261019090148868-3457615937800','OUT','PRODUCTION_ISSUE',2,'PRODUCTION_ISSUE-1',2,2,13,12,100.00,100.00,0.00,6,'2026-10-19 09:01:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (28,'INV-IN-20261019090149671-3458418223900','IN','PRODUCTION_RECEIPT',3,'PRODUCTION_RECEIPT-1',4,4,16,14,100.00,0.00,100.00,6,'2026-10-19 09:01:50',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (29,'INV-OUT-20261019090149925-3458673163500','OUT','SALES_SHIPMENT',3,'SALES_SHIPMENT-5',4,4,16,14,100.00,100.00,0.00,6,'2026-10-19 09:01:50',NULL);
/*!40000 ALTER TABLE `t_inventory_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_location`
--

DROP TABLE IF EXISTS `t_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_location` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '库位ID',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `location_code` varchar(50) NOT NULL COMMENT '库位编码',
  `location_name` varchar(100) NOT NULL COMMENT '库位名称',
  `location_type` varchar(30) DEFAULT NULL COMMENT '库位类型',
  `status` varchar(30) NOT NULL DEFAULT '1' COMMENT '状态',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='库位表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_location`
--

LOCK TABLES `t_location` WRITE;
/*!40000 ALTER TABLE `t_location` DISABLE KEYS */;
INSERT INTO `t_location` (`id`, `warehouse_id`, `location_code`, `location_name`, `location_type`, `status`, `created_at`, `updated_at`, `is_deleted`) VALUES (1,1,'LOC-001','默认库位','NORMAL','1','2026-07-15 10:21:37','2026-07-15 10:21:37',0);
INSERT INTO `t_location` (`id`, `warehouse_id`, `location_code`, `location_name`, `location_type`, `status`, `created_at`, `updated_at`, `is_deleted`) VALUES (2,2,'WH-A100-RM-01','一号库位',NULL,'1','2026-10-19 08:41:54','2026-10-19 08:41:54',0);
INSERT INTO `t_location` (`id`, `warehouse_id`, `location_code`, `location_name`, `location_type`, `status`, `created_at`, `updated_at`, `is_deleted`) VALUES (3,3,'WH-A100-LINE-01','一号库位',NULL,'1','2026-10-19 08:41:54','2026-10-19 08:41:54',0);
INSERT INTO `t_location` (`id`, `warehouse_id`, `location_code`, `location_name`, `location_type`, `status`, `created_at`, `updated_at`, `is_deleted`) VALUES (4,4,'WH-A100-FG-01','一号库位',NULL,'1','2026-10-19 08:41:54','2026-10-19 08:41:54',0);
/*!40000 ALTER TABLE `t_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_login_log`
--

DROP TABLE IF EXISTS `t_login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_login_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '登录日志ID',
  `user_id` bigint DEFAULT NULL COMMENT '用户ID',
  `user_code` varchar(6) NOT NULL COMMENT '用户编码',
  `username` varchar(50) NOT NULL COMMENT '登录账号',
  `login_type` tinyint NOT NULL COMMENT '操作类型：1登录 2登出',
  `login_ip` varchar(50) DEFAULT NULL COMMENT '登录IP',
  `login_location` varchar(100) DEFAULT NULL COMMENT '登录地点',
  `browser` varchar(255) DEFAULT NULL COMMENT '浏览器',
  `os` varchar(255) DEFAULT NULL COMMENT '操作系统',
  `status` tinyint NOT NULL COMMENT '状态：0失败 1成功',
  `msg` varchar(255) DEFAULT NULL COMMENT '提示消息',
  `login_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '登录时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='登录日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_login_log`
--

LOCK TABLES `t_login_log` WRITE;
/*!40000 ALTER TABLE `t_login_log` DISABLE KEYS */;
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (1,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 10:30:23');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (2,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 10:42:43');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (3,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 10:51:17');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (4,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 12:51:59');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (5,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 14:33:47');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (6,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 14:39:34');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (7,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 14:49:01');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (8,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:18:43');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (9,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:23:59');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (10,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:24:57');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (11,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:43:18');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (12,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:46:25');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (13,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:54:24');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (14,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:56:25');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (15,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 16:02:53');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (16,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 16:14:27');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (17,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 17:16:23');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (18,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 17:20:30');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (19,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 18:15:56');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (20,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 18:20:48');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (21,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 18:40:30');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (22,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-15 19:13:32');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (23,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-15 19:15:46');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (24,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 19:16:19');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (25,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-15 19:18:28');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (26,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 19:21:38');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (27,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-15 19:31:50');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (28,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 19:40:27');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (29,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 19:51:06');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (30,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 20:09:03');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (31,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 20:37:43');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (32,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-16 08:52:29');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (33,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 08:54:42');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (34,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 09:23:04');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (35,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 10:25:16');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (36,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 10:29:50');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (37,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 10:40:43');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (38,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 10:46:00');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (39,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 10:50:16');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (40,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 11:03:09');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (41,1,'109001','admin',1,'172.24.79.157',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-16 11:21:10');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (42,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 11:24:54');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (43,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 11:30:09');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (44,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 12:22:24');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (45,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 12:28:50');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (46,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 13:06:01');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (47,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 14:25:11');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (48,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 14:38:45');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (49,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 15:56:23');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (50,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 22:42:16');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (51,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 22:42:49');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (52,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 22:53:03');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (53,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 08:31:56');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (54,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-07-17 08:55:53');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (55,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 08:57:11');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (56,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-07-17 09:07:04');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (57,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-07-17 09:09:58');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (58,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 09:11:59');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (59,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-07-17 09:14:48');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (60,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-07-17 09:24:56');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (61,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-07-17 09:32:46');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (62,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 13:19:59');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (63,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 13:25:37');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (64,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 13:51:53');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (65,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 13:54:59');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (66,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 13:56:52');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (67,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 14:04:10');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (68,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 14:04:23');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (69,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:16:08');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (70,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 14:18:43');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (71,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:19:48');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (72,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:22:18');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (73,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:24:42');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (74,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:28:12');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (75,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:31:05');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (76,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:33:25');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (77,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:34:49');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (78,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:41:47');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (79,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:42:28');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (80,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 14:43:04');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (81,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:43:51');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (82,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 14:44:16');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (83,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:45:39');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (84,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-18 08:37:01');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (85,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-18 08:37:09');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (86,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-18 08:37:59');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (87,2,'101001','prod_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-18 15:23:07');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (88,2,'101001','prod_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-18 15:23:26');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (89,1,'109001','admin',1,'127.0.0.1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-10-18 15:29:08');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (90,1,'109001','admin',1,'127.0.0.1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-10-19 08:43:28');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (91,1,'109001','admin',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-19 08:45:07');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (92,1,'109001','admin',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-19 09:01:46');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (93,4,'103001','worker1',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-19 09:01:47');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (94,5,'104001','qc_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-19 09:01:47');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (95,6,'105001','warehouse_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-19 09:01:47');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (96,7,'106001','purchase_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-19 09:01:47');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (97,8,'107001','sales_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-19 09:01:47');
/*!40000 ALTER TABLE `t_login_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_lot`
--

DROP TABLE IF EXISTS `t_lot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_lot` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '批次ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_no` varchar(50) NOT NULL COMMENT '批次号',
  `production_date` datetime DEFAULT NULL COMMENT '生产日期',
  `expire_date` datetime DEFAULT NULL COMMENT '过期日期',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `lot_no` (`lot_no`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='批次表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_lot`
--

LOCK TABLES `t_lot` WRITE;
/*!40000 ALTER TABLE `t_lot` DISABLE KEYS */;
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (1,2,'PO-1-1','2026-10-19 09:01:47',NULL,'2026-10-19 09:01:47','2026-10-19 09:01:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (2,3,'PO-1-2','2026-10-19 09:01:47',NULL,'2026-10-19 09:01:47','2026-10-19 09:01:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (3,4,'PO-1-3','2026-10-19 09:01:47',NULL,'2026-10-19 09:01:47','2026-10-19 09:01:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (4,5,'PO-1-4','2026-10-19 09:01:47',NULL,'2026-10-19 09:01:47','2026-10-19 09:01:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (5,6,'PO-1-5','2026-10-19 09:01:47',NULL,'2026-10-19 09:01:47','2026-10-19 09:01:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (6,7,'PO-1-6','2026-10-19 09:01:47',NULL,'2026-10-19 09:01:47','2026-10-19 09:01:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (7,8,'PO-1-7','2026-10-19 09:01:47',NULL,'2026-10-19 09:01:47','2026-10-19 09:01:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (8,9,'PO-1-8','2026-10-19 09:01:47',NULL,'2026-10-19 09:01:47','2026-10-19 09:01:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (9,10,'PO-1-9','2026-10-19 09:01:47',NULL,'2026-10-19 09:01:47','2026-10-19 09:01:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (10,11,'PO-1-10','2026-10-19 09:01:47',NULL,'2026-10-19 09:01:47','2026-10-19 09:01:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (11,12,'PO-1-11','2026-10-19 09:01:47',NULL,'2026-10-19 09:01:47','2026-10-19 09:01:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (12,13,'PO-1-12','2026-10-19 09:01:47',NULL,'2026-10-19 09:01:47','2026-10-19 09:01:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (13,10,'PO-2-13','2026-10-19 09:01:48',NULL,'2026-10-19 09:01:48','2026-10-19 09:01:48',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (14,16,'FG-MO-1','2026-10-19 09:01:49',NULL,'2026-10-19 09:01:49','2026-10-19 09:01:49',0);
/*!40000 ALTER TABLE `t_lot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_maintenance`
--

DROP TABLE IF EXISTS `t_maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_maintenance` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '维护记录ID',
  `maintenance_no` varchar(50) NOT NULL COMMENT '维护单号',
  `equipment_id` bigint NOT NULL COMMENT '设备ID',
  `equipment_name` varchar(100) NOT NULL COMMENT '设备名称',
  `maintenance_type` tinyint NOT NULL COMMENT '维护类型',
  `fault_desc` text COMMENT '故障描述',
  `maintenance_content` text,
  `maintenance_user_id` bigint DEFAULT NULL,
  `maintenance_user_name` varchar(50) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `cost` decimal(10,2) DEFAULT NULL COMMENT '维护费用',
  `result` varchar(50) DEFAULT NULL,
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `status` varchar(30) NOT NULL DEFAULT 'PENDING' COMMENT '维修状态',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `maintenance_no` (`maintenance_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='设备维护记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_maintenance`
--

LOCK TABLES `t_maintenance` WRITE;
/*!40000 ALTER TABLE `t_maintenance` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_maintenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_material`
--

DROP TABLE IF EXISTS `t_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_material` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '物料ID',
  `material_code` varchar(50) NOT NULL COMMENT '物料编码',
  `material_name` varchar(100) NOT NULL COMMENT '物料名称',
  `material_type` tinyint NOT NULL COMMENT '物料类型：1原材料 2半成品 3成品',
  `specification` varchar(100) DEFAULT NULL COMMENT '规格型号',
  `unit` varchar(20) NOT NULL COMMENT '计量单位',
  `safety_stock` int DEFAULT NULL COMMENT '安全库存',
  `current_stock` int NOT NULL DEFAULT '0' COMMENT '当前库存',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0禁用 1启用',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `material_code` (`material_code`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='物料表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_material`
--

LOCK TABLES `t_material` WRITE;
/*!40000 ALTER TABLE `t_material` DISABLE KEYS */;
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`) VALUES (1,'MAT-001','测试物料',1,'默认规格','个',10,100,1,'系统初始化物料','2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`) VALUES (2,'MAT-SHELL-TOP-A100','鼠标上盖',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-19 09:01:48');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`) VALUES (3,'MAT-SHELL-BOTTOM-A100','鼠标下盖',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-19 09:01:48');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`) VALUES (4,'MAT-PCB-A100','PCB主板',1,NULL,'块',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-19 09:01:48');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`) VALUES (5,'MAT-SWITCH-01','微动开关',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-19 09:01:48');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`) VALUES (6,'MAT-ENCODER-01','滚轮编码器',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-19 09:01:48');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`) VALUES (7,'MAT-USB-CABLE-A100','USB连接线',1,NULL,'根',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-19 09:01:48');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`) VALUES (8,'MAT-WHEEL-A100','滚轮组件',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-19 09:01:48');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`) VALUES (9,'MAT-LENS-A100','光学透镜',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-19 09:01:48');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`) VALUES (10,'MAT-SCREW-A100','固定螺钉',1,NULL,'颗',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-19 09:01:48');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`) VALUES (11,'MAT-FEET-A100','防滑脚贴',1,NULL,'套',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-19 09:01:48');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`) VALUES (12,'MAT-LABEL-A100','产品铭牌',1,NULL,'张',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-19 09:01:48');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`) VALUES (13,'MAT-BOX-A100','包装盒',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-19 09:01:48');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`) VALUES (14,'MAT-SEMI-E-A100','A100电子组件',2,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-19 08:41:54');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`) VALUES (15,'MAT-SEMI-S-A100','A100结构组件',2,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-19 08:41:54');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`) VALUES (16,'MAT-FG-A100','A100鼠标成品',3,NULL,'只',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-19 09:01:49');
/*!40000 ALTER TABLE `t_material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_material_issue`
--

DROP TABLE IF EXISTS `t_material_issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_material_issue` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '领料单ID',
  `issue_no` varchar(50) NOT NULL COMMENT '领料单号',
  `work_order_id` bigint NOT NULL COMMENT '工单ID',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `total_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总数量',
  `status` varchar(30) NOT NULL DEFAULT 'PENDING' COMMENT '状态',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `issue_no` (`issue_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产领料单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_material_issue`
--

LOCK TABLES `t_material_issue` WRITE;
/*!40000 ALTER TABLE `t_material_issue` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_material_issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_material_issue_item`
--

DROP TABLE IF EXISTS `t_material_issue_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_material_issue_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '领料明细ID',
  `issue_id` bigint NOT NULL COMMENT '领料单ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_id` bigint DEFAULT NULL COMMENT '批次ID',
  `planned_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '计划数量',
  `actual_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '实际数量',
  `location_id` bigint DEFAULT NULL COMMENT '库位ID',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产领料明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_material_issue_item`
--

LOCK TABLES `t_material_issue_item` WRITE;
/*!40000 ALTER TABLE `t_material_issue_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_material_issue_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_operation_log`
--

DROP TABLE IF EXISTS `t_operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_operation_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '操作日志ID',
  `user_id` bigint DEFAULT NULL COMMENT '操作人ID',
  `user_code` varchar(6) NOT NULL COMMENT '操作人编码',
  `username` varchar(50) NOT NULL COMMENT '操作人账号',
  `module` varchar(50) NOT NULL COMMENT '操作模块',
  `operation` varchar(100) NOT NULL COMMENT '操作描述',
  `method` varchar(200) DEFAULT NULL COMMENT '请求方法',
  `request_url` varchar(255) DEFAULT NULL COMMENT '请求URL',
  `request_param` text COMMENT '请求参数',
  `response_result` text COMMENT '返回结果',
  `operate_ip` varchar(50) DEFAULT NULL COMMENT '操作IP',
  `operate_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  `status` tinyint NOT NULL COMMENT '状态：0失败 1成功',
  `error_msg` text COMMENT '错误消息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='操作日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_operation_log`
--

LOCK TABLES `t_operation_log` WRITE;
/*!40000 ALTER TABLE `t_operation_log` DISABLE KEYS */;
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (1,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 10:30:23',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (2,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 10:42:43',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (3,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 10:51:17',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (4,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 12:51:59',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (5,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 14:33:47',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (6,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 14:39:34',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (7,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 14:49:01',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (8,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:18:43',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (9,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:23:59',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (10,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:24:57',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (11,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:43:18',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (12,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:46:25',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (13,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:54:24',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (14,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:56:25',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (15,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 16:02:53',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (16,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 16:14:27',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (17,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 17:16:23',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (18,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 17:20:30',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (19,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 18:15:56',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (20,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 18:20:48',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (21,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 18:40:30',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (22,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:13:32',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (23,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:15:46',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (24,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:16:19',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (25,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:18:28',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (26,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:21:38',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (27,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:31:50',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (28,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:40:27',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (29,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:51:06',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (30,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 20:09:03',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (31,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 20:37:43',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (32,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 08:52:29',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (33,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 08:54:42',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (34,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 09:23:04',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (35,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 10:25:16',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (36,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 10:29:50',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (37,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 10:40:43',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (38,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 10:46:00',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (39,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 10:50:16',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (40,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 11:03:09',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (41,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 11:21:10',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (42,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 11:24:54',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (43,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 11:30:09',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (44,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 12:22:24',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (45,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 12:28:50',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (46,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 13:06:01',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (47,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 14:25:11',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (48,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 14:38:45',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (49,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 15:56:23',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (50,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 22:42:16',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (51,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 22:42:49',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (52,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 22:53:03',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (53,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 08:31:56',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (54,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 08:55:53',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (55,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 08:57:11',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (56,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 09:07:04',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (57,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 09:09:58',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (58,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 09:11:59',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (59,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 09:14:48',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (60,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 09:24:56',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (61,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 09:32:46',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (62,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 13:19:59',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (63,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 13:25:37',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (64,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 13:51:53',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (65,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 13:54:59',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (66,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 13:56:52',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (67,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:04:10',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (68,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:04:23',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (69,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:16:08',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (70,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:18:43',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (71,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:19:48',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (72,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:22:18',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (73,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:24:42',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (74,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:28:12',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (75,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:31:05',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (76,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:33:25',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (77,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:34:49',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (78,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:41:47',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (79,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:42:28',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (80,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:43:04',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (81,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:43:51',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (82,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:44:16',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (83,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:45:39',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (84,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-18 08:37:01',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (85,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-18 08:37:09',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (86,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-18 08:37:59',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (87,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-18 15:23:07',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (88,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-18 15:23:26',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (89,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-18 15:29:08',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (90,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-19 08:43:28',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (91,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-19 08:45:07',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (92,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-19 09:01:46',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (93,4,'103001','worker1','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-19 09:01:47',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (94,5,'104001','qc_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-19 09:01:47',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (95,6,'105001','warehouse_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-19 09:01:47',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (96,7,'106001','purchase_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-19 09:01:47',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (97,8,'107001','sales_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-19 09:01:47',1,NULL);
/*!40000 ALTER TABLE `t_operation_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order`
--

DROP TABLE IF EXISTS `t_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `order_no` varchar(50) NOT NULL COMMENT '订单编号',
  `customer_name` varchar(100) NOT NULL COMMENT '客户名称',
  `customer_phone` varchar(20) DEFAULT NULL COMMENT '客户电话',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `quantity` int NOT NULL COMMENT '订单数量',
  `unit_price` decimal(10,2) NOT NULL COMMENT '单价',
  `total_amount` decimal(10,2) NOT NULL COMMENT '总金额',
  `order_date` date NOT NULL COMMENT '下单日期',
  `delivery_date` date DEFAULT NULL COMMENT '交付日期',
  `order_status` tinyint NOT NULL DEFAULT '0' COMMENT '订单状态',
  `priority` tinyint NOT NULL DEFAULT '2' COMMENT '优先级',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_by` bigint NOT NULL COMMENT '创建人ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order`
--

LOCK TABLES `t_order` WRITE;
/*!40000 ALTER TABLE `t_order` DISABLE KEYS */;
INSERT INTO `t_order` (`id`, `order_no`, `customer_name`, `customer_phone`, `product_name`, `quantity`, `unit_price`, `total_amount`, `order_date`, `delivery_date`, `order_status`, `priority`, `remark`, `create_by`, `create_time`, `update_time`, `deleted`) VALUES (1,'ORD-20260715001','测试客户A','13900139001','测试鼠标',100,59.00,5900.00,'2026-07-15','2026-07-25',3,2,'测试订单',2,'2026-07-15 10:23:38','2026-07-16 11:29:17',0);
INSERT INTO `t_order` (`id`, `order_no`, `customer_name`, `customer_phone`, `product_name`, `quantity`, `unit_price`, `total_amount`, `order_date`, `delivery_date`, `order_status`, `priority`, `remark`, `create_by`, `create_time`, `update_time`, `deleted`) VALUES (2,'ORD-20260715002','测试客户B','13900139002','测试鼠标',200,59.00,11800.00,'2026-07-14','2026-07-22',1,1,'紧急订单',2,'2026-07-15 10:23:38','2026-07-17 13:57:49',1);
INSERT INTO `t_order` (`id`, `order_no`, `customer_name`, `customer_phone`, `product_name`, `quantity`, `unit_price`, `total_amount`, `order_date`, `delivery_date`, `order_status`, `priority`, `remark`, `create_by`, `create_time`, `update_time`, `deleted`) VALUES (3,'ORD-20260715003','测试客户C','13900139003','测试鼠标',150,59.00,8850.00,'2026-07-13','2026-07-20',2,2,'普通订单',2,'2026-07-15 10:23:38','2026-07-15 10:23:38',0);
INSERT INTO `t_order` (`id`, `order_no`, `customer_name`, `customer_phone`, `product_name`, `quantity`, `unit_price`, `total_amount`, `order_date`, `delivery_date`, `order_status`, `priority`, `remark`, `create_by`, `create_time`, `update_time`, `deleted`) VALUES (4,'ORD-20260715962','plt','15555555555','滚轮',10,10.00,100.00,'2026-07-15','2026-07-25',1,3,'无',2,'2026-07-15 20:41:20','2026-07-16 12:35:09',0);
INSERT INTO `t_order` (`id`, `order_no`, `customer_name`, `customer_phone`, `product_name`, `quantity`, `unit_price`, `total_amount`, `order_date`, `delivery_date`, `order_status`, `priority`, `remark`, `create_by`, `create_time`, `update_time`, `deleted`) VALUES (5,'S2-090146140344','隔离验收客户',NULL,'A100有线办公鼠标',100,89.00,8900.00,'2026-10-19',NULL,3,2,NULL,8,'2026-10-19 09:01:47','2026-10-19 09:01:49',0);
/*!40000 ALTER TABLE `t_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_product`
--

DROP TABLE IF EXISTS `t_order_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_product` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '订单产品明细ID',
  `order_id` bigint NOT NULL COMMENT '订单ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `quantity` int NOT NULL COMMENT '数量',
  `unit_price` decimal(10,2) NOT NULL COMMENT '单价',
  `subtotal` decimal(10,2) NOT NULL COMMENT '小计',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='订单产品明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_product`
--

LOCK TABLES `t_order_product` WRITE;
/*!40000 ALTER TABLE `t_order_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_order_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_product`
--

DROP TABLE IF EXISTS `t_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_product` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '产品ID',
  `product_code` varchar(50) NOT NULL COMMENT '产品编码',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `product_type` varchar(50) DEFAULT NULL COMMENT '产品类型',
  `model` varchar(50) DEFAULT NULL COMMENT '产品型号',
  `specification` varchar(100) DEFAULT NULL COMMENT '规格',
  `unit` varchar(20) NOT NULL COMMENT '单位',
  `cost_price` decimal(10,2) DEFAULT NULL COMMENT '成本价',
  `selling_price` decimal(10,2) DEFAULT NULL COMMENT '销售价',
  `description` text COMMENT '描述',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0停售 1在售',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code` (`product_code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='产品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_product`
--

LOCK TABLES `t_product` WRITE;
/*!40000 ALTER TABLE `t_product` DISABLE KEYS */;
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`) VALUES (1,'PROD-001','测试鼠标','鼠标','M-001','默认规格','个',20.00,59.00,NULL,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`) VALUES (2,'PROD-002','无线鼠标','鼠标','M-002','无线蓝牙版','个',35.00,89.00,NULL,1,'2026-07-17 14:01:48','2026-07-17 14:01:48');
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`) VALUES (3,'PROD-003','游戏鼠标','鼠标','M-003','RGB背光','个',50.00,129.00,NULL,1,'2026-07-17 14:01:48','2026-07-17 14:01:48');
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`) VALUES (4,'PROD-004','办公鼠标','鼠标','M-004','静音版','个',25.00,69.00,NULL,1,'2026-07-17 14:01:48','2026-07-17 14:01:48');
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`) VALUES (5,'PROD-005','有线鼠标','鼠标','M-005','USB接口','个',15.00,49.00,NULL,1,'2026-07-17 14:01:48','2026-07-17 14:01:48');
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`) VALUES (6,'PRD-MOUSE-A100','A100有线办公鼠标','有线鼠标','A100','USB有线、1200DPI、3键','只',42.00,89.00,NULL,1,'2026-10-19 08:41:54','2026-10-19 08:41:54');
/*!40000 ALTER TABLE `t_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_production_order`
--

DROP TABLE IF EXISTS `t_production_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_production_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '生产订单ID',
  `po_no` varchar(50) NOT NULL COMMENT '生产订单编号',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `planned_quantity` decimal(10,2) NOT NULL COMMENT '计划数量',
  `actual_quantity` decimal(10,2) DEFAULT '0.00' COMMENT '实际数量',
  `planned_start_date` datetime DEFAULT NULL COMMENT '计划开始时间',
  `planned_end_date` datetime DEFAULT NULL COMMENT '计划结束时间',
  `actual_start_date` datetime DEFAULT NULL COMMENT '实际开始时间',
  `actual_end_date` datetime DEFAULT NULL COMMENT '实际结束时间',
  `status` varchar(30) NOT NULL DEFAULT 'DRAFT' COMMENT '状态',
  `department_id` bigint DEFAULT NULL COMMENT '部门ID',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `po_no` (`po_no`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_production_order`
--

LOCK TABLES `t_production_order` WRITE;
/*!40000 ALTER TABLE `t_production_order` DISABLE KEYS */;
INSERT INTO `t_production_order` (`id`, `po_no`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (1,'PO-20260715001',1,200.00,50.00,'2026-07-15 08:00:00','2026-07-22 18:00:00',NULL,NULL,'IN_PROGRESS',2,2,'2026-07-15 10:24:08','2026-07-15 10:24:08',0);
INSERT INTO `t_production_order` (`id`, `po_no`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (2,'PO-20260715002',1,100.00,0.00,'2026-07-16 08:00:00','2026-07-25 18:00:00',NULL,NULL,'DRAFT',2,2,'2026-07-15 10:24:08','2026-07-15 10:24:08',0);
/*!40000 ALTER TABLE `t_production_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_production_plan`
--

DROP TABLE IF EXISTS `t_production_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_production_plan` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '计划ID',
  `plan_no` varchar(50) NOT NULL COMMENT '计划编号',
  `order_id` bigint DEFAULT NULL COMMENT '订单ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `plan_quantity` int NOT NULL COMMENT '计划数量',
  `completed_quantity` int NOT NULL DEFAULT '0' COMMENT '完成数量',
  `start_date` date DEFAULT NULL COMMENT '开始日期',
  `end_date` date DEFAULT NULL COMMENT '结束日期',
  `plan_status` tinyint NOT NULL DEFAULT '0' COMMENT '计划状态',
  `priority` tinyint NOT NULL DEFAULT '2' COMMENT '优先级',
  `create_by` bigint NOT NULL COMMENT '创建人ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `plan_no` (`plan_no`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产计划表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_production_plan`
--

LOCK TABLES `t_production_plan` WRITE;
/*!40000 ALTER TABLE `t_production_plan` DISABLE KEYS */;
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (1,'PLAN-20260715001',2,1,'测试鼠标',200,50,'2026-07-15','2026-07-22',1,1,2,'2026-07-15 10:23:53','2026-07-15 10:23:53');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (2,'PLAN-20260715002',1,1,'测试鼠标',100,0,'2026-07-16','2026-07-25',0,2,2,'2026-07-15 10:23:53','2026-07-15 10:23:53');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (3,'PLAN-20260715003',3,1,'测试鼠标',150,150,'2026-07-13','2026-07-20',2,2,2,'2026-07-15 10:23:53','2026-07-15 10:23:53');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (7,'PLAN1784270777801',4,1,'滚轮',10,0,'2026-07-17','2026-07-25',0,3,2,'2026-07-17 14:46:18','2026-07-17 14:46:18');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (8,'PP1792371707287',5,6,'A100有线办公鼠标',100,100,'2026-10-19',NULL,2,2,8,'2026-10-19 09:01:47','2026-10-19 09:01:49');
/*!40000 ALTER TABLE `t_production_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_production_report`
--

DROP TABLE IF EXISTS `t_production_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_production_report` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '报工ID',
  `task_id` bigint NOT NULL COMMENT '任务ID',
  `report_user_id` bigint NOT NULL COMMENT '报工人ID',
  `report_user_name` varchar(50) NOT NULL COMMENT '报工人姓名',
  `report_quantity` int NOT NULL COMMENT '本次完成数量',
  `qualified_quantity` int NOT NULL COMMENT '合格数量',
  `defect_quantity` int NOT NULL COMMENT '不合格数量',
  `report_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '报工时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产报工表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_production_report`
--

LOCK TABLES `t_production_report` WRITE;
/*!40000 ALTER TABLE `t_production_report` DISABLE KEYS */;
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (1,1,3,'赵六',50,48,2,'2026-07-15 12:00:00','上午报工');
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (2,1,3,'赵六',30,29,1,'2026-07-15 18:00:00','下午报工');
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (3,2,4,'赵六',100,0,0,'2026-10-19 09:01:49',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (4,3,4,'赵六',100,0,0,'2026-10-19 09:01:49',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (5,4,4,'赵六',100,0,0,'2026-10-19 09:01:49',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (6,5,4,'赵六',100,0,0,'2026-10-19 09:01:50',NULL);
/*!40000 ALTER TABLE `t_production_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_production_report_item`
--

DROP TABLE IF EXISTS `t_production_report_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_production_report_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '报工明细ID',
  `report_id` bigint NOT NULL COMMENT '报工ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `good_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '良品数量',
  `defective_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '不良数量',
  `defect_type` varchar(100) DEFAULT NULL COMMENT '缺陷类型',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产报工明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_production_report_item`
--

LOCK TABLES `t_production_report_item` WRITE;
/*!40000 ALTER TABLE `t_production_report_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_production_report_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_production_task`
--

DROP TABLE IF EXISTS `t_production_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_production_task` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '任务ID',
  `task_no` varchar(50) NOT NULL COMMENT '任务编号',
  `plan_id` bigint NOT NULL COMMENT '计划ID',
  `task_type` tinyint NOT NULL COMMENT '任务类型',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `quantity` int NOT NULL COMMENT '任务数量',
  `assigned_user_id` bigint DEFAULT NULL COMMENT '分配用户ID',
  `assigned_user_name` varchar(50) DEFAULT NULL COMMENT '分配用户姓名',
  `task_status` tinyint NOT NULL DEFAULT '0' COMMENT '任务状态',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_no` (`task_no`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产任务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_production_task`
--

LOCK TABLES `t_production_task` WRITE;
/*!40000 ALTER TABLE `t_production_task` DISABLE KEYS */;
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (2,'MO-1-10',8,1,6,'A100有线办公鼠标',100,4,'赵六',4,'2026-10-19 09:01:49','2026-10-19 09:01:49',NULL,'2026-10-19 09:01:47','2026-10-19 09:01:49');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (3,'MO-1-20',8,1,6,'A100有线办公鼠标',100,4,'赵六',4,'2026-10-19 09:01:49','2026-10-19 09:01:49',NULL,'2026-10-19 09:01:47','2026-10-19 09:01:49');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (4,'MO-1-30',8,1,6,'A100有线办公鼠标',100,4,'赵六',4,'2026-10-19 09:01:49','2026-10-19 09:01:49',NULL,'2026-10-19 09:01:47','2026-10-19 09:01:49');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (5,'MO-1-40',8,1,6,'A100有线办公鼠标',100,4,'赵六',4,'2026-10-19 09:01:50','2026-10-19 09:01:50',NULL,'2026-10-19 09:01:47','2026-10-19 09:01:49');
/*!40000 ALTER TABLE `t_production_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_purchase_order`
--

DROP TABLE IF EXISTS `t_purchase_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_purchase_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '采购订单ID',
  `po_no` varchar(50) NOT NULL COMMENT '采购订单编号',
  `supplier_id` bigint NOT NULL COMMENT '供应商ID',
  `order_date` datetime DEFAULT NULL COMMENT '采购日期',
  `expected_date` datetime DEFAULT NULL COMMENT '预计到货日期',
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总金额',
  `status` varchar(30) NOT NULL DEFAULT 'DRAFT' COMMENT '状态：DRAFT/SUBMITTED/APPROVED/PARTIAL_RECEIVED/COMPLETED/CANCELLED',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  `sales_order_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `po_no` (`po_no`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='采购订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_purchase_order`
--

LOCK TABLES `t_purchase_order` WRITE;
/*!40000 ALTER TABLE `t_purchase_order` DISABLE KEYS */;
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (1,'S2-090146140344-MAIN',1,NULL,NULL,1599.00,'COMPLETED',NULL,7,'2026-10-19 09:01:48','2026-10-19 09:01:47',0,NULL);
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (2,'S2-090146140344-TOPUP',1,NULL,NULL,1.00,'COMPLETED',NULL,7,'2026-10-19 09:01:49','2026-10-19 09:01:48',0,NULL);
/*!40000 ALTER TABLE `t_purchase_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_purchase_order_item`
--

DROP TABLE IF EXISTS `t_purchase_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_purchase_order_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '采购订单明细ID',
  `po_id` bigint NOT NULL COMMENT '采购订单ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `quantity` decimal(10,2) NOT NULL COMMENT '采购数量',
  `unit_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '单价',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `received_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '已到货数量',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='采购订单明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_purchase_order_item`
--

LOCK TABLES `t_purchase_order_item` WRITE;
/*!40000 ALTER TABLE `t_purchase_order_item` DISABLE KEYS */;
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (1,1,2,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (2,1,3,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (3,1,4,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (4,1,5,200.00,1.00,200.00,200.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (5,1,6,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (6,1,7,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (7,1,8,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (8,1,9,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (9,1,10,399.00,1.00,399.00,399.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (10,1,11,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (11,1,12,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (12,1,13,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (13,2,10,1.00,1.00,1.00,1.00,NULL);
/*!40000 ALTER TABLE `t_purchase_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_qc_inspection`
--

DROP TABLE IF EXISTS `t_qc_inspection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_qc_inspection` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '质检单ID',
  `inspection_no` varchar(50) NOT NULL COMMENT '质检单号',
  `inspection_type` varchar(30) NOT NULL COMMENT '质检类型',
  `source_order_id` bigint DEFAULT NULL COMMENT '来源单ID',
  `source_order_no` varchar(80) DEFAULT NULL COMMENT '来源单号',
  `sample_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '抽检数量',
  `qualified_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '合格数量',
  `defective_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '不合格数量',
  `result` varchar(30) DEFAULT NULL COMMENT '质检结果',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  `qualified_rate` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '合格率',
  `defect_reason` varchar(500) DEFAULT NULL COMMENT '不合格原因',
  `handle_method` varchar(500) DEFAULT NULL COMMENT '处理方式',
  `business_status` varchar(50) DEFAULT NULL COMMENT '后续业务状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `inspection_no` (`inspection_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='质检检验单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_qc_inspection`
--

LOCK TABLES `t_qc_inspection` WRITE;
/*!40000 ALTER TABLE `t_qc_inspection` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_qc_inspection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_qc_inspection_item`
--

DROP TABLE IF EXISTS `t_qc_inspection_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_qc_inspection_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '质检明细ID',
  `inspection_id` bigint NOT NULL COMMENT '质检单ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_id` bigint DEFAULT NULL COMMENT '批次ID',
  `sample_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '抽检数量',
  `qualified_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '合格数量',
  `defective_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '不合格数量',
  `defect_type` varchar(100) DEFAULT NULL COMMENT '缺陷类型',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `inspection_item` varchar(100) NOT NULL COMMENT '检测项',
  `inspection_standard` varchar(500) DEFAULT NULL COMMENT '检测标准',
  `actual_value` varchar(500) DEFAULT NULL COMMENT '实测值',
  `item_result` varchar(30) DEFAULT NULL COMMENT '明细结果',
  `defect_reason` varchar(500) DEFAULT NULL COMMENT '不合格原因',
  `handle_method` varchar(500) DEFAULT NULL COMMENT '处理方式',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='质检检验明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_qc_inspection_item`
--

LOCK TABLES `t_qc_inspection_item` WRITE;
/*!40000 ALTER TABLE `t_qc_inspection_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_qc_inspection_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_quality_check`
--

DROP TABLE IF EXISTS `t_quality_check`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_quality_check` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '质检记录ID',
  `check_no` varchar(50) NOT NULL COMMENT '质检单号',
  `task_id` bigint DEFAULT NULL COMMENT '任务ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `check_quantity` int NOT NULL COMMENT '质检数量',
  `qualified_quantity` int NOT NULL COMMENT '合格数量',
  `defect_quantity` int NOT NULL COMMENT '不合格数量',
  `qualified_rate` decimal(5,2) NOT NULL COMMENT '合格率',
  `check_result` tinyint NOT NULL COMMENT '质检结果',
  `checker_id` bigint NOT NULL COMMENT '质检员ID',
  `checker_name` varchar(50) NOT NULL COMMENT '质检员姓名',
  `check_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '质检时间',
  `defect_desc` text COMMENT '缺陷描述',
  `handle_result` varchar(500) DEFAULT NULL COMMENT '处理结果',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `check_no` (`check_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='质检记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_quality_check`
--

LOCK TABLES `t_quality_check` WRITE;
/*!40000 ALTER TABLE `t_quality_check` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_quality_check` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_quality_standard`
--

DROP TABLE IF EXISTS `t_quality_standard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_quality_standard` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '质检标准ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `standard_name` varchar(100) NOT NULL COMMENT '标准名称',
  `standard_content` text NOT NULL COMMENT '标准内容',
  `qualified_threshold` decimal(5,2) DEFAULT NULL COMMENT '合格阈值',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0禁用 1启用',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='质检标准表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_quality_standard`
--

LOCK TABLES `t_quality_standard` WRITE;
/*!40000 ALTER TABLE `t_quality_standard` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_quality_standard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_role`
--

DROP TABLE IF EXISTS `t_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_role` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `role_code` varchar(10) NOT NULL COMMENT '角色编码',
  `role_name` varchar(50) NOT NULL COMMENT '角色名称',
  `role_desc` varchar(255) DEFAULT NULL COMMENT '角色描述',
  `sort` int NOT NULL DEFAULT '0' COMMENT '显示顺序',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0禁用 1启用',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_code` (`role_code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='角色表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_role`
--

LOCK TABLES `t_role` WRITE;
/*!40000 ALTER TABLE `t_role` DISABLE KEYS */;
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (1,'101','生产经理','负责生产计划制定、任务分配和进度跟踪',1,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (2,'102','车间主任','负责车间日常管理和生产调度',2,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (3,'103','操作工','负责生产线操作和产品加工',3,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (4,'104','质检员','负责产品质量检测和质量标准执行',4,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (5,'105','仓管员','负责物料出入库管理和库存盘点',5,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (6,'106','采购专员','负责原材料采购和供应商管理',6,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (7,'107','销售专员','负责客户订单对接和销售业务',7,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (8,'108','设备管理员','负责设备管理和维修',8,1,'2026-07-15 10:21:37','2026-07-17 13:19:03');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (9,'109','CEO','公司最高管理者，拥有系统全部权限',9,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (10,'110','CFO','财务总监，负责公司利润、收入和支出管理',10,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
/*!40000 ALTER TABLE `t_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_sales_order`
--

DROP TABLE IF EXISTS `t_sales_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_sales_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '销售订单ID',
  `so_no` varchar(50) NOT NULL COMMENT '销售订单编号',
  `customer_id` bigint NOT NULL COMMENT '客户ID',
  `order_date` datetime DEFAULT NULL COMMENT '下单日期',
  `delivery_date` datetime DEFAULT NULL COMMENT '交付日期',
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总金额',
  `status` varchar(30) NOT NULL DEFAULT 'DRAFT' COMMENT '状态',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `so_no` (`so_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='销售订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_sales_order`
--

LOCK TABLES `t_sales_order` WRITE;
/*!40000 ALTER TABLE `t_sales_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_sales_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_sales_order_item`
--

DROP TABLE IF EXISTS `t_sales_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_sales_order_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '销售订单明细ID',
  `so_id` bigint NOT NULL COMMENT '销售订单ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `quantity` decimal(10,2) NOT NULL COMMENT '数量',
  `unit_price` decimal(10,2) NOT NULL COMMENT '单价',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='销售订单明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_sales_order_item`
--

LOCK TABLES `t_sales_order_item` WRITE;
/*!40000 ALTER TABLE `t_sales_order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_sales_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_stock_in`
--

DROP TABLE IF EXISTS `t_stock_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_stock_in` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '通用入库单ID',
  `stock_in_no` varchar(80) NOT NULL COMMENT '入库单号',
  `stock_in_type` varchar(30) NOT NULL COMMENT '入库类型',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `source_order_id` bigint DEFAULT NULL COMMENT '来源订单ID',
  `source_order_no` varchar(80) DEFAULT NULL COMMENT '来源订单编号',
  `total_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总数量',
  `status` varchar(30) NOT NULL DEFAULT 'PENDING' COMMENT '状态',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_in_no` (`stock_in_no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通用入库单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_stock_in`
--

LOCK TABLES `t_stock_in` WRITE;
/*!40000 ALTER TABLE `t_stock_in` DISABLE KEYS */;
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (1,'PURCHASE_RECEIPT-1','PURCHASE_RECEIPT',2,1,'S2-090146140344-MAIN',1599.00,'COMPLETED',NULL,6,'2026-10-19 09:01:48','2026-10-19 09:01:48',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (2,'PURCHASE_RECEIPT-2','PURCHASE_RECEIPT',2,2,'S2-090146140344-TOPUP',1.00,'COMPLETED',NULL,6,'2026-10-19 09:01:49','2026-10-19 09:01:49',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (3,'PRODUCTION_RECEIPT-1','PRODUCTION_RECEIPT',4,1,'MO-PP1792371707287',100.00,'COMPLETED',NULL,6,'2026-10-19 09:01:50','2026-10-19 09:01:50',0);
/*!40000 ALTER TABLE `t_stock_in` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_stock_in_item`
--

DROP TABLE IF EXISTS `t_stock_in_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_stock_in_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '通用入库明细ID',
  `stock_in_id` bigint NOT NULL COMMENT '入库单ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_id` bigint DEFAULT NULL COMMENT '批次ID',
  `quantity` decimal(10,2) NOT NULL COMMENT '数量',
  `location_id` bigint DEFAULT NULL COMMENT '库位ID',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通用入库明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_stock_in_item`
--

LOCK TABLES `t_stock_in_item` WRITE;
/*!40000 ALTER TABLE `t_stock_in_item` DISABLE KEYS */;
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (1,1,2,1,100.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (2,1,3,2,100.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (3,1,4,3,100.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (4,1,5,4,200.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (5,1,6,5,100.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (6,1,7,6,100.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (7,1,8,7,100.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (8,1,9,8,100.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (9,1,10,9,399.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (10,1,11,10,100.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (11,1,12,11,100.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (12,1,13,12,100.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (13,2,10,13,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (14,3,16,14,100.00,4,NULL);
/*!40000 ALTER TABLE `t_stock_in_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_stock_out`
--

DROP TABLE IF EXISTS `t_stock_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_stock_out` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '通用出库单ID',
  `stock_out_no` varchar(80) NOT NULL COMMENT '出库单号',
  `stock_out_type` varchar(30) NOT NULL COMMENT '出库类型',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `source_order_id` bigint DEFAULT NULL COMMENT '来源订单ID',
  `source_order_no` varchar(80) DEFAULT NULL COMMENT '来源订单编号',
  `total_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总数量',
  `status` varchar(30) NOT NULL DEFAULT 'PENDING' COMMENT '状态',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_out_no` (`stock_out_no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通用出库单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_stock_out`
--

LOCK TABLES `t_stock_out` WRITE;
/*!40000 ALTER TABLE `t_stock_out` DISABLE KEYS */;
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (2,'PRODUCTION_ISSUE-1','PRODUCTION_ISSUE',2,1,'MO-PP1792371707287',1600.00,'COMPLETED',NULL,6,'2026-10-19 09:01:49','2026-10-19 09:01:49',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (3,'SALES_SHIPMENT-5','SALES_SHIPMENT',4,5,'S2-090146140344',100.00,'COMPLETED',NULL,6,'2026-10-19 09:01:50','2026-10-19 09:01:50',0);
/*!40000 ALTER TABLE `t_stock_out` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_stock_out_item`
--

DROP TABLE IF EXISTS `t_stock_out_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_stock_out_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '通用出库明细ID',
  `stock_out_id` bigint NOT NULL COMMENT '出库单ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_id` bigint DEFAULT NULL COMMENT '批次ID',
  `quantity` decimal(10,2) NOT NULL COMMENT '数量',
  `location_id` bigint DEFAULT NULL COMMENT '库位ID',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通用出库明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_stock_out_item`
--

LOCK TABLES `t_stock_out_item` WRITE;
/*!40000 ALTER TABLE `t_stock_out_item` DISABLE KEYS */;
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (3,2,2,1,100.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (4,2,3,2,100.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (5,2,4,3,100.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (6,2,5,4,200.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (7,2,6,5,100.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (8,2,7,6,100.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (9,2,8,7,100.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (10,2,9,8,100.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (11,2,10,9,399.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (12,2,10,13,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (13,2,11,10,100.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (14,2,12,11,100.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (15,2,13,12,100.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (16,3,16,14,100.00,4,NULL);
/*!40000 ALTER TABLE `t_stock_out_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_supplier`
--

DROP TABLE IF EXISTS `t_supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_supplier` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '供应商ID',
  `supplier_code` varchar(50) NOT NULL COMMENT '供应商编码',
  `supplier_name` varchar(100) NOT NULL COMMENT '供应商名称',
  `contact_person` varchar(50) DEFAULT NULL COMMENT '联系人',
  `contact_phone` varchar(20) DEFAULT NULL COMMENT '联系电话',
  `address` varchar(255) DEFAULT NULL COMMENT '地址',
  `bank_name` varchar(100) DEFAULT NULL COMMENT '开户银行',
  `bank_account` varchar(50) DEFAULT NULL COMMENT '银行账号',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：-1删除 0禁用 1活跃',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_code` (`supplier_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='供应商表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_supplier`
--

LOCK TABLES `t_supplier` WRITE;
/*!40000 ALTER TABLE `t_supplier` DISABLE KEYS */;
INSERT INTO `t_supplier` (`id`, `supplier_code`, `supplier_name`, `contact_person`, `contact_phone`, `address`, `bank_name`, `bank_account`, `status`, `remark`, `create_time`, `update_time`) VALUES (1,'S2-090146140344','隔离验收供应商','验收','10000',NULL,NULL,NULL,1,NULL,'2026-10-19 09:01:47','2026-10-19 09:01:47');
/*!40000 ALTER TABLE `t_supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_uom`
--

DROP TABLE IF EXISTS `t_uom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_uom` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '计量单位ID',
  `uom_code` varchar(50) NOT NULL COMMENT '单位编码',
  `uom_name` varchar(100) NOT NULL COMMENT '单位名称',
  `status` varchar(30) NOT NULL DEFAULT '1' COMMENT '状态',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uom_code` (`uom_code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='计量单位表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_uom`
--

LOCK TABLES `t_uom` WRITE;
/*!40000 ALTER TABLE `t_uom` DISABLE KEYS */;
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`) VALUES (1,'S1-U1','只','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`) VALUES (2,'S1-U2','个','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`) VALUES (3,'S1-U3','块','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`) VALUES (4,'S1-U4','根','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`) VALUES (5,'S1-U5','颗','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`) VALUES (6,'S1-U6','套','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`) VALUES (7,'S1-U7','张','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0);
/*!40000 ALTER TABLE `t_uom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_user` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `user_code` varchar(6) NOT NULL COMMENT '6位用户编码',
  `username` varchar(50) NOT NULL COMMENT '登录账号',
  `password` varchar(255) NOT NULL COMMENT '登录密码',
  `real_name` varchar(50) DEFAULT NULL COMMENT '真实姓名',
  `phone` varchar(20) DEFAULT NULL COMMENT '手机号',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `gender` tinyint DEFAULT NULL COMMENT '性别：0女 1男',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像',
  `role_id` int NOT NULL COMMENT '角色ID',
  `dept_id` bigint DEFAULT NULL COMMENT '部门ID',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0离职 1在职 2试用期',
  `entry_date` date DEFAULT NULL COMMENT '入职日期',
  `leave_date` date DEFAULT NULL COMMENT '离职日期',
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(50) DEFAULT NULL COMMENT '最后登录IP',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除：0未删除 1已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_code` (`user_code`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user`
--

LOCK TABLES `t_user` WRITE;
/*!40000 ALTER TABLE `t_user` DISABLE KEYS */;
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (1,'109001','admin','','张三','13800138001','zhangsan@mouse.com',1,NULL,9,1,1,NULL,NULL,'2026-10-19 09:01:46','127.0.0.1','2026-07-15 10:21:37','2026-10-19 09:01:46',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (2,'101001','prod_manager','','李四','13800138002','lisi@mouse.com',1,NULL,1,2,1,NULL,NULL,'2026-10-18 15:23:26','127.0.0.1','2026-07-15 10:21:37','2026-10-18 15:23:26',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (3,'102001','workshop_manager','','王五','13800138003','wangwu@mouse.com',1,NULL,2,2,1,NULL,NULL,NULL,NULL,'2026-07-15 10:21:37','2026-07-15 10:21:37',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (4,'103001','worker1','','赵六','13800138004','zhaoliu@mouse.com',1,NULL,3,2,1,NULL,NULL,'2026-10-19 09:01:47','127.0.0.1','2026-07-15 10:21:37','2026-10-19 09:01:46',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (5,'104001','qc_manager','','周八','13800138006','zhouba@mouse.com',1,NULL,4,3,1,NULL,NULL,'2026-10-19 09:01:47','127.0.0.1','2026-07-15 10:21:37','2026-10-19 09:01:46',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (6,'105001','warehouse_manager','','吴九','13800138007','wujiu@mouse.com',1,NULL,5,4,1,NULL,NULL,'2026-10-19 09:01:47','127.0.0.1','2026-07-15 10:21:37','2026-10-19 09:01:46',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (7,'106001','purchase_manager','','郑十','13800138008','zhengshi@mouse.com',1,NULL,6,5,1,NULL,NULL,'2026-10-19 09:01:47','127.0.0.1','2026-07-15 10:21:37','2026-10-19 09:01:47',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (8,'107001','sales_manager','','陈十一','13800138009','chenshiyi@mouse.com',1,NULL,7,6,1,NULL,NULL,'2026-10-19 09:01:47','127.0.0.1','2026-07-15 10:21:37','2026-10-19 09:01:47',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (9,'108001','equipment_manager','','黄十二','13800138010','huangshier@mouse.com',1,NULL,8,7,1,NULL,NULL,NULL,NULL,'2026-07-15 10:21:37','2026-07-15 10:21:37',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (10,'110001','cfo','','钱十三','13800138011','qianshisan@mouse.com',1,NULL,10,8,1,NULL,NULL,NULL,NULL,'2026-07-15 10:21:37','2026-07-15 10:21:37',0);
/*!40000 ALTER TABLE `t_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user_role`
--

DROP TABLE IF EXISTS `t_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_user_role` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户角色关系ID',
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `role_id` bigint NOT NULL COMMENT '角色ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户角色关系表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user_role`
--

LOCK TABLES `t_user_role` WRITE;
/*!40000 ALTER TABLE `t_user_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_warehouse`
--

DROP TABLE IF EXISTS `t_warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_warehouse` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '仓库ID',
  `warehouse_code` varchar(50) NOT NULL COMMENT '仓库编码',
  `warehouse_name` varchar(100) NOT NULL COMMENT '仓库名称',
  `location` varchar(255) DEFAULT NULL COMMENT '仓库位置',
  `manager_id` bigint DEFAULT NULL COMMENT '仓管员ID',
  `manager_name` varchar(50) DEFAULT NULL COMMENT '仓管员姓名',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0禁用 1启用',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `warehouse_code` (`warehouse_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='仓库表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_warehouse`
--

LOCK TABLES `t_warehouse` WRITE;
/*!40000 ALTER TABLE `t_warehouse` DISABLE KEYS */;
INSERT INTO `t_warehouse` (`id`, `warehouse_code`, `warehouse_name`, `location`, `manager_id`, `manager_name`, `status`, `remark`, `create_time`, `update_time`) VALUES (1,'WH-001','默认仓库','默认库区',NULL,NULL,1,'系统初始化仓库','2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_warehouse` (`id`, `warehouse_code`, `warehouse_name`, `location`, `manager_id`, `manager_name`, `status`, `remark`, `create_time`, `update_time`) VALUES (2,'WH-A100-RM','A100原料仓',NULL,NULL,NULL,1,NULL,'2026-10-19 08:41:54','2026-10-19 08:41:54');
INSERT INTO `t_warehouse` (`id`, `warehouse_code`, `warehouse_name`, `location`, `manager_id`, `manager_name`, `status`, `remark`, `create_time`, `update_time`) VALUES (3,'WH-A100-LINE','A100线边库',NULL,NULL,NULL,1,NULL,'2026-10-19 08:41:54','2026-10-19 08:41:54');
INSERT INTO `t_warehouse` (`id`, `warehouse_code`, `warehouse_name`, `location`, `manager_id`, `manager_name`, `status`, `remark`, `create_time`, `update_time`) VALUES (4,'WH-A100-FG','A100成品仓',NULL,NULL,NULL,1,NULL,'2026-10-19 08:41:54','2026-10-19 08:41:54');
/*!40000 ALTER TABLE `t_warehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_work_order`
--

DROP TABLE IF EXISTS `t_work_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_work_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '工单ID',
  `wo_no` varchar(50) NOT NULL COMMENT '工单编号',
  `production_order_id` bigint NOT NULL COMMENT '生产订单ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `planned_quantity` decimal(10,2) NOT NULL COMMENT '计划数量',
  `actual_quantity` decimal(10,2) DEFAULT '0.00' COMMENT '实际数量',
  `planned_start_date` datetime DEFAULT NULL COMMENT '计划开始时间',
  `planned_end_date` datetime DEFAULT NULL COMMENT '计划结束时间',
  `actual_start_date` datetime DEFAULT NULL COMMENT '实际开始时间',
  `actual_end_date` datetime DEFAULT NULL COMMENT '实际结束时间',
  `status` varchar(30) NOT NULL DEFAULT 'PLANNED' COMMENT '状态',
  `department_id` bigint DEFAULT NULL COMMENT '部门ID',
  `assigned_user_id` bigint DEFAULT NULL COMMENT '分配员工ID',
  `assigned_user_name` varchar(50) DEFAULT NULL COMMENT '分配员工姓名',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `wo_no` (`wo_no`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_work_order`
--

LOCK TABLES `t_work_order` WRITE;
/*!40000 ALTER TABLE `t_work_order` DISABLE KEYS */;
INSERT INTO `t_work_order` (`id`, `wo_no`, `production_order_id`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `assigned_user_id`, `assigned_user_name`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (1,'WO-20260715001',1,1,100.00,0.00,'2026-07-15 08:00:00','2026-07-18 18:00:00','2026-07-17 14:47:24','2026-07-17 14:42:07','IN_PROGRESS',2,NULL,NULL,2,'2026-07-15 10:24:22','2026-07-17 14:47:24',0);
INSERT INTO `t_work_order` (`id`, `wo_no`, `production_order_id`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `assigned_user_id`, `assigned_user_name`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (2,'WO-20260715002',1,2,100.00,0.00,'2026-07-19 08:00:00','2026-07-22 18:00:00',NULL,NULL,'ASSIGNED',2,NULL,NULL,2,'2026-07-15 10:24:22','2026-07-17 14:03:01',0);
INSERT INTO `t_work_order` (`id`, `wo_no`, `production_order_id`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `assigned_user_id`, `assigned_user_name`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (3,'WO-20260715003',2,3,50.00,0.00,'2026-07-16 08:00:00','2026-07-20 18:00:00',NULL,NULL,'PLANNED',2,NULL,NULL,2,'2026-07-15 10:24:22','2026-07-17 14:03:01',0);
INSERT INTO `t_work_order` (`id`, `wo_no`, `production_order_id`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `assigned_user_id`, `assigned_user_name`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (4,'WO-20260717001',1,4,200.00,0.00,NULL,NULL,NULL,NULL,'PLANNED',2,NULL,NULL,2,'2026-07-17 14:03:01','2026-07-17 14:03:01',0);
INSERT INTO `t_work_order` (`id`, `wo_no`, `production_order_id`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `assigned_user_id`, `assigned_user_name`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (5,'WO-20260717002',2,2,150.00,0.00,NULL,NULL,NULL,NULL,'ASSIGNED',2,NULL,NULL,2,'2026-07-17 14:03:01','2026-07-17 14:41:13',0);
INSERT INTO `t_work_order` (`id`, `wo_no`, `production_order_id`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `assigned_user_id`, `assigned_user_name`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (6,'WO-20260717003',3,5,80.00,0.00,NULL,NULL,NULL,NULL,'ASSIGNED',2,NULL,NULL,2,'2026-07-17 14:03:01','2026-07-17 14:03:01',0);
/*!40000 ALTER TABLE `t_work_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'mouse_mes_stage2_test_20261019_090135'
--

--
-- Dumping routines for database 'mouse_mes_stage2_test_20261019_090135'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-01  8:18:24
