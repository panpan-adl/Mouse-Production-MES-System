-- MySQL dump 10.13  Distrib 8.3.0, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mouse_mes_completion_test_20261024_102513
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mm_ai_budget`
--

DROP TABLE IF EXISTS `mm_ai_budget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_ai_budget` (
  `user_id` bigint NOT NULL,
  `day` date NOT NULL,
  `calls` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`,`day`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_ai_budget`
--

LOCK TABLES `mm_ai_budget` WRITE;
/*!40000 ALTER TABLE `mm_ai_budget` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_ai_budget` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_ai_session`
--

DROP TABLE IF EXISTS `mm_ai_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_ai_session` (
  `id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` bigint NOT NULL,
  `filters` json NOT NULL,
  `revision` int NOT NULL DEFAULT '0',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_ai_session`
--

LOCK TABLES `mm_ai_session` WRITE;
/*!40000 ALTER TABLE `mm_ai_session` DISABLE KEYS */;
INSERT INTO `mm_ai_session` (`id`, `user_id`, `filters`, `revision`, `updated_at`) VALUES ('2a1e9996-b2b1-4c5b-b82a-e7fd1fda5fad',1,'{\"kind\": \"INVENTORY\", \"material\": \"5\"}',1,'2026-10-23 23:35:17');
INSERT INTO `mm_ai_session` (`id`, `user_id`, `filters`, `revision`, `updated_at`) VALUES ('7ba9a8a9-d4e8-4c7b-9b69-148b09245174',1,'{\"to\": \"2026-10-23\", \"from\": \"2026-10-01\", \"kind\": \"INVENTORY\", \"material\": \"5\"}',1,'2026-10-23 23:24:51');
/*!40000 ALTER TABLE `mm_ai_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_area`
--

DROP TABLE IF EXISTS `mm_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_area` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `warehouse_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_area`
--

LOCK TABLES `mm_area` WRITE;
/*!40000 ALTER TABLE `mm_area` DISABLE KEYS */;
INSERT INTO `mm_area` (`id`, `code`, `name`, `warehouse_id`, `created_at`) VALUES (1,'WH-A100-RM-A','默认库区',2,'2026-10-19 00:41:54');
INSERT INTO `mm_area` (`id`, `code`, `name`, `warehouse_id`, `created_at`) VALUES (2,'WH-A100-LINE-A','默认库区',3,'2026-10-19 00:41:54');
INSERT INTO `mm_area` (`id`, `code`, `name`, `warehouse_id`, `created_at`) VALUES (3,'WH-A100-FG-A','默认库区',4,'2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_audit`
--

DROP TABLE IF EXISTS `mm_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_audit` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `actor_id` bigint NOT NULL,
  `resource` varchar(60) NOT NULL,
  `action` varchar(30) NOT NULL,
  `record_id` bigint DEFAULT NULL,
  `details` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=419 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_audit`
--

LOCK TABLES `mm_audit` WRITE;
/*!40000 ALTER TABLE `mm_audit` DISABLE KEYS */;
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (1,1,'units','SAVE',8,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (2,1,'units','SAVE',9,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (3,1,'categories','SAVE',1,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (4,1,'categories','SAVE',2,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (5,1,'mes:code','POST',0,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (6,1,'mes:code','POST',0,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (7,1,'mes:code','POST',0,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (8,1,'mes:code','POST',0,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (9,1,'mes:code','POST',0,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (10,1,'mes:code','POST',0,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (11,1,'mes:code','POST',0,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (12,1,'mes:code','POST',0,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (13,1,'mes:code','POST',0,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (14,1,'mes:code','POST',0,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (15,1,'mes:code','POST',0,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (16,1,'mes:code','POST',0,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (17,1,'mes:code','POST',0,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (18,1,'mes:code','POST',0,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (19,1,'mes:code','POST',0,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (20,1,'workshops','SAVE',2,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (21,1,'equipment','SAVE',2,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (22,1,'stations','SAVE',5,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (23,1,'operations','SAVE',1,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (24,1,'operations','SAVE',2,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (25,1,'operations','SAVE',3,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (26,1,'operations','SAVE',4,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (27,1,'qc-items','SAVE',5,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (28,1,'qc-templates','SAVE',4,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (29,1,'qc-lines','SAVE',13,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (30,1,'qc-templates','SAVE',5,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (31,1,'qc-lines','SAVE',14,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (32,1,'qc-templates','SAVE',6,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (33,1,'qc-lines','SAVE',15,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (34,1,'qc-templates','SAVE',7,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (35,1,'qc-lines','SAVE',16,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (36,1,'teams','SAVE',2,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (37,1,'members','SAVE',2,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (38,1,'schedules','SAVE',1,NULL,'2026-10-24 02:25:30');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (39,1,'work-orders','CREATE',1,NULL,'2026-10-24 02:25:31');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (40,7,'suppliers','SAVE',1,NULL,'2026-10-24 02:25:31');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (41,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:31');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (42,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:31');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (43,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:31');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (44,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:31');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (45,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:31');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (46,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:31');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (47,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:31');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (48,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:31');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (49,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:31');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (50,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:31');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (51,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:31');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (52,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:31');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (53,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:31');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (54,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:31');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (55,6,'stock-documents','PURCHASE_RECEIPT',1,NULL,'2026-10-24 02:25:31');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (56,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:31');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (57,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:32');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (58,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:32');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (59,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:32');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (60,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:32');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (61,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:32');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (62,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:32');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (63,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:32');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (64,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:32');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (65,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:32');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (66,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:32');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (67,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:32');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (68,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:32');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (69,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:32');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (70,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:32');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (71,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:32');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (72,6,'stock-documents','PURCHASE_RECEIPT',2,NULL,'2026-10-24 02:25:32');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (73,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:32');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (74,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:32');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (75,6,'fulfillment','ISSUE',1,NULL,'2026-10-24 02:25:33');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (76,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:33');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (77,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:33');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (78,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:33');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (79,6,'stock-documents','LINE_RETURN',3,NULL,'2026-10-24 02:25:33');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (80,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:33');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (81,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:34');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (82,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:34');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (83,6,'stock-documents','LINE_ISSUE',4,NULL,'2026-10-24 02:25:34');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (84,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:34');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (85,5,'inspections','EXECUTE',1,NULL,'2026-10-24 02:25:34');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (86,5,'mes:disposition','POST',0,NULL,'2026-10-24 02:25:34');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (87,4,'mes:rework','POST',0,NULL,'2026-10-24 02:25:34');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (88,5,'inspections','EXECUTE',2,NULL,'2026-10-24 02:25:34');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (89,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:34');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (90,5,'inspections','EXECUTE',3,NULL,'2026-10-24 02:25:34');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (91,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:34');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (92,5,'inspections','EXECUTE',4,NULL,'2026-10-24 02:25:34');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (93,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:34');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (94,5,'inspections','EXECUTE',5,NULL,'2026-10-24 02:25:34');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (95,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:34');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (96,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:34');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (97,6,'stock-documents','PRODUCTION_RECEIPT',5,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (98,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (99,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (100,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (101,6,'stock-documents','PRODUCTION_RECEIPT',6,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (102,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (103,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (104,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (105,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (106,6,'stock-documents','SALES_SHIPMENT',7,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (107,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (108,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (109,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (110,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (111,6,'stock-documents','SALES_SHIPMENT',8,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (112,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (113,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (114,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (115,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (116,6,'stock-documents','SALES_RETURN',9,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (117,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (118,6,'mes:createBox','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (119,6,'mes:item','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (120,6,'mes:confirmBox','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (121,6,'mes:createBox','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (122,6,'mes:child','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (123,6,'mes:confirmBox','POST',0,NULL,'2026-10-24 02:25:35');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (124,1,'mes:publish','POST',0,NULL,'2026-10-24 02:25:36');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (125,4,'mes:read','POST',0,NULL,'2026-10-24 02:25:36');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (126,1,'units','SAVE',10,NULL,'2026-10-24 02:25:36');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (127,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:36');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (128,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:36');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (129,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:36');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (130,6,'stock-documents','PURCHASE_RECEIPT',11,NULL,'2026-10-24 02:25:36');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (131,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:36');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (132,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:36');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (133,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:36');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (134,6,'stock-documents','PURCHASE_RETURN',12,NULL,'2026-10-24 02:25:36');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (135,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:36');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (136,1,'checks','SAVE',2,NULL,'2026-10-24 02:25:36');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (137,9,'mes:generateChecks','POST',0,NULL,'2026-10-24 02:25:36');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (138,9,'mes:generateChecks','POST',0,NULL,'2026-10-24 02:25:36');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (139,9,'check-records','SAVE',1,NULL,'2026-10-24 02:25:36');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (140,9,'check-records','SAVE',2,NULL,'2026-10-24 02:25:36');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (141,1,'teams','SAVE',3,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (142,1,'members','SAVE',3,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (143,1,'shifts','SAVE',2,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (144,1,'shifts','SAVE',3,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (145,1,'holidays','SAVE',1,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (146,1,'rotations','SAVE',1,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (147,1,'rotation-teams','SAVE',1,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (148,1,'rotation-teams','SAVE',2,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (149,1,'rotation-shifts','SAVE',1,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (150,1,'rotation-shifts','SAVE',2,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (151,1,'schedules','SAVE',2,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (152,1,'schedules','SAVE',3,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (153,1,'mes:rotate','POST',0,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (154,1,'mes:image','POST',0,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (155,1,'sops','SAVE',1,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (156,1,'products','SAVE',7,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (157,1,'mappings','SAVE',2,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (158,1,'bom-versions','SAVE',2,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (159,1,'bom-lines','SAVE',15,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (160,1,'bom-lines','SAVE',16,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (161,1,'bom-lines','SAVE',17,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (162,1,'bom-lines','SAVE',18,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (163,1,'bom-lines','SAVE',19,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (164,1,'routes','SAVE',2,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (165,1,'operations','SAVE',5,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (166,1,'qc-templates','SAVE',8,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (167,1,'qc-lines','SAVE',17,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (168,1,'products','SAVE',8,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (169,1,'mappings','SAVE',3,NULL,'2026-10-24 02:25:37');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (170,1,'bom-versions','SAVE',3,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (171,1,'bom-lines','SAVE',20,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (172,1,'bom-lines','SAVE',21,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (173,1,'bom-lines','SAVE',22,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (174,1,'bom-lines','SAVE',23,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (175,1,'routes','SAVE',3,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (176,1,'operations','SAVE',6,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (177,1,'qc-templates','SAVE',9,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (178,1,'qc-lines','SAVE',18,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (179,1,'work-orders','CREATE',2,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (180,1,'mes:work','POST',0,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (181,1,'work-orders','CREATE',3,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (182,1,'work-orders','CREATE',4,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (183,1,'mes:decompose','POST',0,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (184,1,'mes:split','POST',0,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (185,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (186,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (187,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (188,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (189,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (190,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (191,6,'stock-documents','PURCHASE_RECEIPT',15,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (192,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (193,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (194,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (195,6,'stock-documents','LINE_ISSUE',16,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (196,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:38');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (197,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:39');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (198,5,'inspections','EXECUTE',6,NULL,'2026-10-24 02:25:39');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (199,6,'fulfillment','RECEIPT',3,NULL,'2026-10-24 02:25:39');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (200,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:39');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (201,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:39');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (202,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:39');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (203,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:39');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (204,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:39');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (205,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:39');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (206,6,'stock-documents','PURCHASE_RECEIPT',17,NULL,'2026-10-24 02:25:39');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (207,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:39');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (208,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:39');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (209,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:39');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (210,6,'stock-documents','LINE_ISSUE',18,NULL,'2026-10-24 02:25:39');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (211,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:39');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (212,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:39');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (213,5,'inspections','EXECUTE',7,NULL,'2026-10-24 02:25:39');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (214,6,'fulfillment','RECEIPT',4,NULL,'2026-10-24 02:25:39');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (215,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (216,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (217,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (218,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (219,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (220,6,'stock-documents','PURCHASE_RECEIPT',19,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (221,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (222,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (223,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (224,6,'stock-documents','LINE_ISSUE',20,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (225,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (226,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (227,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (228,6,'stock-documents','LINE_ISSUE',21,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (229,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (230,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (231,5,'inspections','EXECUTE',8,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (232,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (233,5,'inspections','EXECUTE',9,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (234,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (235,5,'inspections','EXECUTE',10,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (236,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:40');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (237,5,'inspections','EXECUTE',11,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (238,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (239,5,'inspections','EXECUTE',12,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (240,6,'fulfillment','RECEIPT',2,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (241,1,'work-orders','CREATE',5,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (242,1,'mes:work','POST',0,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (243,1,'work-orders','CREATE',6,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (244,1,'mes:work','POST',0,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (245,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (246,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (247,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (248,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (249,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (250,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (251,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (252,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (253,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (254,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (255,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (256,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (257,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:41');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (258,6,'stock-documents','PURCHASE_RECEIPT',22,NULL,'2026-10-24 02:25:42');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (259,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:42');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (260,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:42');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (261,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:42');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (262,6,'stock-documents','LINE_ISSUE',23,NULL,'2026-10-24 02:25:42');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (263,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:42');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (264,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:42');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (265,5,'inspections','EXECUTE',13,NULL,'2026-10-24 02:25:42');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (266,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:42');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (267,5,'inspections','EXECUTE',14,NULL,'2026-10-24 02:25:42');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (268,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:42');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (269,5,'inspections','EXECUTE',15,NULL,'2026-10-24 02:25:42');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (270,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:42');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (271,5,'inspections','EXECUTE',16,NULL,'2026-10-24 02:25:42');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (272,6,'fulfillment','RECEIPT',5,NULL,'2026-10-24 02:25:42');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (273,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (274,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (275,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (276,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (277,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (278,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (279,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (280,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (281,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (282,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (283,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (284,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (285,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (286,6,'stock-documents','PURCHASE_RECEIPT',24,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (287,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (288,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (289,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (290,6,'stock-documents','LINE_ISSUE',25,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (291,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (292,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (293,5,'inspections','EXECUTE',17,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (294,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:43');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (295,5,'inspections','EXECUTE',18,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (296,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (297,5,'inspections','EXECUTE',19,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (298,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (299,5,'inspections','EXECUTE',20,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (300,6,'fulfillment','RECEIPT',6,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (301,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (302,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (303,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (304,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (305,6,'stock-documents','SALES_SHIPMENT',26,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (306,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (307,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (308,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (309,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (310,6,'stock-documents','PURCHASE_RECEIPT',27,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (311,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (312,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (313,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:44');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (314,6,'stock-documents','PURCHASE_RETURN',28,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (315,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (316,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (317,11,'positions','SAVE',1,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (318,11,'user-positions','SAVE',1,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (319,11,'menus','SAVE',1,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (320,11,'role-menus','SAVE',1,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (321,11,'role-menus','DELETE',1,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (322,11,'parameters','SAVE',2,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (323,1,'mes:publish','POST',0,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (324,1,'mes:publish','POST',0,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (325,11,'parameters','SAVE',2,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (326,11,'jobs','SAVE',1,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (327,11,'jobs','SAVE',1,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (328,11,'mes:runJob','POST',0,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (329,1,'work-orders','CREATE',7,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (330,1,'mes:work','POST',0,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (331,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (332,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (333,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (334,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (335,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (336,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (337,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (338,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (339,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (340,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (341,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (342,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:45');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (343,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:46');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (344,6,'stock-documents','PURCHASE_RECEIPT',29,NULL,'2026-10-24 02:25:46');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (345,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:46');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (346,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:46');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (347,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:46');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (348,6,'stock-documents','LINE_ISSUE',30,NULL,'2026-10-24 02:25:46');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (349,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:46');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (350,1,'qc-templates','SAVE',10,NULL,'2026-10-24 02:25:46');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (351,1,'qc-lines','SAVE',19,NULL,'2026-10-24 02:25:46');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (352,5,'inspections','EXECUTE',21,NULL,'2026-10-24 02:25:46');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (353,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:46');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (354,5,'inspections','EXECUTE',22,NULL,'2026-10-24 02:25:46');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (355,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:46');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (356,5,'inspections','EXECUTE',23,NULL,'2026-10-24 02:25:46');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (357,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:46');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (358,5,'inspections','EXECUTE',24,NULL,'2026-10-24 02:25:46');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (359,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:46');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (360,5,'inspections','EXECUTE',25,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (361,5,'mes:disposition','POST',0,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (362,6,'quality','SCRAP',2,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (363,6,'mes:scrap','POST',0,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (364,6,'mes:scrap','POST',0,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (365,1,'work-orders','CREATE',8,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (366,1,'mes:work','POST',0,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (367,1,'materials','SAVE',17,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (368,1,'materials','SAVE',18,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (369,1,'products','SAVE',9,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (370,1,'mappings','SAVE',4,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (371,1,'bom-versions','SAVE',4,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (372,1,'bom-lines','SAVE',24,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (373,6,'mes:createBox','POST',0,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (374,6,'mes:item','POST',0,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (375,1,'work-orders','CREATE',9,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (376,1,'mes:work','POST',0,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (377,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (378,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (379,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (380,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (381,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (382,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (383,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (384,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (385,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (386,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (387,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (388,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (389,5,'mes:inspectLine','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (390,6,'stock-documents','PURCHASE_RECEIPT',31,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (391,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (392,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (393,6,'mes:confirm','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (394,6,'stock-documents','LINE_ISSUE',32,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (395,6,'mes:post','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (396,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (397,4,'mes:reportDraft','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (398,1,'mes:reportReject','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (399,4,'mes:reportDraft','POST',0,NULL,'2026-10-24 02:25:48');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (400,1,'mes:reportConfirm','POST',0,NULL,'2026-10-24 02:25:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (401,1,'mes:reportConfirm','POST',0,NULL,'2026-10-24 02:25:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (402,5,'inspections','EXECUTE',26,NULL,'2026-10-24 02:25:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (403,5,'mes:disposition','POST',0,NULL,'2026-10-24 02:25:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (404,4,'mes:rework','POST',0,NULL,'2026-10-24 02:25:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (405,5,'inspections','EXECUTE',27,NULL,'2026-10-24 02:25:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (406,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (407,4,'mes:reportDraft','POST',0,NULL,'2026-10-24 02:25:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (408,1,'mes:reportConfirm','POST',0,NULL,'2026-10-24 02:25:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (409,5,'inspections','EXECUTE',28,NULL,'2026-10-24 02:25:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (410,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (411,4,'mes:reportDraft','POST',0,NULL,'2026-10-24 02:25:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (412,1,'mes:reportConfirm','POST',0,NULL,'2026-10-24 02:25:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (413,5,'inspections','EXECUTE',29,NULL,'2026-10-24 02:25:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (414,1,'mes:dispatch','POST',0,NULL,'2026-10-24 02:25:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (415,4,'mes:reportDraft','POST',0,NULL,'2026-10-24 02:25:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (416,1,'mes:reportConfirm','POST',0,NULL,'2026-10-24 02:25:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (417,5,'inspections','EXECUTE',30,NULL,'2026-10-24 02:25:49');
INSERT INTO `mm_audit` (`id`, `actor_id`, `resource`, `action`, `record_id`, `details`, `created_at`) VALUES (418,6,'mes:draft','POST',0,NULL,'2026-10-24 02:25:49');
/*!40000 ALTER TABLE `mm_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_auto_event`
--

DROP TABLE IF EXISTS `mm_auto_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_auto_event` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `rule_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `task_id` bigint NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'PENDING',
  `attempts` int NOT NULL DEFAULT '0',
  `error` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `finished_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rule_code` (`rule_code`,`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_auto_event`
--

LOCK TABLES `mm_auto_event` WRITE;
/*!40000 ALTER TABLE `mm_auto_event` DISABLE KEYS */;
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (1,'REPORT_QC',2,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 10:25:34.207234','2026-10-24 10:25:35.777731');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (2,'REPORT_QC',3,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 10:25:34.505603','2026-10-24 10:25:35.783124');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (3,'REPORT_QC',4,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 10:25:34.677642','2026-10-24 10:25:35.788811');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (4,'REPORT_QC',5,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 10:25:34.847272','2026-10-24 10:25:35.798041');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (5,'REPORT_QC',10,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 10:25:39.150315','2026-10-24 10:25:39.835130');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (6,'REPORT_QC',11,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 10:25:39.879274','2026-10-24 10:25:41.867410');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (7,'REPORT_QC',6,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 10:25:40.677871','2026-10-24 10:25:41.875568');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (8,'REPORT_QC',12,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 10:25:40.813699','2026-10-24 10:25:41.881778');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (9,'REPORT_QC',7,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 10:25:40.917635','2026-10-24 10:25:41.890461');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (10,'REPORT_QC',8,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 10:25:41.043234','2026-10-24 10:25:41.900384');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (11,'REPORT_QC',9,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 10:25:41.136666','2026-10-24 10:25:41.909433');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (12,'REPORT_QC',13,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 10:25:42.468789','2026-10-24 10:25:43.924595');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (13,'REPORT_QC',14,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 10:25:42.588796','2026-10-24 10:25:43.931592');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (14,'REPORT_QC',15,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 10:25:42.696729','2026-10-24 10:25:43.936421');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (15,'REPORT_QC',16,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 10:25:42.789223','2026-10-24 10:25:43.940365');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (16,'REPORT_QC',17,'SUCCEEDED',1,NULL,'2026-10-24 10:25:43.911003','2026-10-24 10:25:43.950145');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (17,'REPORT_QC',18,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 10:25:43.988689','2026-10-24 10:25:45.975127');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (18,'REPORT_QC',19,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 10:25:44.117691','2026-10-24 10:25:45.982548');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (19,'REPORT_QC',20,'SKIPPED',0,'任务已放行或不再需要质检','2026-10-24 10:25:44.243877','2026-10-24 10:25:45.987689');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (20,'REPORT_QC',21,'SUCCEEDED',1,NULL,'2026-10-24 10:25:46.634151','2026-10-24 10:25:46.644814');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (21,'REPORT_QC',22,'SUCCEEDED',1,NULL,'2026-10-24 10:25:46.770804','2026-10-24 10:25:46.783434');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (22,'REPORT_QC',23,'SUCCEEDED',1,NULL,'2026-10-24 10:25:46.892907','2026-10-24 10:25:46.920129');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (23,'REPORT_QC',24,'SUCCEEDED',1,NULL,'2026-10-24 10:25:47.005727','2026-10-24 10:25:47.032522');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (24,'REPORT_QC',29,'SUCCEEDED',1,NULL,'2026-10-24 10:25:49.041205','2026-10-24 10:25:49.203125');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (25,'REPORT_QC',30,'SUCCEEDED',1,NULL,'2026-10-24 10:25:49.423865','2026-10-24 10:25:49.438242');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (26,'REPORT_QC',31,'SUCCEEDED',1,NULL,'2026-10-24 10:25:49.533683','2026-10-24 10:25:49.574726');
INSERT INTO `mm_auto_event` (`id`, `rule_code`, `task_id`, `status`, `attempts`, `error`, `created_at`, `finished_at`) VALUES (27,'REPORT_QC',32,'SUCCEEDED',1,NULL,'2026-10-24 10:25:49.652905','2026-10-24 10:25:49.683779');
/*!40000 ALTER TABLE `mm_auto_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_auto_rule`
--

DROP TABLE IF EXISTS `mm_auto_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_auto_rule` (
  `code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `enabled` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_auto_rule`
--

LOCK TABLES `mm_auto_rule` WRITE;
/*!40000 ALTER TABLE `mm_auto_rule` DISABLE KEYS */;
INSERT INTO `mm_auto_rule` (`code`, `name`, `enabled`) VALUES ('REPORT_QC','完整报工后自动创建质检待办',1);
/*!40000 ALTER TABLE `mm_auto_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_bom`
--

DROP TABLE IF EXISTS `mm_bom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_bom` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `product_id` bigint NOT NULL,
  `root_material_id` bigint NOT NULL,
  `version` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_bom`
--

LOCK TABLES `mm_bom` WRITE;
/*!40000 ALTER TABLE `mm_bom` DISABLE KEYS */;
INSERT INTO `mm_bom` (`id`, `code`, `name`, `product_id`, `root_material_id`, `version`, `created_at`) VALUES (1,'BOM-A100-V1','A100多级BOM',6,16,'1.0','2026-10-19 00:41:54');
INSERT INTO `mm_bom` (`id`, `code`, `name`, `product_id`, `root_material_id`, `version`, `created_at`) VALUES (2,'MC-SB-15-102528061580','隔离半成品BOM',7,15,'1','2026-10-24 02:25:37');
INSERT INTO `mm_bom` (`id`, `code`, `name`, `product_id`, `root_material_id`, `version`, `created_at`) VALUES (3,'MC-SB-14-102528061580','隔离半成品BOM',8,14,'1','2026-10-24 02:25:38');
INSERT INTO `mm_bom` (`id`, `code`, `name`, `product_id`, `root_material_id`, `version`, `created_at`) VALUES (4,'MC-BUY-B-102528061580','外购半成品装配BOM',9,18,'1','2026-10-24 02:25:47');
/*!40000 ALTER TABLE `mm_bom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_bom_line`
--

DROP TABLE IF EXISTS `mm_bom_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_bom_line` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `bom_id` bigint NOT NULL,
  `parent_material_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `quantity` decimal(14,4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bom_id` (`bom_id`,`parent_material_id`,`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_bom_line`
--

LOCK TABLES `mm_bom_line` WRITE;
/*!40000 ALTER TABLE `mm_bom_line` DISABLE KEYS */;
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (1,1,16,14,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (2,1,16,15,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (3,1,15,2,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (4,1,15,3,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (5,1,14,4,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (6,1,14,5,2.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (7,1,14,6,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (8,1,14,7,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (9,1,15,8,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (10,1,15,9,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (11,1,15,10,4.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (12,1,16,11,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (13,1,16,12,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (14,1,16,13,1.0000,'2026-10-19 00:41:54');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (15,2,15,10,4.0000,'2026-10-24 02:25:37');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (16,2,15,9,1.0000,'2026-10-24 02:25:37');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (17,2,15,8,1.0000,'2026-10-24 02:25:37');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (18,2,15,3,1.0000,'2026-10-24 02:25:37');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (19,2,15,2,1.0000,'2026-10-24 02:25:37');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (20,3,14,7,1.0000,'2026-10-24 02:25:38');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (21,3,14,6,1.0000,'2026-10-24 02:25:38');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (22,3,14,5,2.0000,'2026-10-24 02:25:38');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (23,3,14,4,1.0000,'2026-10-24 02:25:38');
INSERT INTO `mm_bom_line` (`id`, `bom_id`, `parent_material_id`, `material_id`, `quantity`, `created_at`) VALUES (24,4,18,17,1.0000,'2026-10-24 02:25:47');
/*!40000 ALTER TABLE `mm_bom_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_category`
--

DROP TABLE IF EXISTS `mm_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `parent_id` bigint DEFAULT NULL,
  `kind` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_category`
--

LOCK TABLES `mm_category` WRITE;
/*!40000 ALTER TABLE `mm_category` DISABLE KEYS */;
INSERT INTO `mm_category` (`id`, `code`, `name`, `parent_id`, `kind`) VALUES (1,'MC-CAT-102528061580','鼠标产品',NULL,'PRODUCT');
INSERT INTO `mm_category` (`id`, `code`, `name`, `parent_id`, `kind`) VALUES (2,'MC-SUB-102528061580','办公鼠标',1,'PRODUCT');
/*!40000 ALTER TABLE `mm_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_check_due`
--

DROP TABLE IF EXISTS `mm_check_due`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_check_due` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `plan_id` bigint NOT NULL,
  `due_date` date NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'PENDING',
  `record_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_due` (`plan_id`,`due_date`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_check_due`
--

LOCK TABLES `mm_check_due` WRITE;
/*!40000 ALTER TABLE `mm_check_due` DISABLE KEYS */;
INSERT INTO `mm_check_due` (`id`, `plan_id`, `due_date`, `status`, `record_id`) VALUES (1,1,'2026-10-19','OVERDUE',NULL);
INSERT INTO `mm_check_due` (`id`, `plan_id`, `due_date`, `status`, `record_id`) VALUES (2,1,'2026-10-20','OVERDUE',NULL);
INSERT INTO `mm_check_due` (`id`, `plan_id`, `due_date`, `status`, `record_id`) VALUES (3,1,'2026-10-21','OVERDUE',NULL);
INSERT INTO `mm_check_due` (`id`, `plan_id`, `due_date`, `status`, `record_id`) VALUES (4,1,'2026-10-22','OVERDUE',NULL);
INSERT INTO `mm_check_due` (`id`, `plan_id`, `due_date`, `status`, `record_id`) VALUES (5,1,'2026-10-23','OVERDUE',NULL);
INSERT INTO `mm_check_due` (`id`, `plan_id`, `due_date`, `status`, `record_id`) VALUES (6,1,'2026-10-24','PENDING',NULL);
INSERT INTO `mm_check_due` (`id`, `plan_id`, `due_date`, `status`, `record_id`) VALUES (7,2,'2026-10-24','DONE',1);
/*!40000 ALTER TABLE `mm_check_due` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_check_plan`
--

DROP TABLE IF EXISTS `mm_check_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_check_plan` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `equipment_id` bigint NOT NULL,
  `interval_days` int NOT NULL,
  `standard` varchar(500) NOT NULL,
  `owner_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enabled` int NOT NULL DEFAULT '1',
  `plan_type` varchar(20) NOT NULL DEFAULT 'CHECK',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_check_plan`
--

LOCK TABLES `mm_check_plan` WRITE;
/*!40000 ALTER TABLE `mm_check_plan` DISABLE KEYS */;
INSERT INTO `mm_check_plan` (`id`, `code`, `name`, `equipment_id`, `interval_days`, `standard`, `owner_id`, `created_at`, `enabled`, `plan_type`) VALUES (1,'CHECK-A100','USB功能测试台日点检',1,1,'连接完整、供电正常、测试软件可识别',1,'2026-10-19 00:41:54',1,'CHECK');
INSERT INTO `mm_check_plan` (`id`, `code`, `name`, `equipment_id`, `interval_days`, `standard`, `owner_id`, `created_at`, `enabled`, `plan_type`) VALUES (2,'MC-CHECK-102528061580','隔离周期点检',2,1,'供电及功能正常',9,'2026-10-24 02:25:36',1,'CHECK');
/*!40000 ALTER TABLE `mm_check_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_check_plan_subject`
--

DROP TABLE IF EXISTS `mm_check_plan_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_check_plan_subject` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `plan_id` bigint NOT NULL,
  `subject_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_check_subject` (`plan_id`,`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_check_plan_subject`
--

LOCK TABLES `mm_check_plan_subject` WRITE;
/*!40000 ALTER TABLE `mm_check_plan_subject` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_check_plan_subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_check_record`
--

DROP TABLE IF EXISTS `mm_check_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_check_record` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `plan_id` bigint NOT NULL,
  `checked_at` datetime NOT NULL,
  `actual_value` varchar(500) NOT NULL,
  `result` varchar(20) NOT NULL,
  `remark` varchar(500) DEFAULT NULL,
  `actor_id` bigint NOT NULL,
  `maintenance_id` bigint DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_check_record`
--

LOCK TABLES `mm_check_record` WRITE;
/*!40000 ALTER TABLE `mm_check_record` DISABLE KEYS */;
INSERT INTO `mm_check_record` (`id`, `plan_id`, `checked_at`, `actual_value`, `result`, `remark`, `actor_id`, `maintenance_id`, `created_at`) VALUES (1,2,'2026-10-24 10:25:37','隔离验收异常，生成报修','FAIL',NULL,9,1,'2026-10-24 02:25:36');
INSERT INTO `mm_check_record` (`id`, `plan_id`, `checked_at`, `actual_value`, `result`, `remark`, `actor_id`, `maintenance_id`, `created_at`) VALUES (2,2,'2026-10-24 10:25:37','隔离验收异常，生成报修','FAIL',NULL,9,1,'2026-10-24 02:25:36');
/*!40000 ALTER TABLE `mm_check_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_check_subject`
--

DROP TABLE IF EXISTS `mm_check_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_check_subject` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `kind` varchar(20) NOT NULL,
  `standard` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_check_subject`
--

LOCK TABLES `mm_check_subject` WRITE;
/*!40000 ALTER TABLE `mm_check_subject` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_check_subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_code_rule`
--

DROP TABLE IF EXISTS `mm_code_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_code_rule` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `prefix` varchar(32) NOT NULL,
  `width` int NOT NULL DEFAULT '6',
  `next_value` bigint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_code_rule`
--

LOCK TABLES `mm_code_rule` WRITE;
/*!40000 ALTER TABLE `mm_code_rule` DISABLE KEYS */;
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (1,'ITEM_CODE','ITEM_CODE','MAT-',6,16);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (2,'VENDOR_CODE','VENDOR_CODE','SUP-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (3,'CLIENT_CODE','CLIENT_CODE','CUS-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (4,'WORKSHOP_CODE','WORKSHOP_CODE','WS-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (5,'WORKSTATION_CODE','WORKSTATION_CODE','ST-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (6,'WAREHOUSE_CODE','WAREHOUSE_CODE','WH-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (7,'AREA_CODE','AREA_CODE','AR-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (8,'LOCATION_CODE','LOCATION_CODE','LOC-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (9,'ISSUE_CODE','ISSUE_CODE','ISS-',6,11);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (10,'WORKORDER_CODE','WORKORDER_CODE','MO-',6,18);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (11,'PACKAGE_CODE','PACKAGE_CODE','PKG-',6,4);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (12,'DOCUMENT_CODE','DOCUMENT_CODE','DOC-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (13,'UOM_CODE','UOM_CODE','UOM-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (14,'PRODUCT_CODE','PRODUCT_CODE','PRD-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (15,'PROCESS_CODE','PROCESS_CODE','OP-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (16,'ROUTE_CODE','ROUTE_CODE','ROUTE-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (17,'CHECKPLAN_CODE','CHECKPLAN_CODE','CHECK-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (18,'MACHINERY_CODE','MACHINERY_CODE','EQ-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (19,'QC_TEMPLATR_CODE','QC_TEMPLATR_CODE','QCT-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (20,'QC_ITEM_CODE','QC_ITEM_CODE','QCI-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (21,'DEFECT_CODE','DEFECT_CODE','DF-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (22,'BOM_CODE','BOM_CODE','BOM-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (23,'TEAM_CODE','TEAM_CODE','TEAM-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (24,'CAL_PLAN_CODE','CAL_PLAN_CODE','CAL-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (25,'SOP_CODE','SOP_CODE','SOP-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (26,'ITEMRECPT_CODE','ITEMRECPT_CODE','PR-',6,12);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (27,'WM_RTVENDOR_CODE','WM_RTVENDOR_CODE','P-RET-',6,4);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (28,'RTISSUE_CODE','RTISSUE_CODE','L-RET-',6,2);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (29,'PRODUCTRECPT_CODE','PRODUCTRECPT_CODE','FG-IN-',6,8);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (30,'PRODUCTSALSE_CODE','PRODUCTSALSE_CODE','SHIP-',6,4);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (31,'RTSALSE_CODE','RTSALSE_CODE','S-RET-',6,2);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (32,'QC_IQC_CODE','QC_IQC_CODE','IQC-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (33,'IPQC_CODE','IPQC_CODE','IPQC-',6,31);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (34,'OQC_CODE','OQC_CODE','OQC-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (35,'REPAIR_CODE','REPAIR_CODE','REPAIR-',6,2);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (83,'SUBJECT_CODE','SUBJECT_CODE','SUBJ-',6,1);
INSERT INTO `mm_code_rule` (`id`, `code`, `name`, `prefix`, `width`, `next_value`) VALUES (84,'REPORT_CODE','REPORT_CODE','RPT-',6,6);
/*!40000 ALTER TABLE `mm_code_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_defect`
--

DROP TABLE IF EXISTS `mm_defect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_defect` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `severity` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_defect`
--

LOCK TABLES `mm_defect` WRITE;
/*!40000 ALTER TABLE `mm_defect` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_defect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_document`
--

DROP TABLE IF EXISTS `mm_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_document` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(80) NOT NULL,
  `kind` varchar(32) NOT NULL,
  `source_id` bigint DEFAULT NULL,
  `warehouse_id` bigint NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'DRAFT',
  `reason` varchar(500) DEFAULT NULL,
  `actor_id` bigint NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `posted_at` datetime DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `business_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_document`
--

LOCK TABLES `mm_document` WRITE;
/*!40000 ALTER TABLE `mm_document` DISABLE KEYS */;
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (1,'PR-000001','PURCHASE_RECEIPT',1,2,'POSTED','隔离验收',6,'2026-10-24 10:25:31','2026-10-24 10:25:31','PURCHASE_RECEIPT PR-000001','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (2,'PR-000002','PURCHASE_RECEIPT',1,2,'POSTED','隔离验收',6,'2026-10-24 10:25:32','2026-10-24 10:25:32','PURCHASE_RECEIPT PR-000002','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (3,'L-RET-000001','LINE_RETURN',1,2,'POSTED','隔离验收',6,'2026-10-24 10:25:33','2026-10-24 10:25:33','LINE_RETURN L-RET-000001','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (4,'ISS-000002','LINE_ISSUE',1,2,'POSTED','隔离验收',6,'2026-10-24 10:25:34','2026-10-24 10:25:34','LINE_ISSUE ISS-000002','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (5,'FG-IN-000001','PRODUCTION_RECEIPT',1,4,'POSTED','隔离验收',6,'2026-10-24 10:25:34','2026-10-24 10:25:35','PRODUCTION_RECEIPT FG-IN-000001','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (6,'FG-IN-000002','PRODUCTION_RECEIPT',1,4,'POSTED','隔离验收',6,'2026-10-24 10:25:35','2026-10-24 10:25:35','PRODUCTION_RECEIPT FG-IN-000002','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (7,'SHIP-000001','SALES_SHIPMENT',5,4,'POSTED','隔离验收',6,'2026-10-24 10:25:35','2026-10-24 10:25:35','SALES_SHIPMENT SHIP-000001','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (8,'SHIP-000002','SALES_SHIPMENT',5,4,'POSTED','隔离验收',6,'2026-10-24 10:25:35','2026-10-24 10:25:35','SALES_SHIPMENT SHIP-000002','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (9,'S-RET-000001','SALES_RETURN',5,4,'POSTED','隔离验收',6,'2026-10-24 10:25:35','2026-10-24 10:25:35','SALES_RETURN S-RET-000001','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (11,'PR-000003','PURCHASE_RECEIPT',2,2,'POSTED','隔离验收',6,'2026-10-24 10:25:36','2026-10-24 10:25:36','PURCHASE_RECEIPT PR-000003','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (12,'P-RET-000001','PURCHASE_RETURN',2,2,'POSTED','隔离验收',6,'2026-10-24 10:25:36','2026-10-24 10:25:36','PURCHASE_RETURN P-RET-000001','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (15,'PR-000004','PURCHASE_RECEIPT',3,2,'POSTED','隔离验收',6,'2026-10-24 10:25:38','2026-10-24 10:25:38','PURCHASE_RECEIPT PR-000004','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (16,'ISS-000003','LINE_ISSUE',3,2,'POSTED','隔离验收',6,'2026-10-24 10:25:38','2026-10-24 10:25:38','LINE_ISSUE ISS-000003','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (17,'PR-000005','PURCHASE_RECEIPT',4,2,'POSTED','隔离验收',6,'2026-10-24 10:25:39','2026-10-24 10:25:39','PURCHASE_RECEIPT PR-000005','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (18,'ISS-000004','LINE_ISSUE',4,2,'POSTED','隔离验收',6,'2026-10-24 10:25:39','2026-10-24 10:25:39','LINE_ISSUE ISS-000004','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (19,'PR-000006','PURCHASE_RECEIPT',5,2,'POSTED','隔离验收',6,'2026-10-24 10:25:40','2026-10-24 10:25:40','PURCHASE_RECEIPT PR-000006','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (20,'ISS-000005','LINE_ISSUE',2,2,'POSTED','隔离验收',6,'2026-10-24 10:25:40','2026-10-24 10:25:40','LINE_ISSUE ISS-000005','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (21,'ISS-000006','LINE_ISSUE',2,4,'POSTED','隔离验收',6,'2026-10-24 10:25:40','2026-10-24 10:25:40','LINE_ISSUE ISS-000006','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (22,'PR-000007','PURCHASE_RECEIPT',6,2,'POSTED','隔离验收',6,'2026-10-24 10:25:41','2026-10-24 10:25:42','PURCHASE_RECEIPT PR-000007','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (23,'ISS-000007','LINE_ISSUE',5,2,'POSTED','隔离验收',6,'2026-10-24 10:25:42','2026-10-24 10:25:42','LINE_ISSUE ISS-000007','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (24,'PR-000008','PURCHASE_RECEIPT',7,2,'POSTED','隔离验收',6,'2026-10-24 10:25:43','2026-10-24 10:25:43','PURCHASE_RECEIPT PR-000008','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (25,'ISS-000008','LINE_ISSUE',6,2,'POSTED','隔离验收',6,'2026-10-24 10:25:43','2026-10-24 10:25:43','LINE_ISSUE ISS-000008','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (26,'SHIP-000003','SALES_SHIPMENT',6,4,'POSTED','隔离验收',6,'2026-10-24 10:25:44','2026-10-24 10:25:44','SALES_SHIPMENT SHIP-000003','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (27,'PR-000009','PURCHASE_RECEIPT',8,2,'POSTED','隔离验收',6,'2026-10-24 10:25:44','2026-10-24 10:25:44','PURCHASE_RECEIPT PR-000009','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (28,'P-RET-000002','PURCHASE_RETURN',8,2,'POSTED','隔离验收',6,'2026-10-24 10:25:44','2026-10-24 10:25:45','PURCHASE_RETURN P-RET-000002','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (29,'PR-000010','PURCHASE_RECEIPT',9,2,'POSTED','隔离验收',6,'2026-10-24 10:25:45','2026-10-24 10:25:46','PURCHASE_RECEIPT PR-000010','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (30,'ISS-000009','LINE_ISSUE',7,2,'POSTED','隔离验收',6,'2026-10-24 10:25:46','2026-10-24 10:25:46','LINE_ISSUE ISS-000009','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (31,'PR-000011','PURCHASE_RECEIPT',10,2,'POSTED','隔离验收',6,'2026-10-24 10:25:47','2026-10-24 10:25:48','PURCHASE_RECEIPT PR-000011','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (32,'ISS-000010','LINE_ISSUE',9,2,'POSTED','隔离验收',6,'2026-10-24 10:25:48','2026-10-24 10:25:48','LINE_ISSUE ISS-000010','2026-10-24');
INSERT INTO `mm_document` (`id`, `code`, `kind`, `source_id`, `warehouse_id`, `status`, `reason`, `actor_id`, `created_at`, `posted_at`, `name`, `business_date`) VALUES (33,'P-RET-000003','PURCHASE_RETURN',8,2,'DRAFT','核验头部',6,'2026-10-24 10:25:49',NULL,'验收供应商退货','2026-10-24');
/*!40000 ALTER TABLE `mm_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_document_check`
--

DROP TABLE IF EXISTS `mm_document_check`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_document_check` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `line_id` bigint NOT NULL,
  `template_id` bigint NOT NULL,
  `quantity` decimal(18,2) NOT NULL,
  `qualified_quantity` decimal(18,2) NOT NULL,
  `results` json NOT NULL,
  `status` varchar(20) NOT NULL,
  `actor_id` bigint NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_document_check`
--

LOCK TABLES `mm_document_check` WRITE;
/*!40000 ALTER TABLE `mm_document_check` DISABLE KEYS */;
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (1,1,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:31');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (2,2,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:31');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (3,3,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:31');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (4,4,1,100.00,100.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:31');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (5,5,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:31');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (6,6,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:31');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (7,7,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:31');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (8,8,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:31');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (9,9,1,200.00,200.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:31');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (10,10,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:31');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (11,11,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:31');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (12,12,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:31');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (13,13,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:32');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (14,14,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:32');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (15,15,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:32');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (16,16,1,100.00,100.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:32');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (17,17,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:32');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (18,18,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:32');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (19,19,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:32');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (20,20,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:32');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (21,21,1,200.00,200.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:32');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (22,22,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:32');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (23,23,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:32');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (24,24,1,50.00,50.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:32');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (25,29,3,40.00,40.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:35');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (26,30,3,60.00,60.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:35');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (27,31,3,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:35');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (28,33,1,20.00,20.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:36');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (29,37,1,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:38');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (30,38,1,20.00,20.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:38');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (31,39,1,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:38');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (32,40,1,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:38');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (33,45,1,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:39');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (34,46,1,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:39');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (35,47,1,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:39');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (36,48,1,40.00,40.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:39');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (37,54,1,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:40');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (38,55,1,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:40');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (39,56,1,10.00,10.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:40');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (40,62,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:41');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (41,63,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:41');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (42,64,1,2.00,2.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:41');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (43,65,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:41');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (44,66,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:41');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (45,67,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:41');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (46,68,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:41');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (47,69,1,4.00,4.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:41');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (48,70,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:41');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (49,71,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:41');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (50,72,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:41');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (51,85,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:43');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (52,86,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:43');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (53,87,1,2.00,2.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:43');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (54,88,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:43');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (55,89,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:43');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (56,90,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:43');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (57,91,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:43');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (58,92,1,4.00,4.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:43');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (59,93,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:43');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (60,94,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:43');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (61,95,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:43');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (62,108,3,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:44');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (63,109,3,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:44');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (64,110,1,2.00,2.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:44');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (65,112,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:45');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (66,113,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:45');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (67,114,1,2.00,2.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:45');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (68,115,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:45');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (69,116,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:45');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (70,117,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:45');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (71,118,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:45');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (72,119,1,4.00,4.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:45');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (73,120,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:45');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (74,121,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:45');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (75,122,1,1.00,1.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:45');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (76,135,1,2.00,2.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:48');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (77,136,1,2.00,2.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:48');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (78,137,1,4.00,4.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:48');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (79,138,1,2.00,2.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:48');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (80,139,1,2.00,2.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:48');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (81,140,1,2.00,2.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:48');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (82,141,1,2.00,2.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:48');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (83,142,1,8.00,8.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:48');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (84,143,1,2.00,2.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:48');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (85,144,1,2.00,2.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:48');
INSERT INTO `mm_document_check` (`id`, `line_id`, `template_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (86,145,1,2.00,2.00,'[{\"item\": {\"id\": 1, \"code\": \"QC-VISUAL\", \"name\": \"外观装配\", \"standard\": \"零件完整、无明显裂纹\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 2, \"code\": \"QC-USB\", \"name\": \"USB识别\", \"standard\": \"连接后可识别输入设备\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 3, \"code\": \"QC-KEY\", \"name\": \"按键滚轮\", \"standard\": \"左右键与滚轮均有响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}, {\"item\": {\"id\": 4, \"code\": \"QC-MOVE\", \"name\": \"指针移动\", \"standard\": \"测试面移动可产生指针响应\", \"data_type\": \"TEXT\", \"created_at\": \"2026-10-19 08:41:54\", \"lower_limit\": null, \"upper_limit\": null}, \"actual\": \"人工检查合格\", \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 10:25:48');
/*!40000 ALTER TABLE `mm_document_check` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_document_line`
--

DROP TABLE IF EXISTS `mm_document_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_document_line` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `document_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `lot_id` bigint NOT NULL,
  `location_id` bigint DEFAULT NULL,
  `quantity` decimal(18,2) NOT NULL,
  `source_line_id` bigint DEFAULT NULL,
  `input_unit_id` bigint DEFAULT NULL,
  `entered_quantity` decimal(18,6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `mm_document_line_chk_1` CHECK ((`quantity` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_document_line`
--

LOCK TABLES `mm_document_line` WRITE;
/*!40000 ALTER TABLE `mm_document_line` DISABLE KEYS */;
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (1,1,2,1,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (2,1,3,2,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (3,1,4,3,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (4,1,5,4,2,100.00,NULL,NULL,100.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (5,1,6,5,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (6,1,7,6,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (7,1,8,7,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (8,1,9,8,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (9,1,10,9,2,200.00,NULL,NULL,200.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (10,1,11,10,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (11,1,12,11,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (12,1,13,12,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (13,2,2,13,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (14,2,3,14,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (15,2,4,15,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (16,2,5,16,2,100.00,NULL,NULL,100.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (17,2,6,17,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (18,2,7,18,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (19,2,8,19,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (20,2,9,20,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (21,2,10,21,2,200.00,NULL,NULL,200.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (22,2,11,22,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (23,2,12,23,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (24,2,13,24,2,50.00,NULL,NULL,50.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (25,3,2,13,2,40.00,NULL,NULL,40.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (26,4,2,13,2,40.00,NULL,NULL,40.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (27,5,16,25,4,40.00,NULL,NULL,40.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (28,6,16,25,4,60.00,NULL,NULL,60.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (29,7,16,25,4,40.00,NULL,NULL,40.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (30,8,16,25,4,60.00,NULL,NULL,60.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (31,9,16,25,4,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (33,11,2,26,2,20.00,NULL,10,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (34,12,2,26,2,5.00,NULL,NULL,5.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (37,15,4,27,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (38,15,5,28,2,20.00,NULL,NULL,20.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (39,15,6,29,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (40,15,7,30,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (41,16,4,27,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (42,16,5,28,2,20.00,NULL,NULL,20.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (43,16,6,29,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (44,16,7,30,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (45,17,3,32,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (46,17,8,33,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (47,17,9,34,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (48,17,10,35,2,40.00,NULL,NULL,40.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (49,18,2,26,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (50,18,3,32,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (51,18,8,33,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (52,18,9,34,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (53,18,10,35,2,40.00,NULL,NULL,40.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (54,19,11,37,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (55,19,12,38,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (56,19,13,39,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (57,20,11,37,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (58,20,12,38,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (59,20,13,39,2,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (60,21,14,31,4,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (61,21,15,36,4,10.00,NULL,NULL,10.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (62,22,3,41,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (63,22,4,42,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (64,22,5,43,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (65,22,6,44,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (66,22,7,45,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (67,22,8,46,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (68,22,9,47,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (69,22,10,48,2,4.00,NULL,NULL,4.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (70,22,11,49,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (71,22,12,50,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (72,22,13,51,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (73,23,2,26,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (74,23,3,41,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (75,23,4,42,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (76,23,5,43,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (77,23,6,44,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (78,23,7,45,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (79,23,8,46,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (80,23,9,47,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (81,23,10,48,2,4.00,NULL,NULL,4.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (82,23,11,49,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (83,23,12,50,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (84,23,13,51,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (85,24,3,53,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (86,24,4,54,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (87,24,5,55,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (88,24,6,56,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (89,24,7,57,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (90,24,8,58,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (91,24,9,59,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (92,24,10,60,2,4.00,NULL,NULL,4.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (93,24,11,61,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (94,24,12,62,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (95,24,13,63,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (96,25,2,26,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (97,25,3,53,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (98,25,4,54,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (99,25,5,55,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (100,25,6,56,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (101,25,7,57,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (102,25,8,58,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (103,25,9,59,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (104,25,10,60,2,4.00,NULL,NULL,4.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (105,25,11,61,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (106,25,12,62,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (107,25,13,63,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (108,26,16,52,4,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (109,26,16,64,4,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (110,27,2,65,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (111,28,2,65,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (112,29,3,66,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (113,29,4,67,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (114,29,5,68,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (115,29,6,69,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (116,29,7,70,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (117,29,8,71,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (118,29,9,72,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (119,29,10,73,2,4.00,NULL,NULL,4.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (120,29,11,74,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (121,29,12,75,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (122,29,13,76,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (123,30,2,26,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (124,30,3,66,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (125,30,4,67,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (126,30,5,68,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (127,30,6,69,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (128,30,7,70,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (129,30,8,71,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (130,30,9,72,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (131,30,10,73,2,4.00,NULL,NULL,4.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (132,30,11,74,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (133,30,12,75,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (134,30,13,76,2,1.00,NULL,NULL,1.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (135,31,3,78,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (136,31,4,79,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (137,31,5,80,2,4.00,NULL,NULL,4.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (138,31,6,81,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (139,31,7,82,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (140,31,8,83,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (141,31,9,84,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (142,31,10,85,2,8.00,NULL,NULL,8.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (143,31,11,86,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (144,31,12,87,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (145,31,13,88,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (146,32,2,26,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (147,32,3,78,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (148,32,4,79,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (149,32,5,80,2,4.00,NULL,NULL,4.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (150,32,6,81,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (151,32,7,82,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (152,32,8,83,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (153,32,9,84,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (154,32,10,85,2,8.00,NULL,NULL,8.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (155,32,11,86,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (156,32,12,87,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (157,32,13,88,2,2.00,NULL,NULL,2.000000);
INSERT INTO `mm_document_line` (`id`, `document_id`, `material_id`, `lot_id`, `location_id`, `quantity`, `source_line_id`, `input_unit_id`, `entered_quantity`) VALUES (158,33,2,65,2,1.00,NULL,NULL,1.000000);
/*!40000 ALTER TABLE `mm_document_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_guard`
--

DROP TABLE IF EXISTS `mm_guard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_guard` (
  `id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_guard`
--

LOCK TABLES `mm_guard` WRITE;
/*!40000 ALTER TABLE `mm_guard` DISABLE KEYS */;
INSERT INTO `mm_guard` (`id`) VALUES (1);
/*!40000 ALTER TABLE `mm_guard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_holiday`
--

DROP TABLE IF EXISTS `mm_holiday`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_holiday` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_date` date NOT NULL,
  `is_working` int NOT NULL,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `work_date` (`work_date`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_holiday`
--

LOCK TABLES `mm_holiday` WRITE;
/*!40000 ALTER TABLE `mm_holiday` DISABLE KEYS */;
INSERT INTO `mm_holiday` (`id`, `work_date`, `is_working`, `name`) VALUES (1,'2032-01-10',1,'隔离调休上班');
/*!40000 ALTER TABLE `mm_holiday` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_inspection`
--

DROP TABLE IF EXISTS `mm_inspection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_inspection` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(80) NOT NULL,
  `template_id` bigint NOT NULL,
  `kind` varchar(30) NOT NULL,
  `source_type` varchar(30) NOT NULL,
  `source_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  `qualified_quantity` int NOT NULL,
  `results` json NOT NULL,
  `status` varchar(30) NOT NULL,
  `actor_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_inspection`
--

LOCK TABLES `mm_inspection` WRITE;
/*!40000 ALTER TABLE `mm_inspection` DISABLE KEYS */;
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (1,'IPQC-000001',4,'PROCESS','TASK',2,100,0,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 20, \"result\": \"FAIL\"}]','BLOCKED',5,'2026-10-24 02:25:34');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (2,'IPQC-000002',4,'PROCESS','TASK',2,100,100,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:34');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (3,'IPQC-000003',5,'PROCESS','TASK',3,100,100,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:34');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (4,'IPQC-000004',6,'PROCESS','TASK',4,100,100,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:34');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (5,'IPQC-000005',7,'PROCESS','TASK',5,100,100,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:34');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (6,'IPQC-000006',9,'PROCESS','TASK',10,10,10,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:39');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (7,'IPQC-000007',8,'PROCESS','TASK',11,10,10,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:39');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (8,'IPQC-000008',4,'PROCESS','TASK',6,6,6,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:40');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (9,'IPQC-000009',4,'PROCESS','TASK',12,4,4,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:40');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (10,'IPQC-000010',5,'PROCESS','TASK',7,10,10,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:40');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (11,'IPQC-000011',6,'PROCESS','TASK',8,10,10,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:41');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (12,'IPQC-000012',7,'PROCESS','TASK',9,10,10,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:41');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (13,'IPQC-000013',4,'PROCESS','TASK',13,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:42');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (14,'IPQC-000014',5,'PROCESS','TASK',14,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:42');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (15,'IPQC-000015',6,'PROCESS','TASK',15,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:42');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (16,'IPQC-000016',7,'PROCESS','TASK',16,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:42');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (17,'IPQC-000017',4,'PROCESS','TASK',17,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:43');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (18,'IPQC-000018',5,'PROCESS','TASK',18,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:44');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (19,'IPQC-000019',6,'PROCESS','TASK',19,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:44');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (20,'IPQC-000020',7,'PROCESS','TASK',20,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:44');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (21,'IPQC-000021',10,'PROCESS','TASK',21,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:46');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (22,'IPQC-000022',4,'PROCESS','TASK',21,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:46');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (23,'IPQC-000023',5,'PROCESS','TASK',22,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:46');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (24,'IPQC-000024',6,'PROCESS','TASK',23,1,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:46');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (25,'IPQC-000025',7,'PROCESS','TASK',24,1,0,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 20, \"result\": \"FAIL\"}]','BLOCKED',5,'2026-10-24 02:25:47');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (26,'IPQC-000026',4,'PROCESS','TASK',29,2,1,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','BLOCKED',5,'2026-10-24 02:25:49');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (27,'IPQC-000027',4,'PROCESS','TASK',29,2,2,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:49');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (28,'IPQC-000028',5,'PROCESS','TASK',30,2,2,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:49');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (29,'IPQC-000029',6,'PROCESS','TASK',31,2,2,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:49');
INSERT INTO `mm_inspection` (`id`, `code`, `template_id`, `kind`, `source_type`, `source_id`, `quantity`, `qualified_quantity`, `results`, `status`, `actor_id`, `created_at`) VALUES (30,'IPQC-000030',7,'PROCESS','TASK',32,2,2,'[{\"item\": {\"id\": 5, \"code\": \"MC-QC-102528061580\", \"name\": \"数值检验\", \"standard\": \"0至10\", \"data_type\": \"NUMBER\", \"created_at\": \"2026-10-24 10:25:30\", \"lower_limit\": 0.0, \"upper_limit\": 10.0}, \"actual\": 5, \"result\": \"PASS\"}]','RELEASED',5,'2026-10-24 02:25:49');
/*!40000 ALTER TABLE `mm_inspection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_inventory_anchor`
--

DROP TABLE IF EXISTS `mm_inventory_anchor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_inventory_anchor` (
  `id` int NOT NULL,
  `captured_at` datetime(6) NOT NULL,
  `ledger_id` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_inventory_anchor`
--

LOCK TABLES `mm_inventory_anchor` WRITE;
/*!40000 ALTER TABLE `mm_inventory_anchor` DISABLE KEYS */;
INSERT INTO `mm_inventory_anchor` (`id`, `captured_at`, `ledger_id`) VALUES (1,'2026-10-23 23:22:35.041312',0);
/*!40000 ALTER TABLE `mm_inventory_anchor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_inventory_baseline`
--

DROP TABLE IF EXISTS `mm_inventory_baseline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_inventory_baseline` (
  `material_id` bigint NOT NULL,
  `warehouse_id` bigint NOT NULL,
  `quantity` decimal(18,2) NOT NULL,
  PRIMARY KEY (`material_id`,`warehouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_inventory_baseline`
--

LOCK TABLES `mm_inventory_baseline` WRITE;
/*!40000 ALTER TABLE `mm_inventory_baseline` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_inventory_baseline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_job_config`
--

DROP TABLE IF EXISTS `mm_job_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_job_config` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `enabled` int NOT NULL DEFAULT '1',
  `interval_seconds` int NOT NULL,
  `last_run` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_job_config`
--

LOCK TABLES `mm_job_config` WRITE;
/*!40000 ALTER TABLE `mm_job_config` DISABLE KEYS */;
INSERT INTO `mm_job_config` (`id`, `code`, `name`, `enabled`, `interval_seconds`, `last_run`) VALUES (1,'EQUIPMENT_CHECK','设备到期任务',1,60,'2026-10-24 10:25:45');
INSERT INTO `mm_job_config` (`id`, `code`, `name`, `enabled`, `interval_seconds`, `last_run`) VALUES (2,'REPORT_QC','报工质检事件',1,2,'2026-10-24 10:26:18');
/*!40000 ALTER TABLE `mm_job_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_job_run`
--

DROP TABLE IF EXISTS `mm_job_run`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_job_run` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(80) NOT NULL,
  `started_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `finished_at` datetime DEFAULT NULL,
  `status` varchar(20) NOT NULL,
  `error` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_job_run`
--

LOCK TABLES `mm_job_run` WRITE;
/*!40000 ALTER TABLE `mm_job_run` DISABLE KEYS */;
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (1,'EQUIPMENT_CHECK','2026-10-24 10:18:23','2026-10-24 10:18:23','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (2,'EQUIPMENT_CHECK','2026-10-24 10:19:23','2026-10-24 10:19:23','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (3,'EQUIPMENT_CHECK','2026-10-24 10:20:23','2026-10-24 10:20:23','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (4,'EQUIPMENT_CHECK','2026-10-24 10:21:23','2026-10-24 10:21:23','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (5,'EQUIPMENT_CHECK','2026-10-24 10:22:23','2026-10-24 10:22:23','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (6,'EQUIPMENT_CHECK','2026-10-24 10:23:23','2026-10-24 10:23:23','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (7,'EQUIPMENT_CHECK','2026-10-24 10:24:23','2026-10-24 10:24:23','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (8,'EQUIPMENT_CHECK','2026-10-24 10:25:36','2026-10-24 10:25:36','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (9,'EQUIPMENT_CHECK','2026-10-24 10:25:36','2026-10-24 10:25:36','SUCCEEDED',NULL);
INSERT INTO `mm_job_run` (`id`, `code`, `started_at`, `finished_at`, `status`, `error`) VALUES (10,'EQUIPMENT_CHECK','2026-10-24 10:25:45','2026-10-24 10:25:45','SUCCEEDED',NULL);
/*!40000 ALTER TABLE `mm_job_run` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_legacy_link`
--

DROP TABLE IF EXISTS `mm_legacy_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_legacy_link` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `source_type` varchar(40) NOT NULL,
  `source_id` bigint NOT NULL,
  `plan_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `source_type` (`source_type`,`source_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_legacy_link`
--

LOCK TABLES `mm_legacy_link` WRITE;
/*!40000 ALTER TABLE `mm_legacy_link` DISABLE KEYS */;
INSERT INTO `mm_legacy_link` (`id`, `source_type`, `source_id`, `plan_id`, `created_at`) VALUES (1,'ORDER',2,1,'2026-10-19 00:41:54');
INSERT INTO `mm_legacy_link` (`id`, `source_type`, `source_id`, `plan_id`, `created_at`) VALUES (2,'ORDER',1,2,'2026-10-19 00:41:54');
INSERT INTO `mm_legacy_link` (`id`, `source_type`, `source_id`, `plan_id`, `created_at`) VALUES (3,'ORDER',3,3,'2026-10-19 00:41:54');
INSERT INTO `mm_legacy_link` (`id`, `source_type`, `source_id`, `plan_id`, `created_at`) VALUES (4,'ORDER',4,7,'2026-10-19 00:41:54');
/*!40000 ALTER TABLE `mm_legacy_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_line_movement`
--

DROP TABLE IF EXISTS `mm_line_movement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_line_movement` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `lot_id` bigint NOT NULL,
  `quantity` decimal(18,6) NOT NULL,
  `kind` varchar(32) NOT NULL,
  `source_id` bigint NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_line_move` (`kind`,`source_id`,`material_id`,`lot_id`)
) ENGINE=InnoDB AUTO_INCREMENT=208 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_line_movement`
--

LOCK TABLES `mm_line_movement` WRITE;
/*!40000 ALTER TABLE `mm_line_movement` DISABLE KEYS */;
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (1,1,2,1,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (2,1,2,13,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (3,1,3,2,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (4,1,3,14,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (5,1,4,3,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (6,1,4,15,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (7,1,5,4,100.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (8,1,5,16,100.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (9,1,6,5,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (10,1,6,17,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (11,1,7,6,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (12,1,7,18,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (13,1,8,7,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (14,1,8,19,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (15,1,9,8,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (16,1,9,20,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (17,1,10,9,200.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (18,1,10,21,200.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (19,1,11,10,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (20,1,11,22,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (21,1,12,11,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (22,1,12,23,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (23,1,13,12,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (24,1,13,24,50.000000,'ISSUE',1,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (25,1,2,1,-50.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (26,1,2,13,-10.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (27,1,3,2,-50.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (28,1,3,14,-10.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (29,1,4,3,-50.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (30,1,4,15,-10.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (31,1,5,4,-100.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (32,1,5,16,-20.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (33,1,6,5,-50.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (34,1,6,17,-10.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (35,1,7,6,-50.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (36,1,7,18,-10.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (37,1,8,7,-50.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (38,1,8,19,-10.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (39,1,9,8,-50.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (40,1,9,20,-10.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (41,1,10,9,-200.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (42,1,10,21,-40.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (43,1,11,10,-50.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (44,1,11,22,-10.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (45,1,12,11,-50.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (46,1,12,23,-10.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (47,1,13,12,-50.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (48,1,13,24,-10.000000,'CONSUME',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (49,1,2,13,-40.000000,'LINE_RETURN',3,'2026-10-24 10:25:33');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (50,1,2,13,40.000000,'LINE_ISSUE',4,'2026-10-24 10:25:34');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (51,1,2,13,-40.000000,'CONSUME',4,'2026-10-24 10:25:34');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (52,1,3,14,-40.000000,'CONSUME',4,'2026-10-24 10:25:34');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (53,1,4,15,-40.000000,'CONSUME',4,'2026-10-24 10:25:34');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (54,1,5,16,-80.000000,'CONSUME',4,'2026-10-24 10:25:34');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (55,1,6,17,-40.000000,'CONSUME',4,'2026-10-24 10:25:34');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (56,1,7,18,-40.000000,'CONSUME',4,'2026-10-24 10:25:34');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (57,1,8,19,-40.000000,'CONSUME',4,'2026-10-24 10:25:34');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (58,1,9,20,-40.000000,'CONSUME',4,'2026-10-24 10:25:34');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (59,1,10,21,-160.000000,'CONSUME',4,'2026-10-24 10:25:34');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (60,1,11,22,-40.000000,'CONSUME',4,'2026-10-24 10:25:34');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (61,1,12,23,-40.000000,'CONSUME',4,'2026-10-24 10:25:34');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (62,1,13,24,-40.000000,'CONSUME',4,'2026-10-24 10:25:34');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (63,1,16,25,100.000000,'OUTPUT',7,'2026-10-24 10:25:34');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (64,1,16,25,-40.000000,'PRODUCTION_RECEIPT',5,'2026-10-24 10:25:35');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (65,1,16,25,-60.000000,'PRODUCTION_RECEIPT',6,'2026-10-24 10:25:35');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (66,3,4,27,10.000000,'LINE_ISSUE',16,'2026-10-24 10:25:38');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (67,3,5,28,20.000000,'LINE_ISSUE',16,'2026-10-24 10:25:38');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (68,3,6,29,10.000000,'LINE_ISSUE',16,'2026-10-24 10:25:38');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (69,3,7,30,10.000000,'LINE_ISSUE',16,'2026-10-24 10:25:38');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (70,3,4,27,-10.000000,'CONSUME',8,'2026-10-24 10:25:39');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (71,3,5,28,-20.000000,'CONSUME',8,'2026-10-24 10:25:39');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (72,3,6,29,-10.000000,'CONSUME',8,'2026-10-24 10:25:39');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (73,3,7,30,-10.000000,'CONSUME',8,'2026-10-24 10:25:39');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (74,3,14,31,10.000000,'OUTPUT',8,'2026-10-24 10:25:39');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (75,3,14,31,-10.000000,'RECEIPT',9,'2026-10-24 10:25:39');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (76,4,2,26,10.000000,'LINE_ISSUE',18,'2026-10-24 10:25:39');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (77,4,3,32,10.000000,'LINE_ISSUE',18,'2026-10-24 10:25:39');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (78,4,8,33,10.000000,'LINE_ISSUE',18,'2026-10-24 10:25:39');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (79,4,9,34,10.000000,'LINE_ISSUE',18,'2026-10-24 10:25:39');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (80,4,10,35,40.000000,'LINE_ISSUE',18,'2026-10-24 10:25:39');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (81,4,2,26,-10.000000,'CONSUME',9,'2026-10-24 10:25:39');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (82,4,3,32,-10.000000,'CONSUME',9,'2026-10-24 10:25:39');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (83,4,8,33,-10.000000,'CONSUME',9,'2026-10-24 10:25:39');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (84,4,9,34,-10.000000,'CONSUME',9,'2026-10-24 10:25:39');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (85,4,10,35,-40.000000,'CONSUME',9,'2026-10-24 10:25:39');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (86,4,15,36,10.000000,'OUTPUT',9,'2026-10-24 10:25:39');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (87,4,15,36,-10.000000,'RECEIPT',11,'2026-10-24 10:25:39');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (88,2,11,37,10.000000,'LINE_ISSUE',20,'2026-10-24 10:25:40');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (89,2,12,38,10.000000,'LINE_ISSUE',20,'2026-10-24 10:25:40');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (90,2,13,39,10.000000,'LINE_ISSUE',20,'2026-10-24 10:25:40');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (91,2,14,31,10.000000,'LINE_ISSUE',21,'2026-10-24 10:25:40');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (92,2,15,36,10.000000,'LINE_ISSUE',21,'2026-10-24 10:25:40');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (93,2,11,37,-6.000000,'CONSUME',10,'2026-10-24 10:25:40');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (94,2,12,38,-6.000000,'CONSUME',10,'2026-10-24 10:25:40');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (95,2,13,39,-6.000000,'CONSUME',10,'2026-10-24 10:25:40');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (96,2,14,31,-6.000000,'CONSUME',10,'2026-10-24 10:25:40');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (97,2,15,36,-6.000000,'CONSUME',10,'2026-10-24 10:25:40');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (98,2,11,37,-4.000000,'CONSUME',11,'2026-10-24 10:25:40');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (99,2,12,38,-4.000000,'CONSUME',11,'2026-10-24 10:25:40');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (100,2,13,39,-4.000000,'CONSUME',11,'2026-10-24 10:25:40');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (101,2,14,31,-4.000000,'CONSUME',11,'2026-10-24 10:25:40');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (102,2,15,36,-4.000000,'CONSUME',11,'2026-10-24 10:25:40');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (103,2,16,40,10.000000,'OUTPUT',14,'2026-10-24 10:25:41');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (104,2,16,40,-10.000000,'RECEIPT',13,'2026-10-24 10:25:41');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (105,5,2,26,1.000000,'LINE_ISSUE',23,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (106,5,3,41,1.000000,'LINE_ISSUE',23,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (107,5,4,42,1.000000,'LINE_ISSUE',23,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (108,5,5,43,2.000000,'LINE_ISSUE',23,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (109,5,6,44,1.000000,'LINE_ISSUE',23,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (110,5,7,45,1.000000,'LINE_ISSUE',23,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (111,5,8,46,1.000000,'LINE_ISSUE',23,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (112,5,9,47,1.000000,'LINE_ISSUE',23,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (113,5,10,48,4.000000,'LINE_ISSUE',23,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (114,5,11,49,1.000000,'LINE_ISSUE',23,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (115,5,12,50,1.000000,'LINE_ISSUE',23,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (116,5,13,51,1.000000,'LINE_ISSUE',23,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (117,5,2,26,-1.000000,'CONSUME',15,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (118,5,3,41,-1.000000,'CONSUME',15,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (119,5,4,42,-1.000000,'CONSUME',15,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (120,5,5,43,-2.000000,'CONSUME',15,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (121,5,6,44,-1.000000,'CONSUME',15,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (122,5,7,45,-1.000000,'CONSUME',15,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (123,5,8,46,-1.000000,'CONSUME',15,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (124,5,9,47,-1.000000,'CONSUME',15,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (125,5,10,48,-4.000000,'CONSUME',15,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (126,5,11,49,-1.000000,'CONSUME',15,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (127,5,12,50,-1.000000,'CONSUME',15,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (128,5,13,51,-1.000000,'CONSUME',15,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (129,5,16,52,1.000000,'OUTPUT',18,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (130,5,16,52,-1.000000,'RECEIPT',15,'2026-10-24 10:25:42');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (131,6,2,26,1.000000,'LINE_ISSUE',25,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (132,6,3,53,1.000000,'LINE_ISSUE',25,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (133,6,4,54,1.000000,'LINE_ISSUE',25,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (134,6,5,55,2.000000,'LINE_ISSUE',25,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (135,6,6,56,1.000000,'LINE_ISSUE',25,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (136,6,7,57,1.000000,'LINE_ISSUE',25,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (137,6,8,58,1.000000,'LINE_ISSUE',25,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (138,6,9,59,1.000000,'LINE_ISSUE',25,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (139,6,10,60,4.000000,'LINE_ISSUE',25,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (140,6,11,61,1.000000,'LINE_ISSUE',25,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (141,6,12,62,1.000000,'LINE_ISSUE',25,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (142,6,13,63,1.000000,'LINE_ISSUE',25,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (143,6,2,26,-1.000000,'CONSUME',19,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (144,6,3,53,-1.000000,'CONSUME',19,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (145,6,4,54,-1.000000,'CONSUME',19,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (146,6,5,55,-2.000000,'CONSUME',19,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (147,6,6,56,-1.000000,'CONSUME',19,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (148,6,7,57,-1.000000,'CONSUME',19,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (149,6,8,58,-1.000000,'CONSUME',19,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (150,6,9,59,-1.000000,'CONSUME',19,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (151,6,10,60,-4.000000,'CONSUME',19,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (152,6,11,61,-1.000000,'CONSUME',19,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (153,6,12,62,-1.000000,'CONSUME',19,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (154,6,13,63,-1.000000,'CONSUME',19,'2026-10-24 10:25:43');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (155,6,16,64,1.000000,'OUTPUT',22,'2026-10-24 10:25:44');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (156,6,16,64,-1.000000,'RECEIPT',17,'2026-10-24 10:25:44');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (157,7,2,26,1.000000,'LINE_ISSUE',30,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (158,7,3,66,1.000000,'LINE_ISSUE',30,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (159,7,4,67,1.000000,'LINE_ISSUE',30,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (160,7,5,68,2.000000,'LINE_ISSUE',30,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (161,7,6,69,1.000000,'LINE_ISSUE',30,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (162,7,7,70,1.000000,'LINE_ISSUE',30,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (163,7,8,71,1.000000,'LINE_ISSUE',30,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (164,7,9,72,1.000000,'LINE_ISSUE',30,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (165,7,10,73,4.000000,'LINE_ISSUE',30,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (166,7,11,74,1.000000,'LINE_ISSUE',30,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (167,7,12,75,1.000000,'LINE_ISSUE',30,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (168,7,13,76,1.000000,'LINE_ISSUE',30,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (169,7,2,26,-1.000000,'CONSUME',23,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (170,7,3,66,-1.000000,'CONSUME',23,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (171,7,4,67,-1.000000,'CONSUME',23,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (172,7,5,68,-2.000000,'CONSUME',23,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (173,7,6,69,-1.000000,'CONSUME',23,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (174,7,7,70,-1.000000,'CONSUME',23,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (175,7,8,71,-1.000000,'CONSUME',23,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (176,7,9,72,-1.000000,'CONSUME',23,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (177,7,10,73,-4.000000,'CONSUME',23,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (178,7,11,74,-1.000000,'CONSUME',23,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (179,7,12,75,-1.000000,'CONSUME',23,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (180,7,13,76,-1.000000,'CONSUME',23,'2026-10-24 10:25:46');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (181,7,16,77,1.000000,'OUTPUT',26,'2026-10-24 10:25:47');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (182,7,16,77,-1.000000,'SCRAP',2,'2026-10-24 10:25:47');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (183,9,2,26,2.000000,'LINE_ISSUE',32,'2026-10-24 10:25:48');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (184,9,3,78,2.000000,'LINE_ISSUE',32,'2026-10-24 10:25:48');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (185,9,4,79,2.000000,'LINE_ISSUE',32,'2026-10-24 10:25:48');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (186,9,5,80,4.000000,'LINE_ISSUE',32,'2026-10-24 10:25:48');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (187,9,6,81,2.000000,'LINE_ISSUE',32,'2026-10-24 10:25:48');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (188,9,7,82,2.000000,'LINE_ISSUE',32,'2026-10-24 10:25:48');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (189,9,8,83,2.000000,'LINE_ISSUE',32,'2026-10-24 10:25:48');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (190,9,9,84,2.000000,'LINE_ISSUE',32,'2026-10-24 10:25:48');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (191,9,10,85,8.000000,'LINE_ISSUE',32,'2026-10-24 10:25:48');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (192,9,11,86,2.000000,'LINE_ISSUE',32,'2026-10-24 10:25:48');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (193,9,12,87,2.000000,'LINE_ISSUE',32,'2026-10-24 10:25:48');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (194,9,13,88,2.000000,'LINE_ISSUE',32,'2026-10-24 10:25:48');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (195,9,2,26,-2.000000,'CONSUME',27,'2026-10-24 10:25:48');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (196,9,3,78,-2.000000,'CONSUME',27,'2026-10-24 10:25:48');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (197,9,4,79,-2.000000,'CONSUME',27,'2026-10-24 10:25:49');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (198,9,5,80,-4.000000,'CONSUME',27,'2026-10-24 10:25:49');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (199,9,6,81,-2.000000,'CONSUME',27,'2026-10-24 10:25:49');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (200,9,7,82,-2.000000,'CONSUME',27,'2026-10-24 10:25:49');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (201,9,8,83,-2.000000,'CONSUME',27,'2026-10-24 10:25:49');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (202,9,9,84,-2.000000,'CONSUME',27,'2026-10-24 10:25:49');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (203,9,10,85,-8.000000,'CONSUME',27,'2026-10-24 10:25:49');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (204,9,11,86,-2.000000,'CONSUME',27,'2026-10-24 10:25:49');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (205,9,12,87,-2.000000,'CONSUME',27,'2026-10-24 10:25:49');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (206,9,13,88,-2.000000,'CONSUME',27,'2026-10-24 10:25:49');
INSERT INTO `mm_line_movement` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`, `kind`, `source_id`, `created_at`) VALUES (207,9,16,89,2.000000,'OUTPUT',30,'2026-10-24 10:25:49');
/*!40000 ALTER TABLE `mm_line_movement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_line_stock`
--

DROP TABLE IF EXISTS `mm_line_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_line_stock` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `lot_id` bigint NOT NULL,
  `quantity` decimal(18,6) NOT NULL DEFAULT '0.000000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_line` (`work_order_id`,`material_id`,`lot_id`),
  CONSTRAINT `mm_line_stock_chk_1` CHECK ((`quantity` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_line_stock`
--

LOCK TABLES `mm_line_stock` WRITE;
/*!40000 ALTER TABLE `mm_line_stock` DISABLE KEYS */;
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (1,1,2,1,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (2,1,2,13,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (3,1,3,2,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (4,1,3,14,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (5,1,4,3,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (6,1,4,15,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (7,1,5,4,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (8,1,5,16,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (9,1,6,5,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (10,1,6,17,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (11,1,7,6,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (12,1,7,18,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (13,1,8,7,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (14,1,8,19,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (15,1,9,8,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (16,1,9,20,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (17,1,10,9,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (18,1,10,21,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (19,1,11,10,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (20,1,11,22,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (21,1,12,11,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (22,1,12,23,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (23,1,13,12,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (24,1,13,24,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (26,1,16,25,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (27,3,4,27,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (28,3,5,28,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (29,3,6,29,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (30,3,7,30,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (31,3,14,31,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (32,4,2,26,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (33,4,3,32,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (34,4,8,33,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (35,4,9,34,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (36,4,10,35,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (37,4,15,36,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (38,2,11,37,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (39,2,12,38,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (40,2,13,39,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (41,2,14,31,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (42,2,15,36,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (43,2,16,40,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (44,5,2,26,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (45,5,3,41,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (46,5,4,42,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (47,5,5,43,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (48,5,6,44,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (49,5,7,45,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (50,5,8,46,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (51,5,9,47,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (52,5,10,48,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (53,5,11,49,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (54,5,12,50,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (55,5,13,51,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (56,5,16,52,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (57,6,2,26,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (58,6,3,53,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (59,6,4,54,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (60,6,5,55,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (61,6,6,56,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (62,6,7,57,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (63,6,8,58,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (64,6,9,59,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (65,6,10,60,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (66,6,11,61,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (67,6,12,62,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (68,6,13,63,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (69,6,16,64,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (70,7,2,26,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (71,7,3,66,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (72,7,4,67,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (73,7,5,68,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (74,7,6,69,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (75,7,7,70,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (76,7,8,71,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (77,7,9,72,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (78,7,10,73,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (79,7,11,74,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (80,7,12,75,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (81,7,13,76,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (82,7,16,77,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (83,9,2,26,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (84,9,3,78,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (85,9,4,79,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (86,9,5,80,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (87,9,6,81,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (88,9,7,82,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (89,9,8,83,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (90,9,9,84,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (91,9,10,85,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (92,9,11,86,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (93,9,12,87,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (94,9,13,88,0.000000);
INSERT INTO `mm_line_stock` (`id`, `work_order_id`, `material_id`, `lot_id`, `quantity`) VALUES (95,9,16,89,2.000000);
/*!40000 ALTER TABLE `mm_line_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_location`
--

DROP TABLE IF EXISTS `mm_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_location` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `area_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `x_coordinate` int DEFAULT NULL,
  `y_coordinate` int DEFAULT NULL,
  `z_coordinate` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_location`
--

LOCK TABLES `mm_location` WRITE;
/*!40000 ALTER TABLE `mm_location` DISABLE KEYS */;
INSERT INTO `mm_location` (`id`, `code`, `name`, `area_id`, `created_at`, `x_coordinate`, `y_coordinate`, `z_coordinate`) VALUES (1,'WH-A100-RM-01','一号库位',1,'2026-10-19 00:41:54',NULL,NULL,NULL);
INSERT INTO `mm_location` (`id`, `code`, `name`, `area_id`, `created_at`, `x_coordinate`, `y_coordinate`, `z_coordinate`) VALUES (2,'WH-A100-LINE-01','一号库位',2,'2026-10-19 00:41:54',NULL,NULL,NULL);
INSERT INTO `mm_location` (`id`, `code`, `name`, `area_id`, `created_at`, `x_coordinate`, `y_coordinate`, `z_coordinate`) VALUES (3,'WH-A100-FG-01','一号库位',3,'2026-10-19 00:41:54',NULL,NULL,NULL);
/*!40000 ALTER TABLE `mm_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_member`
--

DROP TABLE IF EXISTS `mm_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_member` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `team_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `team_id` (`team_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_member`
--

LOCK TABLES `mm_member` WRITE;
/*!40000 ALTER TABLE `mm_member` DISABLE KEYS */;
INSERT INTO `mm_member` (`id`, `team_id`, `user_id`, `created_at`) VALUES (1,1,1,'2026-10-19 00:41:54');
INSERT INTO `mm_member` (`id`, `team_id`, `user_id`, `created_at`) VALUES (2,2,4,'2026-10-24 02:25:30');
INSERT INTO `mm_member` (`id`, `team_id`, `user_id`, `created_at`) VALUES (3,3,12,'2026-10-24 02:25:37');
/*!40000 ALTER TABLE `mm_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_menu`
--

DROP TABLE IF EXISTS `mm_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_menu` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `path` varchar(200) NOT NULL,
  `parent_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_menu`
--

LOCK TABLES `mm_menu` WRITE;
/*!40000 ALTER TABLE `mm_menu` DISABLE KEYS */;
INSERT INTO `mm_menu` (`id`, `code`, `name`, `path`, `parent_id`) VALUES (1,'MC-MENU-102528061580','运营中心验收','/mes',NULL);
/*!40000 ALTER TABLE `mm_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_nc`
--

DROP TABLE IF EXISTS `mm_nc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_nc` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `inspection_id` bigint NOT NULL,
  `task_id` bigint DEFAULT NULL,
  `defect_id` bigint DEFAULT NULL,
  `quantity` decimal(18,2) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'OPEN',
  `decision` varchar(20) DEFAULT NULL,
  `reason` varchar(500) DEFAULT NULL,
  `approved_by` bigint DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inspection_id` (`inspection_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_nc`
--

LOCK TABLES `mm_nc` WRITE;
/*!40000 ALTER TABLE `mm_nc` DISABLE KEYS */;
INSERT INTO `mm_nc` (`id`, `inspection_id`, `task_id`, `defect_id`, `quantity`, `status`, `decision`, `reason`, `approved_by`, `created_at`) VALUES (1,1,2,NULL,100.00,'CLOSED','REWORK','重新校准后返工',5,'2026-10-24 10:25:34');
INSERT INTO `mm_nc` (`id`, `inspection_id`, `task_id`, `defect_id`, `quantity`, `status`, `decision`, `reason`, `approved_by`, `created_at`) VALUES (2,25,24,NULL,1.00,'CLOSED','SCRAP','隔离验收：整批报废',5,'2026-10-24 10:25:47');
INSERT INTO `mm_nc` (`id`, `inspection_id`, `task_id`, `defect_id`, `quantity`, `status`, `decision`, `reason`, `approved_by`, `created_at`) VALUES (3,26,29,NULL,1.00,'CLOSED','REWORK','返工已申报的不良品',5,'2026-10-24 10:25:49');
/*!40000 ALTER TABLE `mm_nc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_notice`
--

DROP TABLE IF EXISTS `mm_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_notice` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `kind` varchar(20) NOT NULL,
  `target_role` bigint DEFAULT NULL,
  `published_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` datetime DEFAULT NULL,
  `actor_id` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_notice`
--

LOCK TABLES `mm_notice` WRITE;
/*!40000 ALTER TABLE `mm_notice` DISABLE KEYS */;
INSERT INTO `mm_notice` (`id`, `title`, `content`, `kind`, `target_role`, `published_at`, `expires_at`, `actor_id`) VALUES (1,'隔离公告102528061580','真实持久化公告','info',3,'2026-10-24 10:25:36',NULL,1);
INSERT INTO `mm_notice` (`id`, `title`, `content`, `kind`, `target_role`, `published_at`, `expires_at`, `actor_id`) VALUES (2,'限量公告一102528061580','真实公告','info',NULL,'2026-10-24 10:25:45',NULL,1);
INSERT INTO `mm_notice` (`id`, `title`, `content`, `kind`, `target_role`, `published_at`, `expires_at`, `actor_id`) VALUES (3,'限量公告二102528061580','真实公告','info',NULL,'2026-10-24 10:25:45',NULL,1);
/*!40000 ALTER TABLE `mm_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_notice_read`
--

DROP TABLE IF EXISTS `mm_notice_read`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_notice_read` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `notice_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `read_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_read` (`notice_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_notice_read`
--

LOCK TABLES `mm_notice_read` WRITE;
/*!40000 ALTER TABLE `mm_notice_read` DISABLE KEYS */;
INSERT INTO `mm_notice_read` (`id`, `notice_id`, `user_id`, `read_at`) VALUES (1,1,4,'2026-10-24 10:25:36');
/*!40000 ALTER TABLE `mm_notice_read` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_operation`
--

DROP TABLE IF EXISTS `mm_operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_operation` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `route_id` bigint NOT NULL,
  `sequence_no` int NOT NULL,
  `station_id` bigint NOT NULL,
  `predecessor_id` bigint DEFAULT NULL,
  `standard_minutes` decimal(10,2) NOT NULL,
  `requires_qc` int NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_key` int NOT NULL DEFAULT '0',
  `output_material_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `route_id` (`route_id`,`sequence_no`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_operation`
--

LOCK TABLES `mm_operation` WRITE;
/*!40000 ALTER TABLE `mm_operation` DISABLE KEYS */;
INSERT INTO `mm_operation` (`id`, `code`, `name`, `route_id`, `sequence_no`, `station_id`, `predecessor_id`, `standard_minutes`, `requires_qc`, `created_at`, `is_key`, `output_material_id`) VALUES (1,'OP-A100-1','电子装配站',1,10,5,NULL,2.00,1,'2026-10-19 00:41:54',0,NULL);
INSERT INTO `mm_operation` (`id`, `code`, `name`, `route_id`, `sequence_no`, `station_id`, `predecessor_id`, `standard_minutes`, `requires_qc`, `created_at`, `is_key`, `output_material_id`) VALUES (2,'OP-A100-2','结构装配站',1,20,5,NULL,2.00,1,'2026-10-19 00:41:54',0,NULL);
INSERT INTO `mm_operation` (`id`, `code`, `name`, `route_id`, `sequence_no`, `station_id`, `predecessor_id`, `standard_minutes`, `requires_qc`, `created_at`, `is_key`, `output_material_id`) VALUES (3,'OP-A100-3','总装测试站',1,30,5,2,2.00,1,'2026-10-19 00:41:54',0,NULL);
INSERT INTO `mm_operation` (`id`, `code`, `name`, `route_id`, `sequence_no`, `station_id`, `predecessor_id`, `standard_minutes`, `requires_qc`, `created_at`, `is_key`, `output_material_id`) VALUES (4,'OP-A100-4','贴标包装站',1,40,5,3,2.00,1,'2026-10-19 00:41:54',1,NULL);
INSERT INTO `mm_operation` (`id`, `code`, `name`, `route_id`, `sequence_no`, `station_id`, `predecessor_id`, `standard_minutes`, `requires_qc`, `created_at`, `is_key`, `output_material_id`) VALUES (5,'MC-SO-15-102528061580','半成品制造',2,10,5,NULL,1.00,1,'2026-10-24 02:25:37',1,NULL);
INSERT INTO `mm_operation` (`id`, `code`, `name`, `route_id`, `sequence_no`, `station_id`, `predecessor_id`, `standard_minutes`, `requires_qc`, `created_at`, `is_key`, `output_material_id`) VALUES (6,'MC-SO-14-102528061580','半成品制造',3,10,5,NULL,1.00,1,'2026-10-24 02:25:38',1,NULL);
/*!40000 ALTER TABLE `mm_operation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_package`
--

DROP TABLE IF EXISTS `mm_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_package` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(80) NOT NULL,
  `customer_id` bigint DEFAULT NULL,
  `order_id` bigint DEFAULT NULL,
  `length_mm` decimal(18,2) NOT NULL,
  `width_mm` decimal(18,2) NOT NULL,
  `height_mm` decimal(18,2) NOT NULL,
  `net_weight` decimal(18,2) NOT NULL,
  `gross_weight` decimal(18,2) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'DRAFT',
  `parent_id` bigint DEFAULT NULL,
  `created_by` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_package`
--

LOCK TABLES `mm_package` WRITE;
/*!40000 ALTER TABLE `mm_package` DISABLE KEYS */;
INSERT INTO `mm_package` (`id`, `code`, `customer_id`, `order_id`, `length_mm`, `width_mm`, `height_mm`, `net_weight`, `gross_weight`, `status`, `parent_id`, `created_by`) VALUES (1,'PKG-000001',NULL,NULL,100.00,100.00,100.00,1.00,2.00,'CONFIRMED',2,6);
INSERT INTO `mm_package` (`id`, `code`, `customer_id`, `order_id`, `length_mm`, `width_mm`, `height_mm`, `net_weight`, `gross_weight`, `status`, `parent_id`, `created_by`) VALUES (2,'PKG-000002',NULL,NULL,100.00,100.00,100.00,1.00,2.00,'CONFIRMED',NULL,6);
INSERT INTO `mm_package` (`id`, `code`, `customer_id`, `order_id`, `length_mm`, `width_mm`, `height_mm`, `net_weight`, `gross_weight`, `status`, `parent_id`, `created_by`) VALUES (3,'PKG-000003',NULL,NULL,100.00,100.00,100.00,1.00,2.00,'DRAFT',NULL,6);
/*!40000 ALTER TABLE `mm_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_package_item`
--

DROP TABLE IF EXISTS `mm_package_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_package_item` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `package_id` bigint NOT NULL,
  `inventory_id` bigint NOT NULL,
  `quantity` decimal(18,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_package_item` (`package_id`,`inventory_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_package_item`
--

LOCK TABLES `mm_package_item` WRITE;
/*!40000 ALTER TABLE `mm_package_item` DISABLE KEYS */;
INSERT INTO `mm_package_item` (`id`, `package_id`, `inventory_id`, `quantity`) VALUES (1,1,50,4.00);
INSERT INTO `mm_package_item` (`id`, `package_id`, `inventory_id`, `quantity`) VALUES (2,3,50,7.00);
/*!40000 ALTER TABLE `mm_package_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_parameter`
--

DROP TABLE IF EXISTS `mm_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_parameter` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_parameter`
--

LOCK TABLES `mm_parameter` WRITE;
/*!40000 ALTER TABLE `mm_parameter` DISABLE KEYS */;
INSERT INTO `mm_parameter` (`id`, `code`, `name`, `value`) VALUES (1,'APP_NAME','系统显示名称','Mouse MES');
INSERT INTO `mm_parameter` (`id`, `code`, `name`, `value`) VALUES (2,'NOTICE_LIMIT','公告最多显示条数','200');
INSERT INTO `mm_parameter` (`id`, `code`, `name`, `value`) VALUES (3,'DEFAULT_DURATION_MINUTES','默认任务时长（分钟）','60');
/*!40000 ALTER TABLE `mm_parameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_position`
--

DROP TABLE IF EXISTS `mm_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_position` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `department_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_position`
--

LOCK TABLES `mm_position` WRITE;
/*!40000 ALTER TABLE `mm_position` DISABLE KEYS */;
INSERT INTO `mm_position` (`id`, `code`, `name`, `department_id`) VALUES (1,'MC-POS-102528061580','隔离操作岗位',1);
/*!40000 ALTER TABLE `mm_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_product_material`
--

DROP TABLE IF EXISTS `mm_product_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_product_material` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`),
  UNIQUE KEY `material_id` (`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_product_material`
--

LOCK TABLES `mm_product_material` WRITE;
/*!40000 ALTER TABLE `mm_product_material` DISABLE KEYS */;
INSERT INTO `mm_product_material` (`id`, `product_id`, `material_id`, `created_at`) VALUES (1,6,16,'2026-10-19 00:41:54');
INSERT INTO `mm_product_material` (`id`, `product_id`, `material_id`, `created_at`) VALUES (2,7,15,'2026-10-24 02:25:37');
INSERT INTO `mm_product_material` (`id`, `product_id`, `material_id`, `created_at`) VALUES (3,8,14,'2026-10-24 02:25:37');
INSERT INTO `mm_product_material` (`id`, `product_id`, `material_id`, `created_at`) VALUES (4,9,18,'2026-10-24 02:25:47');
/*!40000 ALTER TABLE `mm_product_material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_qc_item`
--

DROP TABLE IF EXISTS `mm_qc_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_qc_item` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `standard` varchar(500) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_type` varchar(20) NOT NULL DEFAULT 'TEXT',
  `lower_limit` decimal(18,6) DEFAULT NULL,
  `upper_limit` decimal(18,6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_qc_item`
--

LOCK TABLES `mm_qc_item` WRITE;
/*!40000 ALTER TABLE `mm_qc_item` DISABLE KEYS */;
INSERT INTO `mm_qc_item` (`id`, `code`, `name`, `standard`, `created_at`, `data_type`, `lower_limit`, `upper_limit`) VALUES (1,'QC-VISUAL','外观装配','零件完整、无明显裂纹','2026-10-19 00:41:54','TEXT',NULL,NULL);
INSERT INTO `mm_qc_item` (`id`, `code`, `name`, `standard`, `created_at`, `data_type`, `lower_limit`, `upper_limit`) VALUES (2,'QC-USB','USB识别','连接后可识别输入设备','2026-10-19 00:41:54','TEXT',NULL,NULL);
INSERT INTO `mm_qc_item` (`id`, `code`, `name`, `standard`, `created_at`, `data_type`, `lower_limit`, `upper_limit`) VALUES (3,'QC-KEY','按键滚轮','左右键与滚轮均有响应','2026-10-19 00:41:54','TEXT',NULL,NULL);
INSERT INTO `mm_qc_item` (`id`, `code`, `name`, `standard`, `created_at`, `data_type`, `lower_limit`, `upper_limit`) VALUES (4,'QC-MOVE','指针移动','测试面移动可产生指针响应','2026-10-19 00:41:54','TEXT',NULL,NULL);
INSERT INTO `mm_qc_item` (`id`, `code`, `name`, `standard`, `created_at`, `data_type`, `lower_limit`, `upper_limit`) VALUES (5,'MC-QC-102528061580','数值检验','0至10','2026-10-24 02:25:30','NUMBER',0.000000,10.000000);
/*!40000 ALTER TABLE `mm_qc_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_qc_line`
--

DROP TABLE IF EXISTS `mm_qc_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_qc_line` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `template_id` bigint NOT NULL,
  `item_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_id` (`template_id`,`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_qc_line`
--

LOCK TABLES `mm_qc_line` WRITE;
/*!40000 ALTER TABLE `mm_qc_line` DISABLE KEYS */;
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (1,3,3,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (2,2,3,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (3,1,3,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (4,3,4,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (5,2,4,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (6,1,4,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (7,3,2,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (8,2,2,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (9,1,2,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (10,3,1,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (11,2,1,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (12,1,1,'2026-10-19 00:41:54');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (13,4,5,'2026-10-24 02:25:30');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (14,5,5,'2026-10-24 02:25:30');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (15,6,5,'2026-10-24 02:25:30');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (16,7,5,'2026-10-24 02:25:30');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (17,8,5,'2026-10-24 02:25:37');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (18,9,5,'2026-10-24 02:25:38');
INSERT INTO `mm_qc_line` (`id`, `template_id`, `item_id`, `created_at`) VALUES (19,10,5,'2026-10-24 02:25:46');
/*!40000 ALTER TABLE `mm_qc_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_qc_template`
--

DROP TABLE IF EXISTS `mm_qc_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_qc_template` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `product_id` bigint NOT NULL,
  `kind` varchar(30) NOT NULL,
  `version` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operation_id` bigint DEFAULT NULL,
  `phase` varchar(20) NOT NULL DEFAULT 'FINAL',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_qc_template`
--

LOCK TABLES `mm_qc_template` WRITE;
/*!40000 ALTER TABLE `mm_qc_template` DISABLE KEYS */;
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (1,'QC-A100-INCOMING','A100来料检测模板',6,'INCOMING','1.0','2026-10-19 00:41:54',NULL,'FINAL');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (2,'QC-A100-PROCESS','A100过程检测模板',6,'PROCESS','1.0','2026-10-19 00:41:54',NULL,'FINAL');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (3,'QC-A100-SHIPPING','A100出货检测模板',6,'SHIPPING','1.0','2026-10-19 00:41:54',NULL,'FINAL');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (4,'MC-T-102528061580-1','电子装配站专用检验',6,'PROCESS','1','2026-10-24 02:25:30',1,'FINAL');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (5,'MC-T-102528061580-2','结构装配站专用检验',6,'PROCESS','1','2026-10-24 02:25:30',2,'FINAL');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (6,'MC-T-102528061580-3','总装测试站专用检验',6,'PROCESS','1','2026-10-24 02:25:30',3,'FINAL');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (7,'MC-T-102528061580-4','贴标包装站专用检验',6,'PROCESS','1','2026-10-24 02:25:30',4,'FINAL');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (8,'MC-SQ-15-102528061580','半成品最终检验',7,'PROCESS','1','2026-10-24 02:25:37',5,'FINAL');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (9,'MC-SQ-14-102528061580','半成品最终检验',8,'PROCESS','1','2026-10-24 02:25:38',6,'FINAL');
INSERT INTO `mm_qc_template` (`id`, `code`, `name`, `product_id`, `kind`, `version`, `created_at`, `operation_id`, `phase`) VALUES (10,'MC-FIRST-102528061580','首件检验验收',6,'PROCESS','1','2026-10-24 02:25:46',1,'FIRST');
/*!40000 ALTER TABLE `mm_qc_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_qc_todo`
--

DROP TABLE IF EXISTS `mm_qc_todo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_qc_todo` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `event_id` bigint DEFAULT NULL,
  `task_id` bigint NOT NULL,
  `work_order_id` bigint NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'WAITING',
  `inspection_id` bigint DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `completed_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_id` (`task_id`),
  UNIQUE KEY `event_id` (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_qc_todo`
--

LOCK TABLES `mm_qc_todo` WRITE;
/*!40000 ALTER TABLE `mm_qc_todo` DISABLE KEYS */;
INSERT INTO `mm_qc_todo` (`id`, `event_id`, `task_id`, `work_order_id`, `status`, `inspection_id`, `created_at`, `completed_at`) VALUES (1,16,17,6,'WAITING',NULL,'2026-10-24 10:25:43.946359',NULL);
INSERT INTO `mm_qc_todo` (`id`, `event_id`, `task_id`, `work_order_id`, `status`, `inspection_id`, `created_at`, `completed_at`) VALUES (2,20,21,7,'DONE',22,'2026-10-24 10:25:46.644661','2026-10-24 10:25:46.674335');
INSERT INTO `mm_qc_todo` (`id`, `event_id`, `task_id`, `work_order_id`, `status`, `inspection_id`, `created_at`, `completed_at`) VALUES (3,21,22,7,'DONE',23,'2026-10-24 10:25:46.783319','2026-10-24 10:25:46.793947');
INSERT INTO `mm_qc_todo` (`id`, `event_id`, `task_id`, `work_order_id`, `status`, `inspection_id`, `created_at`, `completed_at`) VALUES (4,22,23,7,'DONE',24,'2026-10-24 10:25:46.919954','2026-10-24 10:25:46.930277');
INSERT INTO `mm_qc_todo` (`id`, `event_id`, `task_id`, `work_order_id`, `status`, `inspection_id`, `created_at`, `completed_at`) VALUES (5,23,24,7,'CANCELLED',25,'2026-10-24 10:25:47.032401','2026-10-24 10:25:47.000000');
INSERT INTO `mm_qc_todo` (`id`, `event_id`, `task_id`, `work_order_id`, `status`, `inspection_id`, `created_at`, `completed_at`) VALUES (6,24,29,9,'DONE',27,'2026-10-24 10:25:49.202906','2026-10-24 10:25:49.343561');
INSERT INTO `mm_qc_todo` (`id`, `event_id`, `task_id`, `work_order_id`, `status`, `inspection_id`, `created_at`, `completed_at`) VALUES (7,25,30,9,'DONE',28,'2026-10-24 10:25:49.438080','2026-10-24 10:25:49.470424');
INSERT INTO `mm_qc_todo` (`id`, `event_id`, `task_id`, `work_order_id`, `status`, `inspection_id`, `created_at`, `completed_at`) VALUES (8,26,31,9,'DONE',29,'2026-10-24 10:25:49.574558','2026-10-24 10:25:49.606439');
INSERT INTO `mm_qc_todo` (`id`, `event_id`, `task_id`, `work_order_id`, `status`, `inspection_id`, `created_at`, `completed_at`) VALUES (9,27,32,9,'DONE',30,'2026-10-24 10:25:49.683636','2026-10-24 10:25:49.714081');
/*!40000 ALTER TABLE `mm_qc_todo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_query_audit`
--

DROP TABLE IF EXISTS `mm_query_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_query_audit` (
  `id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` bigint NOT NULL,
  `session_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `question` varchar(1200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `mode` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `filters` json DEFAULT NULL,
  `input_tokens` int NOT NULL DEFAULT '0',
  `output_tokens` int NOT NULL DEFAULT '0',
  `elapsed_ms` bigint NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_query_audit`
--

LOCK TABLES `mm_query_audit` WRITE;
/*!40000 ALTER TABLE `mm_query_audit` DISABLE KEYS */;
INSERT INTO `mm_query_audit` (`id`, `user_id`, `session_id`, `question`, `mode`, `status`, `filters`, `input_tokens`, `output_tokens`, `elapsed_ms`, `created_at`) VALUES ('2e9dfb16-ae6b-4ffb-8f88-263a35e8c358',1,'2a1e9996-b2b1-4c5b-b82a-e7fd1fda5fad','当前微动开关库存','local','SUCCEEDED','{\"kind\": \"INVENTORY\", \"material\": \"5\"}',0,0,11,'2026-10-23 23:35:17');
INSERT INTO `mm_query_audit` (`id`, `user_id`, `session_id`, `question`, `mode`, `status`, `filters`, `input_tokens`, `output_tokens`, `elapsed_ms`, `created_at`) VALUES ('4264f7dc-23ee-4338-a236-f71c725fd046',1,'7ba9a8a9-d4e8-4c7b-9b69-148b09245174','本月微动开关库存','local','SUCCEEDED','{\"to\": \"2026-10-23\", \"from\": \"2026-10-01\", \"kind\": \"INVENTORY\", \"material\": \"5\"}',0,0,16,'2026-10-23 23:24:51');
/*!40000 ALTER TABLE `mm_query_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_replenishment`
--

DROP TABLE IF EXISTS `mm_replenishment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_replenishment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `material_id` bigint NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'SUGGESTED',
  `confirmed_by` bigint DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `material_id` (`material_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_replenishment`
--

LOCK TABLES `mm_replenishment` WRITE;
/*!40000 ALTER TABLE `mm_replenishment` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_replenishment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_report_sheet`
--

DROP TABLE IF EXISTS `mm_report_sheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_report_sheet` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(80) NOT NULL,
  `task_id` bigint NOT NULL,
  `reporter_id` bigint NOT NULL,
  `good_quantity` int NOT NULL,
  `bad_quantity` int NOT NULL,
  `report_time` datetime NOT NULL,
  `remark` varchar(500) DEFAULT NULL,
  `created_by` bigint NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'PENDING',
  `approved_by` bigint DEFAULT NULL,
  `approval_note` varchar(500) DEFAULT NULL,
  `report_id` bigint DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_report_sheet`
--

LOCK TABLES `mm_report_sheet` WRITE;
/*!40000 ALTER TABLE `mm_report_sheet` DISABLE KEYS */;
INSERT INTO `mm_report_sheet` (`id`, `code`, `task_id`, `reporter_id`, `good_quantity`, `bad_quantity`, `report_time`, `remark`, `created_by`, `status`, `approved_by`, `approval_note`, `report_id`, `approved_at`) VALUES (1,'RPT-000001',29,4,2,0,'2026-10-24 10:25:49','',4,'REJECTED',1,'验收驳回，不应扣料',NULL,NULL);
INSERT INTO `mm_report_sheet` (`id`, `code`, `task_id`, `reporter_id`, `good_quantity`, `bad_quantity`, `report_time`, `remark`, `created_by`, `status`, `approved_by`, `approval_note`, `report_id`, `approved_at`) VALUES (2,'RPT-000002',29,4,1,1,'2026-10-24 10:25:49','',4,'CONFIRMED',1,NULL,27,'2026-10-24 10:25:49');
INSERT INTO `mm_report_sheet` (`id`, `code`, `task_id`, `reporter_id`, `good_quantity`, `bad_quantity`, `report_time`, `remark`, `created_by`, `status`, `approved_by`, `approval_note`, `report_id`, `approved_at`) VALUES (3,'RPT-000003',30,4,2,0,'2026-10-24 10:25:49','',4,'CONFIRMED',1,NULL,28,'2026-10-24 10:25:49');
INSERT INTO `mm_report_sheet` (`id`, `code`, `task_id`, `reporter_id`, `good_quantity`, `bad_quantity`, `report_time`, `remark`, `created_by`, `status`, `approved_by`, `approval_note`, `report_id`, `approved_at`) VALUES (4,'RPT-000004',31,4,2,0,'2026-10-24 10:25:50','',4,'CONFIRMED',1,NULL,29,'2026-10-24 10:25:49');
INSERT INTO `mm_report_sheet` (`id`, `code`, `task_id`, `reporter_id`, `good_quantity`, `bad_quantity`, `report_time`, `remark`, `created_by`, `status`, `approved_by`, `approval_note`, `report_id`, `approved_at`) VALUES (5,'RPT-000005',32,4,2,0,'2026-10-24 10:25:50','',4,'CONFIRMED',1,NULL,30,'2026-10-24 10:25:49');
/*!40000 ALTER TABLE `mm_report_sheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_rework`
--

DROP TABLE IF EXISTS `mm_rework`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_rework` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nc_id` bigint NOT NULL,
  `task_id` bigint NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'PENDING',
  `result` varchar(500) DEFAULT NULL,
  `completed_by` bigint DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nc_id` (`nc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_rework`
--

LOCK TABLES `mm_rework` WRITE;
/*!40000 ALTER TABLE `mm_rework` DISABLE KEYS */;
INSERT INTO `mm_rework` (`id`, `nc_id`, `task_id`, `status`, `result`, `completed_by`, `completed_at`) VALUES (1,1,2,'DONE','隔离验收：完成返工',4,'2026-10-24 10:25:34');
INSERT INTO `mm_rework` (`id`, `nc_id`, `task_id`, `status`, `result`, `completed_by`, `completed_at`) VALUES (2,3,29,'DONE','已修复申报缺陷，等待独立复检',4,'2026-10-24 10:25:49');
/*!40000 ALTER TABLE `mm_rework` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_role_menu`
--

DROP TABLE IF EXISTS `mm_role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_role_menu` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `role_id` bigint NOT NULL,
  `menu_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_menu` (`role_id`,`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_role_menu`
--

LOCK TABLES `mm_role_menu` WRITE;
/*!40000 ALTER TABLE `mm_role_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_role_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_rotation`
--

DROP TABLE IF EXISTS `mm_rotation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_rotation` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `station_id` bigint NOT NULL,
  `cycle_days` int NOT NULL DEFAULT '1',
  `cycle_unit` varchar(20) NOT NULL DEFAULT 'DAY',
  `mode` varchar(20) NOT NULL,
  `is_generated` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_rotation`
--

LOCK TABLES `mm_rotation` WRITE;
/*!40000 ALTER TABLE `mm_rotation` DISABLE KEYS */;
INSERT INTO `mm_rotation` (`id`, `code`, `name`, `start_date`, `end_date`, `station_id`, `cycle_days`, `cycle_unit`, `mode`, `is_generated`) VALUES (1,'MC-ROT-102528061580','隔离两班倒','2032-01-10','2032-01-10',5,1,'DAY','TWO',1);
/*!40000 ALTER TABLE `mm_rotation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_rotation_shift`
--

DROP TABLE IF EXISTS `mm_rotation_shift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_rotation_shift` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `rotation_id` bigint NOT NULL,
  `shift_id` bigint NOT NULL,
  `sequence_no` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rotation_shift` (`rotation_id`,`shift_id`),
  UNIQUE KEY `uq_rotation_shift_sequence` (`rotation_id`,`sequence_no`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_rotation_shift`
--

LOCK TABLES `mm_rotation_shift` WRITE;
/*!40000 ALTER TABLE `mm_rotation_shift` DISABLE KEYS */;
INSERT INTO `mm_rotation_shift` (`id`, `rotation_id`, `shift_id`, `sequence_no`) VALUES (1,1,2,1);
INSERT INTO `mm_rotation_shift` (`id`, `rotation_id`, `shift_id`, `sequence_no`) VALUES (2,1,3,2);
/*!40000 ALTER TABLE `mm_rotation_shift` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_rotation_team`
--

DROP TABLE IF EXISTS `mm_rotation_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_rotation_team` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `rotation_id` bigint NOT NULL,
  `team_id` bigint NOT NULL,
  `sequence_no` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rotation_team` (`rotation_id`,`team_id`),
  UNIQUE KEY `uq_rotation_seq` (`rotation_id`,`sequence_no`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_rotation_team`
--

LOCK TABLES `mm_rotation_team` WRITE;
/*!40000 ALTER TABLE `mm_rotation_team` DISABLE KEYS */;
INSERT INTO `mm_rotation_team` (`id`, `rotation_id`, `team_id`, `sequence_no`) VALUES (1,1,2,1);
INSERT INTO `mm_rotation_team` (`id`, `rotation_id`, `team_id`, `sequence_no`) VALUES (2,1,3,2);
/*!40000 ALTER TABLE `mm_rotation_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_route`
--

DROP TABLE IF EXISTS `mm_route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_route` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `product_id` bigint NOT NULL,
  `version` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_route`
--

LOCK TABLES `mm_route` WRITE;
/*!40000 ALTER TABLE `mm_route` DISABLE KEYS */;
INSERT INTO `mm_route` (`id`, `code`, `name`, `product_id`, `version`, `created_at`) VALUES (1,'ROUTE-A100-V1','A100装配工艺',6,'1.0','2026-10-19 00:41:54');
INSERT INTO `mm_route` (`id`, `code`, `name`, `product_id`, `version`, `created_at`) VALUES (2,'MC-SR-15-102528061580','隔离半成品路线',7,'1','2026-10-24 02:25:37');
INSERT INTO `mm_route` (`id`, `code`, `name`, `product_id`, `version`, `created_at`) VALUES (3,'MC-SR-14-102528061580','隔离半成品路线',8,'1','2026-10-24 02:25:38');
/*!40000 ALTER TABLE `mm_route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_schedule`
--

DROP TABLE IF EXISTS `mm_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_schedule` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `team_id` bigint NOT NULL,
  `shift_id` bigint NOT NULL,
  `station_id` bigint NOT NULL,
  `equipment_id` bigint DEFAULT NULL,
  `start_at` datetime NOT NULL,
  `end_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `start_at` (`start_at`,`end_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_schedule`
--

LOCK TABLES `mm_schedule` WRITE;
/*!40000 ALTER TABLE `mm_schedule` DISABLE KEYS */;
INSERT INTO `mm_schedule` (`id`, `team_id`, `shift_id`, `station_id`, `equipment_id`, `start_at`, `end_at`, `created_at`) VALUES (1,2,1,5,2,'2026-10-24 09:25:31','2026-10-24 16:25:31','2026-10-24 02:25:30');
INSERT INTO `mm_schedule` (`id`, `team_id`, `shift_id`, `station_id`, `equipment_id`, `start_at`, `end_at`, `created_at`) VALUES (2,2,2,5,2,'2032-01-10 08:00:00','2032-01-10 20:00:00','2026-10-24 02:25:37');
INSERT INTO `mm_schedule` (`id`, `team_id`, `shift_id`, `station_id`, `equipment_id`, `start_at`, `end_at`, `created_at`) VALUES (3,3,3,5,2,'2032-01-10 20:00:00','2032-01-11 08:00:00','2026-10-24 02:25:37');
/*!40000 ALTER TABLE `mm_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_shift`
--

DROP TABLE IF EXISTS `mm_shift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_shift` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_shift`
--

LOCK TABLES `mm_shift` WRITE;
/*!40000 ALTER TABLE `mm_shift` DISABLE KEYS */;
INSERT INTO `mm_shift` (`id`, `code`, `name`, `start_time`, `end_time`, `created_at`) VALUES (1,'DAY','白班','08:00:00','17:00:00','2026-10-19 00:41:54');
INSERT INTO `mm_shift` (`id`, `code`, `name`, `start_time`, `end_time`, `created_at`) VALUES (2,'MC-DAY-102528061580','验收日班','08:00:00','20:00:00','2026-10-24 02:25:37');
INSERT INTO `mm_shift` (`id`, `code`, `name`, `start_time`, `end_time`, `created_at`) VALUES (3,'MC-NIGHT-102528061580','验收夜班','20:00:00','08:00:00','2026-10-24 02:25:37');
/*!40000 ALTER TABLE `mm_shift` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_sop`
--

DROP TABLE IF EXISTS `mm_sop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_sop` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `product_id` bigint NOT NULL,
  `operation_id` bigint NOT NULL,
  `version` varchar(32) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `enabled` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_sop`
--

LOCK TABLES `mm_sop` WRITE;
/*!40000 ALTER TABLE `mm_sop` DISABLE KEYS */;
INSERT INTO `mm_sop` (`id`, `code`, `name`, `product_id`, `operation_id`, `version`, `image_path`, `enabled`) VALUES (1,'MC-SOP-102528061580','隔离上传验收图',6,1,'1','/api/mes/sop-images/0050a9ed-fbab-4911-8213-6e073b489274.png',1);
/*!40000 ALTER TABLE `mm_sop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_station`
--

DROP TABLE IF EXISTS `mm_station`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_station` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `workshop_id` bigint NOT NULL,
  `equipment_id` bigint DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_station`
--

LOCK TABLES `mm_station` WRITE;
/*!40000 ALTER TABLE `mm_station` DISABLE KEYS */;
INSERT INTO `mm_station` (`id`, `code`, `name`, `workshop_id`, `equipment_id`, `created_at`) VALUES (1,'ST-A100-1','电子装配站',1,NULL,'2026-10-19 00:41:54');
INSERT INTO `mm_station` (`id`, `code`, `name`, `workshop_id`, `equipment_id`, `created_at`) VALUES (2,'ST-A100-2','结构装配站',1,NULL,'2026-10-19 00:41:54');
INSERT INTO `mm_station` (`id`, `code`, `name`, `workshop_id`, `equipment_id`, `created_at`) VALUES (3,'ST-A100-3','总装测试站',1,1,'2026-10-19 00:41:54');
INSERT INTO `mm_station` (`id`, `code`, `name`, `workshop_id`, `equipment_id`, `created_at`) VALUES (4,'ST-A100-4','贴标包装站',1,NULL,'2026-10-19 00:41:54');
INSERT INTO `mm_station` (`id`, `code`, `name`, `workshop_id`, `equipment_id`, `created_at`) VALUES (5,'MC-ST-102528061580','隔离生产工作站',2,2,'2026-10-24 02:25:30');
/*!40000 ALTER TABLE `mm_station` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_station_resource`
--

DROP TABLE IF EXISTS `mm_station_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_station_resource` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `station_id` bigint NOT NULL,
  `resource_type` varchar(20) NOT NULL,
  `equipment_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_station_resource`
--

LOCK TABLES `mm_station_resource` WRITE;
/*!40000 ALTER TABLE `mm_station_resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_station_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_stock_posting`
--

DROP TABLE IF EXISTS `mm_stock_posting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_stock_posting` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `kind` varchar(30) NOT NULL,
  `source_id` bigint NOT NULL,
  `document_id` bigint NOT NULL,
  `document_no` varchar(80) NOT NULL,
  `warehouse_id` bigint NOT NULL,
  `location_id` bigint DEFAULT NULL,
  `quantity` decimal(14,2) NOT NULL,
  `actor_id` bigint NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kind` (`kind`,`source_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_stock_posting`
--

LOCK TABLES `mm_stock_posting` WRITE;
/*!40000 ALTER TABLE `mm_stock_posting` DISABLE KEYS */;
INSERT INTO `mm_stock_posting` (`id`, `kind`, `source_id`, `document_id`, `document_no`, `warehouse_id`, `location_id`, `quantity`, `actor_id`, `created_at`) VALUES (1,'ISSUE',1,1,'ISS-000001',2,NULL,100.00,6,'2026-10-24 10:25:33');
INSERT INTO `mm_stock_posting` (`id`, `kind`, `source_id`, `document_id`, `document_no`, `warehouse_id`, `location_id`, `quantity`, `actor_id`, `created_at`) VALUES (2,'RECEIPT',3,9,'FG-IN-000003',4,4,10.00,6,'2026-10-24 10:25:39');
INSERT INTO `mm_stock_posting` (`id`, `kind`, `source_id`, `document_id`, `document_no`, `warehouse_id`, `location_id`, `quantity`, `actor_id`, `created_at`) VALUES (3,'RECEIPT',4,11,'FG-IN-000004',4,4,10.00,6,'2026-10-24 10:25:39');
INSERT INTO `mm_stock_posting` (`id`, `kind`, `source_id`, `document_id`, `document_no`, `warehouse_id`, `location_id`, `quantity`, `actor_id`, `created_at`) VALUES (4,'RECEIPT',2,13,'FG-IN-000005',4,4,10.00,6,'2026-10-24 10:25:41');
INSERT INTO `mm_stock_posting` (`id`, `kind`, `source_id`, `document_id`, `document_no`, `warehouse_id`, `location_id`, `quantity`, `actor_id`, `created_at`) VALUES (5,'RECEIPT',5,15,'FG-IN-000006',4,4,1.00,6,'2026-10-24 10:25:42');
INSERT INTO `mm_stock_posting` (`id`, `kind`, `source_id`, `document_id`, `document_no`, `warehouse_id`, `location_id`, `quantity`, `actor_id`, `created_at`) VALUES (6,'RECEIPT',6,17,'FG-IN-000007',4,4,1.00,6,'2026-10-24 10:25:44');
/*!40000 ALTER TABLE `mm_stock_posting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_task_consumption`
--

DROP TABLE IF EXISTS `mm_task_consumption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_task_consumption` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `operation_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `quantity_per_unit` decimal(18,6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_consume` (`operation_id`,`material_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_task_consumption`
--

LOCK TABLES `mm_task_consumption` WRITE;
/*!40000 ALTER TABLE `mm_task_consumption` DISABLE KEYS */;
/*!40000 ALTER TABLE `mm_task_consumption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_task_context`
--

DROP TABLE IF EXISTS `mm_task_context`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_task_context` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `task_id` bigint NOT NULL,
  `work_order_id` bigint NOT NULL,
  `operation_id` bigint NOT NULL,
  `sequence_no` int NOT NULL,
  `predecessor_id` bigint DEFAULT NULL,
  `requires_qc` int NOT NULL,
  `is_terminal` int NOT NULL,
  `station_id` bigint NOT NULL,
  `schedule_id` bigint DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_id` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_task_context`
--

LOCK TABLES `mm_task_context` WRITE;
/*!40000 ALTER TABLE `mm_task_context` DISABLE KEYS */;
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (1,2,1,1,10,NULL,1,0,5,1,'2026-10-24 02:25:31');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (2,3,1,2,20,NULL,1,0,5,1,'2026-10-24 02:25:31');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (3,4,1,3,30,2,1,0,5,1,'2026-10-24 02:25:31');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (4,5,1,4,40,3,1,1,5,1,'2026-10-24 02:25:31');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (5,6,2,1,10,NULL,1,0,5,1,'2026-10-24 02:25:38');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (6,7,2,2,20,NULL,1,0,5,1,'2026-10-24 02:25:38');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (7,8,2,3,30,2,1,0,5,1,'2026-10-24 02:25:38');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (8,9,2,4,40,3,1,1,5,1,'2026-10-24 02:25:38');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (9,10,3,6,10,NULL,1,1,5,1,'2026-10-24 02:25:38');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (10,11,4,5,10,NULL,1,1,5,1,'2026-10-24 02:25:38');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (11,12,2,1,10,NULL,1,0,5,1,'2026-10-24 02:25:38');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (12,13,5,1,10,NULL,1,0,5,1,'2026-10-24 02:25:41');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (13,14,5,2,20,NULL,1,0,5,1,'2026-10-24 02:25:41');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (14,15,5,3,30,2,1,0,5,1,'2026-10-24 02:25:41');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (15,16,5,4,40,3,1,1,5,1,'2026-10-24 02:25:41');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (16,17,6,1,10,NULL,1,0,5,1,'2026-10-24 02:25:41');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (17,18,6,2,20,NULL,1,0,5,1,'2026-10-24 02:25:41');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (18,19,6,3,30,2,1,0,5,1,'2026-10-24 02:25:41');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (19,20,6,4,40,3,1,1,5,1,'2026-10-24 02:25:41');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (20,21,7,1,10,NULL,1,0,5,1,'2026-10-24 02:25:45');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (21,22,7,2,20,NULL,1,0,5,1,'2026-10-24 02:25:45');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (22,23,7,3,30,2,1,0,5,1,'2026-10-24 02:25:45');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (23,24,7,4,40,3,1,1,5,1,'2026-10-24 02:25:45');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (24,25,8,1,10,NULL,1,0,5,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (25,26,8,2,20,NULL,1,0,5,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (26,27,8,3,30,2,1,0,5,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (27,28,8,4,40,3,1,1,5,NULL,'2026-10-24 02:25:47');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (28,29,9,1,10,NULL,1,0,5,1,'2026-10-24 02:25:47');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (29,30,9,2,20,NULL,1,0,5,1,'2026-10-24 02:25:47');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (30,31,9,3,30,2,1,0,5,1,'2026-10-24 02:25:47');
INSERT INTO `mm_task_context` (`id`, `task_id`, `work_order_id`, `operation_id`, `sequence_no`, `predecessor_id`, `requires_qc`, `is_terminal`, `station_id`, `schedule_id`, `created_at`) VALUES (31,32,9,4,40,3,1,1,5,1,'2026-10-24 02:25:47');
/*!40000 ALTER TABLE `mm_task_context` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_task_slot`
--

DROP TABLE IF EXISTS `mm_task_slot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_task_slot` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `task_id` bigint NOT NULL,
  `station_id` bigint NOT NULL,
  `owner_id` bigint NOT NULL,
  `start_at` datetime NOT NULL,
  `end_at` datetime NOT NULL,
  `quantity` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_id` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_task_slot`
--

LOCK TABLES `mm_task_slot` WRITE;
/*!40000 ALTER TABLE `mm_task_slot` DISABLE KEYS */;
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (1,2,5,4,'2026-10-24 10:24:34','2026-10-24 11:25:34',100);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (2,3,5,4,'2026-10-24 10:24:34','2026-10-24 11:25:34',100);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (3,4,5,4,'2026-10-24 10:24:35','2026-10-24 11:25:35',100);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (4,5,5,4,'2026-10-24 10:24:35','2026-10-24 11:25:35',100);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (5,10,5,4,'2026-10-24 10:24:39','2026-10-24 11:25:39',10);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (6,11,5,4,'2026-10-24 10:24:40','2026-10-24 11:25:40',10);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (7,6,5,4,'2026-10-24 10:24:41','2026-10-24 11:25:41',6);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (8,12,5,4,'2026-10-24 10:24:41','2026-10-24 11:25:41',4);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (9,7,5,4,'2026-10-24 10:24:41','2026-10-24 11:25:41',10);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (10,8,5,4,'2026-10-24 10:24:41','2026-10-24 11:25:41',10);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (11,9,5,4,'2026-10-24 10:24:41','2026-10-24 11:25:41',10);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (12,13,5,4,'2026-10-24 10:24:42','2026-10-24 11:25:42',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (13,14,5,4,'2026-10-24 10:24:42','2026-10-24 11:25:42',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (14,15,5,4,'2026-10-24 10:24:43','2026-10-24 11:25:43',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (15,16,5,4,'2026-10-24 10:24:43','2026-10-24 11:25:43',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (16,17,5,4,'2026-10-24 10:24:44','2026-10-24 11:25:44',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (17,18,5,4,'2026-10-24 10:24:44','2026-10-24 11:25:44',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (18,19,5,4,'2026-10-24 10:24:44','2026-10-24 11:25:44',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (19,20,5,4,'2026-10-24 10:24:44','2026-10-24 11:25:44',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (20,21,5,4,'2026-10-24 10:24:47','2026-10-24 11:25:47',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (21,22,5,4,'2026-10-24 10:24:47','2026-10-24 11:25:47',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (22,23,5,4,'2026-10-24 10:24:47','2026-10-24 11:25:47',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (23,24,5,4,'2026-10-24 10:24:47','2026-10-24 11:25:47',1);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (24,29,5,4,'2026-10-24 10:24:49','2026-10-24 11:25:49',2);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (25,30,5,4,'2026-10-24 10:24:49','2026-10-24 11:25:49',2);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (26,31,5,4,'2026-10-24 10:24:49','2026-10-24 11:25:49',2);
INSERT INTO `mm_task_slot` (`id`, `task_id`, `station_id`, `owner_id`, `start_at`, `end_at`, `quantity`) VALUES (27,32,5,4,'2026-10-24 10:24:50','2026-10-24 11:25:50',2);
/*!40000 ALTER TABLE `mm_task_slot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_team`
--

DROP TABLE IF EXISTS `mm_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_team` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `leader_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_team`
--

LOCK TABLES `mm_team` WRITE;
/*!40000 ALTER TABLE `mm_team` DISABLE KEYS */;
INSERT INTO `mm_team` (`id`, `code`, `name`, `leader_id`, `created_at`) VALUES (1,'TEAM-A100','A100装配一班',1,'2026-10-19 00:41:54');
INSERT INTO `mm_team` (`id`, `code`, `name`, `leader_id`, `created_at`) VALUES (2,'MC-TEAM-102528061580','验收班组',4,'2026-10-24 02:25:30');
INSERT INTO `mm_team` (`id`, `code`, `name`, `leader_id`, `created_at`) VALUES (3,'MC-TEAM2-102528061580','第二验收班组',12,'2026-10-24 02:25:37');
/*!40000 ALTER TABLE `mm_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_user_position`
--

DROP TABLE IF EXISTS `mm_user_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_user_position` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `position_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_position` (`user_id`,`position_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_user_position`
--

LOCK TABLES `mm_user_position` WRITE;
/*!40000 ALTER TABLE `mm_user_position` DISABLE KEYS */;
INSERT INTO `mm_user_position` (`id`, `user_id`, `position_id`) VALUES (1,4,1);
/*!40000 ALTER TABLE `mm_user_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_work_consumption`
--

DROP TABLE IF EXISTS `mm_work_consumption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_work_consumption` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `operation_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `quantity_per_unit` decimal(18,6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_work_consume` (`work_order_id`,`operation_id`,`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_work_consumption`
--

LOCK TABLES `mm_work_consumption` WRITE;
/*!40000 ALTER TABLE `mm_work_consumption` DISABLE KEYS */;
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (1,1,1,4,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (2,1,1,5,2.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (3,1,1,6,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (4,1,1,7,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (5,1,1,2,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (6,1,1,3,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (7,1,1,8,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (8,1,1,9,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (9,1,1,10,4.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (10,1,1,11,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (11,1,1,12,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (12,1,1,13,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (25,2,1,11,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (26,2,1,12,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (27,2,1,13,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (28,2,1,14,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (29,2,1,15,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (30,3,6,4,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (31,3,6,5,2.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (32,3,6,6,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (33,3,6,7,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (34,4,5,2,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (35,4,5,3,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (36,4,5,8,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (37,4,5,9,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (38,4,5,10,4.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (39,5,1,2,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (40,5,1,3,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (41,5,1,4,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (42,5,1,5,2.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (43,5,1,6,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (44,5,1,7,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (45,5,1,8,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (46,5,1,9,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (47,5,1,10,4.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (48,5,1,11,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (49,5,1,12,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (50,5,1,13,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (51,6,1,2,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (52,6,1,3,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (53,6,1,4,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (54,6,1,5,2.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (55,6,1,6,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (56,6,1,7,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (57,6,1,8,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (58,6,1,9,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (59,6,1,10,4.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (60,6,1,11,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (61,6,1,12,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (62,6,1,13,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (63,7,1,2,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (64,7,1,3,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (65,7,1,4,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (66,7,1,5,2.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (67,7,1,6,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (68,7,1,7,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (69,7,1,8,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (70,7,1,9,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (71,7,1,10,4.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (72,7,1,11,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (73,7,1,12,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (74,7,1,13,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (75,8,1,2,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (76,8,1,3,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (77,8,1,4,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (78,8,1,5,2.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (79,8,1,6,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (80,8,1,7,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (81,8,1,8,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (82,8,1,9,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (83,8,1,10,4.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (84,8,1,11,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (85,8,1,12,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (86,8,1,13,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (87,9,1,2,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (88,9,1,3,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (89,9,1,4,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (90,9,1,5,2.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (91,9,1,6,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (92,9,1,7,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (93,9,1,8,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (94,9,1,9,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (95,9,1,10,4.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (96,9,1,11,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (97,9,1,12,1.000000);
INSERT INTO `mm_work_consumption` (`id`, `work_order_id`, `operation_id`, `material_id`, `quantity_per_unit`) VALUES (98,9,1,13,1.000000);
/*!40000 ALTER TABLE `mm_work_consumption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_work_material`
--

DROP TABLE IF EXISTS `mm_work_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_work_material` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `material_code` varchar(60) NOT NULL,
  `material_name` varchar(100) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `required_quantity` decimal(14,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `work_order_id` (`work_order_id`,`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_work_material`
--

LOCK TABLES `mm_work_material` WRITE;
/*!40000 ALTER TABLE `mm_work_material` DISABLE KEYS */;
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (1,1,4,'MAT-PCB-A100','PCB主板','块',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (2,1,5,'MAT-SWITCH-01','微动开关','个',200.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (3,1,6,'MAT-ENCODER-01','滚轮编码器','个',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (4,1,7,'MAT-USB-CABLE-A100','USB连接线','根',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (5,1,2,'MAT-SHELL-TOP-A100','鼠标上盖','个',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (6,1,3,'MAT-SHELL-BOTTOM-A100','鼠标下盖','个',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (7,1,8,'MAT-WHEEL-A100','滚轮组件','个',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (8,1,9,'MAT-LENS-A100','光学透镜','个',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (9,1,10,'MAT-SCREW-A100','固定螺钉','颗',400.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (10,1,11,'MAT-FEET-A100','防滑脚贴','套',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (11,1,12,'MAT-LABEL-A100','产品铭牌','张',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (12,1,13,'MAT-BOX-A100','包装盒','个',100.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (25,2,11,'MAT-FEET-A100','防滑脚贴','套',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (26,2,12,'MAT-LABEL-A100','产品铭牌','张',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (27,2,13,'MAT-BOX-A100','包装盒','个',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (28,2,14,'MAT-SEMI-E-A100','A100电子组件','个',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (29,2,15,'MAT-SEMI-S-A100','A100结构组件','个',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (30,3,4,'MAT-PCB-A100','PCB主板','块',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (31,3,5,'MAT-SWITCH-01','微动开关','个',20.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (32,3,6,'MAT-ENCODER-01','滚轮编码器','个',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (33,3,7,'MAT-USB-CABLE-A100','USB连接线','根',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (34,4,2,'MAT-SHELL-TOP-A100','鼠标上盖','个',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (35,4,3,'MAT-SHELL-BOTTOM-A100','鼠标下盖','个',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (36,4,8,'MAT-WHEEL-A100','滚轮组件','个',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (37,4,9,'MAT-LENS-A100','光学透镜','个',10.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (38,4,10,'MAT-SCREW-A100','固定螺钉','颗',40.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (39,5,11,'MAT-FEET-A100','防滑脚贴','套',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (40,5,12,'MAT-LABEL-A100','产品铭牌','张',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (41,5,13,'MAT-BOX-A100','包装盒','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (42,5,4,'MAT-PCB-A100','PCB主板','块',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (43,5,5,'MAT-SWITCH-01','微动开关','个',2.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (44,5,6,'MAT-ENCODER-01','滚轮编码器','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (45,5,7,'MAT-USB-CABLE-A100','USB连接线','根',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (46,5,2,'MAT-SHELL-TOP-A100','鼠标上盖','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (47,5,3,'MAT-SHELL-BOTTOM-A100','鼠标下盖','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (48,5,8,'MAT-WHEEL-A100','滚轮组件','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (49,5,9,'MAT-LENS-A100','光学透镜','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (50,5,10,'MAT-SCREW-A100','固定螺钉','颗',4.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (51,6,11,'MAT-FEET-A100','防滑脚贴','套',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (52,6,12,'MAT-LABEL-A100','产品铭牌','张',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (53,6,13,'MAT-BOX-A100','包装盒','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (54,6,4,'MAT-PCB-A100','PCB主板','块',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (55,6,5,'MAT-SWITCH-01','微动开关','个',2.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (56,6,6,'MAT-ENCODER-01','滚轮编码器','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (57,6,7,'MAT-USB-CABLE-A100','USB连接线','根',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (58,6,2,'MAT-SHELL-TOP-A100','鼠标上盖','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (59,6,3,'MAT-SHELL-BOTTOM-A100','鼠标下盖','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (60,6,8,'MAT-WHEEL-A100','滚轮组件','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (61,6,9,'MAT-LENS-A100','光学透镜','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (62,6,10,'MAT-SCREW-A100','固定螺钉','颗',4.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (63,7,11,'MAT-FEET-A100','防滑脚贴','套',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (64,7,12,'MAT-LABEL-A100','产品铭牌','张',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (65,7,13,'MAT-BOX-A100','包装盒','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (66,7,4,'MAT-PCB-A100','PCB主板','块',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (67,7,5,'MAT-SWITCH-01','微动开关','个',2.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (68,7,6,'MAT-ENCODER-01','滚轮编码器','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (69,7,7,'MAT-USB-CABLE-A100','USB连接线','根',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (70,7,2,'MAT-SHELL-TOP-A100','鼠标上盖','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (71,7,3,'MAT-SHELL-BOTTOM-A100','鼠标下盖','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (72,7,8,'MAT-WHEEL-A100','滚轮组件','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (73,7,9,'MAT-LENS-A100','光学透镜','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (74,7,10,'MAT-SCREW-A100','固定螺钉','颗',4.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (75,8,11,'MAT-FEET-A100','防滑脚贴','套',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (76,8,12,'MAT-LABEL-A100','产品铭牌','张',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (77,8,13,'MAT-BOX-A100','包装盒','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (78,8,4,'MAT-PCB-A100','PCB主板','块',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (79,8,5,'MAT-SWITCH-01','微动开关','个',2.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (80,8,6,'MAT-ENCODER-01','滚轮编码器','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (81,8,7,'MAT-USB-CABLE-A100','USB连接线','根',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (82,8,2,'MAT-SHELL-TOP-A100','鼠标上盖','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (83,8,3,'MAT-SHELL-BOTTOM-A100','鼠标下盖','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (84,8,8,'MAT-WHEEL-A100','滚轮组件','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (85,8,9,'MAT-LENS-A100','光学透镜','个',1.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (86,8,10,'MAT-SCREW-A100','固定螺钉','颗',4.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (87,9,11,'MAT-FEET-A100','防滑脚贴','套',2.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (88,9,12,'MAT-LABEL-A100','产品铭牌','张',2.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (89,9,13,'MAT-BOX-A100','包装盒','个',2.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (90,9,4,'MAT-PCB-A100','PCB主板','块',2.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (91,9,5,'MAT-SWITCH-01','微动开关','个',4.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (92,9,6,'MAT-ENCODER-01','滚轮编码器','个',2.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (93,9,7,'MAT-USB-CABLE-A100','USB连接线','根',2.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (94,9,2,'MAT-SHELL-TOP-A100','鼠标上盖','个',2.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (95,9,3,'MAT-SHELL-BOTTOM-A100','鼠标下盖','个',2.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (96,9,8,'MAT-WHEEL-A100','滚轮组件','个',2.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (97,9,9,'MAT-LENS-A100','光学透镜','个',2.00);
INSERT INTO `mm_work_material` (`id`, `work_order_id`, `material_id`, `material_code`, `material_name`, `unit`, `required_quantity`) VALUES (98,9,10,'MAT-SCREW-A100','固定螺钉','颗',8.00);
/*!40000 ALTER TABLE `mm_work_material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_work_order`
--

DROP TABLE IF EXISTS `mm_work_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_work_order` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(80) NOT NULL,
  `plan_id` bigint NOT NULL,
  `bom_id` bigint NOT NULL,
  `route_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  `bom_snapshot` json NOT NULL,
  `route_snapshot` json NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'CREATED',
  `created_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `plan_id` (`plan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_work_order`
--

LOCK TABLES `mm_work_order` WRITE;
/*!40000 ALTER TABLE `mm_work_order` DISABLE KEYS */;
INSERT INTO `mm_work_order` (`id`, `code`, `plan_id`, `bom_id`, `route_id`, `quantity`, `bom_snapshot`, `route_snapshot`, `status`, `created_by`, `created_at`) VALUES (1,'MO-000001',8,1,1,100,'[{\"id\": 1, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 14, \"parent_material_id\": 16}, {\"id\": 2, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 15, \"parent_material_id\": 16}, {\"id\": 3, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 2, \"parent_material_id\": 15}, {\"id\": 4, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 3, \"parent_material_id\": 15}, {\"id\": 5, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 4, \"parent_material_id\": 14}, {\"id\": 6, \"bom_id\": 1, \"quantity\": 2.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 5, \"parent_material_id\": 14}, {\"id\": 7, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 6, \"parent_material_id\": 14}, {\"id\": 8, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 7, \"parent_material_id\": 14}, {\"id\": 9, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 8, \"parent_material_id\": 15}, {\"id\": 10, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 9, \"parent_material_id\": 15}, {\"id\": 11, \"bom_id\": 1, \"quantity\": 4.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 10, \"parent_material_id\": 15}, {\"id\": 12, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 11, \"parent_material_id\": 16}, {\"id\": 13, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 12, \"parent_material_id\": 16}, {\"id\": 14, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 13, \"parent_material_id\": 16}]','[{\"id\": 1, \"code\": \"OP-A100-1\", \"name\": \"电子装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 10, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 2, \"code\": \"OP-A100-2\", \"name\": \"结构装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 20, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 3, \"code\": \"OP-A100-3\", \"name\": \"总装测试站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 30, \"predecessor_id\": 2, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 4, \"code\": \"OP-A100-4\", \"name\": \"贴标包装站\", \"is_key\": 1, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 40, \"predecessor_id\": 3, \"standard_minutes\": 2.0, \"output_material_id\": null}]','PRODUCTION_COMPLETED',1,'2026-10-24 02:25:31');
INSERT INTO `mm_work_order` (`id`, `code`, `plan_id`, `bom_id`, `route_id`, `quantity`, `bom_snapshot`, `route_snapshot`, `status`, `created_by`, `created_at`) VALUES (2,'MO-000003',9,1,1,10,'[{\"id\": 5, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 4, \"parent_material_id\": 14}, {\"id\": 6, \"bom_id\": 1, \"quantity\": 2.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 5, \"parent_material_id\": 14}, {\"id\": 7, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 6, \"parent_material_id\": 14}, {\"id\": 8, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 7, \"parent_material_id\": 14}, {\"id\": 3, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 2, \"parent_material_id\": 15}, {\"id\": 4, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 3, \"parent_material_id\": 15}, {\"id\": 9, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 8, \"parent_material_id\": 15}, {\"id\": 10, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 9, \"parent_material_id\": 15}, {\"id\": 11, \"bom_id\": 1, \"quantity\": 4.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 10, \"parent_material_id\": 15}, {\"id\": 12, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 11, \"parent_material_id\": 16}, {\"id\": 13, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 12, \"parent_material_id\": 16}, {\"id\": 14, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 13, \"parent_material_id\": 16}, {\"id\": 1, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 14, \"parent_material_id\": 16}, {\"id\": 2, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 15, \"parent_material_id\": 16}]','[{\"id\": 1, \"code\": \"OP-A100-1\", \"name\": \"电子装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 10, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 2, \"code\": \"OP-A100-2\", \"name\": \"结构装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 20, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 3, \"code\": \"OP-A100-3\", \"name\": \"总装测试站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 30, \"predecessor_id\": 2, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 4, \"code\": \"OP-A100-4\", \"name\": \"贴标包装站\", \"is_key\": 1, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 40, \"predecessor_id\": 3, \"standard_minutes\": 2.0, \"output_material_id\": null}]','PRODUCTION_COMPLETED',1,'2026-10-24 02:25:38');
INSERT INTO `mm_work_order` (`id`, `code`, `plan_id`, `bom_id`, `route_id`, `quantity`, `bom_snapshot`, `route_snapshot`, `status`, `created_by`, `created_at`) VALUES (3,'MO-000005',10,3,3,10,'[{\"id\": 23, \"bom_id\": 3, \"quantity\": 1.0, \"created_at\": \"2026-10-24 10:25:38\", \"material_id\": 4, \"parent_material_id\": 14}, {\"id\": 22, \"bom_id\": 3, \"quantity\": 2.0, \"created_at\": \"2026-10-24 10:25:38\", \"material_id\": 5, \"parent_material_id\": 14}, {\"id\": 21, \"bom_id\": 3, \"quantity\": 1.0, \"created_at\": \"2026-10-24 10:25:38\", \"material_id\": 6, \"parent_material_id\": 14}, {\"id\": 20, \"bom_id\": 3, \"quantity\": 1.0, \"created_at\": \"2026-10-24 10:25:38\", \"material_id\": 7, \"parent_material_id\": 14}]','[{\"id\": 6, \"code\": \"MC-SO-14-102528061580\", \"name\": \"半成品制造\", \"is_key\": 1, \"route_id\": 3, \"created_at\": \"2026-10-24 10:25:38\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 10, \"predecessor_id\": null, \"standard_minutes\": 1.0, \"output_material_id\": null}]','PRODUCTION_COMPLETED',1,'2026-10-24 02:25:38');
INSERT INTO `mm_work_order` (`id`, `code`, `plan_id`, `bom_id`, `route_id`, `quantity`, `bom_snapshot`, `route_snapshot`, `status`, `created_by`, `created_at`) VALUES (4,'MO-000007',11,2,2,10,'[{\"id\": 19, \"bom_id\": 2, \"quantity\": 1.0, \"created_at\": \"2026-10-24 10:25:37\", \"material_id\": 2, \"parent_material_id\": 15}, {\"id\": 18, \"bom_id\": 2, \"quantity\": 1.0, \"created_at\": \"2026-10-24 10:25:37\", \"material_id\": 3, \"parent_material_id\": 15}, {\"id\": 17, \"bom_id\": 2, \"quantity\": 1.0, \"created_at\": \"2026-10-24 10:25:37\", \"material_id\": 8, \"parent_material_id\": 15}, {\"id\": 16, \"bom_id\": 2, \"quantity\": 1.0, \"created_at\": \"2026-10-24 10:25:37\", \"material_id\": 9, \"parent_material_id\": 15}, {\"id\": 15, \"bom_id\": 2, \"quantity\": 4.0, \"created_at\": \"2026-10-24 10:25:37\", \"material_id\": 10, \"parent_material_id\": 15}]','[{\"id\": 5, \"code\": \"MC-SO-15-102528061580\", \"name\": \"半成品制造\", \"is_key\": 1, \"route_id\": 2, \"created_at\": \"2026-10-24 10:25:37\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 10, \"predecessor_id\": null, \"standard_minutes\": 1.0, \"output_material_id\": null}]','PRODUCTION_COMPLETED',1,'2026-10-24 02:25:38');
INSERT INTO `mm_work_order` (`id`, `code`, `plan_id`, `bom_id`, `route_id`, `quantity`, `bom_snapshot`, `route_snapshot`, `status`, `created_by`, `created_at`) VALUES (5,'MO-000009',12,1,1,1,'[{\"id\": 5, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 4, \"parent_material_id\": 14}, {\"id\": 6, \"bom_id\": 1, \"quantity\": 2.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 5, \"parent_material_id\": 14}, {\"id\": 7, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 6, \"parent_material_id\": 14}, {\"id\": 8, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 7, \"parent_material_id\": 14}, {\"id\": 3, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 2, \"parent_material_id\": 15}, {\"id\": 4, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 3, \"parent_material_id\": 15}, {\"id\": 9, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 8, \"parent_material_id\": 15}, {\"id\": 10, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 9, \"parent_material_id\": 15}, {\"id\": 11, \"bom_id\": 1, \"quantity\": 4.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 10, \"parent_material_id\": 15}, {\"id\": 12, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 11, \"parent_material_id\": 16}, {\"id\": 13, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 12, \"parent_material_id\": 16}, {\"id\": 14, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 13, \"parent_material_id\": 16}, {\"id\": 1, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 14, \"parent_material_id\": 16}, {\"id\": 2, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 15, \"parent_material_id\": 16}]','[{\"id\": 1, \"code\": \"OP-A100-1\", \"name\": \"电子装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 10, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 2, \"code\": \"OP-A100-2\", \"name\": \"结构装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 20, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 3, \"code\": \"OP-A100-3\", \"name\": \"总装测试站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 30, \"predecessor_id\": 2, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 4, \"code\": \"OP-A100-4\", \"name\": \"贴标包装站\", \"is_key\": 1, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 40, \"predecessor_id\": 3, \"standard_minutes\": 2.0, \"output_material_id\": null}]','PRODUCTION_COMPLETED',1,'2026-10-24 02:25:41');
INSERT INTO `mm_work_order` (`id`, `code`, `plan_id`, `bom_id`, `route_id`, `quantity`, `bom_snapshot`, `route_snapshot`, `status`, `created_by`, `created_at`) VALUES (6,'MO-000011',13,1,1,1,'[{\"id\": 5, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 4, \"parent_material_id\": 14}, {\"id\": 6, \"bom_id\": 1, \"quantity\": 2.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 5, \"parent_material_id\": 14}, {\"id\": 7, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 6, \"parent_material_id\": 14}, {\"id\": 8, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 7, \"parent_material_id\": 14}, {\"id\": 3, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 2, \"parent_material_id\": 15}, {\"id\": 4, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 3, \"parent_material_id\": 15}, {\"id\": 9, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 8, \"parent_material_id\": 15}, {\"id\": 10, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 9, \"parent_material_id\": 15}, {\"id\": 11, \"bom_id\": 1, \"quantity\": 4.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 10, \"parent_material_id\": 15}, {\"id\": 12, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 11, \"parent_material_id\": 16}, {\"id\": 13, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 12, \"parent_material_id\": 16}, {\"id\": 14, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 13, \"parent_material_id\": 16}, {\"id\": 1, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 14, \"parent_material_id\": 16}, {\"id\": 2, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 15, \"parent_material_id\": 16}]','[{\"id\": 1, \"code\": \"OP-A100-1\", \"name\": \"电子装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 10, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 2, \"code\": \"OP-A100-2\", \"name\": \"结构装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 20, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 3, \"code\": \"OP-A100-3\", \"name\": \"总装测试站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 30, \"predecessor_id\": 2, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 4, \"code\": \"OP-A100-4\", \"name\": \"贴标包装站\", \"is_key\": 1, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 40, \"predecessor_id\": 3, \"standard_minutes\": 2.0, \"output_material_id\": null}]','PRODUCTION_COMPLETED',1,'2026-10-24 02:25:41');
INSERT INTO `mm_work_order` (`id`, `code`, `plan_id`, `bom_id`, `route_id`, `quantity`, `bom_snapshot`, `route_snapshot`, `status`, `created_by`, `created_at`) VALUES (7,'MO-000013',14,1,1,1,'[{\"id\": 5, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 4, \"parent_material_id\": 14}, {\"id\": 6, \"bom_id\": 1, \"quantity\": 2.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 5, \"parent_material_id\": 14}, {\"id\": 7, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 6, \"parent_material_id\": 14}, {\"id\": 8, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 7, \"parent_material_id\": 14}, {\"id\": 3, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 2, \"parent_material_id\": 15}, {\"id\": 4, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 3, \"parent_material_id\": 15}, {\"id\": 9, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 8, \"parent_material_id\": 15}, {\"id\": 10, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 9, \"parent_material_id\": 15}, {\"id\": 11, \"bom_id\": 1, \"quantity\": 4.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 10, \"parent_material_id\": 15}, {\"id\": 12, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 11, \"parent_material_id\": 16}, {\"id\": 13, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 12, \"parent_material_id\": 16}, {\"id\": 14, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 13, \"parent_material_id\": 16}, {\"id\": 1, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 14, \"parent_material_id\": 16}, {\"id\": 2, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 15, \"parent_material_id\": 16}]','[{\"id\": 1, \"code\": \"OP-A100-1\", \"name\": \"电子装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 10, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 2, \"code\": \"OP-A100-2\", \"name\": \"结构装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 20, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 3, \"code\": \"OP-A100-3\", \"name\": \"总装测试站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 30, \"predecessor_id\": 2, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 4, \"code\": \"OP-A100-4\", \"name\": \"贴标包装站\", \"is_key\": 1, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 40, \"predecessor_id\": 3, \"standard_minutes\": 2.0, \"output_material_id\": null}]','SCRAP_HOLD',1,'2026-10-24 02:25:45');
INSERT INTO `mm_work_order` (`id`, `code`, `plan_id`, `bom_id`, `route_id`, `quantity`, `bom_snapshot`, `route_snapshot`, `status`, `created_by`, `created_at`) VALUES (8,'MO-000015',15,1,1,1,'[{\"id\": 5, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 4, \"parent_material_id\": 14}, {\"id\": 6, \"bom_id\": 1, \"quantity\": 2.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 5, \"parent_material_id\": 14}, {\"id\": 7, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 6, \"parent_material_id\": 14}, {\"id\": 8, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 7, \"parent_material_id\": 14}, {\"id\": 3, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 2, \"parent_material_id\": 15}, {\"id\": 4, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 3, \"parent_material_id\": 15}, {\"id\": 9, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 8, \"parent_material_id\": 15}, {\"id\": 10, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 9, \"parent_material_id\": 15}, {\"id\": 11, \"bom_id\": 1, \"quantity\": 4.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 10, \"parent_material_id\": 15}, {\"id\": 12, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 11, \"parent_material_id\": 16}, {\"id\": 13, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 12, \"parent_material_id\": 16}, {\"id\": 14, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 13, \"parent_material_id\": 16}, {\"id\": 1, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 14, \"parent_material_id\": 16}, {\"id\": 2, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 15, \"parent_material_id\": 16}]','[{\"id\": 1, \"code\": \"OP-A100-1\", \"name\": \"电子装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 10, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 2, \"code\": \"OP-A100-2\", \"name\": \"结构装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 20, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 3, \"code\": \"OP-A100-3\", \"name\": \"总装测试站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 30, \"predecessor_id\": 2, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 4, \"code\": \"OP-A100-4\", \"name\": \"贴标包装站\", \"is_key\": 1, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 40, \"predecessor_id\": 3, \"standard_minutes\": 2.0, \"output_material_id\": null}]','CREATED',1,'2026-10-24 02:25:47');
INSERT INTO `mm_work_order` (`id`, `code`, `plan_id`, `bom_id`, `route_id`, `quantity`, `bom_snapshot`, `route_snapshot`, `status`, `created_by`, `created_at`) VALUES (9,'MO-000017',16,1,1,2,'[{\"id\": 5, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 4, \"parent_material_id\": 14}, {\"id\": 6, \"bom_id\": 1, \"quantity\": 2.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 5, \"parent_material_id\": 14}, {\"id\": 7, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 6, \"parent_material_id\": 14}, {\"id\": 8, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 7, \"parent_material_id\": 14}, {\"id\": 3, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 2, \"parent_material_id\": 15}, {\"id\": 4, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 3, \"parent_material_id\": 15}, {\"id\": 9, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 8, \"parent_material_id\": 15}, {\"id\": 10, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 9, \"parent_material_id\": 15}, {\"id\": 11, \"bom_id\": 1, \"quantity\": 4.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 10, \"parent_material_id\": 15}, {\"id\": 12, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 11, \"parent_material_id\": 16}, {\"id\": 13, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 12, \"parent_material_id\": 16}, {\"id\": 14, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 13, \"parent_material_id\": 16}, {\"id\": 1, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 14, \"parent_material_id\": 16}, {\"id\": 2, \"bom_id\": 1, \"quantity\": 1.0, \"created_at\": \"2026-10-19 08:41:54\", \"material_id\": 15, \"parent_material_id\": 16}]','[{\"id\": 1, \"code\": \"OP-A100-1\", \"name\": \"电子装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 10, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 2, \"code\": \"OP-A100-2\", \"name\": \"结构装配站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 20, \"predecessor_id\": null, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 3, \"code\": \"OP-A100-3\", \"name\": \"总装测试站\", \"is_key\": 0, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 30, \"predecessor_id\": 2, \"standard_minutes\": 2.0, \"output_material_id\": null}, {\"id\": 4, \"code\": \"OP-A100-4\", \"name\": \"贴标包装站\", \"is_key\": 1, \"route_id\": 1, \"created_at\": \"2026-10-19 08:41:54\", \"station_id\": 5, \"requires_qc\": 1, \"sequence_no\": 40, \"predecessor_id\": 3, \"standard_minutes\": 2.0, \"output_material_id\": null}]','PRODUCTION_COMPLETED',1,'2026-10-24 02:25:47');
/*!40000 ALTER TABLE `mm_work_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_work_output`
--

DROP TABLE IF EXISTS `mm_work_output`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_work_output` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `operation_id` bigint NOT NULL,
  `material_id` bigint DEFAULT NULL,
  `is_key` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_work_output` (`work_order_id`,`operation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_work_output`
--

LOCK TABLES `mm_work_output` WRITE;
/*!40000 ALTER TABLE `mm_work_output` DISABLE KEYS */;
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (1,1,1,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (2,1,2,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (3,1,3,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (4,1,4,16,1);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (9,2,1,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (10,2,2,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (11,2,3,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (12,2,4,16,1);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (13,3,6,14,1);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (14,4,5,15,1);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (15,5,1,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (16,5,2,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (17,5,3,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (18,5,4,16,1);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (19,6,1,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (20,6,2,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (21,6,3,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (22,6,4,16,1);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (23,7,1,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (24,7,2,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (25,7,3,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (26,7,4,16,1);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (27,8,1,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (28,8,2,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (29,8,3,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (30,8,4,16,1);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (31,9,1,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (32,9,2,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (33,9,3,NULL,0);
INSERT INTO `mm_work_output` (`id`, `work_order_id`, `operation_id`, `material_id`, `is_key`) VALUES (34,9,4,16,1);
/*!40000 ALTER TABLE `mm_work_output` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_work_product`
--

DROP TABLE IF EXISTS `mm_work_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_work_product` (
  `work_order_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  PRIMARY KEY (`work_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_work_product`
--

LOCK TABLES `mm_work_product` WRITE;
/*!40000 ALTER TABLE `mm_work_product` DISABLE KEYS */;
INSERT INTO `mm_work_product` (`work_order_id`, `material_id`, `quantity`) VALUES (1,16,100);
INSERT INTO `mm_work_product` (`work_order_id`, `material_id`, `quantity`) VALUES (2,16,10);
INSERT INTO `mm_work_product` (`work_order_id`, `material_id`, `quantity`) VALUES (3,14,10);
INSERT INTO `mm_work_product` (`work_order_id`, `material_id`, `quantity`) VALUES (4,15,10);
INSERT INTO `mm_work_product` (`work_order_id`, `material_id`, `quantity`) VALUES (5,16,1);
INSERT INTO `mm_work_product` (`work_order_id`, `material_id`, `quantity`) VALUES (6,16,1);
INSERT INTO `mm_work_product` (`work_order_id`, `material_id`, `quantity`) VALUES (7,16,1);
INSERT INTO `mm_work_product` (`work_order_id`, `material_id`, `quantity`) VALUES (8,16,1);
INSERT INTO `mm_work_product` (`work_order_id`, `material_id`, `quantity`) VALUES (9,16,2);
/*!40000 ALTER TABLE `mm_work_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_work_relation`
--

DROP TABLE IF EXISTS `mm_work_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_work_relation` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `parent_work_order_id` bigint NOT NULL,
  `child_work_order_id` bigint NOT NULL,
  `material_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `child_work_order_id` (`child_work_order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_work_relation`
--

LOCK TABLES `mm_work_relation` WRITE;
/*!40000 ALTER TABLE `mm_work_relation` DISABLE KEYS */;
INSERT INTO `mm_work_relation` (`id`, `parent_work_order_id`, `child_work_order_id`, `material_id`) VALUES (1,2,3,14);
INSERT INTO `mm_work_relation` (`id`, `parent_work_order_id`, `child_work_order_id`, `material_id`) VALUES (2,2,4,15);
/*!40000 ALTER TABLE `mm_work_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mm_workshop`
--

DROP TABLE IF EXISTS `mm_workshop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mm_workshop` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(60) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mm_workshop`
--

LOCK TABLES `mm_workshop` WRITE;
/*!40000 ALTER TABLE `mm_workshop` DISABLE KEYS */;
INSERT INTO `mm_workshop` (`id`, `code`, `name`, `created_at`) VALUES (1,'WS-A100','鼠标装配车间','2026-10-19 00:41:54');
INSERT INTO `mm_workshop` (`id`, `code`, `name`, `created_at`) VALUES (2,'MC-WS-102528061580','隔离验收车间','2026-10-24 02:25:30');
/*!40000 ALTER TABLE `mm_workshop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_attendance`
--

DROP TABLE IF EXISTS `t_attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_attendance` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '考勤ID',
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `user_name` varchar(50) NOT NULL COMMENT '用户姓名',
  `attendance_date` date NOT NULL COMMENT '考勤日期',
  `check_in_time` datetime DEFAULT NULL COMMENT '签到时间',
  `check_out_time` datetime DEFAULT NULL COMMENT '签退时间',
  `work_hours` decimal(5,2) DEFAULT NULL COMMENT '工时',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='考勤记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_attendance`
--

LOCK TABLES `t_attendance` WRITE;
/*!40000 ALTER TABLE `t_attendance` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_bom`
--

DROP TABLE IF EXISTS `t_bom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_bom` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'BOM ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `material_name` varchar(100) NOT NULL COMMENT '物料名称',
  `quantity` decimal(10,2) NOT NULL COMMENT '用量',
  `unit` varchar(20) NOT NULL COMMENT '单位',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='BOM表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_bom`
--

LOCK TABLES `t_bom` WRITE;
/*!40000 ALTER TABLE `t_bom` DISABLE KEYS */;
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (25,8,4,'PCB主板',1.00,'块','BOM版本 1');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (26,8,5,'微动开关',2.00,'个','BOM版本 1');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (27,8,6,'滚轮编码器',1.00,'个','BOM版本 1');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (28,8,7,'USB连接线',1.00,'根','BOM版本 1');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (29,7,2,'鼠标上盖',1.00,'个','BOM版本 1');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (30,7,3,'鼠标下盖',1.00,'个','BOM版本 1');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (31,7,8,'滚轮组件',1.00,'个','BOM版本 1');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (32,7,9,'光学透镜',1.00,'个','BOM版本 1');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (33,7,10,'固定螺钉',4.00,'颗','BOM版本 1');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (82,6,11,'防滑脚贴',1.00,'套','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (83,6,12,'产品铭牌',1.00,'张','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (84,6,13,'包装盒',1.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (85,6,4,'PCB主板',1.00,'块','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (86,6,5,'微动开关',2.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (87,6,6,'滚轮编码器',1.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (88,6,7,'USB连接线',1.00,'根','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (89,6,2,'鼠标上盖',1.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (90,6,3,'鼠标下盖',1.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (91,6,8,'滚轮组件',1.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (92,6,9,'光学透镜',1.00,'个','BOM版本 1.0');
INSERT INTO `t_bom` (`id`, `product_id`, `material_id`, `material_name`, `quantity`, `unit`, `remark`) VALUES (93,6,10,'固定螺钉',4.00,'颗','BOM版本 1.0');
/*!40000 ALTER TABLE `t_bom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_bom_item`
--

DROP TABLE IF EXISTS `t_bom_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_bom_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'BOM明细ID',
  `bom_id` bigint NOT NULL COMMENT 'BOM ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `quantity` decimal(10,2) NOT NULL COMMENT '用量',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='BOM明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_bom_item`
--

LOCK TABLES `t_bom_item` WRITE;
/*!40000 ALTER TABLE `t_bom_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_bom_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_customer`
--

DROP TABLE IF EXISTS `t_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_customer` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '客户ID',
  `customer_code` varchar(50) NOT NULL COMMENT '客户编码',
  `customer_name` varchar(100) NOT NULL COMMENT '客户名称',
  `contact_person` varchar(50) DEFAULT NULL COMMENT '联系人',
  `phone` varchar(20) DEFAULT NULL COMMENT '电话',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `address` varchar(255) DEFAULT NULL COMMENT '地址',
  `status` varchar(30) NOT NULL DEFAULT '1' COMMENT '状态',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_code` (`customer_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='客户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_customer`
--

LOCK TABLES `t_customer` WRITE;
/*!40000 ALTER TABLE `t_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_department`
--

DROP TABLE IF EXISTS `t_department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_department` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '部门ID',
  `parent_id` bigint NOT NULL DEFAULT '0' COMMENT '父部门ID',
  `dept_name` varchar(50) NOT NULL COMMENT '部门名称',
  `dept_code` varchar(50) NOT NULL COMMENT '部门编码',
  `leader_id` bigint DEFAULT NULL COMMENT '负责人ID',
  `leader_name` varchar(50) DEFAULT NULL COMMENT '负责人姓名',
  `sort` int NOT NULL DEFAULT '0' COMMENT '显示顺序',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：-1删除 0禁用 1活跃',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='部门表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_department`
--

LOCK TABLES `t_department` WRITE;
/*!40000 ALTER TABLE `t_department` DISABLE KEYS */;
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (1,0,'总经办','CEO',NULL,NULL,1,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (2,0,'生产部','PROD',NULL,NULL,2,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (3,0,'质检部','QC',NULL,NULL,3,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (4,0,'仓储部','WAREHOUSE',NULL,NULL,4,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (5,0,'采购部','PURCHASE',NULL,NULL,5,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (6,0,'销售部','SALES',NULL,NULL,6,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (7,0,'设备部','EQUIPMENT',NULL,NULL,7,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (8,0,'财务部','FINANCE',NULL,NULL,8,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_department` (`id`, `parent_id`, `dept_name`, `dept_code`, `leader_id`, `leader_name`, `sort`, `status`, `create_time`, `update_time`) VALUES (9,0,'人力资源部','HR',NULL,NULL,9,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
/*!40000 ALTER TABLE `t_department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_dict`
--

DROP TABLE IF EXISTS `t_dict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_dict` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '字典ID',
  `dict_name` varchar(100) NOT NULL COMMENT '字典名称',
  `dict_type` varchar(100) NOT NULL COMMENT '字典类型',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0禁用 1启用',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `dict_type` (`dict_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='字典类型表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_dict`
--

LOCK TABLES `t_dict` WRITE;
/*!40000 ALTER TABLE `t_dict` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_dict` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_dict_item`
--

DROP TABLE IF EXISTS `t_dict_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_dict_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '字典数据ID',
  `dict_type` varchar(100) NOT NULL COMMENT '字典类型',
  `item_label` varchar(100) NOT NULL COMMENT '字典标签',
  `item_value` varchar(100) NOT NULL COMMENT '字典值',
  `sort` int NOT NULL DEFAULT '0' COMMENT '显示顺序',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0禁用 1启用',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='字典数据表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_dict_item`
--

LOCK TABLES `t_dict_item` WRITE;
/*!40000 ALTER TABLE `t_dict_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_dict_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_equipment`
--

DROP TABLE IF EXISTS `t_equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_equipment` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '设备ID',
  `equipment_code` varchar(50) NOT NULL COMMENT '设备编码',
  `equipment_name` varchar(100) NOT NULL COMMENT '设备名称',
  `equipment_type` varchar(50) DEFAULT NULL COMMENT '设备类型',
  `model` varchar(50) DEFAULT NULL COMMENT '型号',
  `manufacturer` varchar(100) DEFAULT NULL COMMENT '厂商',
  `purchase_date` date DEFAULT NULL COMMENT '购置日期',
  `purchase_price` decimal(12,2) DEFAULT '0.00' COMMENT '购置价格',
  `warranty_period` int DEFAULT NULL COMMENT '保修期',
  `location` varchar(100) DEFAULT NULL COMMENT '设备位置',
  `status` varchar(30) NOT NULL DEFAULT 'NORMAL' COMMENT '状态：NORMAL正常 REPAIR_REQUESTED报修中 REPAIRING维修中 REPAIRED已维修 SCRAPPED报废',
  `responsible_id` bigint DEFAULT NULL COMMENT '负责人ID',
  `responsible_name` varchar(50) DEFAULT NULL COMMENT '负责人姓名',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `equipment_code` (`equipment_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='设备表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_equipment`
--

LOCK TABLES `t_equipment` WRITE;
/*!40000 ALTER TABLE `t_equipment` DISABLE KEYS */;
INSERT INTO `t_equipment` (`id`, `equipment_code`, `equipment_name`, `equipment_type`, `model`, `manufacturer`, `purchase_date`, `purchase_price`, `warranty_period`, `location`, `status`, `responsible_id`, `responsible_name`, `remark`, `create_time`, `update_time`, `is_deleted`) VALUES (1,'EQ-A100-01','A100功能测试台',NULL,'USB测试台',NULL,NULL,0.00,NULL,'总装测试站','NORMAL',NULL,NULL,NULL,'2026-10-19 08:41:54','2026-10-24 10:18:02',0);
INSERT INTO `t_equipment` (`id`, `equipment_code`, `equipment_name`, `equipment_type`, `model`, `manufacturer`, `purchase_date`, `purchase_price`, `warranty_period`, `location`, `status`, `responsible_id`, `responsible_name`, `remark`, `create_time`, `update_time`, `is_deleted`) VALUES (2,'MC-EQ-102528061580','隔离设备',NULL,'TEST',NULL,NULL,0.00,NULL,'隔离车间','NORMAL',NULL,NULL,NULL,'2026-10-24 10:25:30','2026-10-24 10:25:37',0);
/*!40000 ALTER TABLE `t_equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_inventory`
--

DROP TABLE IF EXISTS `t_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_inventory` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '库存ID',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `location_id` bigint DEFAULT NULL COMMENT '库位ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_id` bigint DEFAULT NULL COMMENT '批次ID',
  `quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '库存数量',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '最后更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=176 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='库存表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_inventory`
--

LOCK TABLES `t_inventory` WRITE;
/*!40000 ALTER TABLE `t_inventory` DISABLE KEYS */;
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (1,2,2,2,1,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (2,2,2,3,2,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (3,2,2,4,3,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (4,2,2,5,4,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (5,2,2,6,5,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (6,2,2,7,6,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (7,2,2,8,7,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (8,2,2,9,8,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (9,2,2,10,9,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (10,2,2,11,10,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (11,2,2,12,11,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (12,2,2,13,12,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (13,2,2,2,13,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (14,2,2,3,14,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (15,2,2,4,15,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (16,2,2,5,16,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (17,2,2,6,17,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (18,2,2,7,18,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (19,2,2,8,19,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (20,2,2,9,20,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (21,2,2,10,21,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (22,2,2,11,22,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (23,2,2,12,23,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (24,2,2,13,24,0.00,'2026-10-24 10:25:33',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (25,3,3,2,1,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (26,3,3,2,13,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (27,3,3,3,2,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (28,3,3,3,14,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (29,3,3,4,3,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (30,3,3,4,15,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (31,3,3,5,4,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (32,3,3,5,16,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (33,3,3,6,5,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (34,3,3,6,17,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (35,3,3,7,6,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (36,3,3,7,18,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (37,3,3,8,7,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (38,3,3,8,19,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (39,3,3,9,8,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (40,3,3,9,20,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (41,3,3,10,9,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (42,3,3,10,21,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (43,3,3,11,10,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (44,3,3,11,22,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (45,3,3,12,11,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (46,3,3,12,23,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (47,3,3,13,12,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (48,3,3,13,24,0.00,'2026-10-24 10:25:34',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (49,3,3,16,25,0.00,'2026-10-24 10:25:35',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (50,4,4,16,25,10.00,'2026-10-24 10:25:36',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (51,2,2,2,26,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (52,2,2,4,27,0.00,'2026-10-24 10:25:39',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (53,2,2,5,28,0.00,'2026-10-24 10:25:39',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (54,2,2,6,29,0.00,'2026-10-24 10:25:39',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (55,2,2,7,30,0.00,'2026-10-24 10:25:39',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (56,3,3,4,27,0.00,'2026-10-24 10:25:39',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (57,3,3,5,28,0.00,'2026-10-24 10:25:39',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (58,3,3,6,29,0.00,'2026-10-24 10:25:39',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (59,3,3,7,30,0.00,'2026-10-24 10:25:39',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (60,3,3,14,31,0.00,'2026-10-24 10:25:41',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (61,4,4,14,31,0.00,'2026-10-24 10:25:41',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (62,2,2,3,32,0.00,'2026-10-24 10:25:40',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (63,2,2,8,33,0.00,'2026-10-24 10:25:40',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (64,2,2,9,34,0.00,'2026-10-24 10:25:40',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (65,2,2,10,35,0.00,'2026-10-24 10:25:40',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (66,3,3,2,26,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (67,3,3,3,32,0.00,'2026-10-24 10:25:40',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (68,3,3,8,33,0.00,'2026-10-24 10:25:40',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (69,3,3,9,34,0.00,'2026-10-24 10:25:40',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (70,3,3,10,35,0.00,'2026-10-24 10:25:40',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (71,3,3,15,36,0.00,'2026-10-24 10:25:41',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (72,4,4,15,36,0.00,'2026-10-24 10:25:41',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (73,2,2,11,37,0.00,'2026-10-24 10:25:40',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (74,2,2,12,38,0.00,'2026-10-24 10:25:40',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (75,2,2,13,39,0.00,'2026-10-24 10:25:40',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (76,3,3,11,37,0.00,'2026-10-24 10:25:41',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (77,3,3,12,38,0.00,'2026-10-24 10:25:41',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (78,3,3,13,39,0.00,'2026-10-24 10:25:41',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (79,3,3,16,40,0.00,'2026-10-24 10:25:41',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (80,4,4,16,40,10.00,'2026-10-24 10:25:41',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (81,2,2,3,41,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (82,2,2,4,42,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (83,2,2,5,43,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (84,2,2,6,44,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (85,2,2,7,45,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (86,2,2,8,46,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (87,2,2,9,47,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (88,2,2,10,48,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (89,2,2,11,49,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (90,2,2,12,50,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (91,2,2,13,51,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (92,3,3,3,41,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (93,3,3,4,42,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (94,3,3,5,43,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (95,3,3,6,44,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (96,3,3,7,45,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (97,3,3,8,46,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (98,3,3,9,47,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (99,3,3,10,48,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (100,3,3,11,49,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (101,3,3,12,50,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (102,3,3,13,51,0.00,'2026-10-24 10:25:42',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (103,3,3,16,52,0.00,'2026-10-24 10:25:43',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (104,4,4,16,52,0.00,'2026-10-24 10:25:45',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (105,2,2,3,53,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (106,2,2,4,54,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (107,2,2,5,55,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (108,2,2,6,56,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (109,2,2,7,57,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (110,2,2,8,58,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (111,2,2,9,59,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (112,2,2,10,60,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (113,2,2,11,61,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (114,2,2,12,62,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (115,2,2,13,63,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (116,3,3,3,53,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (117,3,3,4,54,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (118,3,3,5,55,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (119,3,3,6,56,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (120,3,3,7,57,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (121,3,3,8,58,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (122,3,3,9,59,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (123,3,3,10,60,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (124,3,3,11,61,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (125,3,3,12,62,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (126,3,3,13,63,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (127,3,3,16,64,0.00,'2026-10-24 10:25:44',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (128,4,4,16,64,0.00,'2026-10-24 10:25:45',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (129,2,2,2,65,1.00,'2026-10-24 10:25:45',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (130,2,2,3,66,0.00,'2026-10-24 10:25:46',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (131,2,2,4,67,0.00,'2026-10-24 10:25:46',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (132,2,2,5,68,0.00,'2026-10-24 10:25:46',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (133,2,2,6,69,0.00,'2026-10-24 10:25:46',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (134,2,2,7,70,0.00,'2026-10-24 10:25:46',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (135,2,2,8,71,0.00,'2026-10-24 10:25:46',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (136,2,2,9,72,0.00,'2026-10-24 10:25:46',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (137,2,2,10,73,0.00,'2026-10-24 10:25:46',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (138,2,2,11,74,0.00,'2026-10-24 10:25:46',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (139,2,2,12,75,0.00,'2026-10-24 10:25:46',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (140,2,2,13,76,0.00,'2026-10-24 10:25:46',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (141,3,3,3,66,0.00,'2026-10-24 10:25:47',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (142,3,3,4,67,0.00,'2026-10-24 10:25:47',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (143,3,3,5,68,0.00,'2026-10-24 10:25:47',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (144,3,3,6,69,0.00,'2026-10-24 10:25:47',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (145,3,3,7,70,0.00,'2026-10-24 10:25:47',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (146,3,3,8,71,0.00,'2026-10-24 10:25:47',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (147,3,3,9,72,0.00,'2026-10-24 10:25:47',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (148,3,3,10,73,0.00,'2026-10-24 10:25:47',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (149,3,3,11,74,0.00,'2026-10-24 10:25:47',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (150,3,3,12,75,0.00,'2026-10-24 10:25:47',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (151,3,3,13,76,0.00,'2026-10-24 10:25:47',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (152,3,3,16,77,0.00,'2026-10-24 10:25:47',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (153,2,2,3,78,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (154,2,2,4,79,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (155,2,2,5,80,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (156,2,2,6,81,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (157,2,2,7,82,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (158,2,2,8,83,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (159,2,2,9,84,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (160,2,2,10,85,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (161,2,2,11,86,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (162,2,2,12,87,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (163,2,2,13,88,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (164,3,3,3,78,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (165,3,3,4,79,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (166,3,3,5,80,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (167,3,3,6,81,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (168,3,3,7,82,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (169,3,3,8,83,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (170,3,3,9,84,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (171,3,3,10,85,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (172,3,3,11,86,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (173,3,3,12,87,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (174,3,3,13,88,0.00,'2026-10-24 10:25:49',0);
INSERT INTO `t_inventory` (`id`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `last_update_time`, `is_deleted`) VALUES (175,3,3,16,89,2.00,'2026-10-24 10:25:50',0);
/*!40000 ALTER TABLE `t_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_inventory_in`
--

DROP TABLE IF EXISTS `t_inventory_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_inventory_in` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '入库单ID',
  `in_no` varchar(50) NOT NULL COMMENT '入库单号',
  `in_type` tinyint NOT NULL COMMENT '入库类型',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `material_name` varchar(100) NOT NULL COMMENT '物料名称',
  `quantity` int NOT NULL COMMENT '入库数量',
  `unit_price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '总金额',
  `supplier_id` bigint DEFAULT NULL COMMENT '供应商ID',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `in_date` date NOT NULL COMMENT '入库日期',
  `create_by` bigint NOT NULL COMMENT '操作人ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `in_no` (`in_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='入库单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_inventory_in`
--

LOCK TABLES `t_inventory_in` WRITE;
/*!40000 ALTER TABLE `t_inventory_in` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_inventory_in` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_inventory_out`
--

DROP TABLE IF EXISTS `t_inventory_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_inventory_out` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '出库单ID',
  `out_no` varchar(50) NOT NULL COMMENT '出库单号',
  `out_type` tinyint NOT NULL COMMENT '出库类型',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `material_name` varchar(100) NOT NULL COMMENT '物料名称',
  `quantity` int NOT NULL COMMENT '出库数量',
  `unit_price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `total_amount` decimal(10,2) DEFAULT NULL COMMENT '总金额',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `out_date` date NOT NULL COMMENT '出库日期',
  `create_by` bigint NOT NULL COMMENT '操作人ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `out_no` (`out_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='出库单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_inventory_out`
--

LOCK TABLES `t_inventory_out` WRITE;
/*!40000 ALTER TABLE `t_inventory_out` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_inventory_out` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_inventory_transaction`
--

DROP TABLE IF EXISTS `t_inventory_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_inventory_transaction` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '库存流水ID',
  `transaction_no` varchar(80) NOT NULL COMMENT '库存流水编号',
  `transaction_type` varchar(10) NOT NULL COMMENT '流水方向：IN入库 OUT出库',
  `business_type` varchar(30) DEFAULT NULL COMMENT '业务类型',
  `source_order_id` bigint DEFAULT NULL COMMENT '来源单据ID',
  `source_order_no` varchar(80) DEFAULT NULL COMMENT '来源单据编号',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `location_id` bigint DEFAULT NULL COMMENT '库位ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_id` bigint DEFAULT NULL COMMENT '批次ID',
  `quantity` decimal(10,2) NOT NULL COMMENT '变动数量',
  `before_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变动前数量',
  `after_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变动后数量',
  `created_by` bigint DEFAULT NULL COMMENT '操作人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_no` (`transaction_no`)
) ENGINE=InnoDB AUTO_INCREMENT=391 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='库存流水表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_inventory_transaction`
--

LOCK TABLES `t_inventory_transaction` WRITE;
/*!40000 ALTER TABLE `t_inventory_transaction` DISABLE KEYS */;
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (1,'INV-IN-20261024102531900-8840648156600','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,2,1,50.00,0.00,50.00,6,'2026-10-24 10:25:32',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (2,'INV-IN-20261024102531911-8840658482000','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,3,2,50.00,0.00,50.00,6,'2026-10-24 10:25:32',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (3,'INV-IN-20261024102531926-8840673446400','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,4,3,50.00,0.00,50.00,6,'2026-10-24 10:25:32',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (4,'INV-IN-20261024102531930-8840677833800','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,5,4,100.00,0.00,100.00,6,'2026-10-24 10:25:32',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (5,'INV-IN-20261024102531935-8840683159800','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,6,5,50.00,0.00,50.00,6,'2026-10-24 10:25:32',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (6,'INV-IN-20261024102531942-8840689714500','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,7,6,50.00,0.00,50.00,6,'2026-10-24 10:25:32',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (7,'INV-IN-20261024102531947-8840694684700','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,8,7,50.00,0.00,50.00,6,'2026-10-24 10:25:32',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (8,'INV-IN-20261024102531957-8840704294200','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,9,8,50.00,0.00,50.00,6,'2026-10-24 10:25:32',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (9,'INV-IN-20261024102531962-8840709782800','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,10,9,200.00,0.00,200.00,6,'2026-10-24 10:25:32',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (10,'INV-IN-20261024102531968-8840715253300','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,11,10,50.00,0.00,50.00,6,'2026-10-24 10:25:32',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (11,'INV-IN-20261024102531975-8840723260600','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,12,11,50.00,0.00,50.00,6,'2026-10-24 10:25:32',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (12,'INV-IN-20261024102531979-8840727026400','IN','PURCHASE_RECEIPT',1,'PR-000001',2,2,13,12,50.00,0.00,50.00,6,'2026-10-24 10:25:32',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (13,'INV-IN-20261024102532669-8841416842000','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,2,13,50.00,0.00,50.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (14,'INV-IN-20261024102532673-8841420818600','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,3,14,50.00,0.00,50.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (15,'INV-IN-20261024102532676-8841424003500','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,4,15,50.00,0.00,50.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (16,'INV-IN-20261024102532681-8841428562400','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,5,16,100.00,0.00,100.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (17,'INV-IN-20261024102532689-8841437213700','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,6,17,50.00,0.00,50.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (18,'INV-IN-20261024102532693-8841440892900','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,7,18,50.00,0.00,50.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (19,'INV-IN-20261024102532697-8841444515100','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,8,19,50.00,0.00,50.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (20,'INV-IN-20261024102532706-8841453055900','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,9,20,50.00,0.00,50.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (21,'INV-IN-20261024102532709-8841456607000','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,10,21,200.00,0.00,200.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (22,'INV-IN-20261024102532717-8841464433600','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,11,22,50.00,0.00,50.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (23,'INV-IN-20261024102532721-8841468482500','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,12,23,50.00,0.00,50.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (24,'INV-IN-20261024102532724-8841471580800','IN','PURCHASE_RECEIPT',2,'PR-000002',2,2,13,24,50.00,0.00,50.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (25,'INV-OUT-20261024102532984-8841730993300','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,2,1,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (26,'INV-OUT-20261024102532992-8841739427700','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,2,13,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (27,'INV-OUT-20261024102533001-8841747675000','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,3,2,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (28,'INV-OUT-20261024102533004-8841751581500','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,3,14,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (29,'INV-OUT-20261024102533008-8841756064400','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,4,3,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (30,'INV-OUT-20261024102533014-8841761975100','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,4,15,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (31,'INV-OUT-20261024102533019-8841766644800','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,5,4,100.00,100.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (32,'INV-OUT-20261024102533023-8841770152700','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,5,16,100.00,100.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (33,'INV-OUT-20261024102533030-8841778173300','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,6,5,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (34,'INV-OUT-20261024102533035-8841783087500','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,6,17,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (35,'INV-OUT-20261024102533040-8841786960200','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,7,6,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (36,'INV-OUT-20261024102533047-8841794524900','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,7,18,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (37,'INV-OUT-20261024102533052-8841799973500','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,8,7,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (38,'INV-OUT-20261024102533058-8841805786000','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,8,19,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (39,'INV-OUT-20261024102533064-8841811585500','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,9,8,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (40,'INV-OUT-20261024102533070-8841817827400','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,9,20,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (41,'INV-OUT-20261024102533078-8841825852900','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,10,9,200.00,200.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (42,'INV-OUT-20261024102533081-8841828870800','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,10,21,200.00,200.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (43,'INV-OUT-20261024102533085-8841833001800','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,11,10,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (44,'INV-OUT-20261024102533092-8841839601400','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,11,22,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (45,'INV-OUT-20261024102533096-8841843923600','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,12,11,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (46,'INV-OUT-20261024102533107-8841854725900','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,12,23,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (47,'INV-OUT-20261024102533112-8841859256000','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,13,12,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (48,'INV-OUT-20261024102533116-8841863113100','OUT','PRODUCTION_ISSUE',1,'ISS-000001',2,2,13,24,50.00,50.00,0.00,6,'2026-10-24 10:25:33',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (49,'INV-IN-20261024102533127-8841874356300','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,2,1,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (50,'INV-IN-20261024102533135-8841882942400','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,2,13,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (51,'INV-IN-20261024102533139-8841886951100','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,3,2,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (52,'INV-IN-20261024102533143-8841890505600','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,3,14,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (53,'INV-IN-20261024102533152-8841899569300','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,4,3,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (54,'INV-IN-20261024102533157-8841904971500','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,4,15,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (55,'INV-IN-20261024102533166-8841913490600','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,5,4,100.00,0.00,100.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (56,'INV-IN-20261024102533172-8841919411100','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,5,16,100.00,0.00,100.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (57,'INV-IN-20261024102533177-8841924335700','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,6,5,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (58,'INV-IN-20261024102533184-8841931023600','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,6,17,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (59,'INV-IN-20261024102533187-8841935280700','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,7,6,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (60,'INV-IN-20261024102533192-8841939581700','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,7,18,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (61,'INV-IN-20261024102533201-8841948705400','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,8,7,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (62,'INV-IN-20261024102533206-8841953479000','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,8,19,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (63,'INV-IN-20261024102533211-8841959190500','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,9,8,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (64,'INV-IN-20261024102533216-8841963518800','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,9,20,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (65,'INV-IN-20261024102533220-8841967535400','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,10,9,200.00,0.00,200.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (66,'INV-IN-20261024102533223-8841970965600','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,10,21,200.00,0.00,200.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (67,'INV-IN-20261024102533228-8841975243500','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,11,10,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (68,'INV-IN-20261024102533232-8841979140600','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,11,22,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (69,'INV-IN-20261024102533237-8841984630200','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,12,11,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (70,'INV-IN-20261024102533243-8841990882800','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,12,23,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (71,'INV-IN-20261024102533247-8841995218300','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,13,12,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (72,'INV-IN-20261024102533253-8842000327000','IN','WIP_ISSUE',1,'LINE-ISSUE-1-1',3,3,13,24,50.00,0.00,50.00,6,'2026-10-24 10:25:33','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (73,'INV-OUT-20261024102533640-8842387684900','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,2,1,50.00,50.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (74,'INV-OUT-20261024102533646-8842393409900','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,2,13,10.00,50.00,40.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (75,'INV-OUT-20261024102533651-8842398784500','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,3,2,50.00,50.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (76,'INV-OUT-20261024102533655-8842402699900','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,3,14,10.00,50.00,40.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (77,'INV-OUT-20261024102533662-8842408908200','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,4,3,50.00,50.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (78,'INV-OUT-20261024102533665-8842412415800','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,4,15,10.00,50.00,40.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (79,'INV-OUT-20261024102533670-8842417254000','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,5,4,100.00,100.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (80,'INV-OUT-20261024102533675-8842421957000','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,5,16,20.00,100.00,80.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (81,'INV-OUT-20261024102533679-8842426690900','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,6,5,50.00,50.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (82,'INV-OUT-20261024102533684-8842432175400','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,6,17,10.00,50.00,40.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (83,'INV-OUT-20261024102533691-8842438782200','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,7,6,50.00,50.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (84,'INV-OUT-20261024102533696-8842443339400','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,7,18,10.00,50.00,40.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (85,'INV-OUT-20261024102533701-8842448696500','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,8,7,50.00,50.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (86,'INV-OUT-20261024102533708-8842454691000','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,8,19,10.00,50.00,40.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (87,'INV-OUT-20261024102533711-8842458115900','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,9,8,50.00,50.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (88,'INV-OUT-20261024102533717-8842464641000','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,9,20,10.00,50.00,40.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (89,'INV-OUT-20261024102533730-8842477203100','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,10,9,200.00,200.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (90,'INV-OUT-20261024102533737-8842484274600','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,10,21,40.00,200.00,160.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (91,'INV-OUT-20261024102533741-8842489062500','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,11,10,50.00,50.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (92,'INV-OUT-20261024102533746-8842493201900','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,11,22,10.00,50.00,40.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (93,'INV-OUT-20261024102533753-8842501237400','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,12,11,50.00,50.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (94,'INV-OUT-20261024102533758-8842505605900','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,12,23,10.00,50.00,40.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (95,'INV-OUT-20261024102533762-8842510097200','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,13,12,50.00,50.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (96,'INV-OUT-20261024102533770-8842516656200','OUT','WIP_CONSUME',3,'LINE-CONSUME-1-3',3,3,13,24,10.00,50.00,40.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (97,'INV-OUT-20261024102533930-8842677244300','OUT','WIP_LINE_RETURN',3,'LINE-LINE_RETURN-1-3',3,3,2,13,40.00,40.00,0.00,6,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (98,'INV-IN-20261024102533941-8842688492500','IN','LINE_RETURN',3,'L-RET-000001',2,2,2,13,40.00,0.00,40.00,6,'2026-10-24 10:25:34',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (99,'INV-IN-20261024102534070-8842816992800','IN','WIP_LINE_ISSUE',4,'LINE-LINE_ISSUE-1-4',3,3,2,13,40.00,0.00,40.00,6,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (100,'INV-OUT-20261024102534085-8842832559600','OUT','LINE_ISSUE',2,'ISS-000002',2,2,2,13,40.00,40.00,0.00,6,'2026-10-24 10:25:34',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (101,'INV-OUT-20261024102534136-8842882996800','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,2,13,40.00,40.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (102,'INV-OUT-20261024102534139-8842886772300','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,3,14,40.00,40.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (103,'INV-OUT-20261024102534147-8842894543400','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,4,15,40.00,40.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (104,'INV-OUT-20261024102534154-8842901055200','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,5,16,80.00,80.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (105,'INV-OUT-20261024102534159-8842906682700','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,6,17,40.00,40.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (106,'INV-OUT-20261024102534165-8842911861400','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,7,18,40.00,40.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (107,'INV-OUT-20261024102534169-8842916623800','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,8,19,40.00,40.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (108,'INV-OUT-20261024102534179-8842926625100','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,9,20,40.00,40.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (109,'INV-OUT-20261024102534182-8842930183000','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,10,21,160.00,160.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (110,'INV-OUT-20261024102534190-8842937766900','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,11,22,40.00,40.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (111,'INV-OUT-20261024102534195-8842942511800','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,12,23,40.00,40.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (112,'INV-OUT-20261024102534200-8842947830800','OUT','WIP_CONSUME',4,'LINE-CONSUME-1-4',3,3,13,24,40.00,40.00,0.00,4,'2026-10-24 10:25:34','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (113,'INV-IN-20261024102534844-8843591355500','IN','WIP_OUTPUT',7,'LINE-OUTPUT-1-7',3,3,16,25,100.00,0.00,100.00,4,'2026-10-24 10:25:35','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (114,'INV-OUT-20261024102535009-8843756626700','OUT','WIP_PRODUCTION_RECEIPT',5,'LINE-PRODUCTION_RECEIPT-1-5',3,3,16,25,40.00,100.00,60.00,6,'2026-10-24 10:25:35','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (115,'INV-IN-20261024102535015-8843762517500','IN','PRODUCTION_RECEIPT',4,'FG-IN-000001',4,4,16,25,40.00,0.00,40.00,6,'2026-10-24 10:25:35',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (116,'INV-OUT-20261024102535117-8843864533000','OUT','WIP_PRODUCTION_RECEIPT',6,'LINE-PRODUCTION_RECEIPT-1-6',3,3,16,25,60.00,60.00,0.00,6,'2026-10-24 10:25:35','工单 1 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (117,'INV-IN-20261024102535123-8843869925000','IN','PRODUCTION_RECEIPT',5,'FG-IN-000002',4,4,16,25,60.00,40.00,100.00,6,'2026-10-24 10:25:35',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (118,'INV-OUT-20261024102535362-8844109880800','OUT','SALES_SHIPMENT',3,'SHIP-000001',4,4,16,25,40.00,100.00,60.00,6,'2026-10-24 10:25:35',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (119,'INV-OUT-20261024102535535-8844282508900','OUT','SALES_SHIPMENT',4,'SHIP-000002',4,4,16,25,60.00,60.00,0.00,6,'2026-10-24 10:25:36',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (120,'INV-IN-20261024102535732-8844480430200','IN','SALES_RETURN',6,'S-RET-000001',4,4,16,25,10.00,0.00,10.00,6,'2026-10-24 10:25:36',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (121,'INV-IN-20261024102536506-8845253039500','IN','PURCHASE_RECEIPT',7,'PR-000003',2,2,2,26,20.00,0.00,20.00,6,'2026-10-24 10:25:37',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (122,'INV-OUT-20261024102536597-8845344829600','OUT','PURCHASE_RETURN',5,'P-RET-000001',2,2,2,26,5.00,20.00,15.00,6,'2026-10-24 10:25:37',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (123,'INV-IN-20261024102538807-8847555443200','IN','PURCHASE_RECEIPT',8,'PR-000004',2,2,4,27,10.00,0.00,10.00,6,'2026-10-24 10:25:39',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (124,'INV-IN-20261024102538810-8847558095800','IN','PURCHASE_RECEIPT',8,'PR-000004',2,2,5,28,20.00,0.00,20.00,6,'2026-10-24 10:25:39',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (125,'INV-IN-20261024102538814-8847561571100','IN','PURCHASE_RECEIPT',8,'PR-000004',2,2,6,29,10.00,0.00,10.00,6,'2026-10-24 10:25:39',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (126,'INV-IN-20261024102538820-8847567725700','IN','PURCHASE_RECEIPT',8,'PR-000004',2,2,7,30,10.00,0.00,10.00,6,'2026-10-24 10:25:39',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (127,'INV-IN-20261024102538945-8847692865000','IN','WIP_LINE_ISSUE',16,'LINE-LINE_ISSUE-3-16',3,3,4,27,10.00,0.00,10.00,6,'2026-10-24 10:25:39','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (128,'INV-IN-20261024102538953-8847699960800','IN','WIP_LINE_ISSUE',16,'LINE-LINE_ISSUE-3-16',3,3,5,28,20.00,0.00,20.00,6,'2026-10-24 10:25:39','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (129,'INV-IN-20261024102538959-8847706640800','IN','WIP_LINE_ISSUE',16,'LINE-LINE_ISSUE-3-16',3,3,6,29,10.00,0.00,10.00,6,'2026-10-24 10:25:39','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (130,'INV-IN-20261024102538962-8847709600500','IN','WIP_LINE_ISSUE',16,'LINE-LINE_ISSUE-3-16',3,3,7,30,10.00,0.00,10.00,6,'2026-10-24 10:25:39','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (131,'INV-OUT-20261024102538974-8847721811300','OUT','LINE_ISSUE',6,'ISS-000003',2,2,4,27,10.00,10.00,0.00,6,'2026-10-24 10:25:39',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (132,'INV-OUT-20261024102538977-8847724704400','OUT','LINE_ISSUE',6,'ISS-000003',2,2,5,28,20.00,20.00,0.00,6,'2026-10-24 10:25:39',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (133,'INV-OUT-20261024102538981-8847729121900','OUT','LINE_ISSUE',6,'ISS-000003',2,2,6,29,10.00,10.00,0.00,6,'2026-10-24 10:25:39',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (134,'INV-OUT-20261024102538987-8847735345300','OUT','LINE_ISSUE',6,'ISS-000003',2,2,7,30,10.00,10.00,0.00,6,'2026-10-24 10:25:39',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (135,'INV-OUT-20261024102539127-8847874624600','OUT','WIP_CONSUME',8,'LINE-CONSUME-3-8',3,3,4,27,10.00,10.00,0.00,4,'2026-10-24 10:25:39','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (136,'INV-OUT-20261024102539131-8847879102700','OUT','WIP_CONSUME',8,'LINE-CONSUME-3-8',3,3,5,28,20.00,20.00,0.00,4,'2026-10-24 10:25:39','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (137,'INV-OUT-20261024102539134-8847882297900','OUT','WIP_CONSUME',8,'LINE-CONSUME-3-8',3,3,6,29,10.00,10.00,0.00,4,'2026-10-24 10:25:39','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (138,'INV-OUT-20261024102539142-8847889643100','OUT','WIP_CONSUME',8,'LINE-CONSUME-3-8',3,3,7,30,10.00,10.00,0.00,4,'2026-10-24 10:25:39','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (139,'INV-IN-20261024102539146-8847892941800','IN','WIP_OUTPUT',8,'LINE-OUTPUT-3-8',3,3,14,31,10.00,0.00,10.00,4,'2026-10-24 10:25:39','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (140,'INV-IN-20261024102539190-8847937355800','IN','PRODUCTION_RECEIPT',9,'FG-IN-000003',4,4,14,31,10.00,0.00,10.00,6,'2026-10-24 10:25:39',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (141,'INV-OUT-20261024102539195-8847942049200','OUT','WIP_RECEIPT',9,'LINE-RECEIPT-3-9',3,3,14,31,10.00,10.00,0.00,6,'2026-10-24 10:25:39','工单 3 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (142,'INV-IN-20261024102539534-8848281575200','IN','PURCHASE_RECEIPT',10,'PR-000005',2,2,3,32,10.00,0.00,10.00,6,'2026-10-24 10:25:40',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (143,'INV-IN-20261024102539536-8848284049300','IN','PURCHASE_RECEIPT',10,'PR-000005',2,2,8,33,10.00,0.00,10.00,6,'2026-10-24 10:25:40',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (144,'INV-IN-20261024102539539-8848286459500','IN','PURCHASE_RECEIPT',10,'PR-000005',2,2,9,34,10.00,0.00,10.00,6,'2026-10-24 10:25:40',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (145,'INV-IN-20261024102539542-8848290020600','IN','PURCHASE_RECEIPT',10,'PR-000005',2,2,10,35,40.00,0.00,40.00,6,'2026-10-24 10:25:40',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (146,'INV-IN-20261024102539672-8848419540600','IN','WIP_LINE_ISSUE',18,'LINE-LINE_ISSUE-4-18',3,3,2,26,10.00,0.00,10.00,6,'2026-10-24 10:25:40','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (147,'INV-IN-20261024102539676-8848423178900','IN','WIP_LINE_ISSUE',18,'LINE-LINE_ISSUE-4-18',3,3,3,32,10.00,0.00,10.00,6,'2026-10-24 10:25:40','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (148,'INV-IN-20261024102539679-8848425861300','IN','WIP_LINE_ISSUE',18,'LINE-LINE_ISSUE-4-18',3,3,8,33,10.00,0.00,10.00,6,'2026-10-24 10:25:40','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (149,'INV-IN-20261024102539683-8848431491600','IN','WIP_LINE_ISSUE',18,'LINE-LINE_ISSUE-4-18',3,3,9,34,10.00,0.00,10.00,6,'2026-10-24 10:25:40','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (150,'INV-IN-20261024102539687-8848434200000','IN','WIP_LINE_ISSUE',18,'LINE-LINE_ISSUE-4-18',3,3,10,35,40.00,0.00,40.00,6,'2026-10-24 10:25:40','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (151,'INV-OUT-20261024102539697-8848445084500','OUT','LINE_ISSUE',7,'ISS-000004',2,2,2,26,10.00,15.00,5.00,6,'2026-10-24 10:25:40',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (152,'INV-OUT-20261024102539703-8848450591900','OUT','LINE_ISSUE',7,'ISS-000004',2,2,3,32,10.00,10.00,0.00,6,'2026-10-24 10:25:40',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (153,'INV-OUT-20261024102539705-8848453676800','OUT','LINE_ISSUE',7,'ISS-000004',2,2,8,33,10.00,10.00,0.00,6,'2026-10-24 10:25:40',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (154,'INV-OUT-20261024102539709-8848456223100','OUT','LINE_ISSUE',7,'ISS-000004',2,2,9,34,10.00,10.00,0.00,6,'2026-10-24 10:25:40',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (155,'INV-OUT-20261024102539714-8848461141000','OUT','LINE_ISSUE',7,'ISS-000004',2,2,10,35,40.00,40.00,0.00,6,'2026-10-24 10:25:40',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (156,'INV-OUT-20261024102539856-8848603397800','OUT','WIP_CONSUME',9,'LINE-CONSUME-4-9',3,3,2,26,10.00,10.00,0.00,4,'2026-10-24 10:25:40','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (157,'INV-OUT-20261024102539859-8848606659400','OUT','WIP_CONSUME',9,'LINE-CONSUME-4-9',3,3,3,32,10.00,10.00,0.00,4,'2026-10-24 10:25:40','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (158,'INV-OUT-20261024102539861-8848609308700','OUT','WIP_CONSUME',9,'LINE-CONSUME-4-9',3,3,8,33,10.00,10.00,0.00,4,'2026-10-24 10:25:40','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (159,'INV-OUT-20261024102539868-8848615882800','OUT','WIP_CONSUME',9,'LINE-CONSUME-4-9',3,3,9,34,10.00,10.00,0.00,4,'2026-10-24 10:25:40','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (160,'INV-OUT-20261024102539871-8848618670400','OUT','WIP_CONSUME',9,'LINE-CONSUME-4-9',3,3,10,35,40.00,40.00,0.00,4,'2026-10-24 10:25:40','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (161,'INV-IN-20261024102539876-8848623659600','IN','WIP_OUTPUT',9,'LINE-OUTPUT-4-9',3,3,15,36,10.00,0.00,10.00,4,'2026-10-24 10:25:40','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (162,'INV-IN-20261024102539951-8848698697300','IN','PRODUCTION_RECEIPT',11,'FG-IN-000004',4,4,15,36,10.00,0.00,10.00,6,'2026-10-24 10:25:40',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (163,'INV-OUT-20261024102539956-8848703342600','OUT','WIP_RECEIPT',11,'LINE-RECEIPT-4-11',3,3,15,36,10.00,10.00,0.00,6,'2026-10-24 10:25:40','工单 4 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (164,'INV-IN-20261024102540242-8848989329900','IN','PURCHASE_RECEIPT',12,'PR-000006',2,2,11,37,10.00,0.00,10.00,6,'2026-10-24 10:25:40',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (165,'INV-IN-20261024102540245-8848991707000','IN','PURCHASE_RECEIPT',12,'PR-000006',2,2,12,38,10.00,0.00,10.00,6,'2026-10-24 10:25:40',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (166,'INV-IN-20261024102540247-8848994565600','IN','PURCHASE_RECEIPT',12,'PR-000006',2,2,13,39,10.00,0.00,10.00,6,'2026-10-24 10:25:40',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (167,'INV-IN-20261024102540362-8849109660800','IN','WIP_LINE_ISSUE',20,'LINE-LINE_ISSUE-2-20',3,3,11,37,10.00,0.00,10.00,6,'2026-10-24 10:25:40','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (168,'INV-IN-20261024102540365-8849113888700','IN','WIP_LINE_ISSUE',20,'LINE-LINE_ISSUE-2-20',3,3,12,38,10.00,0.00,10.00,6,'2026-10-24 10:25:40','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (169,'INV-IN-20261024102540373-8849119739500','IN','WIP_LINE_ISSUE',20,'LINE-LINE_ISSUE-2-20',3,3,13,39,10.00,0.00,10.00,6,'2026-10-24 10:25:40','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (170,'INV-OUT-20261024102540379-8849126660700','OUT','LINE_ISSUE',8,'ISS-000005',2,2,11,37,10.00,10.00,0.00,6,'2026-10-24 10:25:40',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (171,'INV-OUT-20261024102540382-8849130092200','OUT','LINE_ISSUE',8,'ISS-000005',2,2,12,38,10.00,10.00,0.00,6,'2026-10-24 10:25:40',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (172,'INV-OUT-20261024102540390-8849137588900','OUT','LINE_ISSUE',8,'ISS-000005',2,2,13,39,10.00,10.00,0.00,6,'2026-10-24 10:25:40',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (173,'INV-IN-20261024102540499-8849246687200','IN','WIP_LINE_ISSUE',21,'LINE-LINE_ISSUE-2-21',3,3,14,31,10.00,0.00,10.00,6,'2026-10-24 10:25:40','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (174,'INV-IN-20261024102540502-8849250213000','IN','WIP_LINE_ISSUE',21,'LINE-LINE_ISSUE-2-21',3,3,15,36,10.00,0.00,10.00,6,'2026-10-24 10:25:41','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (175,'INV-OUT-20261024102540518-8849265429400','OUT','LINE_ISSUE',9,'ISS-000006',4,4,14,31,10.00,10.00,0.00,6,'2026-10-24 10:25:41',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (176,'INV-OUT-20261024102540520-8849268189600','OUT','LINE_ISSUE',9,'ISS-000006',4,4,15,36,10.00,10.00,0.00,6,'2026-10-24 10:25:41',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (177,'INV-OUT-20261024102540656-8849403775600','OUT','WIP_CONSUME',10,'LINE-CONSUME-2-10',3,3,11,37,6.00,10.00,4.00,4,'2026-10-24 10:25:41','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (178,'INV-OUT-20261024102540659-8849407146600','OUT','WIP_CONSUME',10,'LINE-CONSUME-2-10',3,3,12,38,6.00,10.00,4.00,4,'2026-10-24 10:25:41','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (179,'INV-OUT-20261024102540664-8849412265300','OUT','WIP_CONSUME',10,'LINE-CONSUME-2-10',3,3,13,39,6.00,10.00,4.00,4,'2026-10-24 10:25:41','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (180,'INV-OUT-20261024102540672-8849418922800','OUT','WIP_CONSUME',10,'LINE-CONSUME-2-10',3,3,14,31,6.00,10.00,4.00,4,'2026-10-24 10:25:41','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (181,'INV-OUT-20261024102540675-8849422666800','OUT','WIP_CONSUME',10,'LINE-CONSUME-2-10',3,3,15,36,6.00,10.00,4.00,4,'2026-10-24 10:25:41','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (182,'INV-OUT-20261024102540793-8849540260500','OUT','WIP_CONSUME',11,'LINE-CONSUME-2-11',3,3,11,37,4.00,4.00,0.00,4,'2026-10-24 10:25:41','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (183,'INV-OUT-20261024102540796-8849543398700','OUT','WIP_CONSUME',11,'LINE-CONSUME-2-11',3,3,12,38,4.00,4.00,0.00,4,'2026-10-24 10:25:41','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (184,'INV-OUT-20261024102540800-8849546911500','OUT','WIP_CONSUME',11,'LINE-CONSUME-2-11',3,3,13,39,4.00,4.00,0.00,4,'2026-10-24 10:25:41','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (185,'INV-OUT-20261024102540808-8849554921800','OUT','WIP_CONSUME',11,'LINE-CONSUME-2-11',3,3,14,31,4.00,4.00,0.00,4,'2026-10-24 10:25:41','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (186,'INV-OUT-20261024102540810-8849558265600','OUT','WIP_CONSUME',11,'LINE-CONSUME-2-11',3,3,15,36,4.00,4.00,0.00,4,'2026-10-24 10:25:41','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (187,'INV-IN-20261024102541133-8849881321500','IN','WIP_OUTPUT',14,'LINE-OUTPUT-2-14',3,3,16,40,10.00,0.00,10.00,4,'2026-10-24 10:25:41','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (188,'INV-IN-20261024102541191-8849939083500','IN','PRODUCTION_RECEIPT',13,'FG-IN-000005',4,4,16,40,10.00,0.00,10.00,6,'2026-10-24 10:25:41',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (189,'INV-OUT-20261024102541195-8849942461900','OUT','WIP_RECEIPT',13,'LINE-RECEIPT-2-13',3,3,16,40,10.00,10.00,0.00,6,'2026-10-24 10:25:41','工单 2 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (190,'INV-IN-20261024102541990-8850737258900','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,3,41,1.00,0.00,1.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (191,'INV-IN-20261024102541997-8850744577000','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,4,42,1.00,0.00,1.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (192,'INV-IN-20261024102542001-8850748727000','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,5,43,2.00,0.00,2.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (193,'INV-IN-20261024102542003-8850751148300','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,6,44,1.00,0.00,1.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (194,'INV-IN-20261024102542009-8850756931800','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,7,45,1.00,0.00,1.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (195,'INV-IN-20261024102542013-8850761412400','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,8,46,1.00,0.00,1.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (196,'INV-IN-20261024102542015-8850763754200','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,9,47,1.00,0.00,1.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (197,'INV-IN-20261024102542020-8850767588000','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,10,48,4.00,0.00,4.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (198,'INV-IN-20261024102542025-8850772490600','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,11,49,1.00,0.00,1.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (199,'INV-IN-20261024102542028-8850775023200','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,12,50,1.00,0.00,1.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (200,'INV-IN-20261024102542031-8850778439900','IN','PURCHASE_RECEIPT',14,'PR-000007',2,2,13,51,1.00,0.00,1.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (201,'INV-IN-20261024102542171-8850918868900','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,2,26,1.00,0.00,1.00,6,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (202,'INV-IN-20261024102542174-8850921993100','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,3,41,1.00,0.00,1.00,6,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (203,'INV-IN-20261024102542181-8850929113200','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,4,42,1.00,0.00,1.00,6,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (204,'INV-IN-20261024102542184-8850932103700','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,5,43,2.00,0.00,2.00,6,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (205,'INV-IN-20261024102542187-8850934631200','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,6,44,1.00,0.00,1.00,6,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (206,'INV-IN-20261024102542193-8850940775600','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,7,45,1.00,0.00,1.00,6,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (207,'INV-IN-20261024102542197-8850944842900','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,8,46,1.00,0.00,1.00,6,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (208,'INV-IN-20261024102542200-8850947883000','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,9,47,1.00,0.00,1.00,6,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (209,'INV-IN-20261024102542204-8850951038800','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,10,48,4.00,0.00,4.00,6,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (210,'INV-IN-20261024102542210-8850957984000','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,11,49,1.00,0.00,1.00,6,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (211,'INV-IN-20261024102542215-8850963197800','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,12,50,1.00,0.00,1.00,6,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (212,'INV-IN-20261024102542218-8850966007600','IN','WIP_LINE_ISSUE',23,'LINE-LINE_ISSUE-5-23',3,3,13,51,1.00,0.00,1.00,6,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (213,'INV-OUT-20261024102542230-8850978440700','OUT','LINE_ISSUE',10,'ISS-000007',2,2,2,26,1.00,5.00,4.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (214,'INV-OUT-20261024102542234-8850981302400','OUT','LINE_ISSUE',10,'ISS-000007',2,2,3,41,1.00,1.00,0.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (215,'INV-OUT-20261024102542236-8850983476300','OUT','LINE_ISSUE',10,'ISS-000007',2,2,4,42,1.00,1.00,0.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (216,'INV-OUT-20261024102542242-8850990031000','OUT','LINE_ISSUE',10,'ISS-000007',2,2,5,43,2.00,2.00,0.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (217,'INV-OUT-20261024102542245-8850993020500','OUT','LINE_ISSUE',10,'ISS-000007',2,2,6,44,1.00,1.00,0.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (218,'INV-OUT-20261024102542249-8850996553700','OUT','LINE_ISSUE',10,'ISS-000007',2,2,7,45,1.00,1.00,0.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (219,'INV-OUT-20261024102542251-8850999170900','OUT','LINE_ISSUE',10,'ISS-000007',2,2,8,46,1.00,1.00,0.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (220,'INV-OUT-20261024102542258-8851005520100','OUT','LINE_ISSUE',10,'ISS-000007',2,2,9,47,1.00,1.00,0.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (221,'INV-OUT-20261024102542260-8851007944200','OUT','LINE_ISSUE',10,'ISS-000007',2,2,10,48,4.00,4.00,0.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (222,'INV-OUT-20261024102542263-8851010846700','OUT','LINE_ISSUE',10,'ISS-000007',2,2,11,49,1.00,1.00,0.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (223,'INV-OUT-20261024102542266-8851013151600','OUT','LINE_ISSUE',10,'ISS-000007',2,2,12,50,1.00,1.00,0.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (224,'INV-OUT-20261024102542270-8851017768300','OUT','LINE_ISSUE',10,'ISS-000007',2,2,13,51,1.00,1.00,0.00,6,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (225,'INV-OUT-20261024102542385-8851132853700','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,2,26,1.00,1.00,0.00,4,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (226,'INV-OUT-20261024102542388-8851135978800','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,3,41,1.00,1.00,0.00,4,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (227,'INV-OUT-20261024102542392-8851139574300','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,4,42,1.00,1.00,0.00,4,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (228,'INV-OUT-20261024102542399-8851147177800','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,5,43,2.00,2.00,0.00,4,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (229,'INV-OUT-20261024102542403-8851150421200','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,6,44,1.00,1.00,0.00,4,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (230,'INV-OUT-20261024102542406-8851153226600','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,7,45,1.00,1.00,0.00,4,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (231,'INV-OUT-20261024102542410-8851157670700','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,8,46,1.00,1.00,0.00,4,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (232,'INV-OUT-20261024102542434-8851180726000','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,9,47,1.00,1.00,0.00,4,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (233,'INV-OUT-20261024102542452-8851199357900','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,10,48,4.00,4.00,0.00,4,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (234,'INV-OUT-20261024102542459-8851206974500','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,11,49,1.00,1.00,0.00,4,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (235,'INV-OUT-20261024102542463-8851210284400','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,12,50,1.00,1.00,0.00,4,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (236,'INV-OUT-20261024102542466-8851213513900','OUT','WIP_CONSUME',15,'LINE-CONSUME-5-15',3,3,13,51,1.00,1.00,0.00,4,'2026-10-24 10:25:42','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (237,'INV-IN-20261024102542786-8851533911000','IN','WIP_OUTPUT',18,'LINE-OUTPUT-5-18',3,3,16,52,1.00,0.00,1.00,4,'2026-10-24 10:25:43','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (238,'INV-IN-20261024102542848-8851595651000','IN','PRODUCTION_RECEIPT',15,'FG-IN-000006',4,4,16,52,1.00,0.00,1.00,6,'2026-10-24 10:25:43',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (239,'INV-OUT-20261024102542851-8851598868300','OUT','WIP_RECEIPT',15,'LINE-RECEIPT-5-15',3,3,16,52,1.00,1.00,0.00,6,'2026-10-24 10:25:43','工单 5 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (240,'INV-IN-20261024102543471-8852219356600','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,3,53,1.00,0.00,1.00,6,'2026-10-24 10:25:43',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (241,'INV-IN-20261024102543474-8852222007700','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,4,54,1.00,0.00,1.00,6,'2026-10-24 10:25:43',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (242,'INV-IN-20261024102543477-8852224401600','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,5,55,2.00,0.00,2.00,6,'2026-10-24 10:25:43',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (243,'INV-IN-20261024102543482-8852229700300','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,6,56,1.00,0.00,1.00,6,'2026-10-24 10:25:43',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (244,'INV-IN-20261024102543485-8852232163900','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,7,57,1.00,0.00,1.00,6,'2026-10-24 10:25:43',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (245,'INV-IN-20261024102543487-8852234678400','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,8,58,1.00,0.00,1.00,6,'2026-10-24 10:25:43',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (246,'INV-IN-20261024102543489-8852236858700','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,9,59,1.00,0.00,1.00,6,'2026-10-24 10:25:43',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (247,'INV-IN-20261024102543491-8852239009500','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,10,60,4.00,0.00,4.00,6,'2026-10-24 10:25:43',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (248,'INV-IN-20261024102543498-8852245910600','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,11,61,1.00,0.00,1.00,6,'2026-10-24 10:25:43',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (249,'INV-IN-20261024102543500-8852248493300','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,12,62,1.00,0.00,1.00,6,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (250,'INV-IN-20261024102543503-8852250646800','IN','PURCHASE_RECEIPT',16,'PR-000008',2,2,13,63,1.00,0.00,1.00,6,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (251,'INV-IN-20261024102543639-8852386564400','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,2,26,1.00,0.00,1.00,6,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (252,'INV-IN-20261024102543642-8852389275000','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,3,53,1.00,0.00,1.00,6,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (253,'INV-IN-20261024102543645-8852392809400','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,4,54,1.00,0.00,1.00,6,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (254,'INV-IN-20261024102543652-8852399968300','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,5,55,2.00,0.00,2.00,6,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (255,'INV-IN-20261024102543654-8852402289000','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,6,56,1.00,0.00,1.00,6,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (256,'INV-IN-20261024102543658-8852406197400','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,7,57,1.00,0.00,1.00,6,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (257,'INV-IN-20261024102543665-8852412646100','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,8,58,1.00,0.00,1.00,6,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (258,'INV-IN-20261024102543668-8852415516900','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,9,59,1.00,0.00,1.00,6,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (259,'INV-IN-20261024102543670-8852417816100','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,10,60,4.00,0.00,4.00,6,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (260,'INV-IN-20261024102543673-8852420394100','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,11,61,1.00,0.00,1.00,6,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (261,'INV-IN-20261024102543675-8852423109800','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,12,62,1.00,0.00,1.00,6,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (262,'INV-IN-20261024102543687-8852434461400','IN','WIP_LINE_ISSUE',25,'LINE-LINE_ISSUE-6-25',3,3,13,63,1.00,0.00,1.00,6,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (263,'INV-OUT-20261024102543705-8852452860600','OUT','LINE_ISSUE',11,'ISS-000008',2,2,2,26,1.00,4.00,3.00,6,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (264,'INV-OUT-20261024102543707-8852454914500','OUT','LINE_ISSUE',11,'ISS-000008',2,2,3,53,1.00,1.00,0.00,6,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (265,'INV-OUT-20261024102543715-8852462192500','OUT','LINE_ISSUE',11,'ISS-000008',2,2,4,54,1.00,1.00,0.00,6,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (266,'INV-OUT-20261024102543717-8852464704100','OUT','LINE_ISSUE',11,'ISS-000008',2,2,5,55,2.00,2.00,0.00,6,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (267,'INV-OUT-20261024102543719-8852466922100','OUT','LINE_ISSUE',11,'ISS-000008',2,2,6,56,1.00,1.00,0.00,6,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (268,'INV-OUT-20261024102543721-8852469028600','OUT','LINE_ISSUE',11,'ISS-000008',2,2,7,57,1.00,1.00,0.00,6,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (269,'INV-OUT-20261024102543732-8852478699400','OUT','LINE_ISSUE',11,'ISS-000008',2,2,8,58,1.00,1.00,0.00,6,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (270,'INV-OUT-20261024102543734-8852481368800','OUT','LINE_ISSUE',11,'ISS-000008',2,2,9,59,1.00,1.00,0.00,6,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (271,'INV-OUT-20261024102543736-8852483547400','OUT','LINE_ISSUE',11,'ISS-000008',2,2,10,60,4.00,4.00,0.00,6,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (272,'INV-OUT-20261024102543738-8852486263400','OUT','LINE_ISSUE',11,'ISS-000008',2,2,11,61,1.00,1.00,0.00,6,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (273,'INV-OUT-20261024102543749-8852496557200','OUT','LINE_ISSUE',11,'ISS-000008',2,2,12,62,1.00,1.00,0.00,6,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (274,'INV-OUT-20261024102543752-8852499454300','OUT','LINE_ISSUE',11,'ISS-000008',2,2,13,63,1.00,1.00,0.00,6,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (275,'INV-OUT-20261024102543869-8852616288700','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,2,26,1.00,1.00,0.00,4,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (276,'INV-OUT-20261024102543872-8852619230000','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,3,53,1.00,1.00,0.00,4,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (277,'INV-OUT-20261024102543874-8852621818700','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,4,54,1.00,1.00,0.00,4,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (278,'INV-OUT-20261024102543880-8852627205600','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,5,55,2.00,2.00,0.00,4,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (279,'INV-OUT-20261024102543883-8852630471700','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,6,56,1.00,1.00,0.00,4,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (280,'INV-OUT-20261024102543886-8852633731900','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,7,57,1.00,1.00,0.00,4,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (281,'INV-OUT-20261024102543889-8852636695500','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,8,58,1.00,1.00,0.00,4,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (282,'INV-OUT-20261024102543895-8852642221300','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,9,59,1.00,1.00,0.00,4,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (283,'INV-OUT-20261024102543898-8852645715400','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,10,60,4.00,4.00,0.00,4,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (284,'INV-OUT-20261024102543901-8852648716000','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,11,61,1.00,1.00,0.00,4,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (285,'INV-OUT-20261024102543903-8852651272600','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,12,62,1.00,1.00,0.00,4,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (286,'INV-OUT-20261024102543907-8852654754400','OUT','WIP_CONSUME',19,'LINE-CONSUME-6-19',3,3,13,63,1.00,1.00,0.00,4,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (287,'INV-IN-20261024102544241-8852988230400','IN','WIP_OUTPUT',22,'LINE-OUTPUT-6-22',3,3,16,64,1.00,0.00,1.00,4,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (288,'INV-IN-20261024102544302-8853049536000','IN','PRODUCTION_RECEIPT',17,'FG-IN-000007',4,4,16,64,1.00,0.00,1.00,6,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (289,'INV-OUT-20261024102544305-8853053053400','OUT','WIP_RECEIPT',17,'LINE-RECEIPT-6-17',3,3,16,64,1.00,1.00,0.00,6,'2026-10-24 10:25:44','工单 6 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (290,'INV-OUT-20261024102544520-8853267249900','OUT','SALES_SHIPMENT',12,'SHIP-000003',4,4,16,52,1.00,1.00,0.00,6,'2026-10-24 10:25:45',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (291,'INV-OUT-20261024102544522-8853269689400','OUT','SALES_SHIPMENT',12,'SHIP-000003',4,4,16,64,1.00,1.00,0.00,6,'2026-10-24 10:25:45',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (292,'INV-IN-20261024102544932-8853679811000','IN','PURCHASE_RECEIPT',18,'PR-000009',2,2,2,65,2.00,0.00,2.00,6,'2026-10-24 10:25:45',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (293,'INV-OUT-20261024102545009-8853756377500','OUT','PURCHASE_RETURN',13,'P-RET-000002',2,2,2,65,1.00,2.00,1.00,6,'2026-10-24 10:25:45',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (294,'INV-IN-20261024102546034-8854781067200','IN','PURCHASE_RECEIPT',19,'PR-000010',2,2,3,66,1.00,0.00,1.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (295,'INV-IN-20261024102546036-8854783603500','IN','PURCHASE_RECEIPT',19,'PR-000010',2,2,4,67,1.00,0.00,1.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (296,'INV-IN-20261024102546042-8854789766100','IN','PURCHASE_RECEIPT',19,'PR-000010',2,2,5,68,2.00,0.00,2.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (297,'INV-IN-20261024102546047-8854794687600','IN','PURCHASE_RECEIPT',19,'PR-000010',2,2,6,69,1.00,0.00,1.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (298,'INV-IN-20261024102546050-8854797171900','IN','PURCHASE_RECEIPT',19,'PR-000010',2,2,7,70,1.00,0.00,1.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (299,'INV-IN-20261024102546054-8854801780800','IN','PURCHASE_RECEIPT',19,'PR-000010',2,2,8,71,1.00,0.00,1.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (300,'INV-IN-20261024102546056-8854804014700','IN','PURCHASE_RECEIPT',19,'PR-000010',2,2,9,72,1.00,0.00,1.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (301,'INV-IN-20261024102546060-8854806944700','IN','PURCHASE_RECEIPT',19,'PR-000010',2,2,10,73,4.00,0.00,4.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (302,'INV-IN-20261024102546064-8854811661400','IN','PURCHASE_RECEIPT',19,'PR-000010',2,2,11,74,1.00,0.00,1.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (303,'INV-IN-20261024102546066-8854813930700','IN','PURCHASE_RECEIPT',19,'PR-000010',2,2,12,75,1.00,0.00,1.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (304,'INV-IN-20261024102546071-8854819241100','IN','PURCHASE_RECEIPT',19,'PR-000010',2,2,13,76,1.00,0.00,1.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (305,'INV-IN-20261024102546204-8854951694600','IN','WIP_LINE_ISSUE',30,'LINE-LINE_ISSUE-7-30',3,3,2,26,1.00,0.00,1.00,6,'2026-10-24 10:25:46','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (306,'INV-IN-20261024102546213-8854960677900','IN','WIP_LINE_ISSUE',30,'LINE-LINE_ISSUE-7-30',3,3,3,66,1.00,0.00,1.00,6,'2026-10-24 10:25:46','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (307,'INV-IN-20261024102546216-8854963702600','IN','WIP_LINE_ISSUE',30,'LINE-LINE_ISSUE-7-30',3,3,4,67,1.00,0.00,1.00,6,'2026-10-24 10:25:46','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (308,'INV-IN-20261024102546228-8854975938200','IN','WIP_LINE_ISSUE',30,'LINE-LINE_ISSUE-7-30',3,3,5,68,2.00,0.00,2.00,6,'2026-10-24 10:25:46','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (309,'INV-IN-20261024102546230-8854978325700','IN','WIP_LINE_ISSUE',30,'LINE-LINE_ISSUE-7-30',3,3,6,69,1.00,0.00,1.00,6,'2026-10-24 10:25:46','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (310,'INV-IN-20261024102546233-8854980462500','IN','WIP_LINE_ISSUE',30,'LINE-LINE_ISSUE-7-30',3,3,7,70,1.00,0.00,1.00,6,'2026-10-24 10:25:46','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (311,'INV-IN-20261024102546235-8854982660300','IN','WIP_LINE_ISSUE',30,'LINE-LINE_ISSUE-7-30',3,3,8,71,1.00,0.00,1.00,6,'2026-10-24 10:25:46','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (312,'INV-IN-20261024102546241-8854988157700','IN','WIP_LINE_ISSUE',30,'LINE-LINE_ISSUE-7-30',3,3,9,72,1.00,0.00,1.00,6,'2026-10-24 10:25:46','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (313,'INV-IN-20261024102546245-8854992060200','IN','WIP_LINE_ISSUE',30,'LINE-LINE_ISSUE-7-30',3,3,10,73,4.00,0.00,4.00,6,'2026-10-24 10:25:46','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (314,'INV-IN-20261024102546249-8854996152600','IN','WIP_LINE_ISSUE',30,'LINE-LINE_ISSUE-7-30',3,3,11,74,1.00,0.00,1.00,6,'2026-10-24 10:25:46','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (315,'INV-IN-20261024102546251-8854999009000','IN','WIP_LINE_ISSUE',30,'LINE-LINE_ISSUE-7-30',3,3,12,75,1.00,0.00,1.00,6,'2026-10-24 10:25:46','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (316,'INV-IN-20261024102546258-8855004859100','IN','WIP_LINE_ISSUE',30,'LINE-LINE_ISSUE-7-30',3,3,13,76,1.00,0.00,1.00,6,'2026-10-24 10:25:46','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (317,'INV-OUT-20261024102546273-8855020926700','OUT','LINE_ISSUE',14,'ISS-000009',2,2,2,26,1.00,3.00,2.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (318,'INV-OUT-20261024102546275-8855023484000','OUT','LINE_ISSUE',14,'ISS-000009',2,2,3,66,1.00,1.00,0.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (319,'INV-OUT-20261024102546279-8855026709000','OUT','LINE_ISSUE',14,'ISS-000009',2,2,4,67,1.00,1.00,0.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (320,'INV-OUT-20261024102546282-8855029048200','OUT','LINE_ISSUE',14,'ISS-000009',2,2,5,68,2.00,2.00,0.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (321,'INV-OUT-20261024102546285-8855032609600','OUT','LINE_ISSUE',14,'ISS-000009',2,2,6,69,1.00,1.00,0.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (322,'INV-OUT-20261024102546287-8855035072200','OUT','LINE_ISSUE',14,'ISS-000009',2,2,7,70,1.00,1.00,0.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (323,'INV-OUT-20261024102546291-8855038261800','OUT','LINE_ISSUE',14,'ISS-000009',2,2,8,71,1.00,1.00,0.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (324,'INV-OUT-20261024102546293-8855040707300','OUT','LINE_ISSUE',14,'ISS-000009',2,2,9,72,1.00,1.00,0.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (325,'INV-OUT-20261024102546295-8855043931200','OUT','LINE_ISSUE',14,'ISS-000009',2,2,10,73,4.00,4.00,0.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (326,'INV-OUT-20261024102546304-8855051574300','OUT','LINE_ISSUE',14,'ISS-000009',2,2,11,74,1.00,1.00,0.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (327,'INV-OUT-20261024102546308-8855055456900','OUT','LINE_ISSUE',14,'ISS-000009',2,2,12,75,1.00,1.00,0.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (328,'INV-OUT-20261024102546311-8855058911800','OUT','LINE_ISSUE',14,'ISS-000009',2,2,13,76,1.00,1.00,0.00,6,'2026-10-24 10:25:46',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (329,'INV-OUT-20261024102546584-8855332340400','OUT','WIP_CONSUME',23,'LINE-CONSUME-7-23',3,3,2,26,1.00,1.00,0.00,4,'2026-10-24 10:25:47','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (330,'INV-OUT-20261024102546588-8855335504300','OUT','WIP_CONSUME',23,'LINE-CONSUME-7-23',3,3,3,66,1.00,1.00,0.00,4,'2026-10-24 10:25:47','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (331,'INV-OUT-20261024102546590-8855338316800','OUT','WIP_CONSUME',23,'LINE-CONSUME-7-23',3,3,4,67,1.00,1.00,0.00,4,'2026-10-24 10:25:47','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (332,'INV-OUT-20261024102546600-8855347337000','OUT','WIP_CONSUME',23,'LINE-CONSUME-7-23',3,3,5,68,2.00,2.00,0.00,4,'2026-10-24 10:25:47','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (333,'INV-OUT-20261024102546602-8855349976400','OUT','WIP_CONSUME',23,'LINE-CONSUME-7-23',3,3,6,69,1.00,1.00,0.00,4,'2026-10-24 10:25:47','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (334,'INV-OUT-20261024102546605-8855352759500','OUT','WIP_CONSUME',23,'LINE-CONSUME-7-23',3,3,7,70,1.00,1.00,0.00,4,'2026-10-24 10:25:47','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (335,'INV-OUT-20261024102546611-8855358460300','OUT','WIP_CONSUME',23,'LINE-CONSUME-7-23',3,3,8,71,1.00,1.00,0.00,4,'2026-10-24 10:25:47','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (336,'INV-OUT-20261024102546614-8855361906700','OUT','WIP_CONSUME',23,'LINE-CONSUME-7-23',3,3,9,72,1.00,1.00,0.00,4,'2026-10-24 10:25:47','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (337,'INV-OUT-20261024102546618-8855365563200','OUT','WIP_CONSUME',23,'LINE-CONSUME-7-23',3,3,10,73,4.00,4.00,0.00,4,'2026-10-24 10:25:47','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (338,'INV-OUT-20261024102546621-8855368679700','OUT','WIP_CONSUME',23,'LINE-CONSUME-7-23',3,3,11,74,1.00,1.00,0.00,4,'2026-10-24 10:25:47','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (339,'INV-OUT-20261024102546628-8855376167600','OUT','WIP_CONSUME',23,'LINE-CONSUME-7-23',3,3,12,75,1.00,1.00,0.00,4,'2026-10-24 10:25:47','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (340,'INV-OUT-20261024102546631-8855378984600','OUT','WIP_CONSUME',23,'LINE-CONSUME-7-23',3,3,13,76,1.00,1.00,0.00,4,'2026-10-24 10:25:47','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (341,'INV-IN-20261024102547003-8855750330900','IN','WIP_OUTPUT',26,'LINE-OUTPUT-7-26',3,3,16,77,1.00,0.00,1.00,4,'2026-10-24 10:25:47','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (342,'INV-OUT-20261024102547215-8855962464400','OUT','WIP_SCRAP',2,'LINE-SCRAP-7-2',3,3,16,77,1.00,1.00,0.00,6,'2026-10-24 10:25:47','工单 7 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (343,'INV-IN-20261024102548366-8857113721500','IN','PURCHASE_RECEIPT',20,'PR-000011',2,2,3,78,2.00,0.00,2.00,6,'2026-10-24 10:25:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (344,'INV-IN-20261024102548372-8857119235100','IN','PURCHASE_RECEIPT',20,'PR-000011',2,2,4,79,2.00,0.00,2.00,6,'2026-10-24 10:25:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (345,'INV-IN-20261024102548374-8857121800200','IN','PURCHASE_RECEIPT',20,'PR-000011',2,2,5,80,4.00,0.00,4.00,6,'2026-10-24 10:25:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (346,'INV-IN-20261024102548378-8857125759600','IN','PURCHASE_RECEIPT',20,'PR-000011',2,2,6,81,2.00,0.00,2.00,6,'2026-10-24 10:25:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (347,'INV-IN-20261024102548381-8857128299500','IN','PURCHASE_RECEIPT',20,'PR-000011',2,2,7,82,2.00,0.00,2.00,6,'2026-10-24 10:25:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (348,'INV-IN-20261024102548383-8857131006300','IN','PURCHASE_RECEIPT',20,'PR-000011',2,2,8,83,2.00,0.00,2.00,6,'2026-10-24 10:25:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (349,'INV-IN-20261024102548390-8857137505600','IN','PURCHASE_RECEIPT',20,'PR-000011',2,2,9,84,2.00,0.00,2.00,6,'2026-10-24 10:25:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (350,'INV-IN-20261024102548393-8857140408400','IN','PURCHASE_RECEIPT',20,'PR-000011',2,2,10,85,8.00,0.00,8.00,6,'2026-10-24 10:25:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (351,'INV-IN-20261024102548396-8857143524200','IN','PURCHASE_RECEIPT',20,'PR-000011',2,2,11,86,2.00,0.00,2.00,6,'2026-10-24 10:25:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (352,'INV-IN-20261024102548399-8857146339100','IN','PURCHASE_RECEIPT',20,'PR-000011',2,2,12,87,2.00,0.00,2.00,6,'2026-10-24 10:25:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (353,'INV-IN-20261024102548404-8857151325200','IN','PURCHASE_RECEIPT',20,'PR-000011',2,2,13,88,2.00,0.00,2.00,6,'2026-10-24 10:25:48',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (354,'INV-IN-20261024102548549-8857296779700','IN','WIP_LINE_ISSUE',32,'LINE-LINE_ISSUE-9-32',3,3,2,26,2.00,0.00,2.00,6,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (355,'INV-IN-20261024102548559-8857306748100','IN','WIP_LINE_ISSUE',32,'LINE-LINE_ISSUE-9-32',3,3,3,78,2.00,0.00,2.00,6,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (356,'INV-IN-20261024102548573-8857320244700','IN','WIP_LINE_ISSUE',32,'LINE-LINE_ISSUE-9-32',3,3,4,79,2.00,0.00,2.00,6,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (357,'INV-IN-20261024102548576-8857323100400','IN','WIP_LINE_ISSUE',32,'LINE-LINE_ISSUE-9-32',3,3,5,80,4.00,0.00,4.00,6,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (358,'INV-IN-20261024102548579-8857326720500','IN','WIP_LINE_ISSUE',32,'LINE-LINE_ISSUE-9-32',3,3,6,81,2.00,0.00,2.00,6,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (359,'INV-IN-20261024102548593-8857340012800','IN','WIP_LINE_ISSUE',32,'LINE-LINE_ISSUE-9-32',3,3,7,82,2.00,0.00,2.00,6,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (360,'INV-IN-20261024102548601-8857348709300','IN','WIP_LINE_ISSUE',32,'LINE-LINE_ISSUE-9-32',3,3,8,83,2.00,0.00,2.00,6,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (361,'INV-IN-20261024102548603-8857351284000','IN','WIP_LINE_ISSUE',32,'LINE-LINE_ISSUE-9-32',3,3,9,84,2.00,0.00,2.00,6,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (362,'INV-IN-20261024102548607-8857354027000','IN','WIP_LINE_ISSUE',32,'LINE-LINE_ISSUE-9-32',3,3,10,85,8.00,0.00,8.00,6,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (363,'INV-IN-20261024102548609-8857357377600','IN','WIP_LINE_ISSUE',32,'LINE-LINE_ISSUE-9-32',3,3,11,86,2.00,0.00,2.00,6,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (364,'INV-IN-20261024102548613-8857360234600','IN','WIP_LINE_ISSUE',32,'LINE-LINE_ISSUE-9-32',3,3,12,87,2.00,0.00,2.00,6,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (365,'INV-IN-20261024102548622-8857369657500','IN','WIP_LINE_ISSUE',32,'LINE-LINE_ISSUE-9-32',3,3,13,88,2.00,0.00,2.00,6,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (366,'INV-OUT-20261024102548638-8857385536600','OUT','LINE_ISSUE',15,'ISS-000010',2,2,2,26,2.00,2.00,0.00,6,'2026-10-24 10:25:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (367,'INV-OUT-20261024102548640-8857387808600','OUT','LINE_ISSUE',15,'ISS-000010',2,2,3,78,2.00,2.00,0.00,6,'2026-10-24 10:25:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (368,'INV-OUT-20261024102548643-8857390829000','OUT','LINE_ISSUE',15,'ISS-000010',2,2,4,79,2.00,2.00,0.00,6,'2026-10-24 10:25:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (369,'INV-OUT-20261024102548651-8857398648400','OUT','LINE_ISSUE',15,'ISS-000010',2,2,5,80,4.00,4.00,0.00,6,'2026-10-24 10:25:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (370,'INV-OUT-20261024102548653-8857400991800','OUT','LINE_ISSUE',15,'ISS-000010',2,2,6,81,2.00,2.00,0.00,6,'2026-10-24 10:25:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (371,'INV-OUT-20261024102548655-8857403020900','OUT','LINE_ISSUE',15,'ISS-000010',2,2,7,82,2.00,2.00,0.00,6,'2026-10-24 10:25:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (372,'INV-OUT-20261024102548657-8857405026600','OUT','LINE_ISSUE',15,'ISS-000010',2,2,8,83,2.00,2.00,0.00,6,'2026-10-24 10:25:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (373,'INV-OUT-20261024102548665-8857412347700','OUT','LINE_ISSUE',15,'ISS-000010',2,2,9,84,2.00,2.00,0.00,6,'2026-10-24 10:25:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (374,'INV-OUT-20261024102548669-8857416443700','OUT','LINE_ISSUE',15,'ISS-000010',2,2,10,85,8.00,8.00,0.00,6,'2026-10-24 10:25:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (375,'INV-OUT-20261024102548677-8857424848200','OUT','LINE_ISSUE',15,'ISS-000010',2,2,11,86,2.00,2.00,0.00,6,'2026-10-24 10:25:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (376,'INV-OUT-20261024102548681-8857429211800','OUT','LINE_ISSUE',15,'ISS-000010',2,2,12,87,2.00,2.00,0.00,6,'2026-10-24 10:25:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (377,'INV-OUT-20261024102548685-8857433672300','OUT','LINE_ISSUE',15,'ISS-000010',2,2,13,88,2.00,2.00,0.00,6,'2026-10-24 10:25:49',NULL);
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (378,'INV-OUT-20261024102548995-8857742535000','OUT','WIP_CONSUME',27,'LINE-CONSUME-9-27',3,3,2,26,2.00,2.00,0.00,4,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (379,'INV-OUT-20261024102549000-8857747410300','OUT','WIP_CONSUME',27,'LINE-CONSUME-9-27',3,3,3,78,2.00,2.00,0.00,4,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (380,'INV-OUT-20261024102549003-8857750050800','OUT','WIP_CONSUME',27,'LINE-CONSUME-9-27',3,3,4,79,2.00,2.00,0.00,4,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (381,'INV-OUT-20261024102549008-8857755248700','OUT','WIP_CONSUME',27,'LINE-CONSUME-9-27',3,3,5,80,4.00,4.00,0.00,4,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (382,'INV-OUT-20261024102549011-8857759243800','OUT','WIP_CONSUME',27,'LINE-CONSUME-9-27',3,3,6,81,2.00,2.00,0.00,4,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (383,'INV-OUT-20261024102549018-8857765070100','OUT','WIP_CONSUME',27,'LINE-CONSUME-9-27',3,3,7,82,2.00,2.00,0.00,4,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (384,'INV-OUT-20261024102549021-8857768212500','OUT','WIP_CONSUME',27,'LINE-CONSUME-9-27',3,3,8,83,2.00,2.00,0.00,4,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (385,'INV-OUT-20261024102549023-8857770850600','OUT','WIP_CONSUME',27,'LINE-CONSUME-9-27',3,3,9,84,2.00,2.00,0.00,4,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (386,'INV-OUT-20261024102549027-8857774900200','OUT','WIP_CONSUME',27,'LINE-CONSUME-9-27',3,3,10,85,8.00,8.00,0.00,4,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (387,'INV-OUT-20261024102549033-8857780595900','OUT','WIP_CONSUME',27,'LINE-CONSUME-9-27',3,3,11,86,2.00,2.00,0.00,4,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (388,'INV-OUT-20261024102549036-8857783202300','OUT','WIP_CONSUME',27,'LINE-CONSUME-9-27',3,3,12,87,2.00,2.00,0.00,4,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (389,'INV-OUT-20261024102549038-8857786085800','OUT','WIP_CONSUME',27,'LINE-CONSUME-9-27',3,3,13,88,2.00,2.00,0.00,4,'2026-10-24 10:25:49','工单 9 线边过账');
INSERT INTO `t_inventory_transaction` (`id`, `transaction_no`, `transaction_type`, `business_type`, `source_order_id`, `source_order_no`, `warehouse_id`, `location_id`, `material_id`, `lot_id`, `quantity`, `before_quantity`, `after_quantity`, `created_by`, `created_at`, `remark`) VALUES (390,'INV-IN-20261024102549650-8858397281000','IN','WIP_OUTPUT',30,'LINE-OUTPUT-9-30',3,3,16,89,2.00,0.00,2.00,4,'2026-10-24 10:25:50','工单 9 线边过账');
/*!40000 ALTER TABLE `t_inventory_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_location`
--

DROP TABLE IF EXISTS `t_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_location` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '库位ID',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `location_code` varchar(50) NOT NULL COMMENT '库位编码',
  `location_name` varchar(100) NOT NULL COMMENT '库位名称',
  `location_type` varchar(30) DEFAULT NULL COMMENT '库位类型',
  `status` varchar(30) NOT NULL DEFAULT '1' COMMENT '状态',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  `x_coordinate` int DEFAULT NULL,
  `y_coordinate` int DEFAULT NULL,
  `z_coordinate` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='库位表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_location`
--

LOCK TABLES `t_location` WRITE;
/*!40000 ALTER TABLE `t_location` DISABLE KEYS */;
INSERT INTO `t_location` (`id`, `warehouse_id`, `location_code`, `location_name`, `location_type`, `status`, `created_at`, `updated_at`, `is_deleted`, `x_coordinate`, `y_coordinate`, `z_coordinate`) VALUES (1,1,'LOC-001','默认库位','NORMAL','1','2026-07-15 10:21:37','2026-07-15 10:21:37',0,NULL,NULL,NULL);
INSERT INTO `t_location` (`id`, `warehouse_id`, `location_code`, `location_name`, `location_type`, `status`, `created_at`, `updated_at`, `is_deleted`, `x_coordinate`, `y_coordinate`, `z_coordinate`) VALUES (2,2,'WH-A100-RM-01','一号库位',NULL,'1','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,NULL,NULL);
INSERT INTO `t_location` (`id`, `warehouse_id`, `location_code`, `location_name`, `location_type`, `status`, `created_at`, `updated_at`, `is_deleted`, `x_coordinate`, `y_coordinate`, `z_coordinate`) VALUES (3,3,'WH-A100-LINE-01','一号库位',NULL,'1','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,NULL,NULL);
INSERT INTO `t_location` (`id`, `warehouse_id`, `location_code`, `location_name`, `location_type`, `status`, `created_at`, `updated_at`, `is_deleted`, `x_coordinate`, `y_coordinate`, `z_coordinate`) VALUES (4,4,'WH-A100-FG-01','一号库位',NULL,'1','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `t_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_login_log`
--

DROP TABLE IF EXISTS `t_login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_login_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '登录日志ID',
  `user_id` bigint DEFAULT NULL COMMENT '用户ID',
  `user_code` varchar(6) NOT NULL COMMENT '用户编码',
  `username` varchar(50) NOT NULL COMMENT '登录账号',
  `login_type` tinyint NOT NULL COMMENT '操作类型：1登录 2登出',
  `login_ip` varchar(50) DEFAULT NULL COMMENT '登录IP',
  `login_location` varchar(100) DEFAULT NULL COMMENT '登录地点',
  `browser` varchar(255) DEFAULT NULL COMMENT '浏览器',
  `os` varchar(255) DEFAULT NULL COMMENT '操作系统',
  `status` tinyint NOT NULL COMMENT '状态：0失败 1成功',
  `msg` varchar(255) DEFAULT NULL COMMENT '提示消息',
  `login_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '登录时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='登录日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_login_log`
--

LOCK TABLES `t_login_log` WRITE;
/*!40000 ALTER TABLE `t_login_log` DISABLE KEYS */;
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (1,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 10:30:23');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (2,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 10:42:43');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (3,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 10:51:17');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (4,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 12:51:59');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (5,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 14:33:47');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (6,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 14:39:34');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (7,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 14:49:01');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (8,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:18:43');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (9,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:23:59');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (10,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:24:57');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (11,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:43:18');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (12,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:46:25');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (13,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:54:24');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (14,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 15:56:25');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (15,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 16:02:53');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (16,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 16:14:27');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (17,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 17:16:23');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (18,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 17:20:30');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (19,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 18:15:56');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (20,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 18:20:48');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (21,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 18:40:30');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (22,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-15 19:13:32');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (23,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-15 19:15:46');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (24,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 19:16:19');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (25,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-15 19:18:28');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (26,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 19:21:38');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (27,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-15 19:31:50');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (28,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 19:40:27');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (29,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 19:51:06');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (30,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 20:09:03');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (31,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-15 20:37:43');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (32,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-16 08:52:29');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (33,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 08:54:42');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (34,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 09:23:04');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (35,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 10:25:16');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (36,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 10:29:50');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (37,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 10:40:43');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (38,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 10:46:00');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (39,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 10:50:16');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (40,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 11:03:09');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (41,1,'109001','admin',1,'172.24.79.157',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-16 11:21:10');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (42,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 11:24:54');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (43,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 11:30:09');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (44,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 12:22:24');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (45,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 12:28:50');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (46,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 13:06:01');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (47,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 14:25:11');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (48,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 14:38:45');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (49,2,'101001','prod_manager',1,'172.24.79.157',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 15:56:23');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (50,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 22:42:16');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (51,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 22:42:49');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (52,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-16 22:53:03');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (53,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 08:31:56');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (54,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-07-17 08:55:53');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (55,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 08:57:11');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (56,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-07-17 09:07:04');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (57,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-07-17 09:09:58');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (58,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 09:11:59');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (59,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-07-17 09:14:48');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (60,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-07-17 09:24:56');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (61,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-07-17 09:32:46');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (62,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 13:19:59');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (63,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 13:25:37');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (64,1,'109001','admin',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 13:51:53');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (65,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 13:54:59');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (66,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 13:56:52');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (67,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 14:04:10');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (68,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 14:04:23');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (69,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:16:08');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (70,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 14:18:43');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (71,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:19:48');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (72,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:22:18');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (73,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:24:42');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (74,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:28:12');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (75,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:31:05');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (76,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:33:25');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (77,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:34:49');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (78,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:41:47');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (79,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:42:28');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (80,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 14:43:04');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (81,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:43:51');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (82,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-17 14:44:16');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (83,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-17 14:45:39');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (84,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-18 08:37:01');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (85,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) W',1,'登录成功','2026-07-18 08:37:09');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (86,2,'101001','prod_manager',1,'0:0:0:0:0:0:0:1',NULL,'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O','Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac O',1,'登录成功','2026-07-18 08:37:59');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (87,2,'101001','prod_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-18 15:23:07');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (88,2,'101001','prod_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-18 15:23:26');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (89,1,'109001','admin',1,'127.0.0.1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-10-18 15:29:08');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (90,1,'109001','admin',1,'127.0.0.1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-10-19 08:43:28');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (91,1,'109001','admin',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-19 08:45:07');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (92,1,'109001','admin',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-19 09:13:50');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (93,1,'109001','admin',1,'127.0.0.1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-10-19 21:27:36');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (94,1,'109001','admin',1,'127.0.0.1',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWeb',1,'登录成功','2026-10-23 23:24:07');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (95,1,'109001','admin',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-23 23:35:18');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (96,1,'109001','admin',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-24 10:25:28');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (97,4,'103001','worker1',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-24 10:25:29');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (98,5,'104001','qc_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-24 10:25:29');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (99,6,'105001','warehouse_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-24 10:25:29');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (100,7,'106001','purchase_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-24 10:25:29');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (101,8,'107001','sales_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-24 10:25:29');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (102,9,'108001','equipment_manager',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-24 10:25:29');
INSERT INTO `t_login_log` (`id`, `user_id`, `user_code`, `username`, `login_type`, `login_ip`, `login_location`, `browser`, `os`, `status`, `msg`, `login_time`) VALUES (103,11,'111001','mcadmin',1,'127.0.0.1',NULL,'Python-urllib/3.12','Python-urllib/3.12',1,'登录成功','2026-10-24 10:25:29');
/*!40000 ALTER TABLE `t_login_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_lot`
--

DROP TABLE IF EXISTS `t_lot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_lot` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '批次ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_no` varchar(50) NOT NULL COMMENT '批次号',
  `production_date` datetime DEFAULT NULL COMMENT '生产日期',
  `expire_date` datetime DEFAULT NULL COMMENT '过期日期',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `lot_no` (`lot_no`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='批次表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_lot`
--

LOCK TABLES `t_lot` WRITE;
/*!40000 ALTER TABLE `t_lot` DISABLE KEYS */;
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (1,2,'MC-102528061580-0-2','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:31','2026-10-24 10:25:31',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (2,3,'MC-102528061580-0-3','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:31','2026-10-24 10:25:31',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (3,4,'MC-102528061580-0-4','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:31','2026-10-24 10:25:31',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (4,5,'MC-102528061580-0-5','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:31','2026-10-24 10:25:31',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (5,6,'MC-102528061580-0-6','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:31','2026-10-24 10:25:31',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (6,7,'MC-102528061580-0-7','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:31','2026-10-24 10:25:31',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (7,8,'MC-102528061580-0-8','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:31','2026-10-24 10:25:31',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (8,9,'MC-102528061580-0-9','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:31','2026-10-24 10:25:31',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (9,10,'MC-102528061580-0-10','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:31','2026-10-24 10:25:31',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (10,11,'MC-102528061580-0-11','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:31','2026-10-24 10:25:31',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (11,12,'MC-102528061580-0-12','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:31','2026-10-24 10:25:31',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (12,13,'MC-102528061580-0-13','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:31','2026-10-24 10:25:31',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (13,2,'MC-102528061580-1-2','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:32','2026-10-24 10:25:32',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (14,3,'MC-102528061580-1-3','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:32','2026-10-24 10:25:32',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (15,4,'MC-102528061580-1-4','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:32','2026-10-24 10:25:32',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (16,5,'MC-102528061580-1-5','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:32','2026-10-24 10:25:32',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (17,6,'MC-102528061580-1-6','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:32','2026-10-24 10:25:32',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (18,7,'MC-102528061580-1-7','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:32','2026-10-24 10:25:32',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (19,8,'MC-102528061580-1-8','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:32','2026-10-24 10:25:32',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (20,9,'MC-102528061580-1-9','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:32','2026-10-24 10:25:32',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (21,10,'MC-102528061580-1-10','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:32','2026-10-24 10:25:32',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (22,11,'MC-102528061580-1-11','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:32','2026-10-24 10:25:32',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (23,12,'MC-102528061580-1-12','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:32','2026-10-24 10:25:32',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (24,13,'MC-102528061580-1-13','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:32','2026-10-24 10:25:32',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (25,16,'FG-MO-1','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:34','2026-10-24 10:25:34',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (26,2,'MC-BOXLOT-102528061580','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:36','2026-10-24 10:25:36',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (27,4,'MC-WO-102528061580-3-4','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:38','2026-10-24 10:25:38',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (28,5,'MC-WO-102528061580-3-5','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:38','2026-10-24 10:25:38',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (29,6,'MC-WO-102528061580-3-6','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:38','2026-10-24 10:25:38',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (30,7,'MC-WO-102528061580-3-7','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:38','2026-10-24 10:25:38',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (31,14,'FG-MO-3','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:39','2026-10-24 10:25:39',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (32,3,'MC-WO-102528061580-4-3','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:39','2026-10-24 10:25:39',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (33,8,'MC-WO-102528061580-4-8','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:39','2026-10-24 10:25:39',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (34,9,'MC-WO-102528061580-4-9','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:39','2026-10-24 10:25:39',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (35,10,'MC-WO-102528061580-4-10','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:39','2026-10-24 10:25:39',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (36,15,'FG-MO-4','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:39','2026-10-24 10:25:39',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (37,11,'MC-WO-102528061580-2-11','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:40','2026-10-24 10:25:40',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (38,12,'MC-WO-102528061580-2-12','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:40','2026-10-24 10:25:40',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (39,13,'MC-WO-102528061580-2-13','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:40','2026-10-24 10:25:40',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (40,16,'FG-MO-2','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:41',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (41,3,'MC-WO-102528061580-5-3','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:41',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (42,4,'MC-WO-102528061580-5-4','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:41',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (43,5,'MC-WO-102528061580-5-5','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:41',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (44,6,'MC-WO-102528061580-5-6','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:41',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (45,7,'MC-WO-102528061580-5-7','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:41',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (46,8,'MC-WO-102528061580-5-8','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:41',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (47,9,'MC-WO-102528061580-5-9','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:41',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (48,10,'MC-WO-102528061580-5-10','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:41',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (49,11,'MC-WO-102528061580-5-11','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:41',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (50,12,'MC-WO-102528061580-5-12','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:41',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (51,13,'MC-WO-102528061580-5-13','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:41',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (52,16,'FG-MO-5','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:42','2026-10-24 10:25:42',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (53,3,'MC-WO-102528061580-6-3','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:43','2026-10-24 10:25:43',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (54,4,'MC-WO-102528061580-6-4','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:43','2026-10-24 10:25:43',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (55,5,'MC-WO-102528061580-6-5','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:43','2026-10-24 10:25:43',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (56,6,'MC-WO-102528061580-6-6','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:43','2026-10-24 10:25:43',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (57,7,'MC-WO-102528061580-6-7','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:43','2026-10-24 10:25:43',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (58,8,'MC-WO-102528061580-6-8','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:43','2026-10-24 10:25:43',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (59,9,'MC-WO-102528061580-6-9','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:43','2026-10-24 10:25:43',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (60,10,'MC-WO-102528061580-6-10','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:43','2026-10-24 10:25:43',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (61,11,'MC-WO-102528061580-6-11','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:43','2026-10-24 10:25:43',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (62,12,'MC-WO-102528061580-6-12','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:43','2026-10-24 10:25:43',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (63,13,'MC-WO-102528061580-6-13','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:43','2026-10-24 10:25:43',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (64,16,'FG-MO-6','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:44','2026-10-24 10:25:44',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (65,2,'MC-RACE-102528061580','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:44','2026-10-24 10:25:44',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (66,3,'MC-WO-102528061580-7-3','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:45','2026-10-24 10:25:45',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (67,4,'MC-WO-102528061580-7-4','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:45','2026-10-24 10:25:45',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (68,5,'MC-WO-102528061580-7-5','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:45','2026-10-24 10:25:45',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (69,6,'MC-WO-102528061580-7-6','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:45','2026-10-24 10:25:45',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (70,7,'MC-WO-102528061580-7-7','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:45','2026-10-24 10:25:45',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (71,8,'MC-WO-102528061580-7-8','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:45','2026-10-24 10:25:45',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (72,9,'MC-WO-102528061580-7-9','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:45','2026-10-24 10:25:45',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (73,10,'MC-WO-102528061580-7-10','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:45','2026-10-24 10:25:45',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (74,11,'MC-WO-102528061580-7-11','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:45','2026-10-24 10:25:45',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (75,12,'MC-WO-102528061580-7-12','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:45','2026-10-24 10:25:45',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (76,13,'MC-WO-102528061580-7-13','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:45','2026-10-24 10:25:45',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (77,16,'FG-MO-7','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:47','2026-10-24 10:25:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (78,3,'MC-WO-102528061580-9-3','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:47','2026-10-24 10:25:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (79,4,'MC-WO-102528061580-9-4','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:47','2026-10-24 10:25:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (80,5,'MC-WO-102528061580-9-5','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:47','2026-10-24 10:25:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (81,6,'MC-WO-102528061580-9-6','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:47','2026-10-24 10:25:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (82,7,'MC-WO-102528061580-9-7','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:47','2026-10-24 10:25:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (83,8,'MC-WO-102528061580-9-8','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:47','2026-10-24 10:25:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (84,9,'MC-WO-102528061580-9-9','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:47','2026-10-24 10:25:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (85,10,'MC-WO-102528061580-9-10','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:47','2026-10-24 10:25:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (86,11,'MC-WO-102528061580-9-11','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:47','2026-10-24 10:25:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (87,12,'MC-WO-102528061580-9-12','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:47','2026-10-24 10:25:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (88,13,'MC-WO-102528061580-9-13','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:47','2026-10-24 10:25:47',0);
INSERT INTO `t_lot` (`id`, `material_id`, `lot_no`, `production_date`, `expire_date`, `created_at`, `updated_at`, `is_deleted`) VALUES (89,16,'FG-MO-9','2026-10-24 00:00:00',NULL,'2026-10-24 10:25:49','2026-10-24 10:25:49',0);
/*!40000 ALTER TABLE `t_lot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_maintenance`
--

DROP TABLE IF EXISTS `t_maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_maintenance` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '维护记录ID',
  `maintenance_no` varchar(50) NOT NULL COMMENT '维护单号',
  `equipment_id` bigint NOT NULL COMMENT '设备ID',
  `equipment_name` varchar(100) NOT NULL COMMENT '设备名称',
  `maintenance_type` tinyint NOT NULL COMMENT '维护类型',
  `fault_desc` text COMMENT '故障描述',
  `maintenance_content` text,
  `maintenance_user_id` bigint DEFAULT NULL,
  `maintenance_user_name` varchar(50) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `cost` decimal(10,2) DEFAULT NULL COMMENT '维护费用',
  `result` varchar(50) DEFAULT NULL,
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `status` varchar(30) NOT NULL DEFAULT 'PENDING' COMMENT '维修状态',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `maintenance_no` (`maintenance_no`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='设备维护记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_maintenance`
--

LOCK TABLES `t_maintenance` WRITE;
/*!40000 ALTER TABLE `t_maintenance` DISABLE KEYS */;
INSERT INTO `t_maintenance` (`id`, `maintenance_no`, `equipment_id`, `equipment_name`, `maintenance_type`, `fault_desc`, `maintenance_content`, `maintenance_user_id`, `maintenance_user_name`, `start_time`, `end_time`, `cost`, `result`, `remark`, `create_time`, `status`, `update_time`) VALUES (1,'REPAIR-000001',2,'隔离设备',2,'隔离验收异常，生成报修','隔离验收维修完成',9,'黄十二','2026-10-24 10:25:37','2026-10-24 10:25:37',0.00,'REPAIRED','来源点检记录 1','2026-10-24 10:25:37','FINISHED','2026-10-24 10:25:37');
/*!40000 ALTER TABLE `t_maintenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_material`
--

DROP TABLE IF EXISTS `t_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_material` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '物料ID',
  `material_code` varchar(50) NOT NULL COMMENT '物料编码',
  `material_name` varchar(100) NOT NULL COMMENT '物料名称',
  `material_type` tinyint NOT NULL COMMENT '物料类型：1原材料 2半成品 3成品',
  `specification` varchar(100) DEFAULT NULL COMMENT '规格型号',
  `unit` varchar(20) NOT NULL COMMENT '计量单位',
  `safety_stock` int DEFAULT NULL COMMENT '安全库存',
  `current_stock` int NOT NULL DEFAULT '0' COMMENT '当前库存',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0禁用 1启用',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `category_id` bigint DEFAULT NULL,
  `max_stock` decimal(18,2) DEFAULT NULL,
  `sourcing_mode` varchar(20) NOT NULL DEFAULT 'AUTO',
  PRIMARY KEY (`id`),
  UNIQUE KEY `material_code` (`material_code`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='物料表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_material`
--

LOCK TABLES `t_material` WRITE;
/*!40000 ALTER TABLE `t_material` DISABLE KEYS */;
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`, `sourcing_mode`) VALUES (1,'MAT-001','测试物料',1,'默认规格','个',10,100,1,'系统初始化物料','2026-07-15 10:21:37','2026-07-15 10:21:37',NULL,NULL,'AUTO');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`, `sourcing_mode`) VALUES (2,'MAT-SHELL-TOP-A100','鼠标上盖',1,NULL,'个',0,1,1,NULL,'2026-10-19 08:41:54','2026-10-24 10:25:48',NULL,NULL,'AUTO');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`, `sourcing_mode`) VALUES (3,'MAT-SHELL-BOTTOM-A100','鼠标下盖',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 10:25:49',NULL,NULL,'AUTO');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`, `sourcing_mode`) VALUES (4,'MAT-PCB-A100','PCB主板',1,NULL,'块',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 10:25:49',NULL,NULL,'AUTO');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`, `sourcing_mode`) VALUES (5,'MAT-SWITCH-01','微动开关',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 10:25:49',NULL,NULL,'AUTO');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`, `sourcing_mode`) VALUES (6,'MAT-ENCODER-01','滚轮编码器',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 10:25:49',NULL,NULL,'AUTO');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`, `sourcing_mode`) VALUES (7,'MAT-USB-CABLE-A100','USB连接线',1,NULL,'根',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 10:25:49',NULL,NULL,'AUTO');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`, `sourcing_mode`) VALUES (8,'MAT-WHEEL-A100','滚轮组件',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 10:25:49',NULL,NULL,'AUTO');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`, `sourcing_mode`) VALUES (9,'MAT-LENS-A100','光学透镜',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 10:25:49',NULL,NULL,'AUTO');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`, `sourcing_mode`) VALUES (10,'MAT-SCREW-A100','固定螺钉',1,NULL,'颗',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 10:25:49',NULL,NULL,'AUTO');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`, `sourcing_mode`) VALUES (11,'MAT-FEET-A100','防滑脚贴',1,NULL,'套',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 10:25:49',NULL,NULL,'AUTO');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`, `sourcing_mode`) VALUES (12,'MAT-LABEL-A100','产品铭牌',1,NULL,'张',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 10:25:49',NULL,NULL,'AUTO');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`, `sourcing_mode`) VALUES (13,'MAT-BOX-A100','包装盒',1,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 10:25:49',NULL,NULL,'AUTO');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`, `sourcing_mode`) VALUES (14,'MAT-SEMI-E-A100','A100电子组件',2,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 10:25:40',NULL,NULL,'AUTO');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`, `sourcing_mode`) VALUES (15,'MAT-SEMI-S-A100','A100结构组件',2,NULL,'个',0,0,1,NULL,'2026-10-19 08:41:54','2026-10-24 10:25:40',NULL,NULL,'AUTO');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`, `sourcing_mode`) VALUES (16,'MAT-FG-A100','A100鼠标成品',3,NULL,'只',0,22,1,NULL,'2026-10-19 08:41:54','2026-10-24 10:25:49',NULL,NULL,'AUTO');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`, `sourcing_mode`) VALUES (17,'MC-BUY-SEMI-102528061580','外购半成品验收',2,NULL,'验收箱102528061580',0,0,1,NULL,'2026-10-24 10:25:47','2026-10-24 10:25:47',NULL,NULL,'BUY');
INSERT INTO `t_material` (`id`, `material_code`, `material_name`, `material_type`, `specification`, `unit`, `safety_stock`, `current_stock`, `status`, `remark`, `create_time`, `update_time`, `category_id`, `max_stock`, `sourcing_mode`) VALUES (18,'MC-BUY-FG-102528061580','外购件装配成品验收',3,NULL,'验收箱102528061580',0,0,1,NULL,'2026-10-24 10:25:47','2026-10-24 10:25:47',NULL,NULL,'MAKE');
/*!40000 ALTER TABLE `t_material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_material_issue`
--

DROP TABLE IF EXISTS `t_material_issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_material_issue` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '领料单ID',
  `issue_no` varchar(50) NOT NULL COMMENT '领料单号',
  `work_order_id` bigint NOT NULL COMMENT '工单ID',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `total_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总数量',
  `status` varchar(30) NOT NULL DEFAULT 'PENDING' COMMENT '状态',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `issue_no` (`issue_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产领料单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_material_issue`
--

LOCK TABLES `t_material_issue` WRITE;
/*!40000 ALTER TABLE `t_material_issue` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_material_issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_material_issue_item`
--

DROP TABLE IF EXISTS `t_material_issue_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_material_issue_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '领料明细ID',
  `issue_id` bigint NOT NULL COMMENT '领料单ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_id` bigint DEFAULT NULL COMMENT '批次ID',
  `planned_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '计划数量',
  `actual_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '实际数量',
  `location_id` bigint DEFAULT NULL COMMENT '库位ID',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产领料明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_material_issue_item`
--

LOCK TABLES `t_material_issue_item` WRITE;
/*!40000 ALTER TABLE `t_material_issue_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_material_issue_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_operation_log`
--

DROP TABLE IF EXISTS `t_operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_operation_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '操作日志ID',
  `user_id` bigint DEFAULT NULL COMMENT '操作人ID',
  `user_code` varchar(6) NOT NULL COMMENT '操作人编码',
  `username` varchar(50) NOT NULL COMMENT '操作人账号',
  `module` varchar(50) NOT NULL COMMENT '操作模块',
  `operation` varchar(100) NOT NULL COMMENT '操作描述',
  `method` varchar(200) DEFAULT NULL COMMENT '请求方法',
  `request_url` varchar(255) DEFAULT NULL COMMENT '请求URL',
  `request_param` text COMMENT '请求参数',
  `response_result` text COMMENT '返回结果',
  `operate_ip` varchar(50) DEFAULT NULL COMMENT '操作IP',
  `operate_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  `status` tinyint NOT NULL COMMENT '状态：0失败 1成功',
  `error_msg` text COMMENT '错误消息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='操作日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_operation_log`
--

LOCK TABLES `t_operation_log` WRITE;
/*!40000 ALTER TABLE `t_operation_log` DISABLE KEYS */;
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (1,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 10:30:23',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (2,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 10:42:43',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (3,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 10:51:17',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (4,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 12:51:59',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (5,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 14:33:47',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (6,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 14:39:34',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (7,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 14:49:01',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (8,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:18:43',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (9,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:23:59',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (10,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:24:57',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (11,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:43:18',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (12,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:46:25',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (13,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:54:24',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (14,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 15:56:25',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (15,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 16:02:53',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (16,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 16:14:27',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (17,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 17:16:23',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (18,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 17:20:30',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (19,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 18:15:56',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (20,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 18:20:48',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (21,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 18:40:30',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (22,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:13:32',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (23,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:15:46',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (24,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:16:19',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (25,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:18:28',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (26,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:21:38',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (27,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:31:50',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (28,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:40:27',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (29,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 19:51:06',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (30,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 20:09:03',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (31,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-15 20:37:43',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (32,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 08:52:29',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (33,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 08:54:42',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (34,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 09:23:04',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (35,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 10:25:16',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (36,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 10:29:50',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (37,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 10:40:43',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (38,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 10:46:00',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (39,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 10:50:16',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (40,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 11:03:09',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (41,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 11:21:10',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (42,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 11:24:54',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (43,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 11:30:09',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (44,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 12:22:24',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (45,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 12:28:50',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (46,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 13:06:01',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (47,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 14:25:11',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (48,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 14:38:45',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (49,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'172.24.79.157','2026-07-16 15:56:23',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (50,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 22:42:16',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (51,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 22:42:49',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (52,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-16 22:53:03',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (53,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 08:31:56',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (54,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 08:55:53',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (55,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 08:57:11',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (56,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 09:07:04',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (57,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 09:09:58',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (58,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 09:11:59',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (59,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 09:14:48',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (60,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 09:24:56',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (61,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 09:32:46',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (62,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 13:19:59',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (63,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 13:25:37',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (64,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 13:51:53',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (65,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 13:54:59',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (66,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 13:56:52',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (67,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:04:10',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (68,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:04:23',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (69,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:16:08',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (70,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:18:43',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (71,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:19:48',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (72,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:22:18',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (73,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:24:42',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (74,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:28:12',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (75,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:31:05',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (76,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:33:25',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (77,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:34:49',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (78,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:41:47',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (79,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:42:28',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (80,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:43:04',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (81,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:43:51',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (82,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:44:16',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (83,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-17 14:45:39',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (84,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-18 08:37:01',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (85,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-18 08:37:09',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (86,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'0:0:0:0:0:0:0:1','2026-07-18 08:37:59',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (87,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-18 15:23:07',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (88,2,'101001','prod_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-18 15:23:26',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (89,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-18 15:29:08',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (90,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-19 08:43:28',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (91,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-19 08:45:07',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (92,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-19 09:13:51',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (93,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-19 21:27:36',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (94,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-23 23:24:07',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (95,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-23 23:35:18',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (96,1,'109001','admin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-24 10:25:28',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (97,4,'103001','worker1','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-24 10:25:29',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (98,5,'104001','qc_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-24 10:25:29',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (99,6,'105001','warehouse_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-24 10:25:29',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (100,7,'106001','purchase_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-24 10:25:29',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (101,8,'107001','sales_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-24 10:25:29',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (102,9,'108001','equipment_manager','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-24 10:25:29',1,NULL);
INSERT INTO `t_operation_log` (`id`, `user_id`, `user_code`, `username`, `module`, `operation`, `method`, `request_url`, `request_param`, `response_result`, `operate_ip`, `operate_time`, `status`, `error_msg`) VALUES (103,11,'111001','mcadmin','系统登录','无','POST','/api/auth/login',NULL,NULL,'127.0.0.1','2026-10-24 10:25:29',1,NULL);
/*!40000 ALTER TABLE `t_operation_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order`
--

DROP TABLE IF EXISTS `t_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `order_no` varchar(50) NOT NULL COMMENT '订单编号',
  `customer_name` varchar(100) NOT NULL COMMENT '客户名称',
  `customer_phone` varchar(20) DEFAULT NULL COMMENT '客户电话',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `quantity` int NOT NULL COMMENT '订单数量',
  `unit_price` decimal(10,2) NOT NULL COMMENT '单价',
  `total_amount` decimal(10,2) NOT NULL COMMENT '总金额',
  `order_date` date NOT NULL COMMENT '下单日期',
  `delivery_date` date DEFAULT NULL COMMENT '交付日期',
  `order_status` tinyint NOT NULL DEFAULT '0' COMMENT '订单状态',
  `priority` tinyint NOT NULL DEFAULT '2' COMMENT '优先级',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_by` bigint NOT NULL COMMENT '创建人ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order`
--

LOCK TABLES `t_order` WRITE;
/*!40000 ALTER TABLE `t_order` DISABLE KEYS */;
INSERT INTO `t_order` (`id`, `order_no`, `customer_name`, `customer_phone`, `product_name`, `quantity`, `unit_price`, `total_amount`, `order_date`, `delivery_date`, `order_status`, `priority`, `remark`, `create_by`, `create_time`, `update_time`, `deleted`) VALUES (1,'ORD-20260715001','测试客户A','13900139001','测试鼠标',100,59.00,5900.00,'2026-07-15','2026-07-25',3,2,'测试订单',2,'2026-07-15 10:23:38','2026-07-16 11:29:17',0);
INSERT INTO `t_order` (`id`, `order_no`, `customer_name`, `customer_phone`, `product_name`, `quantity`, `unit_price`, `total_amount`, `order_date`, `delivery_date`, `order_status`, `priority`, `remark`, `create_by`, `create_time`, `update_time`, `deleted`) VALUES (2,'ORD-20260715002','测试客户B','13900139002','测试鼠标',200,59.00,11800.00,'2026-07-14','2026-07-22',1,1,'紧急订单',2,'2026-07-15 10:23:38','2026-07-17 13:57:49',1);
INSERT INTO `t_order` (`id`, `order_no`, `customer_name`, `customer_phone`, `product_name`, `quantity`, `unit_price`, `total_amount`, `order_date`, `delivery_date`, `order_status`, `priority`, `remark`, `create_by`, `create_time`, `update_time`, `deleted`) VALUES (3,'ORD-20260715003','测试客户C','13900139003','测试鼠标',150,59.00,8850.00,'2026-07-13','2026-07-20',2,2,'普通订单',2,'2026-07-15 10:23:38','2026-07-15 10:23:38',0);
INSERT INTO `t_order` (`id`, `order_no`, `customer_name`, `customer_phone`, `product_name`, `quantity`, `unit_price`, `total_amount`, `order_date`, `delivery_date`, `order_status`, `priority`, `remark`, `create_by`, `create_time`, `update_time`, `deleted`) VALUES (4,'ORD-20260715962','plt','15555555555','滚轮',10,10.00,100.00,'2026-07-15','2026-07-25',1,3,'无',2,'2026-07-15 20:41:20','2026-07-16 12:35:09',0);
INSERT INTO `t_order` (`id`, `order_no`, `customer_name`, `customer_phone`, `product_name`, `quantity`, `unit_price`, `total_amount`, `order_date`, `delivery_date`, `order_status`, `priority`, `remark`, `create_by`, `create_time`, `update_time`, `deleted`) VALUES (5,'MC-102528061580','隔离客户',NULL,'A100有线办公鼠标',100,89.00,8900.00,'2026-10-24',NULL,3,2,NULL,8,'2026-10-24 10:25:31','2026-10-24 10:25:35',0);
INSERT INTO `t_order` (`id`, `order_no`, `customer_name`, `customer_phone`, `product_name`, `quantity`, `unit_price`, `total_amount`, `order_date`, `delivery_date`, `order_status`, `priority`, `remark`, `create_by`, `create_time`, `update_time`, `deleted`) VALUES (6,'MC-MULTI-102528061580','隔离多工单客户',NULL,'A100有线办公鼠标',2,89.00,178.00,'2026-10-24',NULL,3,2,NULL,8,'2026-10-24 10:25:41','2026-10-24 10:25:44',0);
/*!40000 ALTER TABLE `t_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_product`
--

DROP TABLE IF EXISTS `t_order_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_product` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '订单产品明细ID',
  `order_id` bigint NOT NULL COMMENT '订单ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `quantity` int NOT NULL COMMENT '数量',
  `unit_price` decimal(10,2) NOT NULL COMMENT '单价',
  `subtotal` decimal(10,2) NOT NULL COMMENT '小计',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='订单产品明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_product`
--

LOCK TABLES `t_order_product` WRITE;
/*!40000 ALTER TABLE `t_order_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_order_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_product`
--

DROP TABLE IF EXISTS `t_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_product` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '产品ID',
  `product_code` varchar(50) NOT NULL COMMENT '产品编码',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `product_type` varchar(50) DEFAULT NULL COMMENT '产品类型',
  `model` varchar(50) DEFAULT NULL COMMENT '产品型号',
  `specification` varchar(100) DEFAULT NULL COMMENT '规格',
  `unit` varchar(20) NOT NULL COMMENT '单位',
  `cost_price` decimal(10,2) DEFAULT NULL COMMENT '成本价',
  `selling_price` decimal(10,2) DEFAULT NULL COMMENT '销售价',
  `description` text COMMENT '描述',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0停售 1在售',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `category_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code` (`product_code`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='产品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_product`
--

LOCK TABLES `t_product` WRITE;
/*!40000 ALTER TABLE `t_product` DISABLE KEYS */;
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`, `category_id`) VALUES (1,'PROD-001','测试鼠标','鼠标','M-001','默认规格','个',20.00,59.00,NULL,1,'2026-07-15 10:21:37','2026-07-15 10:21:37',NULL);
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`, `category_id`) VALUES (2,'PROD-002','无线鼠标','鼠标','M-002','无线蓝牙版','个',35.00,89.00,NULL,1,'2026-07-17 14:01:48','2026-07-17 14:01:48',NULL);
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`, `category_id`) VALUES (3,'PROD-003','游戏鼠标','鼠标','M-003','RGB背光','个',50.00,129.00,NULL,1,'2026-07-17 14:01:48','2026-07-17 14:01:48',NULL);
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`, `category_id`) VALUES (4,'PROD-004','办公鼠标','鼠标','M-004','静音版','个',25.00,69.00,NULL,1,'2026-07-17 14:01:48','2026-07-17 14:01:48',NULL);
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`, `category_id`) VALUES (5,'PROD-005','有线鼠标','鼠标','M-005','USB接口','个',15.00,49.00,NULL,1,'2026-07-17 14:01:48','2026-07-17 14:01:48',NULL);
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`, `category_id`) VALUES (6,'PRD-MOUSE-A100','A100有线办公鼠标','有线鼠标','A100','USB有线、1200DPI、3键','只',42.00,89.00,NULL,1,'2026-10-19 08:41:54','2026-10-19 08:41:54',NULL);
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`, `category_id`) VALUES (7,'MC-SEMI-15-102528061580','隔离A100结构组件',NULL,NULL,NULL,'个',1.00,1.00,NULL,1,'2026-10-24 10:25:37','2026-10-24 10:25:37',NULL);
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`, `category_id`) VALUES (8,'MC-SEMI-14-102528061580','隔离A100电子组件',NULL,NULL,NULL,'个',1.00,1.00,NULL,1,'2026-10-24 10:25:37','2026-10-24 10:25:37',NULL);
INSERT INTO `t_product` (`id`, `product_code`, `product_name`, `product_type`, `model`, `specification`, `unit`, `cost_price`, `selling_price`, `description`, `status`, `create_time`, `update_time`, `category_id`) VALUES (9,'MC-BUY-P-102528061580','外购件装配验收产品',NULL,NULL,NULL,'验收箱102528061580',1.00,1.00,NULL,1,'2026-10-24 10:25:47','2026-10-24 10:25:47',NULL);
/*!40000 ALTER TABLE `t_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_production_order`
--

DROP TABLE IF EXISTS `t_production_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_production_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '生产订单ID',
  `po_no` varchar(50) NOT NULL COMMENT '生产订单编号',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `planned_quantity` decimal(10,2) NOT NULL COMMENT '计划数量',
  `actual_quantity` decimal(10,2) DEFAULT '0.00' COMMENT '实际数量',
  `planned_start_date` datetime DEFAULT NULL COMMENT '计划开始时间',
  `planned_end_date` datetime DEFAULT NULL COMMENT '计划结束时间',
  `actual_start_date` datetime DEFAULT NULL COMMENT '实际开始时间',
  `actual_end_date` datetime DEFAULT NULL COMMENT '实际结束时间',
  `status` varchar(30) NOT NULL DEFAULT 'DRAFT' COMMENT '状态',
  `department_id` bigint DEFAULT NULL COMMENT '部门ID',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `po_no` (`po_no`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_production_order`
--

LOCK TABLES `t_production_order` WRITE;
/*!40000 ALTER TABLE `t_production_order` DISABLE KEYS */;
INSERT INTO `t_production_order` (`id`, `po_no`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (1,'PO-20260715001',1,200.00,50.00,'2026-07-15 08:00:00','2026-07-22 18:00:00',NULL,NULL,'IN_PROGRESS',2,2,'2026-07-15 10:24:08','2026-07-15 10:24:08',0);
INSERT INTO `t_production_order` (`id`, `po_no`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (2,'PO-20260715002',1,100.00,0.00,'2026-07-16 08:00:00','2026-07-25 18:00:00',NULL,NULL,'DRAFT',2,2,'2026-07-15 10:24:08','2026-07-15 10:24:08',0);
/*!40000 ALTER TABLE `t_production_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_production_plan`
--

DROP TABLE IF EXISTS `t_production_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_production_plan` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '计划ID',
  `plan_no` varchar(50) NOT NULL COMMENT '计划编号',
  `order_id` bigint DEFAULT NULL COMMENT '订单ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `plan_quantity` int NOT NULL COMMENT '计划数量',
  `completed_quantity` int NOT NULL DEFAULT '0' COMMENT '完成数量',
  `start_date` date DEFAULT NULL COMMENT '开始日期',
  `end_date` date DEFAULT NULL COMMENT '结束日期',
  `plan_status` tinyint NOT NULL DEFAULT '0' COMMENT '计划状态',
  `priority` tinyint NOT NULL DEFAULT '2' COMMENT '优先级',
  `create_by` bigint NOT NULL COMMENT '创建人ID',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `plan_no` (`plan_no`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产计划表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_production_plan`
--

LOCK TABLES `t_production_plan` WRITE;
/*!40000 ALTER TABLE `t_production_plan` DISABLE KEYS */;
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (1,'PLAN-20260715001',2,1,'测试鼠标',200,50,'2026-07-15','2026-07-22',1,1,2,'2026-07-15 10:23:53','2026-07-15 10:23:53');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (2,'PLAN-20260715002',1,1,'测试鼠标',100,0,'2026-07-16','2026-07-25',0,2,2,'2026-07-15 10:23:53','2026-07-15 10:23:53');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (3,'PLAN-20260715003',3,1,'测试鼠标',150,150,'2026-07-13','2026-07-20',2,2,2,'2026-07-15 10:23:53','2026-07-15 10:23:53');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (7,'PLAN1784270777801',4,1,'滚轮',10,0,'2026-07-17','2026-07-25',0,3,2,'2026-07-17 14:46:18','2026-07-17 14:46:18');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (8,'PP1792808731000',5,6,'A100有线办公鼠标',100,100,'2026-10-24',NULL,2,2,8,'2026-10-24 10:25:31','2026-10-24 10:25:34');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (9,'PLAN-MO-000002',NULL,6,'A100有线办公鼠标',10,10,'2026-10-24','2026-10-31',2,2,1,'2026-10-24 10:25:38','2026-10-24 10:25:41');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (10,'PLAN-MO-000004',NULL,8,'隔离A100电子组件',10,10,'2026-10-24','2026-10-31',2,2,1,'2026-10-24 10:25:38','2026-10-24 10:25:39');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (11,'PLAN-MO-000006',NULL,7,'隔离A100结构组件',10,10,'2026-10-24','2026-10-31',2,2,1,'2026-10-24 10:25:38','2026-10-24 10:25:39');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (12,'PLAN-MO-000008',6,6,'A100有线办公鼠标',1,1,'2026-10-24','2026-10-31',2,2,1,'2026-10-24 10:25:41','2026-10-24 10:25:42');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (13,'PLAN-MO-000010',6,6,'A100有线办公鼠标',1,1,'2026-10-24','2026-10-31',2,2,1,'2026-10-24 10:25:41','2026-10-24 10:25:44');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (14,'PLAN-MO-000012',NULL,6,'A100有线办公鼠标',1,0,'2026-10-24','2026-10-31',1,2,1,'2026-10-24 10:25:45','2026-10-24 10:25:45');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (15,'PLAN-MO-000014',NULL,6,'A100有线办公鼠标',1,0,'2026-10-24','2026-10-31',1,2,1,'2026-10-24 10:25:47','2026-10-24 10:25:47');
INSERT INTO `t_production_plan` (`id`, `plan_no`, `order_id`, `product_id`, `product_name`, `plan_quantity`, `completed_quantity`, `start_date`, `end_date`, `plan_status`, `priority`, `create_by`, `create_time`, `update_time`) VALUES (16,'PLAN-MO-000016',NULL,6,'A100有线办公鼠标',2,2,'2026-10-24','2026-10-31',2,2,1,'2026-10-24 10:25:47','2026-10-24 10:25:49');
/*!40000 ALTER TABLE `t_production_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_production_report`
--

DROP TABLE IF EXISTS `t_production_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_production_report` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '报工ID',
  `task_id` bigint NOT NULL COMMENT '任务ID',
  `report_user_id` bigint NOT NULL COMMENT '报工人ID',
  `report_user_name` varchar(50) NOT NULL COMMENT '报工人姓名',
  `report_quantity` int NOT NULL COMMENT '本次完成数量',
  `qualified_quantity` int NOT NULL COMMENT '合格数量',
  `defect_quantity` int NOT NULL COMMENT '不合格数量',
  `report_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '报工时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产报工表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_production_report`
--

LOCK TABLES `t_production_report` WRITE;
/*!40000 ALTER TABLE `t_production_report` DISABLE KEYS */;
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (1,1,3,'赵六',50,48,2,'2026-07-15 12:00:00','上午报工');
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (2,1,3,'赵六',30,29,1,'2026-07-15 18:00:00','下午报工');
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (3,2,4,'赵六',60,0,0,'2026-10-24 10:25:34',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (4,2,4,'赵六',40,0,0,'2026-10-24 10:25:34',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (5,3,4,'赵六',100,0,0,'2026-10-24 10:25:35',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (6,4,4,'赵六',100,0,0,'2026-10-24 10:25:35',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (7,5,4,'赵六',100,0,0,'2026-10-24 10:25:35',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (8,10,4,'赵六',10,0,0,'2026-10-24 10:25:39',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (9,11,4,'赵六',10,0,0,'2026-10-24 10:25:40',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (10,6,4,'赵六',6,0,0,'2026-10-24 10:25:41',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (11,12,4,'赵六',4,0,0,'2026-10-24 10:25:41',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (12,7,4,'赵六',10,0,0,'2026-10-24 10:25:41',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (13,8,4,'赵六',10,0,0,'2026-10-24 10:25:41',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (14,9,4,'赵六',10,0,0,'2026-10-24 10:25:41',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (15,13,4,'赵六',1,0,0,'2026-10-24 10:25:42',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (16,14,4,'赵六',1,0,0,'2026-10-24 10:25:43',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (17,15,4,'赵六',1,0,0,'2026-10-24 10:25:43',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (18,16,4,'赵六',1,0,0,'2026-10-24 10:25:43',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (19,17,4,'赵六',1,0,0,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (20,18,4,'赵六',1,0,0,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (21,19,4,'赵六',1,0,0,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (22,20,4,'赵六',1,0,0,'2026-10-24 10:25:44',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (23,21,4,'赵六',1,0,0,'2026-10-24 10:25:47',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (24,22,4,'赵六',1,0,0,'2026-10-24 10:25:47',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (25,23,4,'赵六',1,0,0,'2026-10-24 10:25:47',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (26,24,4,'赵六',1,0,0,'2026-10-24 10:25:47',NULL);
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (27,29,4,'赵六',2,0,0,'2026-10-24 10:25:49','');
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (28,30,4,'赵六',2,0,0,'2026-10-24 10:25:49','');
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (29,31,4,'赵六',2,0,0,'2026-10-24 10:25:50','');
INSERT INTO `t_production_report` (`id`, `task_id`, `report_user_id`, `report_user_name`, `report_quantity`, `qualified_quantity`, `defect_quantity`, `report_time`, `remark`) VALUES (30,32,4,'赵六',2,0,0,'2026-10-24 10:25:50','');
/*!40000 ALTER TABLE `t_production_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_production_report_item`
--

DROP TABLE IF EXISTS `t_production_report_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_production_report_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '报工明细ID',
  `report_id` bigint NOT NULL COMMENT '报工ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `good_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '良品数量',
  `defective_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '不良数量',
  `defect_type` varchar(100) DEFAULT NULL COMMENT '缺陷类型',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产报工明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_production_report_item`
--

LOCK TABLES `t_production_report_item` WRITE;
/*!40000 ALTER TABLE `t_production_report_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_production_report_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_production_task`
--

DROP TABLE IF EXISTS `t_production_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_production_task` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '任务ID',
  `task_no` varchar(50) NOT NULL COMMENT '任务编号',
  `plan_id` bigint NOT NULL COMMENT '计划ID',
  `task_type` tinyint NOT NULL COMMENT '任务类型',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `quantity` int NOT NULL COMMENT '任务数量',
  `assigned_user_id` bigint DEFAULT NULL COMMENT '分配用户ID',
  `assigned_user_name` varchar(50) DEFAULT NULL COMMENT '分配用户姓名',
  `task_status` tinyint NOT NULL DEFAULT '0' COMMENT '任务状态',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_no` (`task_no`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='生产任务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_production_task`
--

LOCK TABLES `t_production_task` WRITE;
/*!40000 ALTER TABLE `t_production_task` DISABLE KEYS */;
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (2,'MO-1-10',8,1,6,'A100有线办公鼠标',100,4,'赵六',4,'2026-10-24 10:25:34','2026-10-24 10:25:34',NULL,'2026-10-24 10:25:31','2026-10-24 10:25:34');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (3,'MO-1-20',8,1,6,'A100有线办公鼠标',100,4,'赵六',4,'2026-10-24 10:25:34','2026-10-24 10:25:35',NULL,'2026-10-24 10:25:31','2026-10-24 10:25:34');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (4,'MO-1-30',8,1,6,'A100有线办公鼠标',100,4,'赵六',4,'2026-10-24 10:25:35','2026-10-24 10:25:35',NULL,'2026-10-24 10:25:31','2026-10-24 10:25:34');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (5,'MO-1-40',8,1,6,'A100有线办公鼠标',100,4,'赵六',4,'2026-10-24 10:25:35','2026-10-24 10:25:35',NULL,'2026-10-24 10:25:31','2026-10-24 10:25:34');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (6,'MO-2-10',9,1,6,'A100有线办公鼠标',6,4,'赵六',4,'2026-10-24 10:25:41','2026-10-24 10:25:41',NULL,'2026-10-24 10:25:38','2026-10-24 10:25:40');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (7,'MO-2-20',9,1,6,'A100有线办公鼠标',10,4,'赵六',4,'2026-10-24 10:25:41','2026-10-24 10:25:41',NULL,'2026-10-24 10:25:38','2026-10-24 10:25:40');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (8,'MO-2-30',9,1,6,'A100有线办公鼠标',10,4,'赵六',4,'2026-10-24 10:25:41','2026-10-24 10:25:41',NULL,'2026-10-24 10:25:38','2026-10-24 10:25:41');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (9,'MO-2-40',9,1,6,'A100有线办公鼠标',10,4,'赵六',4,'2026-10-24 10:25:41','2026-10-24 10:25:41',NULL,'2026-10-24 10:25:38','2026-10-24 10:25:41');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (10,'MO-3-10',10,1,8,'隔离A100电子组件',10,4,'赵六',4,'2026-10-24 10:25:39','2026-10-24 10:25:39',NULL,'2026-10-24 10:25:38','2026-10-24 10:25:39');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (11,'MO-4-10',11,1,7,'隔离A100结构组件',10,4,'赵六',4,'2026-10-24 10:25:40','2026-10-24 10:25:40',NULL,'2026-10-24 10:25:38','2026-10-24 10:25:39');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (12,'MO-2-10-S9252051d',9,1,6,'A100有线办公鼠标',4,4,'赵六',4,'2026-10-24 10:25:41','2026-10-24 10:25:41',NULL,'2026-10-24 10:25:38','2026-10-24 10:25:40');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (13,'MO-5-10',12,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 10:25:42','2026-10-24 10:25:42',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:42');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (14,'MO-5-20',12,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 10:25:43','2026-10-24 10:25:43',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:42');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (15,'MO-5-30',12,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 10:25:43','2026-10-24 10:25:43',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:42');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (16,'MO-5-40',12,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 10:25:43','2026-10-24 10:25:43',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:42');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (17,'MO-6-10',13,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 10:25:44','2026-10-24 10:25:44',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:43');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (18,'MO-6-20',13,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 10:25:44','2026-10-24 10:25:44',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:44');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (19,'MO-6-30',13,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 10:25:44','2026-10-24 10:25:44',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:44');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (20,'MO-6-40',13,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 10:25:44','2026-10-24 10:25:44',NULL,'2026-10-24 10:25:41','2026-10-24 10:25:44');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (21,'MO-7-10',14,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 10:25:47','2026-10-24 10:25:47',NULL,'2026-10-24 10:25:45','2026-10-24 10:25:46');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (22,'MO-7-20',14,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 10:25:47','2026-10-24 10:25:47',NULL,'2026-10-24 10:25:45','2026-10-24 10:25:46');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (23,'MO-7-30',14,1,6,'A100有线办公鼠标',1,4,'赵六',4,'2026-10-24 10:25:47','2026-10-24 10:25:47',NULL,'2026-10-24 10:25:45','2026-10-24 10:25:46');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (24,'MO-7-40',14,1,6,'A100有线办公鼠标',1,4,'赵六',5,'2026-10-24 10:25:47','2026-10-24 10:25:47',NULL,'2026-10-24 10:25:45','2026-10-24 10:25:47');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (25,'MO-8-10',15,1,6,'A100有线办公鼠标',1,4,'赵六',1,NULL,NULL,NULL,'2026-10-24 10:25:47','2026-10-24 10:25:47');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (26,'MO-8-20',15,1,6,'A100有线办公鼠标',1,4,'赵六',1,NULL,NULL,NULL,'2026-10-24 10:25:47','2026-10-24 10:25:47');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (27,'MO-8-30',15,1,6,'A100有线办公鼠标',1,4,'赵六',1,NULL,NULL,NULL,'2026-10-24 10:25:47','2026-10-24 10:25:47');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (28,'MO-8-40',15,1,6,'A100有线办公鼠标',1,4,'赵六',1,NULL,NULL,NULL,'2026-10-24 10:25:47','2026-10-24 10:25:47');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (29,'MO-9-10',16,1,6,'A100有线办公鼠标',2,4,'赵六',4,'2026-10-24 10:25:49','2026-10-24 10:25:49',NULL,'2026-10-24 10:25:47','2026-10-24 10:25:49');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (30,'MO-9-20',16,1,6,'A100有线办公鼠标',2,4,'赵六',4,'2026-10-24 10:25:49','2026-10-24 10:25:49',NULL,'2026-10-24 10:25:47','2026-10-24 10:25:49');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (31,'MO-9-30',16,1,6,'A100有线办公鼠标',2,4,'赵六',4,'2026-10-24 10:25:50','2026-10-24 10:25:50',NULL,'2026-10-24 10:25:47','2026-10-24 10:25:49');
INSERT INTO `t_production_task` (`id`, `task_no`, `plan_id`, `task_type`, `product_id`, `product_name`, `quantity`, `assigned_user_id`, `assigned_user_name`, `task_status`, `start_time`, `end_time`, `remark`, `create_time`, `update_time`) VALUES (32,'MO-9-40',16,1,6,'A100有线办公鼠标',2,4,'赵六',4,'2026-10-24 10:25:50','2026-10-24 10:25:50',NULL,'2026-10-24 10:25:47','2026-10-24 10:25:49');
/*!40000 ALTER TABLE `t_production_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_purchase_order`
--

DROP TABLE IF EXISTS `t_purchase_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_purchase_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '采购订单ID',
  `po_no` varchar(50) NOT NULL COMMENT '采购订单编号',
  `supplier_id` bigint NOT NULL COMMENT '供应商ID',
  `order_date` datetime DEFAULT NULL COMMENT '采购日期',
  `expected_date` datetime DEFAULT NULL COMMENT '预计到货日期',
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总金额',
  `status` varchar(30) NOT NULL DEFAULT 'DRAFT' COMMENT '状态：DRAFT/SUBMITTED/APPROVED/PARTIAL_RECEIVED/COMPLETED/CANCELLED',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  `sales_order_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `po_no` (`po_no`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='采购订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_purchase_order`
--

LOCK TABLES `t_purchase_order` WRITE;
/*!40000 ALTER TABLE `t_purchase_order` DISABLE KEYS */;
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (1,'MC-102528061580-MAIN',1,NULL,NULL,1600.00,'COMPLETED',NULL,NULL,'2026-10-24 10:25:31','2026-10-24 10:25:32',0,NULL);
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (2,'MC-102528061580-CONVERT',1,NULL,NULL,20.00,'COMPLETED',NULL,NULL,'2026-10-24 10:25:36','2026-10-24 10:25:36',0,NULL);
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (3,'MC-102528061580-WO-3',1,NULL,NULL,50.00,'COMPLETED',NULL,NULL,'2026-10-24 10:25:39','2026-10-24 10:25:38',0,NULL);
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (4,'MC-102528061580-WO-4',1,NULL,NULL,70.00,'COMPLETED',NULL,NULL,'2026-10-24 10:25:39','2026-10-24 10:25:39',0,NULL);
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (5,'MC-102528061580-WO-2',1,NULL,NULL,30.00,'COMPLETED',NULL,NULL,'2026-10-24 10:25:40','2026-10-24 10:25:40',0,NULL);
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (6,'MC-102528061580-WO-5',1,NULL,NULL,15.00,'COMPLETED',NULL,NULL,'2026-10-24 10:25:41','2026-10-24 10:25:42',0,NULL);
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (7,'MC-102528061580-WO-6',1,NULL,NULL,15.00,'COMPLETED',NULL,NULL,'2026-10-24 10:25:43','2026-10-24 10:25:43',0,NULL);
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (8,'MC-102528061580-RACE',1,NULL,NULL,2.00,'COMPLETED',NULL,NULL,'2026-10-24 10:25:45','2026-10-24 10:25:44',0,NULL);
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (9,'MC-102528061580-WO-7',1,NULL,NULL,15.00,'COMPLETED',NULL,NULL,'2026-10-24 10:25:46','2026-10-24 10:25:46',0,NULL);
INSERT INTO `t_purchase_order` (`id`, `po_no`, `supplier_id`, `order_date`, `expected_date`, `total_amount`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`, `sales_order_id`) VALUES (10,'MC-102528061580-WO-9',1,NULL,NULL,30.00,'COMPLETED',NULL,NULL,'2026-10-24 10:25:48','2026-10-24 10:25:48',0,NULL);
/*!40000 ALTER TABLE `t_purchase_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_purchase_order_item`
--

DROP TABLE IF EXISTS `t_purchase_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_purchase_order_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '采购订单明细ID',
  `po_id` bigint NOT NULL COMMENT '采购订单ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `quantity` decimal(10,2) NOT NULL COMMENT '采购数量',
  `unit_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '单价',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `received_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '已到货数量',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='采购订单明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_purchase_order_item`
--

LOCK TABLES `t_purchase_order_item` WRITE;
/*!40000 ALTER TABLE `t_purchase_order_item` DISABLE KEYS */;
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (1,1,2,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (2,1,3,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (3,1,4,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (4,1,5,200.00,1.00,200.00,200.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (5,1,6,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (6,1,7,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (7,1,8,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (8,1,9,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (9,1,10,400.00,1.00,400.00,400.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (10,1,11,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (11,1,12,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (12,1,13,100.00,1.00,100.00,100.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (13,2,2,20.00,1.00,20.00,20.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (14,3,4,10.00,1.00,10.00,10.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (15,3,5,20.00,1.00,20.00,20.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (16,3,6,10.00,1.00,10.00,10.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (17,3,7,10.00,1.00,10.00,10.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (18,4,3,10.00,1.00,10.00,10.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (19,4,8,10.00,1.00,10.00,10.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (20,4,9,10.00,1.00,10.00,10.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (21,4,10,40.00,1.00,40.00,40.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (22,5,11,10.00,1.00,10.00,10.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (23,5,12,10.00,1.00,10.00,10.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (24,5,13,10.00,1.00,10.00,10.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (25,6,3,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (26,6,4,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (27,6,5,2.00,1.00,2.00,2.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (28,6,6,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (29,6,7,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (30,6,8,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (31,6,9,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (32,6,10,4.00,1.00,4.00,4.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (33,6,11,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (34,6,12,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (35,6,13,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (36,7,3,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (37,7,4,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (38,7,5,2.00,1.00,2.00,2.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (39,7,6,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (40,7,7,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (41,7,8,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (42,7,9,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (43,7,10,4.00,1.00,4.00,4.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (44,7,11,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (45,7,12,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (46,7,13,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (47,8,2,2.00,1.00,2.00,2.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (48,9,3,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (49,9,4,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (50,9,5,2.00,1.00,2.00,2.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (51,9,6,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (52,9,7,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (53,9,8,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (54,9,9,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (55,9,10,4.00,1.00,4.00,4.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (56,9,11,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (57,9,12,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (58,9,13,1.00,1.00,1.00,1.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (59,10,3,2.00,1.00,2.00,2.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (60,10,4,2.00,1.00,2.00,2.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (61,10,5,4.00,1.00,4.00,4.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (62,10,6,2.00,1.00,2.00,2.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (63,10,7,2.00,1.00,2.00,2.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (64,10,8,2.00,1.00,2.00,2.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (65,10,9,2.00,1.00,2.00,2.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (66,10,10,8.00,1.00,8.00,8.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (67,10,11,2.00,1.00,2.00,2.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (68,10,12,2.00,1.00,2.00,2.00,NULL);
INSERT INTO `t_purchase_order_item` (`id`, `po_id`, `material_id`, `quantity`, `unit_price`, `amount`, `received_quantity`, `remark`) VALUES (69,10,13,2.00,1.00,2.00,2.00,NULL);
/*!40000 ALTER TABLE `t_purchase_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_qc_inspection`
--

DROP TABLE IF EXISTS `t_qc_inspection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_qc_inspection` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '质检单ID',
  `inspection_no` varchar(50) NOT NULL COMMENT '质检单号',
  `inspection_type` varchar(30) NOT NULL COMMENT '质检类型',
  `source_order_id` bigint DEFAULT NULL COMMENT '来源单ID',
  `source_order_no` varchar(80) DEFAULT NULL COMMENT '来源单号',
  `sample_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '抽检数量',
  `qualified_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '合格数量',
  `defective_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '不合格数量',
  `result` varchar(30) DEFAULT NULL COMMENT '质检结果',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  `qualified_rate` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '合格率',
  `defect_reason` varchar(500) DEFAULT NULL COMMENT '不合格原因',
  `handle_method` varchar(500) DEFAULT NULL COMMENT '处理方式',
  `business_status` varchar(50) DEFAULT NULL COMMENT '后续业务状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `inspection_no` (`inspection_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='质检检验单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_qc_inspection`
--

LOCK TABLES `t_qc_inspection` WRITE;
/*!40000 ALTER TABLE `t_qc_inspection` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_qc_inspection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_qc_inspection_item`
--

DROP TABLE IF EXISTS `t_qc_inspection_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_qc_inspection_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '质检明细ID',
  `inspection_id` bigint NOT NULL COMMENT '质检单ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_id` bigint DEFAULT NULL COMMENT '批次ID',
  `sample_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '抽检数量',
  `qualified_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '合格数量',
  `defective_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '不合格数量',
  `defect_type` varchar(100) DEFAULT NULL COMMENT '缺陷类型',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `inspection_item` varchar(100) NOT NULL COMMENT '检测项',
  `inspection_standard` varchar(500) DEFAULT NULL COMMENT '检测标准',
  `actual_value` varchar(500) DEFAULT NULL COMMENT '实测值',
  `item_result` varchar(30) DEFAULT NULL COMMENT '明细结果',
  `defect_reason` varchar(500) DEFAULT NULL COMMENT '不合格原因',
  `handle_method` varchar(500) DEFAULT NULL COMMENT '处理方式',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='质检检验明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_qc_inspection_item`
--

LOCK TABLES `t_qc_inspection_item` WRITE;
/*!40000 ALTER TABLE `t_qc_inspection_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_qc_inspection_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_quality_check`
--

DROP TABLE IF EXISTS `t_quality_check`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_quality_check` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '质检记录ID',
  `check_no` varchar(50) NOT NULL COMMENT '质检单号',
  `task_id` bigint DEFAULT NULL COMMENT '任务ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `check_quantity` int NOT NULL COMMENT '质检数量',
  `qualified_quantity` int NOT NULL COMMENT '合格数量',
  `defect_quantity` int NOT NULL COMMENT '不合格数量',
  `qualified_rate` decimal(5,2) NOT NULL COMMENT '合格率',
  `check_result` tinyint NOT NULL COMMENT '质检结果',
  `checker_id` bigint NOT NULL COMMENT '质检员ID',
  `checker_name` varchar(50) NOT NULL COMMENT '质检员姓名',
  `check_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '质检时间',
  `defect_desc` text COMMENT '缺陷描述',
  `handle_result` varchar(500) DEFAULT NULL COMMENT '处理结果',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `check_no` (`check_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='质检记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_quality_check`
--

LOCK TABLES `t_quality_check` WRITE;
/*!40000 ALTER TABLE `t_quality_check` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_quality_check` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_quality_standard`
--

DROP TABLE IF EXISTS `t_quality_standard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_quality_standard` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '质检标准ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `standard_name` varchar(100) NOT NULL COMMENT '标准名称',
  `standard_content` text NOT NULL COMMENT '标准内容',
  `qualified_threshold` decimal(5,2) DEFAULT NULL COMMENT '合格阈值',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0禁用 1启用',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='质检标准表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_quality_standard`
--

LOCK TABLES `t_quality_standard` WRITE;
/*!40000 ALTER TABLE `t_quality_standard` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_quality_standard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_role`
--

DROP TABLE IF EXISTS `t_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_role` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `role_code` varchar(10) NOT NULL COMMENT '角色编码',
  `role_name` varchar(50) NOT NULL COMMENT '角色名称',
  `role_desc` varchar(255) DEFAULT NULL COMMENT '角色描述',
  `sort` int NOT NULL DEFAULT '0' COMMENT '显示顺序',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0禁用 1启用',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_code` (`role_code`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='角色表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_role`
--

LOCK TABLES `t_role` WRITE;
/*!40000 ALTER TABLE `t_role` DISABLE KEYS */;
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (1,'101','生产经理','负责生产计划制定、任务分配和进度跟踪',1,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (2,'102','车间主任','负责车间日常管理和生产调度',2,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (3,'103','操作工','负责生产线操作和产品加工',3,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (4,'104','质检员','负责产品质量检测和质量标准执行',4,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (5,'105','仓管员','负责物料出入库管理和库存盘点',5,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (6,'106','采购专员','负责原材料采购和供应商管理',6,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (7,'107','销售专员','负责客户订单对接和销售业务',7,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (8,'108','设备管理员','负责设备管理和维修',8,1,'2026-07-15 10:21:37','2026-07-17 13:19:03');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (9,'109','CEO','公司最高管理者，拥有系统全部权限',9,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (10,'110','CFO','财务总监，负责公司利润、收入和支出管理',10,1,'2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_role` (`id`, `role_code`, `role_name`, `role_desc`, `sort`, `status`, `create_time`, `update_time`) VALUES (11,'111','系统管理员','系统配置与运行维护',11,1,'2026-10-24 10:18:02','2026-10-24 10:18:02');
/*!40000 ALTER TABLE `t_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_sales_order`
--

DROP TABLE IF EXISTS `t_sales_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_sales_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '销售订单ID',
  `so_no` varchar(50) NOT NULL COMMENT '销售订单编号',
  `customer_id` bigint NOT NULL COMMENT '客户ID',
  `order_date` datetime DEFAULT NULL COMMENT '下单日期',
  `delivery_date` datetime DEFAULT NULL COMMENT '交付日期',
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总金额',
  `status` varchar(30) NOT NULL DEFAULT 'DRAFT' COMMENT '状态',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `so_no` (`so_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='销售订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_sales_order`
--

LOCK TABLES `t_sales_order` WRITE;
/*!40000 ALTER TABLE `t_sales_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_sales_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_sales_order_item`
--

DROP TABLE IF EXISTS `t_sales_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_sales_order_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '销售订单明细ID',
  `so_id` bigint NOT NULL COMMENT '销售订单ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `quantity` decimal(10,2) NOT NULL COMMENT '数量',
  `unit_price` decimal(10,2) NOT NULL COMMENT '单价',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='销售订单明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_sales_order_item`
--

LOCK TABLES `t_sales_order_item` WRITE;
/*!40000 ALTER TABLE `t_sales_order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_sales_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_stock_in`
--

DROP TABLE IF EXISTS `t_stock_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_stock_in` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '通用入库单ID',
  `stock_in_no` varchar(80) NOT NULL COMMENT '入库单号',
  `stock_in_type` varchar(30) NOT NULL COMMENT '入库类型',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `source_order_id` bigint DEFAULT NULL COMMENT '来源订单ID',
  `source_order_no` varchar(80) DEFAULT NULL COMMENT '来源订单编号',
  `total_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总数量',
  `status` varchar(30) NOT NULL DEFAULT 'PENDING' COMMENT '状态',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_in_no` (`stock_in_no`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通用入库单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_stock_in`
--

LOCK TABLES `t_stock_in` WRITE;
/*!40000 ALTER TABLE `t_stock_in` DISABLE KEYS */;
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (1,'PR-000001','PURCHASE_RECEIPT',2,1,'PR-000001',800.00,'COMPLETED',NULL,6,'2026-10-24 10:25:32','2026-10-24 10:25:32',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (2,'PR-000002','PURCHASE_RECEIPT',2,1,'PR-000002',800.00,'COMPLETED',NULL,6,'2026-10-24 10:25:33','2026-10-24 10:25:33',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (3,'L-RET-000001','LINE_RETURN',2,1,'L-RET-000001',40.00,'COMPLETED',NULL,6,'2026-10-24 10:25:34','2026-10-24 10:25:34',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (4,'FG-IN-000001','PRODUCTION_RECEIPT',4,1,'FG-IN-000001',40.00,'COMPLETED',NULL,6,'2026-10-24 10:25:35','2026-10-24 10:25:35',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (5,'FG-IN-000002','PRODUCTION_RECEIPT',4,1,'FG-IN-000002',60.00,'COMPLETED',NULL,6,'2026-10-24 10:25:35','2026-10-24 10:25:35',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (6,'S-RET-000001','SALES_RETURN',4,5,'S-RET-000001',10.00,'COMPLETED',NULL,6,'2026-10-24 10:25:36','2026-10-24 10:25:36',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (7,'PR-000003','PURCHASE_RECEIPT',2,2,'PR-000003',20.00,'COMPLETED',NULL,6,'2026-10-24 10:25:37','2026-10-24 10:25:37',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (8,'PR-000004','PURCHASE_RECEIPT',2,3,'PR-000004',50.00,'COMPLETED',NULL,6,'2026-10-24 10:25:39','2026-10-24 10:25:39',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (9,'FG-IN-000003','PRODUCTION_RECEIPT',4,3,'MO-000005',10.00,'COMPLETED',NULL,6,'2026-10-24 10:25:39','2026-10-24 10:25:39',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (10,'PR-000005','PURCHASE_RECEIPT',2,4,'PR-000005',70.00,'COMPLETED',NULL,6,'2026-10-24 10:25:40','2026-10-24 10:25:40',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (11,'FG-IN-000004','PRODUCTION_RECEIPT',4,4,'MO-000007',10.00,'COMPLETED',NULL,6,'2026-10-24 10:25:40','2026-10-24 10:25:40',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (12,'PR-000006','PURCHASE_RECEIPT',2,5,'PR-000006',30.00,'COMPLETED',NULL,6,'2026-10-24 10:25:40','2026-10-24 10:25:40',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (13,'FG-IN-000005','PRODUCTION_RECEIPT',4,2,'MO-000003',10.00,'COMPLETED',NULL,6,'2026-10-24 10:25:41','2026-10-24 10:25:41',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (14,'PR-000007','PURCHASE_RECEIPT',2,6,'PR-000007',15.00,'COMPLETED',NULL,6,'2026-10-24 10:25:42','2026-10-24 10:25:42',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (15,'FG-IN-000006','PRODUCTION_RECEIPT',4,5,'MO-000009',1.00,'COMPLETED',NULL,6,'2026-10-24 10:25:43','2026-10-24 10:25:43',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (16,'PR-000008','PURCHASE_RECEIPT',2,7,'PR-000008',15.00,'COMPLETED',NULL,6,'2026-10-24 10:25:43','2026-10-24 10:25:43',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (17,'FG-IN-000007','PRODUCTION_RECEIPT',4,6,'MO-000011',1.00,'COMPLETED',NULL,6,'2026-10-24 10:25:44','2026-10-24 10:25:44',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (18,'PR-000009','PURCHASE_RECEIPT',2,8,'PR-000009',2.00,'COMPLETED',NULL,6,'2026-10-24 10:25:45','2026-10-24 10:25:45',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (19,'PR-000010','PURCHASE_RECEIPT',2,9,'PR-000010',15.00,'COMPLETED',NULL,6,'2026-10-24 10:25:46','2026-10-24 10:25:46',0);
INSERT INTO `t_stock_in` (`id`, `stock_in_no`, `stock_in_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (20,'PR-000011','PURCHASE_RECEIPT',2,10,'PR-000011',30.00,'COMPLETED',NULL,6,'2026-10-24 10:25:48','2026-10-24 10:25:48',0);
/*!40000 ALTER TABLE `t_stock_in` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_stock_in_item`
--

DROP TABLE IF EXISTS `t_stock_in_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_stock_in_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '通用入库明细ID',
  `stock_in_id` bigint NOT NULL COMMENT '入库单ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_id` bigint DEFAULT NULL COMMENT '批次ID',
  `quantity` decimal(10,2) NOT NULL COMMENT '数量',
  `location_id` bigint DEFAULT NULL COMMENT '库位ID',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通用入库明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_stock_in_item`
--

LOCK TABLES `t_stock_in_item` WRITE;
/*!40000 ALTER TABLE `t_stock_in_item` DISABLE KEYS */;
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (1,1,2,1,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (2,1,3,2,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (3,1,4,3,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (4,1,5,4,100.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (5,1,6,5,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (6,1,7,6,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (7,1,8,7,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (8,1,9,8,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (9,1,10,9,200.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (10,1,11,10,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (11,1,12,11,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (12,1,13,12,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (13,2,2,13,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (14,2,3,14,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (15,2,4,15,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (16,2,5,16,100.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (17,2,6,17,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (18,2,7,18,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (19,2,8,19,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (20,2,9,20,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (21,2,10,21,200.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (22,2,11,22,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (23,2,12,23,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (24,2,13,24,50.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (25,3,2,13,40.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (26,4,16,25,40.00,4,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (27,5,16,25,60.00,4,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (28,6,16,25,10.00,4,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (29,7,2,26,20.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (30,8,4,27,10.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (31,8,5,28,20.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (32,8,6,29,10.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (33,8,7,30,10.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (34,9,14,31,10.00,4,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (35,10,3,32,10.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (36,10,8,33,10.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (37,10,9,34,10.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (38,10,10,35,40.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (39,11,15,36,10.00,4,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (40,12,11,37,10.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (41,12,12,38,10.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (42,12,13,39,10.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (43,13,16,40,10.00,4,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (44,14,3,41,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (45,14,4,42,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (46,14,5,43,2.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (47,14,6,44,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (48,14,7,45,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (49,14,8,46,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (50,14,9,47,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (51,14,10,48,4.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (52,14,11,49,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (53,14,12,50,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (54,14,13,51,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (55,15,16,52,1.00,4,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (56,16,3,53,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (57,16,4,54,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (58,16,5,55,2.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (59,16,6,56,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (60,16,7,57,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (61,16,8,58,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (62,16,9,59,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (63,16,10,60,4.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (64,16,11,61,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (65,16,12,62,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (66,16,13,63,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (67,17,16,64,1.00,4,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (68,18,2,65,2.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (69,19,3,66,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (70,19,4,67,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (71,19,5,68,2.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (72,19,6,69,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (73,19,7,70,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (74,19,8,71,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (75,19,9,72,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (76,19,10,73,4.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (77,19,11,74,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (78,19,12,75,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (79,19,13,76,1.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (80,20,3,78,2.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (81,20,4,79,2.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (82,20,5,80,4.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (83,20,6,81,2.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (84,20,7,82,2.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (85,20,8,83,2.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (86,20,9,84,2.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (87,20,10,85,8.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (88,20,11,86,2.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (89,20,12,87,2.00,2,NULL);
INSERT INTO `t_stock_in_item` (`id`, `stock_in_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (90,20,13,88,2.00,2,NULL);
/*!40000 ALTER TABLE `t_stock_in_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_stock_out`
--

DROP TABLE IF EXISTS `t_stock_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_stock_out` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '通用出库单ID',
  `stock_out_no` varchar(80) NOT NULL COMMENT '出库单号',
  `stock_out_type` varchar(30) NOT NULL COMMENT '出库类型',
  `warehouse_id` bigint NOT NULL COMMENT '仓库ID',
  `source_order_id` bigint DEFAULT NULL COMMENT '来源订单ID',
  `source_order_no` varchar(80) DEFAULT NULL COMMENT '来源订单编号',
  `total_quantity` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总数量',
  `status` varchar(30) NOT NULL DEFAULT 'PENDING' COMMENT '状态',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_out_no` (`stock_out_no`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通用出库单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_stock_out`
--

LOCK TABLES `t_stock_out` WRITE;
/*!40000 ALTER TABLE `t_stock_out` DISABLE KEYS */;
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (1,'ISS-000001','PRODUCTION_ISSUE',2,1,'MO-000001',1600.00,'COMPLETED',NULL,6,'2026-10-24 10:25:33','2026-10-24 10:25:33',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (2,'ISS-000002','LINE_ISSUE',2,1,'ISS-000002',40.00,'COMPLETED',NULL,6,'2026-10-24 10:25:34','2026-10-24 10:25:34',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (3,'SHIP-000001','SALES_SHIPMENT',4,5,'SHIP-000001',40.00,'COMPLETED',NULL,6,'2026-10-24 10:25:35','2026-10-24 10:25:35',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (4,'SHIP-000002','SALES_SHIPMENT',4,5,'SHIP-000002',60.00,'COMPLETED',NULL,6,'2026-10-24 10:25:36','2026-10-24 10:25:36',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (5,'P-RET-000001','PURCHASE_RETURN',2,2,'P-RET-000001',5.00,'COMPLETED',NULL,6,'2026-10-24 10:25:37','2026-10-24 10:25:37',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (6,'ISS-000003','LINE_ISSUE',2,3,'ISS-000003',50.00,'COMPLETED',NULL,6,'2026-10-24 10:25:39','2026-10-24 10:25:39',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (7,'ISS-000004','LINE_ISSUE',2,4,'ISS-000004',80.00,'COMPLETED',NULL,6,'2026-10-24 10:25:40','2026-10-24 10:25:40',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (8,'ISS-000005','LINE_ISSUE',2,2,'ISS-000005',30.00,'COMPLETED',NULL,6,'2026-10-24 10:25:40','2026-10-24 10:25:40',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (9,'ISS-000006','LINE_ISSUE',4,2,'ISS-000006',20.00,'COMPLETED',NULL,6,'2026-10-24 10:25:41','2026-10-24 10:25:41',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (10,'ISS-000007','LINE_ISSUE',2,5,'ISS-000007',16.00,'COMPLETED',NULL,6,'2026-10-24 10:25:42','2026-10-24 10:25:42',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (11,'ISS-000008','LINE_ISSUE',2,6,'ISS-000008',16.00,'COMPLETED',NULL,6,'2026-10-24 10:25:44','2026-10-24 10:25:44',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (12,'SHIP-000003','SALES_SHIPMENT',4,6,'SHIP-000003',2.00,'COMPLETED',NULL,6,'2026-10-24 10:25:45','2026-10-24 10:25:45',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (13,'P-RET-000002','PURCHASE_RETURN',2,8,'P-RET-000002',1.00,'COMPLETED',NULL,6,'2026-10-24 10:25:45','2026-10-24 10:25:45',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (14,'ISS-000009','LINE_ISSUE',2,7,'ISS-000009',16.00,'COMPLETED',NULL,6,'2026-10-24 10:25:46','2026-10-24 10:25:46',0);
INSERT INTO `t_stock_out` (`id`, `stock_out_no`, `stock_out_type`, `warehouse_id`, `source_order_id`, `source_order_no`, `total_quantity`, `status`, `remark`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (15,'ISS-000010','LINE_ISSUE',2,9,'ISS-000010',32.00,'COMPLETED',NULL,6,'2026-10-24 10:25:49','2026-10-24 10:25:49',0);
/*!40000 ALTER TABLE `t_stock_out` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_stock_out_item`
--

DROP TABLE IF EXISTS `t_stock_out_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_stock_out_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '通用出库明细ID',
  `stock_out_id` bigint NOT NULL COMMENT '出库单ID',
  `material_id` bigint NOT NULL COMMENT '物料ID',
  `lot_id` bigint DEFAULT NULL COMMENT '批次ID',
  `quantity` decimal(10,2) NOT NULL COMMENT '数量',
  `location_id` bigint DEFAULT NULL COMMENT '库位ID',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通用出库明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_stock_out_item`
--

LOCK TABLES `t_stock_out_item` WRITE;
/*!40000 ALTER TABLE `t_stock_out_item` DISABLE KEYS */;
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (1,1,2,1,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (2,1,2,13,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (3,1,3,2,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (4,1,3,14,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (5,1,4,3,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (6,1,4,15,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (7,1,5,4,100.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (8,1,5,16,100.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (9,1,6,5,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (10,1,6,17,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (11,1,7,6,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (12,1,7,18,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (13,1,8,7,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (14,1,8,19,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (15,1,9,8,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (16,1,9,20,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (17,1,10,9,200.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (18,1,10,21,200.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (19,1,11,10,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (20,1,11,22,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (21,1,12,11,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (22,1,12,23,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (23,1,13,12,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (24,1,13,24,50.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (25,2,2,13,40.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (26,3,16,25,40.00,4,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (27,4,16,25,60.00,4,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (28,5,2,26,5.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (29,6,4,27,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (30,6,5,28,20.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (31,6,6,29,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (32,6,7,30,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (33,7,2,26,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (34,7,3,32,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (35,7,8,33,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (36,7,9,34,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (37,7,10,35,40.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (38,8,11,37,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (39,8,12,38,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (40,8,13,39,10.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (41,9,14,31,10.00,4,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (42,9,15,36,10.00,4,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (43,10,2,26,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (44,10,3,41,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (45,10,4,42,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (46,10,5,43,2.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (47,10,6,44,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (48,10,7,45,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (49,10,8,46,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (50,10,9,47,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (51,10,10,48,4.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (52,10,11,49,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (53,10,12,50,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (54,10,13,51,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (55,11,2,26,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (56,11,3,53,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (57,11,4,54,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (58,11,5,55,2.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (59,11,6,56,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (60,11,7,57,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (61,11,8,58,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (62,11,9,59,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (63,11,10,60,4.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (64,11,11,61,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (65,11,12,62,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (66,11,13,63,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (67,12,16,52,1.00,4,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (68,12,16,64,1.00,4,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (69,13,2,65,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (70,14,2,26,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (71,14,3,66,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (72,14,4,67,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (73,14,5,68,2.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (74,14,6,69,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (75,14,7,70,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (76,14,8,71,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (77,14,9,72,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (78,14,10,73,4.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (79,14,11,74,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (80,14,12,75,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (81,14,13,76,1.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (82,15,2,26,2.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (83,15,3,78,2.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (84,15,4,79,2.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (85,15,5,80,4.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (86,15,6,81,2.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (87,15,7,82,2.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (88,15,8,83,2.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (89,15,9,84,2.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (90,15,10,85,8.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (91,15,11,86,2.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (92,15,12,87,2.00,2,NULL);
INSERT INTO `t_stock_out_item` (`id`, `stock_out_id`, `material_id`, `lot_id`, `quantity`, `location_id`, `remark`) VALUES (93,15,13,88,2.00,2,NULL);
/*!40000 ALTER TABLE `t_stock_out_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_supplier`
--

DROP TABLE IF EXISTS `t_supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_supplier` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '供应商ID',
  `supplier_code` varchar(50) NOT NULL COMMENT '供应商编码',
  `supplier_name` varchar(100) NOT NULL COMMENT '供应商名称',
  `contact_person` varchar(50) DEFAULT NULL COMMENT '联系人',
  `contact_phone` varchar(20) DEFAULT NULL COMMENT '联系电话',
  `address` varchar(255) DEFAULT NULL COMMENT '地址',
  `bank_name` varchar(100) DEFAULT NULL COMMENT '开户银行',
  `bank_account` varchar(50) DEFAULT NULL COMMENT '银行账号',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：-1删除 0禁用 1活跃',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_code` (`supplier_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='供应商表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_supplier`
--

LOCK TABLES `t_supplier` WRITE;
/*!40000 ALTER TABLE `t_supplier` DISABLE KEYS */;
INSERT INTO `t_supplier` (`id`, `supplier_code`, `supplier_name`, `contact_person`, `contact_phone`, `address`, `bank_name`, `bank_account`, `status`, `remark`, `create_time`, `update_time`) VALUES (1,'MC-SUP-102528061580','隔离供应商',NULL,NULL,NULL,NULL,NULL,1,NULL,'2026-10-24 10:25:31','2026-10-24 10:25:31');
/*!40000 ALTER TABLE `t_supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_uom`
--

DROP TABLE IF EXISTS `t_uom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_uom` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '计量单位ID',
  `uom_code` varchar(50) NOT NULL COMMENT '单位编码',
  `uom_name` varchar(100) NOT NULL COMMENT '单位名称',
  `status` varchar(30) NOT NULL DEFAULT '1' COMMENT '状态',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  `main_unit_id` bigint DEFAULT NULL,
  `conversion_rate` decimal(18,6) NOT NULL DEFAULT '1.000000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uom_code` (`uom_code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='计量单位表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_uom`
--

LOCK TABLES `t_uom` WRITE;
/*!40000 ALTER TABLE `t_uom` DISABLE KEYS */;
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (1,'S1-U1','只','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,1.000000);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (2,'S1-U2','个','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,1.000000);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (3,'S1-U3','块','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,1.000000);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (4,'S1-U4','根','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,1.000000);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (5,'S1-U5','颗','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,1.000000);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (6,'S1-U6','套','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,1.000000);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (7,'S1-U7','张','ACTIVE','2026-10-19 08:41:54','2026-10-19 08:41:54',0,NULL,1.000000);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (8,'MC-U-102528061580','测试主单位102528061580','ACTIVE','2026-10-24 10:25:30','2026-10-24 10:25:30',0,NULL,1.000000);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (9,'MC-A-102528061580','测试辅单位102528061580','ACTIVE','2026-10-24 10:25:30','2026-10-24 10:25:30',0,8,20.000000);
INSERT INTO `t_uom` (`id`, `uom_code`, `uom_name`, `status`, `created_at`, `updated_at`, `is_deleted`, `main_unit_id`, `conversion_rate`) VALUES (10,'MC-BOX-102528061580','验收箱102528061580','ACTIVE','2026-10-24 10:25:36','2026-10-24 10:25:36',0,2,10.000000);
/*!40000 ALTER TABLE `t_uom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_user` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `user_code` varchar(6) NOT NULL COMMENT '6位用户编码',
  `username` varchar(50) NOT NULL COMMENT '登录账号',
  `password` varchar(255) NOT NULL COMMENT '登录密码',
  `real_name` varchar(50) DEFAULT NULL COMMENT '真实姓名',
  `phone` varchar(20) DEFAULT NULL COMMENT '手机号',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `gender` tinyint DEFAULT NULL COMMENT '性别：0女 1男',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像',
  `role_id` int NOT NULL COMMENT '角色ID',
  `dept_id` bigint DEFAULT NULL COMMENT '部门ID',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0离职 1在职 2试用期',
  `entry_date` date DEFAULT NULL COMMENT '入职日期',
  `leave_date` date DEFAULT NULL COMMENT '离职日期',
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(50) DEFAULT NULL COMMENT '最后登录IP',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除：0未删除 1已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_code` (`user_code`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user`
--

LOCK TABLES `t_user` WRITE;
/*!40000 ALTER TABLE `t_user` DISABLE KEYS */;
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (1,'109001','admin','','张三','13800138001','zhangsan@mouse.com',1,NULL,9,1,1,NULL,NULL,'2026-10-24 10:25:28','127.0.0.1','2026-07-15 10:21:37','2026-10-24 10:25:28',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (2,'101001','prod_manager','','李四','13800138002','lisi@mouse.com',1,NULL,1,2,1,NULL,NULL,'2026-10-18 15:23:26','127.0.0.1','2026-07-15 10:21:37','2026-10-18 15:23:26',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (3,'102001','workshop_manager','','王五','13800138003','wangwu@mouse.com',1,NULL,2,2,1,NULL,NULL,NULL,NULL,'2026-07-15 10:21:37','2026-07-15 10:21:37',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (4,'103001','worker1','','赵六','13800138004','zhaoliu@mouse.com',1,NULL,3,2,1,NULL,NULL,'2026-10-24 10:25:29','127.0.0.1','2026-07-15 10:21:37','2026-10-24 10:25:28',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (5,'104001','qc_manager','','周八','13800138006','zhouba@mouse.com',1,NULL,4,3,1,NULL,NULL,'2026-10-24 10:25:29','127.0.0.1','2026-07-15 10:21:37','2026-10-24 10:25:28',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (6,'105001','warehouse_manager','','吴九','13800138007','wujiu@mouse.com',1,NULL,5,4,1,NULL,NULL,'2026-10-24 10:25:29','127.0.0.1','2026-07-15 10:21:37','2026-10-24 10:25:28',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (7,'106001','purchase_manager','','郑十','13800138008','zhengshi@mouse.com',1,NULL,6,5,1,NULL,NULL,'2026-10-24 10:25:29','127.0.0.1','2026-07-15 10:21:37','2026-10-24 10:25:28',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (8,'107001','sales_manager','','陈十一','13800138009','chenshiyi@mouse.com',1,NULL,7,6,1,NULL,NULL,'2026-10-24 10:25:29','127.0.0.1','2026-07-15 10:21:37','2026-10-24 10:25:28',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (9,'108001','equipment_manager','','黄十二','13800138010','huangshier@mouse.com',1,NULL,8,7,1,NULL,NULL,'2026-10-24 10:25:29','127.0.0.1','2026-07-15 10:21:37','2026-10-24 10:25:28',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (10,'110001','cfo','','钱十三','13800138011','qianshisan@mouse.com',1,NULL,10,8,1,NULL,NULL,NULL,NULL,'2026-07-15 10:21:37','2026-07-15 10:21:37',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (11,'111001','mcadmin','','隔离系统管理员',NULL,NULL,NULL,NULL,11,1,1,NULL,NULL,'2026-10-24 10:25:29','127.0.0.1','2026-10-24 10:25:28','2026-10-24 10:25:28',0);
INSERT INTO `t_user` (`id`, `user_code`, `username`, `password`, `real_name`, `phone`, `email`, `gender`, `avatar`, `role_id`, `dept_id`, `status`, `entry_date`, `leave_date`, `last_login_time`, `last_login_ip`, `create_time`, `update_time`, `deleted`) VALUES (12,'103999','mcworker2','','隔离第二操作工',NULL,NULL,NULL,NULL,3,1,1,NULL,NULL,NULL,NULL,'2026-10-24 10:25:37','2026-10-24 10:25:37',0);
/*!40000 ALTER TABLE `t_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user_role`
--

DROP TABLE IF EXISTS `t_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_user_role` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户角色关系ID',
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `role_id` bigint NOT NULL COMMENT '角色ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户角色关系表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user_role`
--

LOCK TABLES `t_user_role` WRITE;
/*!40000 ALTER TABLE `t_user_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_warehouse`
--

DROP TABLE IF EXISTS `t_warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_warehouse` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '仓库ID',
  `warehouse_code` varchar(50) NOT NULL COMMENT '仓库编码',
  `warehouse_name` varchar(100) NOT NULL COMMENT '仓库名称',
  `location` varchar(255) DEFAULT NULL COMMENT '仓库位置',
  `manager_id` bigint DEFAULT NULL COMMENT '仓管员ID',
  `manager_name` varchar(50) DEFAULT NULL COMMENT '仓管员姓名',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态：0禁用 1启用',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `warehouse_code` (`warehouse_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='仓库表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_warehouse`
--

LOCK TABLES `t_warehouse` WRITE;
/*!40000 ALTER TABLE `t_warehouse` DISABLE KEYS */;
INSERT INTO `t_warehouse` (`id`, `warehouse_code`, `warehouse_name`, `location`, `manager_id`, `manager_name`, `status`, `remark`, `create_time`, `update_time`) VALUES (1,'WH-001','默认仓库','默认库区',NULL,NULL,1,'系统初始化仓库','2026-07-15 10:21:37','2026-07-15 10:21:37');
INSERT INTO `t_warehouse` (`id`, `warehouse_code`, `warehouse_name`, `location`, `manager_id`, `manager_name`, `status`, `remark`, `create_time`, `update_time`) VALUES (2,'WH-A100-RM','A100原料仓',NULL,NULL,NULL,1,NULL,'2026-10-19 08:41:54','2026-10-19 08:41:54');
INSERT INTO `t_warehouse` (`id`, `warehouse_code`, `warehouse_name`, `location`, `manager_id`, `manager_name`, `status`, `remark`, `create_time`, `update_time`) VALUES (3,'WH-A100-LINE','A100线边库',NULL,NULL,NULL,1,NULL,'2026-10-19 08:41:54','2026-10-19 08:41:54');
INSERT INTO `t_warehouse` (`id`, `warehouse_code`, `warehouse_name`, `location`, `manager_id`, `manager_name`, `status`, `remark`, `create_time`, `update_time`) VALUES (4,'WH-A100-FG','A100成品仓',NULL,NULL,NULL,1,NULL,'2026-10-19 08:41:54','2026-10-19 08:41:54');
/*!40000 ALTER TABLE `t_warehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_work_order`
--

DROP TABLE IF EXISTS `t_work_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_work_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '工单ID',
  `wo_no` varchar(50) NOT NULL COMMENT '工单编号',
  `production_order_id` bigint NOT NULL COMMENT '生产订单ID',
  `product_id` bigint NOT NULL COMMENT '产品ID',
  `planned_quantity` decimal(10,2) NOT NULL COMMENT '计划数量',
  `actual_quantity` decimal(10,2) DEFAULT '0.00' COMMENT '实际数量',
  `planned_start_date` datetime DEFAULT NULL COMMENT '计划开始时间',
  `planned_end_date` datetime DEFAULT NULL COMMENT '计划结束时间',
  `actual_start_date` datetime DEFAULT NULL COMMENT '实际开始时间',
  `actual_end_date` datetime DEFAULT NULL COMMENT '实际结束时间',
  `status` varchar(30) NOT NULL DEFAULT 'PLANNED' COMMENT '状态',
  `department_id` bigint DEFAULT NULL COMMENT '部门ID',
  `assigned_user_id` bigint DEFAULT NULL COMMENT '分配员工ID',
  `assigned_user_name` varchar(50) DEFAULT NULL COMMENT '分配员工姓名',
  `created_by` bigint DEFAULT NULL COMMENT '创建人ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `wo_no` (`wo_no`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='工单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_work_order`
--

LOCK TABLES `t_work_order` WRITE;
/*!40000 ALTER TABLE `t_work_order` DISABLE KEYS */;
INSERT INTO `t_work_order` (`id`, `wo_no`, `production_order_id`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `assigned_user_id`, `assigned_user_name`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (1,'WO-20260715001',1,1,100.00,0.00,'2026-07-15 08:00:00','2026-07-18 18:00:00','2026-07-17 14:47:24','2026-07-17 14:42:07','IN_PROGRESS',2,NULL,NULL,2,'2026-07-15 10:24:22','2026-07-17 14:47:24',0);
INSERT INTO `t_work_order` (`id`, `wo_no`, `production_order_id`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `assigned_user_id`, `assigned_user_name`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (2,'WO-20260715002',1,2,100.00,0.00,'2026-07-19 08:00:00','2026-07-22 18:00:00',NULL,NULL,'ASSIGNED',2,NULL,NULL,2,'2026-07-15 10:24:22','2026-07-17 14:03:01',0);
INSERT INTO `t_work_order` (`id`, `wo_no`, `production_order_id`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `assigned_user_id`, `assigned_user_name`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (3,'WO-20260715003',2,3,50.00,0.00,'2026-07-16 08:00:00','2026-07-20 18:00:00',NULL,NULL,'PLANNED',2,NULL,NULL,2,'2026-07-15 10:24:22','2026-07-17 14:03:01',0);
INSERT INTO `t_work_order` (`id`, `wo_no`, `production_order_id`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `assigned_user_id`, `assigned_user_name`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (4,'WO-20260717001',1,4,200.00,0.00,NULL,NULL,NULL,NULL,'PLANNED',2,NULL,NULL,2,'2026-07-17 14:03:01','2026-07-17 14:03:01',0);
INSERT INTO `t_work_order` (`id`, `wo_no`, `production_order_id`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `assigned_user_id`, `assigned_user_name`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (5,'WO-20260717002',2,2,150.00,0.00,NULL,NULL,NULL,NULL,'ASSIGNED',2,NULL,NULL,2,'2026-07-17 14:03:01','2026-07-17 14:41:13',0);
INSERT INTO `t_work_order` (`id`, `wo_no`, `production_order_id`, `product_id`, `planned_quantity`, `actual_quantity`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `department_id`, `assigned_user_id`, `assigned_user_name`, `created_by`, `created_at`, `updated_at`, `is_deleted`) VALUES (6,'WO-20260717003',3,5,80.00,0.00,NULL,NULL,NULL,NULL,'ASSIGNED',2,NULL,NULL,2,'2026-07-17 14:03:01','2026-07-17 14:03:01',0);
/*!40000 ALTER TABLE `t_work_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'mouse_mes_completion_test_20261024_102513'
--

--
-- Dumping routines for database 'mouse_mes_completion_test_20261024_102513'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-01  8:18:16
